//*******************************************************
// PieProgCtrl.cpp : source file
//
// Written by Mukesh Gupta (mukesh_ind@hotmail.com)
// Copyright (c) 2000.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. If 
// the source code in  this file is used in any commercial application 
// then a simple email would be nice.
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage whatsoever.
//
//*******************************************************


// PieProgCtrl.cpp : Implementation of CPieProgCtrl

#include "stdafx.h"
#include "PieProgressCtrl.h"
#include "math.h"
#include "PieProgCtrl.h"
#include "ocidl.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// CPieProgCtrl

const double  PI     = 3.14159265358979;
const double  TWO_PI = PI * 2;

CPieProgCtrl::CPieProgCtrl()
{
	Init();

	//stock properties
	m_clrBackColor  = ::GetSysColor(COLOR_BTNFACE);
	m_clrFillColor  = ::GetSysColor(COLOR_HIGHLIGHT);

	//custom properties
	m_clrTextColor  = RGB(255,255,255);  //white
	m_bShowText     = TRUE;
}

STDMETHODIMP CPieProgCtrl::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IPieProgCtrl,
	};
	for (int i=0; i<sizeof(arr)/sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i], riid))
			return S_OK;
	}
	return S_FALSE;
}


HRESULT CPieProgCtrl::OnDraw(ATL_DRAWINFO& di)
{
	//get ctrl rectangle
	RECT& rcCtrl = *(RECT*)di.prcBounds;
	CRect rectClient(rcCtrl);

	//get ctrl device context
	CDC dc;
	dc.Attach(di.hdcDraw);

	CDC dcMem;
	CBitmap bm;

	//create off screen buffer
	dcMem.CreateCompatibleDC(&dc);
	bm.CreateCompatibleBitmap(&dc,rectClient.Width(), rectClient.Height());
	CBitmap* pOldBitmap = (CBitmap*)dcMem.SelectObject(&bm);

	CBrush br(m_clrBackColor);
	CBrush *pOldBrush = (CBrush*)dcMem.SelectObject(&br);
		
	//save the state of memory dc
	int iMode = dcMem.SaveDC();

	//paint background
	dcMem.PatBlt(rectClient.left,rectClient.top,rectClient.Width(),rectClient.Height(),PATCOPY);
	dcMem.SelectObject(pOldBrush);

	//change to cartesian co-ordinate system
	dcMem.SetMapMode(MM_ISOTROPIC);

	dcMem.SetWindowOrg(0,0);
	dcMem.SetWindowExt(rectClient.Width(), rectClient.Height());

	dcMem.SetViewportOrg(rectClient.Width()/2, rectClient.Height()/2);
	dcMem.SetViewportExt(rectClient.Width()/2, -rectClient.Height()/2);

	//find the start and end pt of pie 
	CPoint ptStart, ptEnd;
	ptStart.x = long((100.0 * sin(TWO_PI * 0 / 360.0)));
	ptStart.y = long((100.0 * cos(TWO_PI * 0 / 360.0)));

	double dDiff = m_iUpper - m_iLower;
	double dPos  = m_iPos - m_iLower;
	int iPercent = int((dPos / dDiff) * 100.0);
	double dAngle = ((double)iPercent / 100.0) * 360.0;

	ptEnd.x = long(100.0 * sin(TWO_PI * dAngle / 360.0));
	ptEnd.y = long(100.0 * cos(TWO_PI * dAngle / 360.0));

	dcMem.SetArcDirection(AD_CLOCKWISE);

	CBrush brPie(m_clrFillColor);
	pOldBrush = (CBrush*)dcMem.SelectObject(&brPie);

	CPen pen;
	pen.CreatePen(PS_SOLID,1,m_clrFillColor);
	CPen* pOldPen = (CPen*)dcMem.SelectObject(&pen);

	CRect rc(-rectClient.Width(),rectClient.Height(),rectClient.Width(),-rectClient.Height());

	//draw the pie
	dcMem.Pie(rc,ptStart,ptEnd);
	
	//draw the text 
	if (m_bShowText)
	{
		dcMem.SetTextColor(m_clrTextColor);

		CString sPercent;
		sPercent.Format(_T("%d%%"),iPercent);
		
		dcMem.SetBkMode(TRANSPARENT);
		dcMem.DrawText(sPercent, rc, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	}

	//restore mapping mode
	dcMem.RestoreDC(iMode);

	//actually draw the stuff on screen
	dc.BitBlt(0,0,rectClient.Width(),rectClient.Height(),&dcMem,0,0,SRCCOPY);

	//don't forget to free the resources
	dcMem.SelectObject(pOldBitmap);
	bm.DeleteObject();
	dcMem.SelectObject(pOldBrush);
	dcMem.SelectObject(pOldPen);
	dc.Detach();

	return S_OK;
}

STDMETHODIMP CPieProgCtrl::get_TextColor(OLE_COLOR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	*pVal = m_clrTextColor;
	return S_OK;
}

STDMETHODIMP CPieProgCtrl::put_TextColor(OLE_COLOR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if(m_clrTextColor == newVal) //if same color
	{
		return S_OK; //get out quickly
	}

	if(m_bShowText)
	{
		if (!m_nFreezeEvents)
		{
			if (FireOnRequestEdit(DISPID_TEXTCOLOR) == S_FALSE) //ask container for change
			{
				return S_FALSE;
			}
		}

		m_clrTextColor = newVal;
		
		if (!m_nFreezeEvents)
		{
			FireOnChanged(DISPID_TEXTCOLOR);   //notify container of change
		}

		FireViewChange(); //request redraw
		SendOnDataChange(NULL);//notify advise sinks of change

		return S_OK;
	}

	return S_FALSE;
}


STDMETHODIMP CPieProgCtrl::get_ShowText(BOOL* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if(pVal == NULL)
	{
		return E_POINTER;
	}

	*pVal = m_bShowText;
	return S_OK;
}

STDMETHODIMP CPieProgCtrl::put_ShowText(BOOL newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_bShowText = newVal;
	m_bRequiresSave = TRUE;                 // Set dirty flag
	FireViewChange(); //update ctrl
	return S_OK;
}



STDMETHODIMP CPieProgCtrl::SetRange(long iLower, long iUpper)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	m_iLower = iLower;
	m_iUpper = iUpper;
	
	return S_OK;
}

STDMETHODIMP CPieProgCtrl::GetRange(long *iLower, long *iUpper)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if((iLower == NULL) || (iUpper == NULL))
	{
		return E_POINTER;
	}

	*iLower = m_iLower;
	*iUpper = m_iUpper;

	return S_OK;
}

STDMETHODIMP CPieProgCtrl::SetStep(long iStep)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_iStep = iStep;

	return S_OK;
}

STDMETHODIMP CPieProgCtrl::StepIt()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	
	int iPos = m_iPos + m_iStep;
	SetPos(iPos);

	if(m_iPos == m_iUpper) //if end step is reached
	{
		Refresh();
	}
	
	return S_OK;
}

STDMETHODIMP CPieProgCtrl::SetPos(long iPos)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_iPos = iPos;

	ValidateNewPos();

	//redraw ctrl
	::InvalidateRect(m_hWndCD, NULL, FALSE);
	::UpdateWindow(m_hWndCD);

	return S_OK;
}

STDMETHODIMP CPieProgCtrl::OffsetPos(long iPos)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_iPos += iPos;

	ValidateNewPos();

	//redraw ctrl
	::InvalidateRect(m_hWndCD, NULL, FALSE);
	::UpdateWindow(m_hWndCD);

	return S_OK;
}

STDMETHODIMP CPieProgCtrl::GetPos(long *iPos)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	if(iPos == NULL)
	{
		return E_POINTER;
	}

	*iPos = m_iPos;

	return S_OK;
}


STDMETHODIMP CPieProgCtrl::Refresh()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	Init();

	FireViewChange();

	return S_OK;
}


void CPieProgCtrl::Init()
{
	m_iUpper	= 0;
	m_iLower	= 0;
	m_iPos		= 0;
	m_iStep		= 0;
}

void CPieProgCtrl::ValidateNewPos()
{
	if(m_iPos < m_iLower)
	{
		m_iPos = m_iLower;
	}

	if(m_iPos > m_iUpper)
	{
		m_iPos = m_iUpper;
	}
}


