// PieProCtrlProperty.h : Declaration of the CPieProCtrlProperty

#ifndef __PIEPROCTRLPROPERTY_H_
#define __PIEPROCTRLPROPERTY_H_

#include "resource.h"       // main symbols

EXTERN_C const CLSID CLSID_PieProCtrlProperty;

/////////////////////////////////////////////////////////////////////////////
// CPieProCtrlProperty
class ATL_NO_VTABLE CPieProCtrlProperty :
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CPieProCtrlProperty, &CLSID_PieProCtrlProperty>,
	public IPropertyPageImpl<CPieProCtrlProperty>,
	public CDialogImpl<CPieProCtrlProperty>
{
public:
	CPieProCtrlProperty() 
	{
		m_dwTitleID = IDS_TITLEPieProCtrlProperty;
		m_dwHelpFileID = IDS_HELPFILEPieProCtrlProperty;
		m_dwDocStringID = IDS_DOCSTRINGPieProCtrlProperty;

		m_bText = FALSE;
	}

	enum {IDD = IDD_PIEPROCTRLPROPERTY};

DECLARE_REGISTRY_RESOURCEID(IDR_PIEPROCTRLPROPERTY)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPieProCtrlProperty) 
	COM_INTERFACE_ENTRY(IPropertyPage)
END_COM_MAP()

BEGIN_MSG_MAP(CPieProCtrlProperty)
	CHAIN_MSG_MAP(IPropertyPageImpl<CPieProCtrlProperty>)
	COMMAND_HANDLER(IDC_SHOWTEXT, BN_CLICKED, OnClickedShowtext)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	STDMETHOD(Apply)(void);
	STDMETHOD(SetObjects)(ULONG nObjects, IUnknown** ppUnk);
	STDMETHOD(Activate)(HWND hWndParent, LPCRECT prc, BOOL bModal);

	LRESULT OnClickedShowtext(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

	void InitializeControlsFromObject();
	void SetPropertiesFromControls();

private:
	BOOL m_bText;
	
};

#endif //__PIEPROCTRLPROPERTY_H_
