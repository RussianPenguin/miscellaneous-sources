// PieProgCtrl.h : Declaration of the CPieProgCtrl

#ifndef __PIEPROGCTRL_H_
#define __PIEPROGCTRL_H_

#include "resource.h"       // main symbols
#include <atlctl.h>


/////////////////////////////////////////////////////////////////////////////
// CPieProgCtrl
class ATL_NO_VTABLE CPieProgCtrl : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CStockPropImpl<CPieProgCtrl, IPieProgCtrl, &IID_IPieProgCtrl, &LIBID_PIEPROGRESSCTRLLib>,
	public CComControl<CPieProgCtrl>,
	public IPersistStreamInitImpl<CPieProgCtrl>,
	public IOleControlImpl<CPieProgCtrl>,
	public IOleObjectImpl<CPieProgCtrl>,
	public IOleInPlaceActiveObjectImpl<CPieProgCtrl>,
	public IViewObjectExImpl<CPieProgCtrl>,
	public IOleInPlaceObjectWindowlessImpl<CPieProgCtrl>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CPieProgCtrl>,
	public IPersistStorageImpl<CPieProgCtrl>,
	public ISpecifyPropertyPagesImpl<CPieProgCtrl>,
	public IQuickActivateImpl<CPieProgCtrl>,
	public IDataObjectImpl<CPieProgCtrl>,
	public IProvideClassInfo2Impl<&CLSID_PieProgCtrl, &DIID__IPieProgCtrlEvents, &LIBID_PIEPROGRESSCTRLLib>,
	public IPropertyNotifySinkCP<CPieProgCtrl>,
	public CComCoClass<CPieProgCtrl, &CLSID_PieProgCtrl>
{
public:
	CPieProgCtrl();

DECLARE_REGISTRY_RESOURCEID(IDR_PIEPROGCTRL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CPieProgCtrl)
	COM_INTERFACE_ENTRY(IPieProgCtrl)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
END_COM_MAP()

BEGIN_PROP_MAP(CPieProgCtrl)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)

//stock properties
	PROP_ENTRY("BackColor", DISPID_BACKCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("FillColor", DISPID_FILLCOLOR, CLSID_StockColorPage)

//custom properties
	PROP_ENTRY("TextColor", DISPID_TEXTCOLOR, CLSID_StockColorPage)
	PROP_ENTRY("ShowText",  DISPID_SHOWTEXT,  CLSID_PieProCtrlProperty)

END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CPieProgCtrl)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CPieProgCtrl)
	CHAIN_MSG_MAP(CComControl<CPieProgCtrl>)
	DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IViewObjectEx
	DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

// IPieProgCtrl
public:
	STDMETHOD(Refresh)();
	STDMETHOD(GetPos)(/*[out, retval]*/ long* iPos);
	STDMETHOD(OffsetPos)(/*[in]*/ long iPos);
	STDMETHOD(SetPos)(/*[in]*/ long iPos);
	STDMETHOD(StepIt)();
	STDMETHOD(SetStep)(/*[in]*/ long iStep);
	STDMETHOD(GetRange)(/*[out]*/ long* iLower, /*[out]*/ long *iUpper);
	STDMETHOD(SetRange)(/*[in]*/ long iLower, /*[in]*/ long iUpper);
	STDMETHOD(get_ShowText)(/*[out, retval]*/ BOOL* newVal);
	STDMETHOD(put_ShowText)(/*[in]*/ BOOL newVal);
	STDMETHOD(get_TextColor)(/*[out, retval]*/ OLE_COLOR *pVal);
	STDMETHOD(put_TextColor)(/*[in]*/ OLE_COLOR newVal);

	HRESULT OnDraw(ATL_DRAWINFO& di);
	void ValidateNewPos();
	void Init();
	
	OLE_COLOR m_clrBackColor;
	OLE_COLOR m_clrFillColor;

private:
	int m_iUpper;
	int m_iLower;
	int m_iPos;
	int m_iStep;
	BOOL m_bShowText;

	OLE_COLOR m_clrTextColor;
};

#endif //__PIEPROGCTRL_H_
