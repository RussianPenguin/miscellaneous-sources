//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PieProgressCtrl.rc
//
#define IDS_PROJNAME                    100
#define IDB_PIEPROGCTRL                 102
#define IDR_PIEPROGCTRL                 103
#define IDS_TITLEPieProCtrlProperty     104
#define IDS_HELPFILEPieProCtrlProperty  105
#define IDS_DOCSTRINGPieProCtrlProperty 106
#define IDR_PIEPROCTRLPROPERTY          107
#define IDD_PIEPROCTRLPROPERTY          108
#define IDC_SHOWTEXT                    201

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
