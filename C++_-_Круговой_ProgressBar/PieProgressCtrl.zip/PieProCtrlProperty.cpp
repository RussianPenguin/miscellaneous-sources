//*******************************************************
// PieProCtrlProperty.cpp : source file
//
// Written by Mukesh Gupta (mukesh_ind@hotmail.com)
// Copyright (c) 2000.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed unmodified by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. If 
// the source code in  this file is used in any commercial application 
// then a simple email would be nice.
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage whatsoever.
//
//*******************************************************

// PieProCtrlProperty.cpp : Implementation of CPieProCtrlProperty
#include "stdafx.h"
#include "PieProgressCtrl.h"
#include "PieProCtrlProperty.h"

/////////////////////////////////////////////////////////////////////////////
// CPieProCtrlProperty

STDMETHODIMP CPieProCtrlProperty::Apply()
{
	ATLTRACE(_T("CPieProCtrlProperty::Apply\n"));

	SetPropertiesFromControls();

	m_bDirty = FALSE;
	return S_OK;
}

STDMETHODIMP CPieProCtrlProperty::SetObjects(ULONG nObjects, IUnknown** ppUnk)
{
    HRESULT hr = E_INVALIDARG;
    if (nObjects == 1) //cause we hv only one control on the page
    {
        CComQIPtr<IPieProgCtrl> pIPieProgCtrl(ppUnk[0]);
        if (pIPieProgCtrl)
		{
            hr = IPropertyPageImpl<CPieProCtrlProperty>::SetObjects(nObjects, ppUnk);
		}
    }
    return hr;
}

STDMETHODIMP CPieProCtrlProperty::Activate(HWND hWndParent, LPCRECT prc, BOOL bModal)
{
	//if no objects avialble
	if (!m_ppUnk)
	{
        return E_UNEXPECTED;
	}
	
    //call the base class implementation
	HRESULT hr = IPropertyPageImpl<CPieProCtrlProperty>::Activate(hWndParent, prc, bModal);
	if (FAILED(hr))
	{
        return hr;
	}

	InitializeControlsFromObject();

	return S_OK;

}

LRESULT CPieProCtrlProperty::OnClickedShowtext(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	if(SendDlgItemMessage(wID, BM_GETCHECK) == BST_CHECKED) //if checked
	{
		m_bText = TRUE;
	}
	if(SendDlgItemMessage(wID, BM_GETCHECK) == BST_UNCHECKED) //if unchecked
	{
		m_bText = FALSE;
	}

	SetDirty(TRUE); //mark page dirty, so that apply button is enabled

	return 0;
}

void CPieProCtrlProperty::InitializeControlsFromObject()
{
	CComQIPtr<IPieProgCtrl> pIPieProgCtrl = m_ppUnk[0];

	//get ShowText property
	HRESULT hr = pIPieProgCtrl->get_ShowText (&m_bText);
	ATLASSERT (SUCCEEDED (hr));

	if (IsWindow ())
	{
		SendDlgItemMessage (IDC_SHOWTEXT, BM_SETCHECK, m_bText ? BST_CHECKED : BST_UNCHECKED);
	}
}

void CPieProCtrlProperty::SetPropertiesFromControls()
{
	for (UINT i = 0; i < m_nObjects; i++)
	{
		IPieProgCtrl* pIProgCtrl;
		HRESULT hr = m_ppUnk[i]->QueryInterface(IID_IPieProgCtrl, (void**)&pIProgCtrl);
		ATLASSERT(SUCCEEDED(hr));
		
		if(pIProgCtrl)
		{
			if(m_bText)
			{
				pIProgCtrl->put_ShowText(TRUE);
			}
			else
			{
				pIProgCtrl->put_ShowText(FALSE);
			}
		}
		
		pIProgCtrl->Release();	
	}
}
