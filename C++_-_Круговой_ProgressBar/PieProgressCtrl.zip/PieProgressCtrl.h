/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Oct 09 10:36:29 2000
 */
/* Compiler settings for C:\MyWrkArea\PieProgressCtrl\PieProgressCtrl.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __PieProgressCtrl_h__
#define __PieProgressCtrl_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IPieProgCtrl_FWD_DEFINED__
#define __IPieProgCtrl_FWD_DEFINED__
typedef interface IPieProgCtrl IPieProgCtrl;
#endif 	/* __IPieProgCtrl_FWD_DEFINED__ */


#ifndef ___IPieProgCtrlEvents_FWD_DEFINED__
#define ___IPieProgCtrlEvents_FWD_DEFINED__
typedef interface _IPieProgCtrlEvents _IPieProgCtrlEvents;
#endif 	/* ___IPieProgCtrlEvents_FWD_DEFINED__ */


#ifndef __PieProgCtrl_FWD_DEFINED__
#define __PieProgCtrl_FWD_DEFINED__

#ifdef __cplusplus
typedef class PieProgCtrl PieProgCtrl;
#else
typedef struct PieProgCtrl PieProgCtrl;
#endif /* __cplusplus */

#endif 	/* __PieProgCtrl_FWD_DEFINED__ */


#ifndef __PieProCtrlProperty_FWD_DEFINED__
#define __PieProCtrlProperty_FWD_DEFINED__

#ifdef __cplusplus
typedef class PieProCtrlProperty PieProCtrlProperty;
#else
typedef struct PieProCtrlProperty PieProCtrlProperty;
#endif /* __cplusplus */

#endif 	/* __PieProCtrlProperty_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IPieProgCtrl_INTERFACE_DEFINED__
#define __IPieProgCtrl_INTERFACE_DEFINED__

/* interface IPieProgCtrl */
/* [unique][helpstring][dual][uuid][object] */ 

#define	DISPID_TEXTCOLOR	( 0x1 )

#define	DISPID_SHOWTEXT	( 0x2 )

#define	DISPID_SETRANGE	( 0x3 )

#define	DISPID_GETRANGE	( 0x4 )

#define	DISPID_SETSTEP	( 0x5 )

#define	DISPID_SETPIT	( 0x6 )

#define	DISPID_OFFSETPOS	( 0x7 )

#define	DISPID_SETPOS	( 0x8 )

#define	DISPID_GETPOS	( 0x9 )


EXTERN_C const IID IID_IPieProgCtrl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5918D9CF-9AA1-11D4-9198-00D0B707724F")
    IPieProgCtrl : public IDispatch
    {
    public:
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_BackColor( 
            /* [in] */ OLE_COLOR clr) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_BackColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_FillColor( 
            /* [in] */ OLE_COLOR clr) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_FillColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TextColor( 
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TextColor( 
            /* [in] */ OLE_COLOR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ShowText( 
            /* [retval][out] */ BOOL __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ShowText( 
            /* [in] */ BOOL newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetRange( 
            /* [in] */ long iLower,
            /* [in] */ long iUpper) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetRange( 
            /* [out] */ long __RPC_FAR *iLower,
            /* [out] */ long __RPC_FAR *iUpper) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetStep( 
            /* [in] */ long iStep) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE StepIt( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OffsetPos( 
            /* [in] */ long iPos) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetPos( 
            /* [in] */ long iPos) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPos( 
            /* [retval][out] */ long __RPC_FAR *iPos) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Refresh( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IPieProgCtrlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPieProgCtrl __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPieProgCtrl __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BackColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ OLE_COLOR clr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BackColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FillColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ OLE_COLOR clr);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FillColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TextColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TextColor )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ OLE_COLOR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ShowText )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *newVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ShowText )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ BOOL newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetRange )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ long iLower,
            /* [in] */ long iUpper);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRange )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [out] */ long __RPC_FAR *iLower,
            /* [out] */ long __RPC_FAR *iUpper);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetStep )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ long iStep);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StepIt )( 
            IPieProgCtrl __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OffsetPos )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ long iPos);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetPos )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [in] */ long iPos);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPos )( 
            IPieProgCtrl __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *iPos);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Refresh )( 
            IPieProgCtrl __RPC_FAR * This);
        
        END_INTERFACE
    } IPieProgCtrlVtbl;

    interface IPieProgCtrl
    {
        CONST_VTBL struct IPieProgCtrlVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IPieProgCtrl_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPieProgCtrl_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPieProgCtrl_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IPieProgCtrl_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IPieProgCtrl_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IPieProgCtrl_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IPieProgCtrl_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IPieProgCtrl_put_BackColor(This,clr)	\
    (This)->lpVtbl -> put_BackColor(This,clr)

#define IPieProgCtrl_get_BackColor(This,pclr)	\
    (This)->lpVtbl -> get_BackColor(This,pclr)

#define IPieProgCtrl_put_FillColor(This,clr)	\
    (This)->lpVtbl -> put_FillColor(This,clr)

#define IPieProgCtrl_get_FillColor(This,pclr)	\
    (This)->lpVtbl -> get_FillColor(This,pclr)

#define IPieProgCtrl_get_TextColor(This,pVal)	\
    (This)->lpVtbl -> get_TextColor(This,pVal)

#define IPieProgCtrl_put_TextColor(This,newVal)	\
    (This)->lpVtbl -> put_TextColor(This,newVal)

#define IPieProgCtrl_get_ShowText(This,newVal)	\
    (This)->lpVtbl -> get_ShowText(This,newVal)

#define IPieProgCtrl_put_ShowText(This,newVal)	\
    (This)->lpVtbl -> put_ShowText(This,newVal)

#define IPieProgCtrl_SetRange(This,iLower,iUpper)	\
    (This)->lpVtbl -> SetRange(This,iLower,iUpper)

#define IPieProgCtrl_GetRange(This,iLower,iUpper)	\
    (This)->lpVtbl -> GetRange(This,iLower,iUpper)

#define IPieProgCtrl_SetStep(This,iStep)	\
    (This)->lpVtbl -> SetStep(This,iStep)

#define IPieProgCtrl_StepIt(This)	\
    (This)->lpVtbl -> StepIt(This)

#define IPieProgCtrl_OffsetPos(This,iPos)	\
    (This)->lpVtbl -> OffsetPos(This,iPos)

#define IPieProgCtrl_SetPos(This,iPos)	\
    (This)->lpVtbl -> SetPos(This,iPos)

#define IPieProgCtrl_GetPos(This,iPos)	\
    (This)->lpVtbl -> GetPos(This,iPos)

#define IPieProgCtrl_Refresh(This)	\
    (This)->lpVtbl -> Refresh(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id][propput] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_put_BackColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ OLE_COLOR clr);


void __RPC_STUB IPieProgCtrl_put_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_get_BackColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);


void __RPC_STUB IPieProgCtrl_get_BackColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_put_FillColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ OLE_COLOR clr);


void __RPC_STUB IPieProgCtrl_put_FillColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_get_FillColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pclr);


void __RPC_STUB IPieProgCtrl_get_FillColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_get_TextColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [retval][out] */ OLE_COLOR __RPC_FAR *pVal);


void __RPC_STUB IPieProgCtrl_get_TextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_put_TextColor_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ OLE_COLOR newVal);


void __RPC_STUB IPieProgCtrl_put_TextColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_get_ShowText_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *newVal);


void __RPC_STUB IPieProgCtrl_get_ShowText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_put_ShowText_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IPieProgCtrl_put_ShowText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_SetRange_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ long iLower,
    /* [in] */ long iUpper);


void __RPC_STUB IPieProgCtrl_SetRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_GetRange_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [out] */ long __RPC_FAR *iLower,
    /* [out] */ long __RPC_FAR *iUpper);


void __RPC_STUB IPieProgCtrl_GetRange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_SetStep_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ long iStep);


void __RPC_STUB IPieProgCtrl_SetStep_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_StepIt_Proxy( 
    IPieProgCtrl __RPC_FAR * This);


void __RPC_STUB IPieProgCtrl_StepIt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_OffsetPos_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ long iPos);


void __RPC_STUB IPieProgCtrl_OffsetPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_SetPos_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [in] */ long iPos);


void __RPC_STUB IPieProgCtrl_SetPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_GetPos_Proxy( 
    IPieProgCtrl __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *iPos);


void __RPC_STUB IPieProgCtrl_GetPos_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IPieProgCtrl_Refresh_Proxy( 
    IPieProgCtrl __RPC_FAR * This);


void __RPC_STUB IPieProgCtrl_Refresh_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IPieProgCtrl_INTERFACE_DEFINED__ */



#ifndef __PIEPROGRESSCTRLLib_LIBRARY_DEFINED__
#define __PIEPROGRESSCTRLLib_LIBRARY_DEFINED__

/* library PIEPROGRESSCTRLLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_PIEPROGRESSCTRLLib;

#ifndef ___IPieProgCtrlEvents_DISPINTERFACE_DEFINED__
#define ___IPieProgCtrlEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IPieProgCtrlEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IPieProgCtrlEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("5918D9D1-9AA1-11D4-9198-00D0B707724F")
    _IPieProgCtrlEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IPieProgCtrlEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _IPieProgCtrlEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _IPieProgCtrlEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _IPieProgCtrlEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _IPieProgCtrlEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _IPieProgCtrlEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _IPieProgCtrlEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _IPieProgCtrlEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _IPieProgCtrlEventsVtbl;

    interface _IPieProgCtrlEvents
    {
        CONST_VTBL struct _IPieProgCtrlEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IPieProgCtrlEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IPieProgCtrlEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IPieProgCtrlEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IPieProgCtrlEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IPieProgCtrlEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IPieProgCtrlEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IPieProgCtrlEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IPieProgCtrlEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_PieProgCtrl;

#ifdef __cplusplus

class DECLSPEC_UUID("5918D9D0-9AA1-11D4-9198-00D0B707724F")
PieProgCtrl;
#endif

EXTERN_C const CLSID CLSID_PieProCtrlProperty;

#ifdef __cplusplus

class DECLSPEC_UUID("5918D9D3-9AA1-11D4-9198-00D0B707724F")
PieProCtrlProperty;
#endif
#endif /* __PIEPROGRESSCTRLLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
