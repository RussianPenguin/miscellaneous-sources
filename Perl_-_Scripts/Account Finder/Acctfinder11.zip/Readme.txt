Account Finder 1.1 - README  03/11/98

02/22/98 - Account Finder 1.0 released
03/11/98 - Addition of .htaccess and .nsconfig file support.  Also
added user chosen user names.  Added several error screens to assist
users navigate.

Account Finder 1.1 is a program designed for webmasters to allow users/customers the ability to look up their private access account name and password by entering their email address into a form input.  The email address is then checked against a database.  If the account information is in the database, the information is then emailed to the original owner of the account.  No private information is placed on the screen/monitor.

Account Finder is a two part program.  First, Account Finder can be used
to create your member database with.  Although you can create your own
form to create your database, Account Finder's input form was speacially
designed to work with Account Finder perl program.  To bring up the
user input form, to create the user account with, simply call the
acctfinder.pl file.  Simply create a button or a text link from your web
page, like so:

<P><A HREF="http://www.yourdomain.com/full/path/to/acctfinder.pl">Complete our User Information from</A></P>

Be sure to place the correct path for Acctfinder.pl in your web page.

Once the user/member fills in the input form, the data is written to a
database file.  That information is then available to users/members if
they ever lose or misplace their user information.  Simply copy and
paste the code inside the forminput.txt file into any of your web
pages that you would like users/members to be able to access their
account data from.  BE SURE TO ADD THE FORM ACTION PATH TO 
ACCOUNT FINDER!  A form won't work without the form action path!


1)  Fill in all the variables in the Accntfinder.pl file.

2)  Upload the Acctfinder.pl (rename to .cgi if your server requires .cgi extensions) to any properly chmoded directory on your server.

3)  Enter the HTML that you'll find on the forminput.txt file into a web page.  Make sure you tell the form where to find your Accntfinder.pl file.

4)  Run the script!

You can find a help forum at: http://cgi.elitehost.com

Diran A.
CoPromote
http://www.eliteweb.com/copromote