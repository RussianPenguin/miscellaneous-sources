#!/usr/bin/perl

############################################
##                                        ##
##             Account Finder             ##
##              by CoPromote              ##
##       (e-mail cgi@elitehost.com)       ##
##                                        ##
##             version:  1.1              ##
##         last modified:  03/11/98       ##
##           copyright (c) 1998           ##
##                                        ##
##    latest version is available from    ##
##        http://cgi.elitehost.com        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1998 Elite Host.  All Rights Reserved.
#
# This program may be used and modified free of charge by anyone, so
# long as this copyright notice and the header above remain intact.  By
# using this program you agree to indemnify Elite Host and any company
# programmers from any liability.
#
# Selling the code for this program without prior written consent is
# expressly forbidden.  Obtain permission before redistributing this
# program over the Internet or in any other medium.  In all cases
# copyright and header must remain intact.
#
# PROGRAM DESCRIPTION:
#
# This program is designed to allow webmaster allow users/customers
# the ability to look up their private access account name and password
# by entering their email address into a form input.  The email address
# is then checked against a database.  If the account information is in
# the database, the information is then emailed to the original owner of
# the account.  No private information is placed on the screen/monitor.
#
# Please read the README file that comes with this program for complete
# installation and usage instructions, or visit http://cgi.elitehost.com
# for posted instructions.
#################################################################
# DO NOT EDIT BELOW PARAGRAPH
#################################################################

read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	if ($INPUT{$name}) { $INPUT{$name} = $INPUT{$name}.",".$value; }
	else { $INPUT{$name} = $value; }
}
################################################################
# DO NOT EDIT ABOVE PARAGRAPH
################################################################

################################################################
# EDIT USER INFORMATION BELOW
################################################################

# Type the full path to your Mail program
$mailprog = 'c:/winnt/system32/blat.exe';

# Type a full path for a temp directory that BLAT Mail can use
# Comment out this variable if using Sendmail (place a # in front)
$tempfile = "c:/full/path/to/temp/$INPUT{'email'}";

# Type the subject that will appear in the email customer receives
$subject = "ABC Member Info";

# If you use .htaccess or .nsconfig, use a "1", otherwise leave blank
# or set to "0".

$htaccess = "";

# If you entered "1" above, enter the full path to your
# htpasswd or .nsconfig file.
# Like this: $memaccess = "/full/path/to/htpasswd";
# This is the file that houses the usernames and encrypted passwords
# but is only needed if you use .htaccess or .nsconfig
$memaccess = "";

# Type the full path to the database file that contains all the info
$memberinfo = "c:/full/path/to/customersaf.db";

# Type the name of your organization, group, or company
$orgname = "ABC Services";

# Type an email address that customer/user can respond to
$orgemail = "youname\@yoursite.com";

###############################################################
# DO NOT EDIT BELOW THIS LINE
###############################################################

# Full URL to acctfinder.pl (or accntfinder.cgi)
$cgiurl = $ENV{'SCRIPT_NAME'};

# Define arrays for the day of the week and month of the year.           #
    @days   = ('Sunday','Monday','Tuesday','Wednesday',
	       'Thursday','Friday','Saturday');
    @months = ('January','February','March','April','May','June','July',
		 'August','September','October','November','December');

    # Get the current time and format the hour, minutes and seconds.  Add    #
    # 1900 to the year to get the full 4 digit year.                         #
    ($sec,$min,$hour,$mday,$mon,$year,$wday) = (localtime(time))[0,1,2,3,4,5,6];
    $time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
    $year += 1900;

    # Format the date.                                                       #
    $date = "$days[$wday], $months[$mon] $mday, $year at $time";

    $version = "1.1";


if ($INPUT{'find'}) { &find; } ######### Will search for member info.
elsif ($INPUT{'add'}) {&add; } ###### Add member information to database
else {&form;}############# IF no button was pressed, run just as reset, 
exit;

########################################################
# Subroutine FIND - Will find member info and email it
########################################################

sub checkaddress {

unless ($INPUT{'email'} =~ /.*\@.*\..*/) {
print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finders: Improper Address!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER><BR><TABLE
BORDER=\"0\" WIDTH=\"500\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\"><P><B><FONT FACE=\"verdana, arial, helvetica\"><FONT
COLOR=\"#FF0000\">Account Finder</FONT> Status:  Improper Address!</FONT></B></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">You have entered an improper email address.  Please make sure your email address appears in this manner:  username\@domain.com, or username\@domain.net, etc. </FONT></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">If you need further
assistance, please contact us at <A
HREF=\"mailto:$orgemail\">$orgname Support</A>.</FONT></P><HR
SIZE=\"1\"><CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";

exit;
}
}


sub find {

&checkaddress;

# Open member database, read info
open (DAT,"<$memberinfo");
 @database_array = <DAT>;
 close (DAT);

foreach $lines(@database_array) {
          @edit_array = split(/\:/,$lines);
          if ($edit_array[2] =~ /$INPUT{'email'}/i) {last; }
}

unless ($edit_array[2] =~ /$INPUT{'email'}/i) {

print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finders: Not Found!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER><BR><TABLE
BORDER=\"0\" WIDTH=\"500\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\"><P><B><FONT FACE=\"verdana, arial, helvetica\"><FONT
COLOR=\"#FF0000\">Account Finder</FONT> Status:  Not Found!</FONT></B></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Your $orgname account information was not found in our database.  Please make sure that you used the same email address that you created your account with.</FONT></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please contact <A
HREF=\"mailto:$orgemail\">$orgname Support</A> for your account information.</FONT></P><HR
SIZE=\"1\"><CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";

exit;
} 

print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finder: Success!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER><BR><TABLE
BORDER=\"0\" WIDTH=\"500\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\"><P><B><FONT FACE=\"verdana, arial, helvetica\"><FONT
COLOR=\"#FF0000\">Account Finder</FONT> Status:  Success!</FONT></B></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Your $orgname account information has been emailed to you at: $INPUT{'email'}.</FONT></P><P><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please contact <A
HREF=\"mailto:$orgemail\">$orgname Support</A> if you need any further assistance.</FONT></P><HR
SIZE=\"1\"><CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";

# Output a temporary file

    open(MAIL,">$tempfile") || die("Cannot open $tempfile -- Check Directory Permissions : $!"); 
    
    print MAIL "To: $edit_array[2]\n";
    print MAIL "From: $orgemail ($orgname Support)\n";

    #Date
    print MAIL "$date\n";
    
    # Check for Message Subject
    print MAIL "Subject: $subject\n\n";
    print MAIL "-" x 75 . "\n\n";

    print MAIL "You requested your $orgname account information:\n\n";

    print MAIL "Your $orgname User ID is: $edit_array[0]\n";
    print MAIL "Your $orgname password is: $edit_array[1]\n\n";

    print MAIL "please contact $orgname support at: $orgemail\n";
    print MAIL "if you have any questions.\n\n";

    print MAIL "$orgname Support Team\n";    

    close (MAIL);
 
        #'use' the process module.
        use Win32::Process;
        
        #theWin32:: module. Includes the Win32 error checking etc.
        # see Win32:: section for included functions.
        use Win32;
        
        #sub Error{ 
        #print Win32::FormatMessage( Win32::GetLastError() );
        #}
        #Create the process object.
        Win32::Process::Create($ProcessObj, $mailprog, "Blat $tempfile -t $edit_array[2] -s \"$subject\" -i \"$orgemail ($orgname Support)\" -f \"$orgemail ($orgname Support)\" ", 0, DETACHED_PROCESS, ".")|| die ; 
        #Set the process priority
        #$ProcessObj->SetPriority(NORMAL_PRIORITY_CLASS)||die ;

        #Wait for the process to end. NO timeout 
        $ProcessObj->Wait(300);
        unlink($tempfile);
        


}

sub add {

&checkaddress;

unless ($INPUT{'pwd'} eq $INPUT{'pwd2'} && $INPUT{'pwd'} && $INPUT{'pwd2'} ){

print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finder:  Password Mismatch Error!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER><TABLE BORDER=\"0\" WIDTH=\"550\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Finder:</FONT>  Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>Password
Error!  Password Mismatch</B></FONT><BR><BR><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">Please go back and re-enter your
password choice.</FONT></TD></TR><TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER> </TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";
exit;
    } 


if (-e $memberinfo) {

open (MEMBER, "<$memberinfo");
@database_array = <MEMBER>;
 close (MEMBER);

foreach $lines(@database_array) {
          @edit_array = split(/\:/,$lines);
          if ($edit_array[0] =~ /$INPUT{'username'}/i) {last; } 
}


if ($edit_array[0] =~ /$INPUT{'username'}/i) {

print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finder:  User Name already taken!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER><TABLE BORDER=\"0\" WIDTH=\"550\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR
><TD ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Finder:</FONT>  Account Information Input Form</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>User Name Error!  User Name Taken</B></FONT><BR><BR><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">The User Name you have selected is already in use by another user.  Please return and enter another user name.</FONT></TD></TR>
<TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";
exit;
}

}

if ($htaccess == "1") {

chop ($pwd) if ($pwd =~ /\n$/);
		$newpassword = crypt($INPUT{'pwd'}, aa);


$newline = join
("\:",$INPUT{'username'},$newpassword);
$newline .= "\n";


open(DB, ">>$memaccess") or print"unable to open htpasswd";
print DB $newline;
close (DB);

}

$newline2 = join
("\:",$INPUT{'username'},$INPUT{'pwd'},$INPUT{'email'},0);
$newline2 .= "\n";
open(DB, ">>$memberinfo") or print "unable to open customersaf.db";
print DB $newline2;
close (DB);


print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finder:  Welcome to $orgname!</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><CENTER
><TABLE BORDER=\"0\" WIDTH=\"550\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
 ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Finder:</FONT>  New User Welcome!</FONT><BR><BR>
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"LEFT\" COLSTART=\"1\"><FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><B>Welcome to $orgname, $INPUT{'fname'}!</B></FONT><BR><BR><FONT
SIZE=\"-1\" FACE=\"verdana, arial, helvetica\">For the security of your account, we will never post your User ID and/or Password to a web page.  <BR><BR>If you ever misplace your User ID and/or private password, simply look for the Account Finder input area at our website.  Enter your email address into the open area and press the submit button.  Your User ID and private password will immediately be emailed to you!</FONT></TD></TR>
<TR><TD COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER></TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER></BODY></HTML>";


exit;
}

sub form {

print "Content-type: text/html\n\n";
print "<HTML><HEAD><TITLE>Account Finder:  Account Information Input Form</TITLE></HEAD><BODY
BGCOLOR=\"#FFFFFF\"><FORM
ACTION=\"$cgiurl\" METHOD=\"POST\"><CENTER><TABLE
BORDER=\"0\" WIDTH=\"550\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
ALIGN=\"CENTER\" COLSTART=\"1\">     
<FONT SIZE=\"+1\" FACE=\"verdana, arial, helvetica\"><FONT COLOR=\"#FF0000\">Account
Finder:</FONT>  Account Information Input Form</FONT><BR><BR>     
<TABLE BORDER=\"0\"><TBODY><COLDEFS><COLDEF></COLDEFS><ROWS><TR><TD
COLSTART=\"1\">      
<P><FONT SIZE=\"-1\" FACE=\"arial, helvetica\"><B>Contact Information</B><BR>   

<INPUT NAME=\"fname\" SIZE=\"30\"> First Name<BR>   
<INPUT NAME=\"lname\" SIZE=\"30\"> Last Name<BR><INPUT NAME=\"email\" SIZE=\"30\"> Email Address<BR><BR><B>Choose a User Name</B><BR><INPUT
TYPE=\"TEXT\" NAME=\"username\" SIZE=\"30\"> User Name  
</FONT></P>
<P><FONT SIZE=\"-1\" FACE=\"arial, helvetica\"><B>Choose a Password</B></FONT><BR>
      
<INPUT TYPE=\"password\" NAME=\"pwd\" SIZE=\"30\">    
<FONT SIZE=\"-1\" FACE=\"arial, helvetica\">Password</FONT><BR><INPUT
TYPE=\"password\" NAME=\"pwd2\" SIZE=\"30\"> <FONT SIZE=\"-1\" FACE=\"arial, helvetica\">Verify
 Password</FONT><BR>     
</P>
<P><FONT SIZE=\"-1\" FACE=\"arial, helvetica\"><B>Welcome to $orgname!</B></FONT></P>
<P><INPUT TYPE=\"submit\" VALUE=\"    Join Now    \" NAME=\"add\"><INPUT
TYPE=\"reset\" VALUE=\"Reset\"></P>              
</TD></TR><TR><TD VALIGN=\"TOP\" ALIGN=\"CENTER\" COLSTART=\"1\"><HR SIZE=\"1\">
<CENTER><FONT SIZE=\"-2\" FACE=\"verdana, arial, helvetica\"> $orgname is maintained with  <A
HREF=\"http://cgi.elitehost.com\">Account Finder $version</A></FONT>
</CENTER> 
</TD></TR></ROWS></TBODY></TABLE></TD></TR></ROWS></TBODY></TABLE></CENTER></FORM></BODY></HTML> ";
exit;
}
