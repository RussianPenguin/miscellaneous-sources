my ($i,@array)=&podschet;

print <<HTML;
<body bgcolor="#FFFFFF">
<h3 align="center">Cool MySQL Guest Book ver. 2.0</h3>
<div align="center"><center><h1><font color="red">$text</font></h1>
<table border="0" cellpadding="0" cellspacing="0" width="556">
<tr>
<td width="554" bgcolor="#000080"><b><font color="#FFFFFF">English</font></b></td>
</tr>
<tr>
<td width="554">If you have questions or offers contact to the author
If want to order the commercial version of the program contact to the author <a href="mailto:musicwarez\@mail.ru">musicwarez\@mail.ru</a> [<a
href="http://mak.minsk-online.com/cgi-bin/dcforum/dcboard.cgi?az=list&amp;forum=DCForumID13&amp;conf=DCConfID3">Support
Forum</a>] [<a href="http://mak.cit.org.by/gk.htm">Home Page</a>] [<a href="http://mak.minsk-online.com/gk_.zip">Download</a>]</td>
</tr>
<tr>
<td width="554" bgcolor="#000080"><p ALIGN="center"><b><font color="#FFFFFF">Russian</font></b></td>
</tr>
<tr>
<td width="554">���� � ��� ���� ������� ��� ����������� ��������� � �������
���� ������ �������� ������������ ������ ��������� ��������� � �������
<a href="mailto:musicwarez\@mail.ru">musicwarez\@mail.ru</a> [<a
href="http://mak.minsk-online.com/cgi-bin/dcforum/dcboard.cgi?az=list&amp;forum=DCForumID13&amp;conf=DCConfID3">����� ���������</a>] [<a href="http://mak.cit.org.by/gk.htm">�������� ���������</a>] [<a href="http://mak.minsk-online.com/gk_.zip">�������</a>]</td>
</tr>
</table>

</center>
</div>
<p align="center"><a href="gk.cgi?beginz=1">��������</a></p>
<div align="center">
<center>
<table border="1" cellpadding="4" bordercolor="#000080" cellspacing="0">
<tr>
<td><form method="POST" action="gk.cgi" align="center">
<div align="center"><center>

<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td colspan="2" height="35">
<p align="center">In total $i recordings</p>
</td>
</tr>
<tr>
<td>Name</td>
<td><input type="text" name="name" size="20" value="$name"></td>
</tr>
<tr>
<td>Email</td>
<td><input type="text" name="email" size="20" value="$email"></td>
</tr>
<tr>
<td colspan="2"><div align="center"><p>Comment</p>
</div><div align="center"><p><input type="hidden" name="add" value="1"><textarea rows="2" name="comment" cols="23">$comment</textarea></p>
</div>
</td>
</tr>
<tr>
<td colspan="2"><div align="center">
<input type="submit" value="Submit" name="B1"><input type="reset" value="Reset" name="B2">
</div></td>
</tr>
</form>
</table>
</center>
</div>
</td></tr></table>
</center>
</div>

<p align="center"><a href="gk.cgi?beginz=1">Viewing of the messages</a></p>

<center>
<table border="0" cellpadding="0" cellspacing="0" width="90%">
<tr><td height="1" colspan="5" bgcolor="#000000"></td></tr>
<tr><td height="1" bgcolor="#000000"></td>
<td><a href="http://mak.cit.org.by/cgi-bin/ringlink/home.cgi?ringid=perl;siteid=bel"><img align="left" alt="[ Perl WEBRing ]" border="0" src="http://mak.cit.org.by/prlogo.gif"></a></td>
<td><p align="center"><font size="2">This <a href="http://mak.cit.org.by/cgi-bin/ringlink/home.cgi?ringid=perl;siteid=gk"
target="_top">Perl WEBRing</a> site is owned by <a href="mailto:mak\@mak.minsk-online.com?Subject=Perl WEBRing">mak\@mak.minsk-online.com</a>.<br></font>
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/next.cgi?ringid=perl;siteid=gk" target="_top">Next</a>] 
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/prev.cgi?ringid=perl;siteid=gk" target="_top">Prev</a>] 
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/next5.cgi?ringid=perl;siteid=gk" target="_top">Next 5</a>] 
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/prev5.cgi?ringid=perl;siteid=gk" target="_top">Prev 5</a>] 
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/rand.cgi?ringid=perl;siteid=gk" target="_top">Random Link</a>] 
[<a href="http://mak.cit.org.by/cgi-bin/ringlink/list.cgi?ringid=perl;siteid=gk" target="_top">List</a>]
<font size="2"><br>Want to join the ring? Click here for <a href="http://mak.cit.org.by">info</a></font></td>
<td><a href="http://mak.cit.org.by/cgi-bin/ringlink/next.cgi?ringid=perl;siteid=gk"><img align="right" alt="[ Perl WEBRing ]" border="0" src="http://mak.cit.org.by/prnext.gif"></a></td>
<td height="1" bgcolor="#000000"></td>
</tr>
<tr>
<td height="1" colspan="5" bgcolor="#000000" width="985"></td>
</tr>
</table>

</center>

HTML

1;