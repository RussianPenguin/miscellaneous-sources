#!d:/perl/bin/perl.exe
#!/usr/local/bin/perl

print "Content-type: text/html\n\n";
use Htpasswd;
require "htadmin.cfg";

# ������ �������������
# ����������
# ��������� ������
# ��������

#-----------------------------------------------------------# �������� ���������
read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
if (!$buffer) {
 $buffer=$ENV{'QUERY_STRING'};
}
@pairs = split(/&/, $buffer);
foreach $pair (@pairs) {
   ($name, $value) = split(/=/, $pair);
   $value =~ tr/+/ /;
   $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
   $in{$name} = $value;
}

#-----------------------------------------------------------# ���������� ��������
print $start_html;
$passtext=1;
$temp_print="<font color=green><b>worked system</b></font> ";
if ($ENV{'SERVER_SOFTWARE'} =~ /Unix/i) {$temp_print.="[Unix/Linux]";$passtext=0}
elsif ($ENV{'SERVER_SOFTWARE'} =~ /Win/i) {$temp_print.="[Windows]"}
else {$temp_print.="[<font color=red><b>UNKNOWN</b></font>]";$passtext=$code_not_sysinfo}
$temp_print.=" <sup>$><sup>";
if (!-e "$start_work_dir$in{'workdir'}/.htpasswd" and $in{'protected'} and $in{'workdir'} and
    $in{'name'} and $in{'password'}) {
    if (!protected("$in{'name'}","$in{'password'}")) {print qq{
        <table width="600" border="0" cellspacing="0" cellpadding="1" bgcolor=black ><tr><td>
        <table width="600" border="0" cellspacing="1" cellpadding="1" bgcolor=#F9F1D7>
        <td align=center><font size="-1" face="Verdana, Arial" color=red><b>������ ��� ������� ������ ����������<br>
        �������� ��� �������</b><br></font></td>
        </td></tr></table></td></tr></table><br>
    };
    }
}
#-----------------------------------------------------------#
if (-e "$start_work_dir$in{'workdir'}/.htpasswd") {
if ($in{'step'}==1) {
    # �������
    deleteuser();
}
elsif ($in{'step'}==2) {
    # �������� ������
    checkpass();
}
elsif ($in{'step'}==3) {
    # ��������
    adduser();
}
elsif ($in{'step'}==4) {
    # ������� ������
    killprotect();
}
}
#-----------------------------------------------------------# ������� �������
$temp_print0=pr_workdir();

print qq{
<table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor=black ><tr><td>
<table width="600" border="0" cellspacing="1" cellpadding="1">
<tr><td bgcolor=#F7E09A align=center><font size="-1" face="Verdana, Arial"><b>PVD access manager 1.0</b><br></td>
<td bgcolor=#F7E09A align=center><font size="-1" face="Verdana, Arial">$temp_print</form></td></tr>
<tr><td colspan=2 bgcolor=#F9F1D7 align=justify>
<form method=POST action=$script_name>
<table celspacing=0 cellpadding=0><tr>
<td><font size="-1" face="Verdana, Arial">$start_work_dir</font> $temp_print0 <INPUT TYPE="submit" VALUE="������� >>"></td>
</tr>
</table></form>
</td></tr></table></td></tr></table><br>
};

#-----------------------------------------------------------#
if (!-e "$start_work_dir$in{'workdir'}/.htpasswd" and $in{'workdir'}) {
print qq{
<script language="JavaScript">
<!--
function checklp()
{
 if (document.prot.name.value=="") {alert("�� ������� ���!");return false;}
 if (document.prot.password.value=="") {alert("�� ������ ������!");return false;}
 document.prot.submit();
 return true;
}
//-->
</script>
<form name=prot method=POST action=$script_name>
<input type=hidden name=workdir value="$in{'workdir'}">
<input type=hidden name=protected value=1>
<table width="600" border="0" cellspacing="0" cellpadding="1" bgcolor=black ><tr><td>
<table width="600" border="0" cellspacing="1" cellpadding="1" bgcolor=#F9F1D7><tr>
<td align=center><font size="-1" face="Verdana, Arial" color=red><b>��������!!! ���������� �� ��������!!</b><br><br>
LOGIN:<input type=text name=name size=10><br>
PASSWORD:<input type=password name=password size=10><br>
<input type="button" value="*** �������� ***" onclick="checklp()"></font>
</td></tr></table></td></tr></table><br>
</form>
};
}
else {if (-e "$start_work_dir$in{'workdir'}/.htpasswd") {showusers()}}


#-----------------------------------------#

print $end_html;




#-----------------------------------------------------------#
sub killprotect {
unlink("$start_work_dir$in{'workdir'}/.htpasswd");
unlink("$start_work_dir$in{'workdir'}/.htaccess");
}


#-----------------------------------------------------------#
sub checkpass {
    if ($passtext) {
        open TEMP, "<$start_work_dir$in{'workdir'}/.htpasswd";
        $temp_no=-1;
        while (<TEMP>) {
            chomp;
            if ($_ !~ /\n/) {$temp_no+=1;($masusers[$temp_no][0],$masusers[$temp_no][1])=split(/\:/,$_)}
        }
        close TEMP;
        open TEMP, ">$start_work_dir$in{'workdir'}/.htpasswd";
        flock(TEMP,2);
        for($i=0;$i<=$#masusers;$i++) {
            if ($masusers[$i][0] ne $in{'user'}) {print TEMP "$masusers[$i][0]:$masusers[$i][1]\n"}
            else {print TEMP "$masusers[$i][0]:$in{'cpassword'}\n"}
        }
        close TEMP;
    } else {
        $pwdFile = new Htpasswd ("$start_work_dir$in{'workdir'}/.htpasswd");
        return "0" unless $pwdFile->htpasswd("$in{'user'}","$in{'cpassword'}",1);
    }
    return 1;
}


#-----------------------------------------------------------#
sub adduser {
    if ($passtext) {
        open TEMP, ">>$start_work_dir$in{'workdir'}/.htpasswd"; flock(TEMP,2);
        print TEMP "$in{'name'}:$in{'password'}\x0A"; close TEMP;
    } else {
        $pwdFile = new Htpasswd ("$start_work_dir$in{'workdir'}/.htpasswd");
        return "0" unless $pwdFile->htpasswd("$in{'name'}","$in{'password'}");
    }
    return 1;
}


#-----------------------------------------------------------#
sub deleteuser {
    if ($passtext) {
        open TEMP, "<$start_work_dir$in{'workdir'}/.htpasswd";
        $temp_no=-1;
        while (<TEMP>) {
            chomp;
            if ($_ !~ /\n/) {$temp_no+=1;($masusers[$temp_no][0],$masusers[$temp_no][1])=split(/\:/,$_)}
        }
        close TEMP;
        open TEMP, ">$start_work_dir$in{'workdir'}/.htpasswd";
        flock(TEMP,2);
        for($i=0;$i<=$#masusers;$i++) {
            if ($masusers[$i][0] ne $in{'user'}) {print TEMP "$masusers[$i][0]:$masusers[$i][1]\n"}
        }
        close TEMP;
    } else {
        $pwdFile = new Htpasswd ("$start_work_dir$in{'workdir'}/.htpasswd");
        return "0" unless $pwdFile->htDelete("$in{'user'}");
    }
    return 1;
}



#-----------------------------------------------------------#
sub protected {
    my $dir_pr="$start_work_dir$in{'workdir'}";
    my $login_pr=shift;
    my $pass_pr=shift;

open TEMP,">$dir_pr/.htaccess";
print TEMP qq{AuthName "Input password"
AuthType Basic
AuthUserFile "$dir_pr/.htpasswd"
<Files *.*>
require valid-user
</Files>}; close TEMP;

    if ($passtext) {
        open TEMP,">$dir_pr/.htpasswd";
        print TEMP "$login_pr:$pass_pr\x0A";
        close TEMP;
    } else {
        if (!-e ">$dir_pr/.htpasswd") {open(TT, ">$dir_pr/.htpasswd");close TT}
        $pwdFile = new Htpasswd ("$dir_pr/.htpasswd");
        return "0" unless $pwdFile->htpasswd("$login_pr","$pass_pr");
    }
}

#-----------------------------------------------------------#
sub showusers {
my $viewfile="$start_work_dir$in{'workdir'}/.htpasswd";
print qq{<script language="JavaScript">
<!--
function SubmitGoToOp(stepin)
{
 document.work.step.value=stepin; 
 document.work.submit();
}
//-->
</script>
<form name=work method=POST action=$script_name>
<input type=hidden name=workdir value="$in{'workdir'}">
<input type=hidden name=step value=0>
<table width="600" border="0" cellspacing="0" cellpadding="1" bgcolor=black ><tr><td>
<table width="600" border="0" cellspacing="1" cellpadding="1" bgcolor=#F9F1D7>};

    open (TEMP,"<$viewfile"); @tempdb=<TEMP>;
    $sizetempdb=@tempdb; close(TEMP);
    for ($i=0;$i<=$sizetempdb;$i++) {
        chomp($tempdb[$i]);
        if ($tempdb[$i]) {
            @user0=split(/:/,$tempdb[$i]);
            if ($to_check eq "checked") {$to_check=""}
            $to_check="checked";
            print qq~
            <tr>
            <td align=left width=10"><input type=radio $to_check name=user value=$user0[0]></td>
            <td align=left">$user0[0]</td>
            </tr>
            ~;
        }
   }
print qq{</table></td></tr>
<tr><td bgcolor=#F7E09A>
<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor=#F9F1D7>
<tr><td align=left rowspan=3><input type="button" value="������� ������������" onclick="SubmitGoToOp(1)"><br>
<input type="button" value="������� ������ �� >>" onclick="SubmitGoToOp(2)">&nbsp;<input type=password name=cpassword size=10><br>
<input type="button" value="*** ����� ������ ***" onclick="SubmitGoToOp(4)"><br></td>
<td align=right bgcolor=#F7E09A>login&nbsp;<input type=text name=name size=10></td></tr>
<tr><td align=right bgcolor=#F7E09A>password&nbsp;<input type=password name=password size=10></td></tr>
<tr><td colspan=2 align=right bgcolor=#F7E09A><input type="button" value="�������� >>" onclick="SubmitGoToOp(3)"></td></tr></table>
</td></tr>
</table></form><br>
};
}


#-----------------------------------------------------------#
sub pr_workdir {
$bigmassearsh[0]=$start_work_dir;
$sdir0=0; $nomer=0;
my $temp_print0="";
$temp_print0="\n<select name=workdir>\n";
if ((-e "$bigmassearsh[0]/.htpasswd") and (-e "$bigmassearsh[0]/.htaccess")) {$to_passwd="[*]";$to_passwd0="style=\"{color: red;}\""}
if (!$in{'workdir'}) {$to_select="selected"}
$temp_print0.="<option $to_select $to_passwd0 value=\"\/\">\/ $to_passwd</option>\n";
for ($i=0;$i<=$nomer;$i++) {
    opendir (MEMBERDIR, "$bigmassearsh[$i]");
    @sdir = readdir(MEMBERDIR); closedir (MEMBERDIR);
    $sdir0=-1; $sdir0=@sdir;
    for ($l=0;$l<$sdir0;$l++) {
    if (-d "$bigmassearsh[$i]/$sdir[$l]" and $sdir[$l] ne "." and $sdir[$l] ne "..") {
         $nomer+=1;
         $bigmassearsh[$nomer]="$bigmassearsh[$i]/$sdir[$l]";
        if ($to_passwd) {$to_passwd="";$to_passwd0=""}
        if ((-e "$bigmassearsh[$nomer]/.htpasswd") and (-e "$bigmassearsh[$nomer]/.htaccess")) {$to_passwd="[*]";$to_passwd0="style=\"{color: red;}\""}
         $to_print=$bigmassearsh[$nomer];
         $to_print =~ s/$bigmassearsh[0]//igm;
        if ($to_select eq "selected") {$to_select=""}
        if ($to_print eq $in{'workdir'}) {$to_select="selected"}
        $temp_print0.="<option $to_select $to_passwd0 value=\"$to_print\">$to_print $to_passwd</option>\n";
    }
    }
}
$temp_print0.="</select>\n";
return $temp_print0;
}