package Htpasswd;

#
#   AUTHOR INFORMATION
#    Copyright 1998, 1999, 2000, Kevin Meltzer. All rights reserved. It may be used and modified freely, but I do request that
#    this copyright notice remain attached to the file. You may modify this module as you wish, but if you redistribute a
#    modified version, please attach a note listing the modifications you have made.
#
#    Address bug reports and comments to: perlguy@perlguy.com
#

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
#use strict;

use POSIX qw ( SEEK_SET SEEK_END );
use Fcntl qw ( LOCK_EX LOCK_UN );

@ISA = qw(Exporter);
@EXPORT = qw();
@EXPORT_OK = qw(htpasswd htDelete fetchPass htCheckPassword error Version);
%EXPORT_TAGS = (all => [@EXPORT_OK]);
($VERSION = substr(q$Revision: 1.3 $, 10)) =~ s/\s+$//;

sub Version {
    return $VERSION;
}

#-----------------------------------------------------------#
# Public Methods
#-----------------------------------------------------------#

sub new {
    my ($proto, $passwdFile) = @_;

    my $class = ref($proto) || $proto;
    my ($self) = {};
    bless ($self, $class);

    $self->{'PASSWD'} = $passwdFile;
    $self->{'ERROR'} = "";
    $self->{'LOCK'} = 0;
    $self->{'OPEN'} = 0;
    
    return $self;
}

#-----------------------------------------------------------#

sub error {
    my ($self) = @_;
    return $self->{'ERROR'};
}

#-----------------------------------------------------------#

sub htCheckPassword {
    my ($self) = shift;
    my ($Id, $pass) = @_;

    my ($cryptPass) = $self->fetchPass($Id);
    if (!$cryptPass) { return undef; }
    my ($fooCryptPass) = $self->CryptPasswd($pass, $cryptPass);
    if ($fooCryptPass eq $cryptPass) {return 1}
    else {
        $self->{'ERROR'} = __PACKAGE__."::htCheckPassword - Passwords do not match.";
        return 0;
    }
}

#-----------------------------------------------------------#

sub htpasswd {
    my ($self) = shift;
    my ($Id) = shift;
    my ($newPass) = shift;
    my ($oldPass) = @_ if (@_);
    my ($noOld)=0;

    if (!defined($oldPass)) { $noOld=1;}
    if (defined($oldPass) && $oldPass =~ /^\d$/) {
        if ($oldPass == 1) {
            $newPass = $Id unless $newPass;
            my ($newEncrypted) = $self->CryptPasswd($newPass);
            return $self->writePassword($Id, $newEncrypted);
        }
    }

# New Entry
if ($noOld == 1) {
    my ($passwdFile) = $self->{'PASSWD'};

    # Encrypt new password string
    my ($passwordCrypted) = $self->CryptPasswd($newPass);
    $self->_open();
    if ($self->fetchPass($Id)) {
        # User already has a password in the file. 
        $self->{'ERROR'} = __PACKAGE__. "::htpasswd - $Id already exists in $passwdFile";
        $self->_close();  
        return undef;
    } else {
        # If we can add the user.
        seek(FH, 0, SEEK_END);
        print FH "$Id\:$passwordCrypted\n";
        $self->_close();  
        return 1;
    }
    $self->_close();

} # end if $noOld == 1
else {
    $self->_open();
    my ($exists) = $self->htCheckPassword($Id, $oldPass);
    if ($exists) {
        my ($newCrypted) = $self->CryptPasswd($newPass);
        return $self->writePassword($Id, $newCrypted);
    } else {
        # ERROR returned from htCheckPass
        $self->{'ERROR'} = __PACKAGE__."::htpasswd - Password not changed.";
        return undef;
    }
    $self->_close();
    }
} # end htpasswd

#-----------------------------------------------------------#

sub htDelete {
    my ($self, $Id) = @_;
    my ($passwdFile) = $self->{'PASSWD'};
    my (@cache);
    my ($return);

    # Loop through the file, building a cache of exising records
    # which don't match the Id.

    $self->_open();
    seek(FH, 0, SEEK_SET);
    while (<FH>) {
        if (/^$Id\:/) {$return = 1}
        else {push(@cache, $_)}
    }
    # Write out the @cache if needed.
    if ($return) {
        # Return to beginning of file
        seek(FH, 0, SEEK_SET);
        while (@cache) {print FH shift (@cache)}
        # Cut everything beyond current position
        truncate(FH, tell(FH));
    } else {
        $self->{'ERROR'} = __PACKAGE__. "::htDelete - User $Id not found in $passwdFile: $!";
    }
    $self->_close();
    return $return;
}

#-----------------------------------------------------------#

sub fetchPass {
    my ($self) = shift;
    my ($Id) = @_;
    my ($passwdFile) = $self->{'PASSWD'};
    my $passwd = 0;

    $self->_open();
    while (<FH>) {
        chop;
        if ( /^$Id\:/ ) {
            $passwd = $_;
            $passwd =~ s/^[^:]*://;    
            last;
        }
    }
    $self->_close();
    return $passwd;
}

#-----------------------------------------------------------#

sub writePassword {
    my ($self) = shift;
    my ($Id, $newPass) = @_;
    my ($passwdFile) = $self->{'PASSWD'};
    my (@cache);
    my ($return);
    
    $self->_open();
    seek(FH, 0, SEEK_SET);
    while (<FH>) {
        if ( /^$Id\:/ ) {
            push (@cache, "$Id\:$newPass\n");
            $return = 1; 
        }
        else {push (@cache, $_)}
    }

    # Write out the @cache, if needed.
    if ($return) {
        # Return to beginning of file
        seek(FH, 0, SEEK_SET);
        while (@cache) {print FH shift (@cache)}
        # Cut everything beyond current position
        truncate(FH, tell(FH));
    } else {
        $self->{'ERROR'} = __PACKAGE__. "::writePassword - User $Id not found in $passwdFile: $!";
    }
    $self->_close();
    return $return;
}

#-----------------------------------------------------------#

sub CryptPasswd {
    my ($self) = shift;
    my ($passwd, $salt) = @_;

    if ($salt) {$salt = substr ($salt, 0, 2)}
    else {$salt = substr ($0, 0, 2)}
    return crypt ($passwd, $salt);
}

#-----------------------------------------------------------#

# Always release lock, just to be on the safe side
sub DESTROY { close(FH); };

#-----------------------------------------------------------#

    sub _lock {
    my ($self) = shift;
    # Lock if we don't have the lock
    flock(FH, LOCK_EX) if($self->{'LOCK'} == 0);
    # We have the lock
    $self->{'LOCK'} = 1;
    # Seek to head
    seek(FH, 0, SEEK_SET);
    }

#-----------------------------------------------------------#

    sub _unlock {
    my ($self) = shift;
    flock(FH, LOCK_UN);
    $self->{'LOCK'} = 0;
    }

#-----------------------------------------------------------#

sub _open {
    my ($self) = shift;

    if($self->{'OPEN'} > 0) {
    $self->{'OPEN'}++;
    $self->_lock();
    return;
    }

    my $passwdFile = $self->{'PASSWD'};
    if (!-e "$passwdFile") {
        if(!open(TT, ">$passwdFile")) {print "<font color=red>$!</font> ";return 0}
        else {close TT}
    }
    if (!open(FH,"+<$passwdFile")) {
        $self->{'ERROR'} = __PACKAGE__. "::fetchPass - Cannot open $passwdFile: $!";
        print "<font color=red>$!</font>";
    }

    $self->{'OPEN'}++;
    $self->_lock();
}

#-----------------------------------------------------------#

sub _close {
    my ($self) = shift;
    $self->_unlock();
    $self->{'OPEN'}--;
    if($self->{'OPEN'} > 0) { return; }
    if (!close(FH)) {
    my $passwdFile = $self->{'PASSWD'};
    $self->{'ERROR'} = __PACKAGE__. "::htDelete - Cannot close $passwdFile: $!";
    return undef;
    }
}

#-----------------------------------------------------------#

1; 

