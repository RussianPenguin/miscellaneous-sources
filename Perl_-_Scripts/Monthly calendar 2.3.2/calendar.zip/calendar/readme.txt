
CGI Programming by Collin Forbes
--------------------------------
    Calendar of Events 2.3.3, released 17 April 2000.

    Copyright Collin Forbes, 2000. All rights reserved.
    This program is free software; you can redistribute it and/or modify
    it under the same terms as Perl itself ( the "Artistic License" ).

Summary:
--------
    A program to show a calendar of events. Make calendars for months
    between Jan, 1970 and Dec, 2049 using customizable templates and a
    stylesheet.

Version History:
----------------
    * Version 2.3.3, released 20 April 2000
    * Version 2.3.2, released February 1999
    * Version 2.3.1, released January 1999
    * Version 2.3, released February 1998
    * Version 2.2, released August 1996
    * ...and a few earlier versions lost in the shuffle of time.

See Also:
---------
    * http://kuoi.asui.uidaho.edu/~collinf/scripts.html/calendar
    * local documentation

