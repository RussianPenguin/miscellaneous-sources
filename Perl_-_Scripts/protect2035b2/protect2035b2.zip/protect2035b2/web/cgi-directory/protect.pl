#!/usr/bin/perl

# = --------------------------------------------------------------------------
# protect.pl V 2.035b2 written by Michael Nilsson
# http://www.maze.se/freeware/
# ----------------------------------------------------------------------------
# You can use, modify and redistribute this software, provided that
# this header appear on all copies of the software
#
# This software is provided "AS IS," without a warranty of any kind.
# Michael Nilsson or Maze interactive media DON'T TAKE ANY RESPONSE
# FOR ANY DAMAGES SUFFERED AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THE SOFTWARE.
# IN NO EVENT WILL Michael Nilsson OR Maze BE LIABLE FOR ANY LOST
# REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
# CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED
# AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE
# USE OF OR INABILITY TO USE SOFTWARE, EVEN IF Maze and / or
# Michael Nilsson HAS BEEN ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGES.
#
# ----------------------------------------------------------------------------

#use strict;
srand;
my(
	$path, 
	%FORM, 
	$daynyear, 
	$date, 
	$time, 
	$exp_time, 
	@http_ref, 
	$pwfile, 
	@my_email, 
	$errlog, 
	$get_id, 
	$script, 
	$startfile, 
	$file_ext, 
	$id_file, 
	$ref_time, 
	$redir, 
	$max_lines, 
	$fetch_root, 
	$id_root, 
	$get, 
	$post,
	$ImgProtect,
	$script_name
);

# = --------------------------------------------------------------------------
# Require user configuration.
# ----------------------------------------------------------------------------

# Type in the CGI-servers name e.g 
# http://www.yourdomain.com
# or http://www.myisp.com
$script = "http://www.yourdomain.com";

#* Type in the login page URL. 
$redir = "http://www.yourdomain.com/login.html";

#* Type in your e-mail address to be used in  
#* "password expired" error message.
@my_email = ('webmaster@mydomain.com');

#* Type in the address to your site after http://www. and      
#* the corresponding IP-address in this field.
@http_ref = qw(yourdomain.com localhost 127.0.0.1);

# = --------------------------------------------------------------------------
# Optional configuration.
# ----------------------------------------------------------------------------

# = -----------------------------------------------------------------------
# Un comment "#$doc_root" if you want to place your protected HTML
# , password, image and log files outside your web space.
#
# First you have to back out with a coupple of ../ e.g.
# your user name is michael and protect.pl is located in
# /some/long/path/michael/public_html/cgi-bin/protect/protectpl.pl
# Now if you want to use a derectory named 'protecthome' outside your 
# webspace $doc_root will look like  $doc_root = "../../../protecthome";
# -------------------------------------------------------------------------
#$doc_root = "../../../protecthome";

#* This is the start page when you log in
$startfile = "index.html";

#* This is the file extension on all protected pages
#* exept the start page.
$file_ext = ".html";

#* This is the password file.
$pwfile = "pwd.dat";

#* This is the error log file.
$errlog = "errlog.dat";

#* This is the temporary id file.
$id_file = "id.dat";

# = --------------------------------------------------------------------------
# End of user data.
# ----------------------------------------------------------------------------

#* Enable output autoflush.
$| = 1;

#* This is the max number of lines
#* in the id.dat file.
$max_lines = 50;

# > -----------------------------------------------------------------------
# This hack returns pwd on UNIX and Win32.
# -------------------------------------------------------------------------
sub get_path {	
	my ($cwd, $proname, $scrname, $propath);
	use Cwd;
		($cwd = cwd() ) =~ s#\\#/#g;
		($proname = $0) =~ s#\\#/#g;
		($scrname = $proname) =~ s/.*\/\Z?//i;
		($propath = $proname) =~ s/$scrname//i;
		if (-e "$cwd/$scrname") {
			$path = "$cwd/";
		} elsif (-e "$propath$scrname") {
			$path = "$propath";	
		} else {
			print "Content-type: text/html\n\n"; 
			print "<H1>Error: can't get path</H1>\n";
		}
		$path =~ s#/+#/#g;
	
	
		my $n_bref = $doc_root =~ s/\.\.\///g;
		my @get_path = split /\//, $path;
	
		for (my $i = 0; $i < $n_bref; $i++) {
			pop @get_path;
		}
	
	my $new_path;
	
	foreach (@get_path) {
		$new_path .= "$_/";
	}
	
	$doc_root .= "/" if $doc_root;
	
	$path = "$new_path$doc_root";
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Check HTTP referer.
# -------------------------------------------------------------------------
sub check_url {
	my(
		$ref, 
		$match
	);
	if ($ENV{'HTTP_REFERER'}) {
		foreach $ref (@http_ref) {
			if ($ENV{'HTTP_REFERER'} =~ m#.*?://.*?$ref/.*#i) {
				$match = 1;
				last;
			}
		}
	}
	else {
		$match = 0;
	}
	if ($ENV{'HTTP_REFERER'} && ($match == 0) ) {
		error_url();
		exit;
	}
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Read from standard in.
# -------------------------------------------------------------------------
sub read_input { 
	my(
		$input, 
		@pairs, 
		$pair, 
		$name, 
		$value
	);
	
	if ($ENV{'REQUEST_METHOD'} eq "GET") { 
    	$input = $ENV{'QUERY_STRING'};
		$get = 1;
	} 
	elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
		read (STDIN, $input, $ENV{'CONTENT_LENGTH'});
		$post = 1;
	}
	else {
		#* Offline mode goes here.
	}
	
	@pairs = split(/&/, $input);
	
	foreach $pair (@pairs) {
	
		($name, $value) = split(/=/, $pair);
		
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		#* Erase everything exept [0-9 a-z A-Z/-]
		$value =~ s/[^0-9a-z\/\-_]//gi;
		$name =~ s/[^0-9a-z]//gi;
		
		$FORM{$name} = $value;				
	}
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# insert the full path in front of filenames.
# -------------------------------------------------------------------------
sub add_path {
	$pwfile = "$path$pwfile";
	$errlog = "$path$errlog";
	$id_file = "$path$id_file";
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Get local time and do some formatting.
# -------------------------------------------------------------------------
sub get_time {
	my(
		$year, 
		$mon, 
		$day, 
		$hour, 
		$min, 
		$sec
	);

	($daynyear,$year,$mon,$day,$hour,$min,$sec) 
	= (localtime(time))[7,5,4,3,2,1,0];
	
	$mon++;
	
	$year = $year + 1900;
	
	if ($mon > 12) { #* Ops we got an error here.
		$mon = 0;
	}
	
	$date = sprintf(qq/%04d%02d%02d/,$year,$mon,$day);
	$time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Set expiry time for temp-id.
# -------------------------------------------------------------------------
sub set_exp_time {
	my(
		$hour, 
		$min, 
		$add_min, 
		$exp_hour
	);
	
	($hour, $min, $_ ) = split(/:/, $time);
	$add_min = $min + 60;
	
		if ($add_min > 59) {
			$exp_hour = $hour;
			$exp_hour++;	
		}
		
	$exp_time = qq/$date$daynyear$exp_hour$min/;
	$ref_time = qq/$date$daynyear$hour$min/;
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Check Password.
# -------------------------------------------------------------------------
sub check_pw {
	my(
		@pwfile, 
		$loginname, 
		$passwd, 
		$exp_date, 
		$root, 
		$line, 
		$match
	);
	
	$fetch_root = 0;
	open(PWFILE, "$pwfile") || die &error_file;
		while(<PWFILE>) {
		
			chomp;		
			@pwfile = split(/\n/);
			
			foreach $line (@pwfile) {
				next if /#.*/;
				($loginname, $passwd, $exp_date, $root) = split(/::/, $line);
				$root =~ s/[^0-9a-z\/]//gi;
				
				if($passwd eq $FORM{'pass'} && $loginname eq $FORM{'login'}) {
					if($exp_date > $date) {
						$match = 1;
						$fetch_root = $root;
					}
					else {
						#* Password is outdated
						error_expdate();
						exit;
					}
	
				}
			}
			
		}
		
		close(PWFILE);
		
		#* If we get a match, go to login
		if ($match == 1) {
			#* Get the teporary id and write it to id file.
			make_id();
			#* Truncate temporary id files.
			truncate_id_files();
			#* Login
			login();
		}
		else {
			#* Wrong password, write to the errorlog file and 
			#* print an error message to the browser.
			open(FILE, ">>$errlog") || die &error_file;
			print FILE "Date:     $date\n";
			print FILE "Time:     $time\n";
			print FILE "Host:     $ENV{REMOTE_HOST} \n";
			print FILE "IP:       $ENV{REMOTE_ADDR} \n";
			print FILE "Name:     $FORM{'login'}\n";
			print FILE "Passwd:   $FORM{'pass'}\n";
			print FILE "-" x 25;
			print FILE "\n";
			close(FILE);
	
			print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>401 Authorization Required</TITLE>
</HEAD>
<BODY>
<H1>401 Authorization Required</H1>
This server could not verify that you are authorized to access 
the document you requested.
Either you supplied the wrong credentials (e.g., bad password), 
or your browser doesn't understand how to supply the credentials 
required.
</BODY>
</HTML>
END_of_html
		exit;
	}
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Log in and filter the protected page 
# (process protected links etc).
# -------------------------------------------------------------------------
sub login {
	my ($file, $begin_url, $end_url, @link_list, $link, $out_html, 
		$FormFile, $get_path, $get_file, $page, $home, $frames, 
		$frame, $urls, $url, $imgs, $img, $bg_img);

	$begin_url = "$script?file=";
	$FormFile = $FORM{'file'};
	($home  = $startfile) =~ s/\..*//gi;
	
	if ($FormFile =~ m|(.*/)(.*)|) {
		$get_path = $1;
		$get_file = $2;
	}
	else {
		$get_file =$FormFile;
	}

	if ($post) {
		$end_url = "&id=$get_id";
		$file = "$path$fetch_root\/$startfile";
		$file =~ s|/+|/|g;
	}
	elsif ($get) {
		$end_url = "&id=$FORM{'id'}";
		$file = "$path$id_root\/$get_path$get_file$file_ext";
		$file =~ s|/+|/|g;
	}
	else {
		&redir;
		exit;
	}

	open (INFILE, "$file") || die error_file();

	while(<INFILE>) {
		chomp;
		$out_html .= "$_\n";
		$frames = $_;
		$urls = $_;
		$imgs = $_;
		$bg_img = $_;
		$frames =~ s|<FRAME.*?(SRC=".*?").*?>|push(@link_list, $1)|gie;
		$urls =~ s|(~&.*?&~)|push(@link_list, $1)|gie;
		$imgs =~ s|<(IMG SRC=".*?").*?>|push(@link_list, $1)|gie;
		$bg_img =~ s|(BACKGROUND=".*?")|push(@link_list, $1)|gie;
		s|(HREF=".*?")|push(@link_list, $1)|gie;
	}
	close INFILE;

	my ($n_bref, @get_path);

	foreach $link (@link_list) {
		$n_bref = $link =~ s|(\.\./)|$1|g;
	
		@get_path = split '/', $get_path;

		for (my $i = 0; $i < $n_bref; $i++) {
			pop @get_path;
		}
		my ($new_path);
		foreach (@get_path) {
			$new_path .= "$_/";
		}
		
		my $ref = $link;
		$ref =~ s|\.\./||g;
		
		($page = $ref) =~ s/HREF="(.*?)\.(.*?)"/$1/gi;
		
		if ($link =~ m/HREF="mailto:.*?"/i) {next}
		if ($link =~ m/HREF="http.*?"/i) {next}
		if ($link =~ m/SRC="http.*?"/i) {next}
		if ($link =~ m/IMG SRC="http.*?"/i) {next}
		if ($link =~ m/BACKGROUND="http.*?"/i) {next}
		
		if ( ($img = $link) =~ s|BACKGROUND="(.*?\..*?)"|$1|gi ) {
			$out_html =~ s|$link|BACKGROUND="$ImgProtect\?img=$new_path$img$end_url"|gi;
		}
		elsif ( ($img = $link) =~ s|IMG SRC="(.*?\..*?)"|$1|gi ) {
			$out_html =~ s|$link|IMG SRC="$ImgProtect\?img=$new_path$img$end_url"|gi;
		}
		elsif ( ($frame = $ref) =~ s|SRC="(.*?)\.(.*?)"|$1|gi ) {
			$out_html =~ s|$link|SRC="$begin_url$new_path$frame$end_url"|gi;
		}
		elsif ($link =~ s|HREF="my\.index"||gi) {
			$out_html =~ s|$link|HREF="$begin_url$home$end_url\"|gi;
		}
		elsif ( ($url = $link) =~ s|~&(.*?)\.(.*?)&~|$1|gi ) {
			$out_html =~ s|$link|$begin_url$new_path$url$end_url|gi;
		}
		else {
			$out_html =~ s|$link|HREF="$begin_url$new_path$page$end_url\"|gi;
		}
	
	}

	print "Content-type: text/html\n\n";
	print $out_html;
	exit;
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Make the temp-id.
# -------------------------------------------------------------------------
sub make_id {
	my(
		$crypt, 
		$case
	);
	
	#* Make a temporary id by randomizing time and pid 
	$get_id = time();
	$get_id .= abs $$;
	$get_id = int (rand($get_id));
	$crypt = $get_id;
	$case = (int rand(4));
	
	if (0 ==  $case) {
		$crypt =~ tr/0-4/l-z/;
		$crypt .= int (abs (rand($$)));
		$crypt =~ tr/5-9/A-K/;
	}
	elsif (1 == $case) {
		$crypt =~ tr/0-4/a-k/;
		$crypt .= int (abs (rand($$)));
		$crypt =~ tr/5-9/L-Z/;
	}
	elsif (2 == $case) {
		$crypt =~ tr/0-7/A-K/;
		$crypt .= int (abs (rand($$)));
		$crypt =~ tr/8-9/l-z/;
	}
	elsif (3 == $case) {
		$crypt =~ tr/0-2/a-k/;
		$crypt .= int (abs (rand($$)));
		$crypt =~ tr/3-9/L-Z/;
	}
	
	$get_id = $crypt;
	
	#* Print temporary id to user id file
	open (FILE, ">>$id_file") || die error_file();     
	print FILE "$exp_time\::$get_id\::$fetch_root\n";
	close FILE;
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Truncate temporary id files.
# -------------------------------------------------------------------------
sub truncate_id_files {
	my(
		$truncate, 
		$lines, 
		@idfile, 
		$line, 
		$id_time, 
		$id, 
		$keep
	);
	
	$truncate = 0;
	$lines = 0;
	
	open(IDFILE, "$id_file") || die &error_file;
	
	while(<IDFILE>) {
	
		chomp;		
		@idfile = split(/\n/);
		
		foreach $line (@idfile) {
			($id_time, $id) = split(/::/, $line);
			$lines++;
			
			if ( ($lines > $max_lines) && ($id_time < $ref_time) ) {
				$truncate = 1;
			}
			if ($id_time > $ref_time) {
				$keep .= "$line\n";
			}
		}
		
	}
	
	if ($truncate == 1) {
		open(IDFILE, ">>$id_file") || die error_file();
		truncate IDFILE, 0;
		print IDFILE "$keep";
		print "$keep";
	}
	
	close(IDFILE);
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Check id.
# -------------------------------------------------------------------------
sub check_id {
	my(
		@idfile, 
		$id_time, 
		$id, 
		$root, 
		$line, 
		$match
	);
	
	$id_root = 0;

	if ($get) {
		open(IDFILE, "$id_file") || die &error_file;
		while(<IDFILE>) {
		chomp;		
		@idfile = split(/\n/);
			foreach $line (@idfile) {
				($id_time, $id, $root) = split(/::/, $line);
				$root =~ s/[^0-9a-z\/]//gi;
				
				if($id_time > $ref_time && $id eq $FORM{id}) {
					$match = 1;
				}
			}
		}
		close(IDFILE);
		
		if($match == 1) {
			$id_root = $root;	
			login();
		}
		else {
    		redir();
			exit;
		}
		
	}
	else {
    	redir();
		exit;
	}
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Redirect to the login page
# -------------------------------------------------------------------------
sub redir {
	print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>404 $!</TITLE>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
	setTimeout ("changePage()", 1);function changePage(){
	window.location.href="$redir";}
	//-->
	</SCRIPT>
	<META HTTP-EQUIV="Refresh" CONTENT="1;URL=$redir">
</HEAD>
<BODY>
</BODY>
</HTML>
END_of_html
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Print file not found error message
# to the browser
# -------------------------------------------------------------------------
sub error_file {
	print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>404 File not found</TITLE>
</HEAD>
<BODY>
<H1>404 File not found</H1>
$!.
</BODY>
</HTML>
END_of_html
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Print wrong HTTP referer error message
# to the browser
# -------------------------------------------------------------------------
sub error_url {
	print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>403 Forbidden</TITLE>
</HEAD>
<BODY>
<H1>403 Forbidden</H1>
You don't have permission to access  this script.
</BODY>
</HTML>
END_of_html
}
# < -----------------------------------------------------------------------

# > -----------------------------------------------------------------------
# Print password expired, error message
# to the browser
# -------------------------------------------------------------------------
sub error_expdate {
	print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>401 Password Expired</TITLE>
</HEAD>
<BODY>
<H1>401 Password expired</H1>
Please contact the webmaster.
<P><A HREF="mailto:@my_email">@my_email</A>
</BODY>
</HTML>
END_of_html
}
# < -----------------------------------------------------------------------

# = --------------------------------------------------------------------------
# 
# ----------------------------------------------------------------------------

#* Add the server address to the script URL.
$script .= $ENV{'SCRIPT_NAME'};

#* This is the name of the Image protection script.
($script_name = $script) =~ s/.*\/\Z?//i;
($ImgProtect = $script) =~ s/$script_name/ImgProtect.pl/i;

#* Get pwd on UNIX and Win32.
get_path();		

#* Check HTTP referer.
check_url();

#* Read from standard input.
read_input();	

#* Add path to files.
add_path();

#* Get localtime.
get_time();

#* Set the expiry time for temp id.
set_exp_time();

#* Check if this is a POST or a GET.
if ($get) {
	#* Check temporary id

	check_id();

	exit;
}
elsif ($post) {
	#* Check password and login.
	check_pw();
	exit;
}
else {
	redir();
	exit;
}

sub ResponseWrite {
	my $msg = shift;
	print "Content-type: text/html\n\n$msg";
	
}
sub getNewPath {
	my $path = shift;
	my ($new_path);
	
	$path =~ s|\.\./|__split__|;
	
	(my $a, my $b) = split '__split__', $path;
	
	$a =~ s|/$||;
	
	if ($b) {
		$b = '../' . $b;
	}
	
	my $n_bref = $b =~ s|\.\./||g;

	my @get_path = split '/', $a;

	for (my $i = 0; $i < $n_bref; $i++) {
		pop @get_path;
	}
	
	foreach (@get_path) {
		$new_path .= "$_/";
	}
	my $strOut = $new_path . $b;
	$strOut =~ s|/$||;
	return $strOut;
}
#* EOF

