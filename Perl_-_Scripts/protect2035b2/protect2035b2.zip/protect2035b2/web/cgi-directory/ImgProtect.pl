#!/usr/bin/perl

# = ----------------------------------------------------------------------
# ImgProtect.pl V 1.02b2 written by Michael Nilsson
# http://www.maze.se/freeware
#
# You can use, modify and redistribute this software, provided that
# this header appear on all copies of the software
#
# This software is provided "AS IS," without a warranty of any kind.
# Michael Nilsson or Maze interactive media DON'T TAKE ANY RESPONSE
# FOR ANY DAMAGES SUFFERED AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THE SOFTWARE.
# IN NO EVENT WILL Michael Nilsson OR Maze BE LIABLE FOR ANY LOST
# REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
# CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED
# AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE
# USE OF OR INABILITY TO USE SOFTWARE, EVEN IF Maze and / or
# Michael Nilsson HAS BEEN ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGES.
#
# -------------------------------------------------------------------------

#use strict;
my ($path, %FORM, $date, $time, $ref_time, $exp_time, $img, $broken_img,
	$id_file, $get, $post, $id_root, $doc_root);

# = -----------------------------------------------------------------------
# Optional configuration.
# -------------------------------------------------------------------------

# = -----------------------------------------------------------------------
# Un comment "#$doc_root" if you want to place your protected HTML
# , password, image and log files outside your web space.
#
# First you have to back out with a coupple of ../ e.g.
# your user name is michael and protectpl.cgi is located in
# /some/long/path/michael/public_html/cgi-bin/protect/protectpl.cgi
# Now if you want to use a derectory named 'protecthome' outside your 
# webspace $doc_root will look like  $doc_root = "../../../protecthome";
# -------------------------------------------------------------------------
#$doc_root = "../../../protecthome";

#* This is the temporary id file.
$id_file = "id.dat";

# = -----------------------------------------------------------------------
# End of user data.
# -------------------------------------------------------------------------

#* Enable autoflush.
$| = 1;

&read_input;
&get_path;
&get_time;
&set_exp_time;

$id_file = $path . $id_file;
&check_id;

$id_root =~ s|/||;
$id_root .= '/';
$img = $path . $id_root . getNewPath($FORM{'img'});

&push_image;

# > -----------------------------------------------------------------------
# Read from standard in.
# -------------------------------------------------------------------------
sub read_input { 
	my ($input, @pairs, $pair, $name, $value);
	
	if ($ENV{'REQUEST_METHOD'} eq "GET") { 
    	$input = $ENV{'QUERY_STRING'};
		$get = 1;
	} 
	elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
		read (STDIN, $input, $ENV{'CONTENT_LENGTH'});
		$post = 1;
	}
	else {
		#* Offline mode goes here.
	}
	
	@pairs = split(/&/, $input);
	
	foreach $pair (@pairs) {
	
		($name, $value) = split(/=/, $pair);
		
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		#* Erase everything exept [0-9 a-z A-Z/-]
		$value =~ s/[^0-9a-z\/\-_\.]//gi;
		$name =~ s/[^0-9a-z]//gi;
		
		$FORM{$name} = $value;				
	}
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# This hack returns pwd on UNIX and Win32.
# -------------------------------------------------------------------------
sub get_path {	
my($cwd, $proname, $scrname, $propath);
use Cwd;
	($cwd = cwd() ) =~ s|\\|/|g;
	($proname = $0) =~ s|\\|/|g;
	($scrname = $proname) =~ s/.*\/\Z?//i;
	($propath = $proname) =~ s/$scrname//i;
	if (-e "$cwd/$scrname") {
		$path = "$cwd/";
	} elsif (-e "$propath$scrname") {
		$path = "$propath";	
	} else {
		print "Content-type: text/html\n\n"; 
		print "<H1>Error: can't get path</H1>\n";
	}
	$path =~ s|/+|/|g;

	my $n_bref = $doc_root =~ s/\.\.\///g;
	my @get_path = split /\//, $path;
	for (my $i = 0; $i < $n_bref; $i++) {
		pop @get_path;
	}
	my $new_path;
	foreach (@get_path) {
		$new_path .= "$_/";
	}
	$doc_root .= "/" if $doc_root;
	$path = "$new_path$doc_root";
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# Get local time and do some formatting.
# -------------------------------------------------------------------------
sub get_time {
	my ($year, $mon, $day, $hour, $min, $sec);
	
	($year,$mon,$day,$hour,$min,$sec) 
	= (localtime(time))[5,4,3,2,1,0];
	$mon++;
	if ($mon > 12) { #* Ops we got an error here.
		$mon = 0;
	}
	$year += 1900;
	$date = sprintf(qq/%04d%02d%02d/,$year,$mon,$day);
	$time = sprintf("%02d:%02d:%02d",$hour,$min,$sec);
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# Set expiry time for temp-id.
# -------------------------------------------------------------------------
sub set_exp_time {
	my ($hour, $min, $add_min, $exp_hour);
	($hour, $min, $_ ) = split /:/, $time;
	$add_min = $min + 60;
		if ($add_min > 59) {
			$exp_hour = $hour;
			$exp_hour++;	
		}
	$exp_time = $date . $exp_hour . $min;
	$ref_time = $date . $hour . $min;
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# Check id.
# -------------------------------------------------------------------------
sub check_id {
	my (@idfile, $id_time, $id, $root, $line, $match);
	$id_root = 0;
	if ($get) {
		open(IDFILE, "$id_file") || 
		die print "Content-type: text/html\n\n Can't open $id_file: $!";
		
		while(<IDFILE>) {
		chomp;		
		@idfile = split(/\n/);
			foreach $line (@idfile) {
				($id_time, $id, $root) = split(/::/, $line);
				$root =~ s/[^0-9a-z\/]//gi;
					if($id_time > $ref_time && $id eq $FORM{id}) {
						$match = 1;
					}
			}
		}
		close(IDFILE);
		
		if($match == 1) {
			$id_root = $root;	
			#* Do nothing;
		}
		else {
    		&img_not_found;
			exit;
		}
	}
	else {
    	&img_not_found;
		exit;
	}
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# Push the requested image to the browser.
# -------------------------------------------------------------------------
sub push_image {
	open(IMG, "$img") || die &img_not_found;
	binmode(IMG);
	binmode(STDOUT);
	print "Content-type: image/gif\n\n";
	while (<IMG>) {
        print $_;
	}
	close(IMG);
}
# < -----------------------------------------------------------------------


# > -----------------------------------------------------------------------
# Image not found error.
# -------------------------------------------------------------------------
sub img_not_found {
	print "Content-type: text/html\n\n Can't open $img: $!";
	exit;
	}
# < -----------------------------------------------------------------------

sub ResponseWrite {
	my $msg = shift;
	print "Content-type: text/html\n\n$msg";
	
}

sub getNewPath {
	my $path = shift;
	my ($new_path);
	
	$path =~ s|\.\./|__split__|;
	
	(my $a, my $b) = split '__split__', $path;
	
	$a =~ s|/$||;
	
	if ($b) {
		$b = '../' . $b;
	}
	
	my $n_bref = $b =~ s|\.\./||g;

	my @get_path = split '/', $a;

	for (my $i = 0; $i < $n_bref; $i++) {
		pop @get_path;
	}
	
	foreach (@get_path) {
		$new_path .= "$_/";
	}
	my $strOut = $new_path . $b;
	$strOut =~ s|/$||;
	return $strOut;
}
# = -----------------------------------------------------------------------
# EOF
# -------------------------------------------------------------------------

