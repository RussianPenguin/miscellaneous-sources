#!/usr/bin/perl 

# = --------------------------------------------------------------------------
# PasswordTool.pl V 1.06b3 written by Michael Nilsson
# http://www.maze.se/freeware/
# ----------------------------------------------------------------------------
# You can use, modify and redistribute this software, provided that
# this header appear on all copies of the software
#
# This software is provided "AS IS," without a warranty of any kind.
# Michael Nilsson or Maze interactive media DON'T TAKE ANY RESPONSE
# FOR ANY DAMAGES SUFFERED AS A RESULT OF USING, MODIFYING OR
# DISTRIBUTING THE SOFTWARE.
# IN NO EVENT WILL Michael Nilsson OR Maze BE LIABLE FOR ANY LOST
# REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
# CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED
# AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE
# USE OF OR INABILITY TO USE SOFTWARE, EVEN IF Maze and / or
# Michael Nilsson HAS BEEN ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGES.
#
# ----------------------------------------------------------------------------

#use strict;
my(
	$script, 
	$pass, 
	$pwd, 
	$pwd_bak, 
	$path, 
	%FORM, 
	$comments, 
	@keys, 
	%entrys, 
	$begin, 
	$end, 
	$title, 
	$html, 
	$redirect, 
	$date, 
	$tempdate, 
	$ExpDate, 
	$body, 
	$lock, 
	@m_days, 
	@m_names, 
	$html_error_date,
	$doc_root
);

# = --------------------------------------------------------------------------
# Require user configuration.
# ----------------------------------------------------------------------------

# This is the security lock. 
# Change this to  0 to enable PasswordTool.pl
$lock = 1;

# Type in the CGI-servers name e.g 
# http://www.yourdomain.com
# or http://www.myisp.com
$script = "http://www.yourdomain.com";

# Type in a password, replace #lock# 
# with a real password e.g $pass ="ZtpoDSO-52H-tUfp";
# the available characters are: A-Z a-z and -
$pass ="#lock#";

# = --------------------------------------------------------------------------
# Optional configuration.
# ----------------------------------------------------------------------------

# = -----------------------------------------------------------------------
# Un comment "#$doc_root" if you want to place your protected HTML
# , password, image and log files outside your web space.
#
# First you have to back out with a coupple of ../ e.g.
# your user name is michael and protect.pl is located in
# /some/long/path/michael/public_html/cgi-bin/protect/protectpl.pl
# Now if you want to use a derectory named 'protecthome' outside your 
# webspace $doc_root will look like  $doc_root = "../../../protecthome";
# -------------------------------------------------------------------------
#$doc_root = "../../../protecthome";

# Name on the password file
$pwd = "pwd.dat";

# Name on the backup file
$pwd_bak = "pwd-bak.dat";

# = --------------------------------------------------------------------------
# End of user data.
# ----------------------------------------------------------------------------

#* Enable output autoflush.
$| = 1;

if ($lock == 1) {
print "Content-type: text/html\n\n"; 
print "<CENTER><H1>## <FONT COLOR=\"Red\">
LOCKED</FONT> ##</H1></CENTER>\n";
exit;
}

@m_days = qw(31 28 31 30 31 30 31 31 30 31 30 31);

# Month of the year.
@m_names = qw(January February March April May June 
July August September October November December);

# Add the server address to the script URL.
$script .= $ENV{'SCRIPT_NAME'};

# Get pwd on UNIX and Win32.
&get_path;

# Check if the password file exists.
&find_pwd;

# Read from standard input.
&read_input;

# Check password
&check_pass;

# Read file.
&read_file;


if ($FORM{action} eq "login") {
# Create the main page.
&main_page;
}

if ($FORM{action} eq "edit") {
&edit_user;
}

if ($FORM{action} eq "EditUser") {
&get_date;
	if($FORM{user} && $FORM{pass}) {
	&EditFile_EditUser;
	}
	else {
	&error_missing;
	}
}

if ($FORM{action} eq "delete") {
&delete_user;
}

if ($FORM{action} eq "DeleteUser") {
&EditFile_DeleteUser;
}

if ($FORM{action} eq "UndoLast") {
&undo_last;
}

if ($FORM{action} eq "AddNew") {
&new_user;
}

if ($FORM{action} eq "WriteNew") {
&get_date;
if($FORM{user} && $FORM{pass}) {
	&EditFile_AddUser;
	}
	else {
	&error_missing;
	}
}

# Print HTML.
&print_html;

# > -----------------------------------------------------------------------
# This hack returns pwd on UNIX and Win32.
# -------------------------------------------------------------------------
sub get_path {	
my(
	$cwd, 
	$proname, 
	$scrname, 
	$propath
);
use Cwd;
	($cwd = cwd() ) =~ s#\\#/#g;
	($proname = $0) =~ s#\\#/#g;
	($scrname = $proname) =~ s/.*\/\Z?//i;
	($propath = $proname) =~ s/$scrname//i;
	if (-e "$cwd/$scrname") {
	$path = "$cwd/";
	} elsif (-e "$propath$scrname") {
	$path = "$propath";	
	} else {
	print "Content-type: text/html\n\n"; 
	print "<H1>Error: can't get path</H1>\n";
	}
$path =~ s#/+#/#g;


my $n_bref = $doc_root =~ s/\.\.\///g;
my @get_path = split /\//, $path;
my $i;

	for ($i = 0; $i < $n_bref; $i++) {
	pop @get_path;
		
	}

my $new_path;
foreach (@get_path) {
	$new_path .= "$_/";
	}

$doc_root .= "/" if $doc_root;

$path = "$new_path$doc_root";
}
# < -----------------------------------------------------------------------

# ================================================================== #
# Check if we can find the password file
# if not complain a little bit..
# ================================================================== #

sub find_pwd {	
	if (-e "$path$pwd") {
	# Yes we found it, do nothing.
	} 
	else {
	print "Content-type: text/html\n\n"; 
	print "<CENTER><H1>*gasp* *wheez* *choke*</H1> 
<P><H3>Could not find the password file.</CENTER>
<P><TT>You must at least have an empty file named 
$pwd.
</TT></H3>\n";
	exit;
	}
} 

# ================================================================== #
# Read from standard in.
# ================================================================== #

sub read_input { 
	my(
		$input, 
		@pairs, 
		$pair, 
		$name, 
		$value
	);
	
	if ($ENV{'REQUEST_METHOD'} eq "GET") { 
    	$input = $ENV{'QUERY_STRING'};
		$get = 1;
	} 
	elsif ($ENV{'REQUEST_METHOD'} eq "POST") {
		read (STDIN, $input, $ENV{'CONTENT_LENGTH'});
		$post = 1;
	}
	else {
		#* Offline mode goes here.
	}
	
	@pairs = split(/&/, $input);
	
	foreach $pair (@pairs) {
	
		($name, $value) = split(/=/, $pair);
		
		$name =~ tr/+/ /;
		$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		
		$value =~ tr/+/ /;
		$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

		#* Erase everything exept [0-9 a-z A-Z/-_:]
		$value =~ s/[^0-9a-z\/\-_:]//gi;
		$name =~ s/[^0-9a-z]//gi;
		
		$FORM{$name} = $value;
	}
}
# ================================================================== #
# Check the admin password.
# ================================================================== #

sub check_pass {
	if ($FORM{pwd} eq $pass) {
	# Do nothing.
	}
	else {
	&login;
	exit;
	}
}

# ================================================================== #
# Read the password file and do some sorting.
# ================================================================== #

sub read_file{
my(
	@all, 
	$line, 
	$loginname, 
	$passwd, 
	$exp_date, 
	$root, 
	$line
);
open (INFILE, "$path$pwd") || die &error_file;

	while(<INFILE>) {
		chomp;
		@all = split(/\n/);	
		foreach $line (@all) {
		chomp $line;
		if (/#.*/){
		$comments .= "$line\n";
		next;
		}
		($loginname, $passwd, $exp_date, $root) = split(/::/, $line);
		$entrys{$loginname} = join("::", $passwd, $exp_date, $root);
		}
	}
close INFILE;
@keys = sort { lc($a) cmp lc($b) }keys %entrys;	
}

# ================================================================== #
#
# ================================================================== #

sub main_page {
my(
	$loginname, 
	$sorted_user, 
	$passwd, 
	$exp_date, 
	$root, 
	$edit, 
	$delete, 
	$row
);
	foreach $loginname (@keys) {
		$sorted_user = "$loginname\::$entrys{$loginname}\n";
		($loginname, $passwd, $exp_date, $root) = split(/::/, $sorted_user);
		$edit = "<A HREF=\"$script?pwd=$FORM{pwd}\&action=edit&user=$loginname\">Edit</A>";
		$delete = "<A HREF=\"$script?pwd=$FORM{pwd}\&action=delete&user=$loginname\">Delete</A>";
		$row .= "<TR BGCOLOR=\"Teal\"><TD>$edit</TD><TD>$delete</TD><TD>$begin$loginname$end\</TD><TD>$passwd\</TD><TD>$exp_date\</TD><TD>$root</TD></TR>\n";
	}
$title = "PasswordTool";
$body = "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"White\" LINK=\"White\" VLINK=\"White\">";
$html = "<CENTER><H1><FONT COLOR=\"Maroon\">PasswordTool.pl</FONT></H1></CENTER>
<CENTER><TABLE CELLSPACING=10 WIDTH=\"100\" BORDER=0>
<TR><TD COLSPAN =2>&nbsp\;</TD>
<TD ALIGN=\"RIGHT\"><FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"AddNew\">
<INPUT TYPE=\"SUBMIT\" VALUE=\" New \"></FORM></TD>
<TD><FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"UndoLast\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"Undo\"></FORM></TD>
<TD COLSPAN =2>&nbsp\;</TD></TR>
</TABLE>
<TABLE BGCOLOR=\"Maroon\" CELLSPACING=1 WIDTH=\"600\" BORDER=0>
<TR><TD COLSPAN =2>&nbsp\;</TD><TH>User name</TH>
<TH>Password</TH><TH>Date of expiry</TH><TH>Root</TH></TR>
\n$row\</TABLE></CENTER>\n";
}

# ================================================================== #
# Get local time and do some formatting.
# ================================================================== #

sub get_date {
my(
	$year, 
	$mon, 
	$day, 
	$m_days, 
	$exp_day, 
	$exp_mon
);
($year,$mon,$day) = (localtime(time))[5,4,3];
$mon++;
$year = $year + 1900;
	if ($mon > 12) { # Ops we got an error here.
	$mon = 0;
	}
$date = sprintf(qq/%04d%02d%02d/,$year,$mon,$day);
$exp_mon = ((localtime(time))[4]) + 1;
$exp_day = $m_days[$exp_mon];
$exp_mon++;
	if ($exp_mon > 12) { # Ops we got an error here.
	$exp_mon = 1;
	$exp_day = $m_days[($exp_mon + 1)];
	}
$tempdate = sprintf(qq/%04d%02d%02d/,$year,$exp_mon,$exp_day);
}

# ================================================================== #
# Check if it's a leap year
# ================================================================== #

sub is_leap_year {
    my $nYear = shift;

  return 0 unless $nYear % 4 == 0;
  return 1 unless $nYear % 100 == 0;
  return 0 unless $nYear % 400 == 0;
  return 1;
}

# ================================================================== #
# Edit user.
# ================================================================== #

sub edit_user {
my(
	$sorted_user, 
	$loginname, 
	$passwd, 
	$exp_date, 
	$root, 
	$ref, 
	$edit_user, 
	$edit_pwd, 
	$edit_date, 
	$edit_root
);
	foreach $loginname (@keys) {
	$sorted_user = "$loginname\::$entrys{$loginname}\n";
	($loginname, $passwd, $exp_date, $root) = split(/::/, $sorted_user);
		if ($loginname eq $FORM{user}) {
		$ref = $sorted_user;
		$edit_user = $loginname;
		$edit_pwd = $passwd;
		$edit_date = $exp_date;
		chomp ($edit_root = $root);
		}
	}
$title = "Edit User";
$body = "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"White\" LINK=\"White\" VLINK=\"White\">";
$html = "<FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"EditUser\">
<INPUT TYPE=\"HIDDEN\" NAME=\"DeleteRef\" VALUE=\"$ref\">
<INPUT TYPE=\"HIDDEN\" NAME=\"user\" VALUE=\"$edit_user\">
<INPUT TYPE=\"HIDDEN\" NAME=\"redir\" VALUE=\"edit\">
<CENTER><H1><FONT COLOR=\"Maroon\">Edit user</FONT></H1></CENTER>
<CENTER><TABLE BGCOLOR=\"Maroon\" CELLSPACING=0 WIDTH=\"600\" BORDER=0>
<TR><TD COLSPAN=\"4\">&nbsp\;</TD></TR>
<TR><TH>User name</TH><TH>Password</TH>
<TH>Date of expiry</TH><TH>Root</TH></TR>
<TR><TD COLSPAN=\"4\">&nbsp\;</TD></TR>
<TR><TD ALIGN=\"CENTER\">$edit_user</TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"pass\" VALUE=\"$edit_pwd\"></TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"date\" VALUE=\"$edit_date\"></TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"root\" VALUE=\"$edit_root\"></TD></TR>
<TR><TD COLSPAN=\"4\">&nbsp\;</TD></TR>
<TR><TD COLSPAN=\"4\">&nbsp\;</TD></TR>
</TABLE></CENTER>\n<P>&nbsp\;
<CENTER><INPUT TYPE=\"SUBMIT\" VALUE=\"Done\"></CENTER>
</FORM>\n";
}

# ================================================================== #
# Edit file (edit user)
# ================================================================== #

sub EditFile_EditUser {
	my ($old_list, $new_list, $CleanUser, $CleanPass, $loginname, 
		$sorted_user, $row, $CleanDate, $BaseRoot);
	$old_list .= $comments;
	$new_list .= $comments;
	$CleanUser = $FORM{user};
	$CleanUser =~ s/[^a-z0-9\-]//gi;
	$CleanPass = $FORM{pass};
	$CleanPass =~ s/[^a-z0-9\-]//gi;
	$CleanDate = $FORM{date};
	$CleanDate =~ s/[^0-9:]//gi;
	if ($CleanDate) {
		$ExpDate = $CleanDate;
	}
	else {
		$ExpDate = $tempdate;
	}
	# check the date format
	&check_date_format;
	if ($FORM{root}) {
		$BaseRoot = "/$FORM{root}";
	}
	else {
		$BaseRoot = "/";
	}
	$BaseRoot =~ s#/+#/#g;
	$BaseRoot =~ s/[^0-9a-z\/]//gi;
	foreach $loginname (@keys) {
		$sorted_user = "$loginname\::$entrys{$loginname}\n";
		$old_list .= $sorted_user;
		$new_list .= $sorted_user;
		$new_list =~ s/$FORM{'DeleteRef'}//g;
		$new_list =~ s/^\n//m;
		$row = "<TR><TD>$CleanUser\</TD><TD>$CleanPass\</TD><TD>$ExpDate\</TD><TD>$BaseRoot\</TD></TR>\n";
	}
	$new_list .= join("::", $CleanUser, $CleanPass, $ExpDate, $BaseRoot);
	
	open(BAKFILE, ">>$path$pwd_bak") || die &error_file;
	truncate BAKFILE, 0;
	print BAKFILE "$old_list";
	close(BAKFILE);
	
	open(INFILE, ">>$path$pwd") || die &error_file;
	truncate INFILE, 0;
	print INFILE "$new_list\n";
	close(INFILE);
	
	$title = "User data changed";
	$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
	function changePage(){\n
	window.location.href=\"$script?pwd=$FORM{pwd}\&action=login\"\
	;}\n//-->\n</SCRIPT>\n
	<META HTTP-EQUIV=\"Refresh\" 
	CONTENT=\"1;URL=$script?pwd=$FORM{pwd}\&action=login\">\n";
	$body = "<BODY OnLoad=\"changePage()\">\n";
	$html = "";
}

# ================================================================== #
# Delete user.
# ================================================================== #

sub delete_user {
my(
	$loginname, 
	$sorted_user, 
	$user, $passwd, 
	$exp_date, 
	$root, 
	$ref, 
	$row
);
	foreach $loginname (@keys) {
	$sorted_user = "$loginname\::$entrys{$loginname}\n";
	($loginname, $passwd, $exp_date, $root) = split(/::/, $sorted_user);
		if ($FORM{user} eq $loginname) {
		$user = $loginname;
		$ref = $sorted_user;
		$row .= "<TR BGCOLOR=\"Teal\"><TD>$begin$loginname$end\</TD><TD>$passwd\</TD>
<TD>$exp_date\</TD><TD>$root</TD></TR>\n";
		}
	}
$title = "Delete User";
$body = "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"White\" LINK=\"White\" VLINK=\"White\">";
$html = "<CENTER><H1><FONT COLOR=\"Maroon\">Delete user</FONT></H1></CENTER>
<CENTER><TABLE BGCOLOR=\"Maroon\" CELLSPACING=1 WIDTH=\"600\" BORDER=0>
<TR><TH>User name</TH><TH>password</TH>
<TH>Date of expiry</TH><TH>Root</TH></TR>
$row\</TABLE></CENTER>
<CENTER><H3><FONT COLOR=\"Red\">DELETE USER?</B></H3></CENTER>
<CENTER><TABLE CELLSPACING=10 WIDTH=\"150\" BORDER=0>
<TR><TD COLSPAN =\"2\">&nbsp\;</TD>
<TD ALIGN=\"RIGHT\"><FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"DeleteRef\" VALUE=\"$ref\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"DeleteUser\">
<INPUT TYPE=\"HIDDEN\" NAME=\"user\" VALUE=\"$user\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"YES\"></FORM></TD>
<TD><FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"login\">
<INPUT TYPE=\"SUBMIT\" VALUE=\" NO \"></FORM></TD>
<TD COLSPAN =\"2\">&nbsp\;</TD>
</TR>
</TABLE></CENTER>\n";
}

# ================================================================== #
# Edit file (delete user).
# ================================================================== #

sub EditFile_DeleteUser {
my(
	$old_list, 
	$new_list, 
	$loginname, 
	$sorted_user
);
$old_list .= $comments;
$new_list .= $comments;
	foreach $loginname (@keys) {
	$sorted_user = "$loginname\::$entrys{$loginname}\n";
	$old_list .= $sorted_user;
	$new_list .= $sorted_user;
	$new_list =~ s/$FORM{DeleteRef}//g;
	$new_list =~ s/^\n//m;
	}
open(BAKFILE, ">>$path$pwd_bak") || die &error_file;
truncate BAKFILE, 0;
print BAKFILE "$old_list";
close(BAKFILE);

open(INFILE, ">>$path$pwd") || die &error_file;
truncate INFILE, 0;
print INFILE "$new_list";
close(INFILE);

$title = "User deleted";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=login\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"1;URL=$script?pwd=$FORM{pwd}\&action=login\">\n";
$body = "<BODY OnLoad=\"changePage()\">\n";
$html = "";
}

# ================================================================== #
# Undo last and restore from pwd.bak
# ================================================================== #

sub undo_last {
my(@old);
open(BAKFILE, "$path$pwd_bak") || die &error_file;
@old = <BAKFILE>;
close(BAKFILE);

open(PWDFILE, ">>$path$pwd") || die &error_file;
truncate PWDFILE, 0;
print PWDFILE @old;
close(PWDFILE);
$title = "Undo";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=login\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"1;URL=$script?pwd=$FORM{pwd}\&action=login\">\n";
$body = "<BODY OnLoad=\"changePage()\">\n";
$html = "";
}

# ================================================================== #
# Add new user.
# ================================================================== #

sub new_user {
$title = "New user";
$body = "<BODY BGCOLOR=\"#FFFFFF\" TEXT=\"White\" LINK=\"White\" VLINK=\"White\">";
$html = "<CENTER><FONT COLOR=\"Maroon\"><H1>New user</H1></FONT></CENTER>
<FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"WriteNew\">
<INPUT TYPE=\"HIDDEN\" NAME=\"redir\" VALUE=\"AddNew\">
<CENTER><TABLE  BGCOLOR=\"Maroon\" CELLSPACING=0 WIDTH=\"600\" BORDER=0>
<TR><TD COLSPAN =4>&nbsp\;</TD></TR>
<TR><TH>User name</TH><TH>Password</TH>
<TH>Date of expiry</TH><TH>Root</TH></TR>
<TR><TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"user\" ></TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"pass\" VALUE=\"\"></TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"date\" VALUE=\"\"></TD>
<TD ALIGN=\"CENTER\"><INPUT TYPE=\"TEXT\" NAME=\"root\" VALUE=\"\"></TD></TR>
<TR><TD COLSPAN =4>&nbsp\;</TD></TR>
<TR><TD COLSPAN =4>&nbsp\;</TD></TR>
</TABLE></CENTER><P>&nbsp\;
<CENTER><INPUT TYPE=\"SUBMIT\" VALUE=\"   Add   \">
</FORM>
<FORM ACTION=\"$script\" METHOD=\"POST\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"Cancel\">
<INPUT TYPE=\"HIDDEN\" NAME=\"pwd\" VALUE=\"$FORM{pwd}\">
<INPUT TYPE=\"HIDDEN\" NAME=\"action\" VALUE=\"login\">
</FORM></CENTER>\n";
}

# ================================================================== #
# Edit file (add user).
# ================================================================== #

sub EditFile_AddUser {
my(
	@old, 
	$CleanUser, 
	$CleanPass, 
	$CleanDate, 
	$BaseRoot, 
	$loginname, 
	$sorted_user, 
	$passwd, 
	$exp_date, 
	$root
);
$CleanUser = $FORM{user};
$CleanUser =~ s/[^a-z0-9\-]//gi;
$CleanPass = $FORM{pass};
$CleanPass =~ s/[^a-z0-9\-]//gi;
$CleanDate = $FORM{date};
$CleanDate =~ s/[^a-z0-9:]//gi;
	if ($CleanDate) {
	$ExpDate = $CleanDate;
	}
	else {
	$ExpDate = $tempdate;
	}
# check the date format
&check_date_format;
	if ($FORM{root}) {
	$BaseRoot = "/$FORM{root}";
	}
	else {
	$BaseRoot = "/";
	}
$BaseRoot =~ s#/+#/#g;
$BaseRoot =~ s/[^0-9a-z\/]//gi;
	foreach $loginname (@keys) {
		$sorted_user = "$loginname\::$entrys{$loginname}\n";
		($loginname, $passwd, $exp_date, $root) = split(/::/, $sorted_user);
		chomp ($loginname);
			if ($CleanUser eq $loginname) {
			&error_used;
			&print_html;
			}
	}
open(PWDFILE, "$path$pwd") || die &error_file;
@old = <PWDFILE>;
close(PWDFILE);
open(BAKFILE, ">>$path$pwd_bak") || die &error_file;
truncate BAKFILE, 0;
print BAKFILE @old;
close(BAKFILE);

open(PWDFILE, ">>$path$pwd") || die &error_file;
print PWDFILE "$CleanUser\::$CleanPass\::$ExpDate\::$BaseRoot\n";
close(PWDFILE);

$title = "User Added";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=login\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"1;URL=$script?pwd=$FORM{pwd}\&action=login\">\n";
$body = "<BODY OnLoad=\"changePage()\">\n";
$html = "";
}

# ================================================================== #
# Create file not found error message.
# ================================================================== #

sub error_file {
$title = "404 $!";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
setTimeout (\"changePage()\", 6000)\;function changePage(){\n
window.location.href=\"$script\"\;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" CONTENT=\"6;URL=$script\">\n";
$html = "<H1>$!</H1>\n<H3><TT>The requested file 
was not found on this server.</TT></H3>\n";
}

# ================================================================== #
# Print HTML to the browser.
# ================================================================== #

sub print_html {
print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>$title</TITLE>
$redirect
</HEAD>
$body
$html
</BODY>
</HTML>
END_of_html
exit;
}

# ================================================================== #
# Error missing fields.
# ================================================================== #

sub error_missing {
$title = "Error Bank fields";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
setTimeout (\"changePage()\", 6000)\;function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"6;URL=$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\">\n";
$html = "\n<CENTER><H1>Error missing fields!</H1><P><H3><TT>
You can't have blank user or password fields.<TT></H3><CENTER>\n";
}

# ================================================================== #
# Error (Username used).
# ================================================================== #

sub error_used {
$title = "Error user name";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
setTimeout (\"changePage()\", 6000)\;function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"6;URL=$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\">\n";
$html = "\n<CENTER><H1>Error!</H1><P><H3><TT>
Username \"$FORM{user}\" is allready in use.<TT></H3><CENTER>\n";
}

# ================================================================== #
# Login form.
# ================================================================== #

sub login {
# Print the LogIn form to the browser
print <<END_of_html;
Content-type: text/html

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"> 
<HTML>
<HEAD>
	<TITLE>PasswordTool</TITLE>
</HEAD>
<BODY BGCOLOR="#FFFFFF" onLoad="document.forms[0].pwd.focus()">
<FORM ACTION="$script" METHOD="POST">
<INPUT TYPE="HIDDEN" NAME="action" VALUE="login">
<CENTER><H1><FONT COLOR="Maroon">PasswordTool.pl</FONT></H1></CENTER>
<CENTER>
<TABLE CELLSPACING=5 WIDTH="110" BORDER=0>
<TR>
	<TD ALIGN="CENTER">
	<INPUT TYPE="PASSWORD" NAME="pwd">
	</TD>
	<TD ALIGN="CENTER">
	<INPUT TYPE="SUBMIT" VALUE="Login">
	</TD>
</TR>
</TABLE>
</CENTER>
</FORM>
</BODY>
</HTML>
END_of_html
exit;
}

# ================================================================== #
# Check the date format.
# ================================================================== #

sub check_date_format {
my(
	$numbers, 
	$input_date, 
	$inp_days
);

$numbers = $ExpDate =~ tr/[0-9]/[0-9]/;
	# Complain a bit if date contains 
	# illegal characters.
	$input_date = $ExpDate;
	if ($input_date =~ /[^0-9]/) {
	$html_error_date = "The date format is yyyymmdd.";
	&error_date_format;
	}
	elsif ($numbers == 8) {
	$input_date =~ s/(\d{4})(\d{2})(\d{2})/$1$2$3/;

	$inp_days = $2 - 1;
            if (is_leap_year($1) && $inp_days == 1) {$m_days[$inp_days]++}

			if ( ($2 < 1 || $2 > 12) || ($3 < 1 || $3 > $m_days[$inp_days]) ) {
			if( ($3 > $m_days[$inp_days]) && ($2 > 0 && $2 < 13) ) {
				if($input_date < $date) {
				$html_error_date = "I'ts not usefull to enter an old date to day it's $date";
				&error_date_format;
				}
			$html_error_date = "Sorry, $m_names[$inp_days] Year $1 only have $m_days[$inp_days] days.";
			}
			else {
			$html_error_date = "The date format is yyyyddmm.";
			}
		&error_date_format;
		}
	
	}
	else {
	$html_error_date = "The date format is yyyymmdd.";
	&error_date_format;
	}
	if($input_date < $date) {
	$html_error_date = "I'ts not usefull to enter an old date to day it's $date";
	&error_date_format;
	}
}

# ================================================================== #
# Error wrong date format.
# ================================================================== #

sub error_date_format {
$title = "Error wrong format";
$redirect = "<SCRIPT LANGUAGE=\"JavaScript\">\n<!--\n
setTimeout (\"changePage()\", 10000)\;function changePage(){\n
window.location.href=\"$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\"\
;}\n//-->\n</SCRIPT>\n
<META HTTP-EQUIV=\"Refresh\" 
CONTENT=\"10;URL=$script?pwd=$FORM{pwd}\&action=$FORM{redir}&user=$FORM{user}\">\n";
$html = "\n<CENTER><H1>Error wrong format!</H1><P><H3><TT>
$html_error_date <TT></H3><CENTER>\n";
&print_html;
exit;
}

sub ResponseWrite {
	my $msg = shift;
	print "Content-type: text/html\n\n$msg";
	
}

# ================================================================== #
# EOF
# ================================================================== #
