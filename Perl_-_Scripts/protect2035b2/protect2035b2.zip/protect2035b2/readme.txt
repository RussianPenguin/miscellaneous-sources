 # ----------------------------------------------------------------------------
 # Protect.pl, PasswordTool.pl and ImgProtect.pl Read Me File.
 # protect.pl V 2.035b2
 # PasswordTool.pl V 1.06b2
 # ImgProtect.pl V 1.02b2
 # written by Michael Nilsson
 # http://www.maze.se/freeware/
 # ----------------------------------------------------------------------------
 # You can use, modify and redistribute this software, provided that
 # this header appear on all copies of the software
 #
 # This software is provided "AS IS," without a warranty of any kind.
 # Michael Nilsson or Maze interactive media DON'T TAKE ANY RESPONSE
 # FOR ANY DAMAGES SUFFERED AS A RESULT OF USING, MODIFYING OR
 # DISTRIBUTING THE SOFTWARE.
 # IN NO EVENT WILL Michael Nilsson OR Maze BE LIABLE FOR ANY LOST
 # REVENUE, PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL,
 # CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED
 # AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING OUT OF THE
 # USE OF OR INABILITY TO USE SOFTWARE, EVEN IF Maze and / or
 # Michael Nilsson HAS BEEN ADVISED OF THE POSSIBILITY OF
 # SUCH DAMAGES.
 #
 # ----------------------------------------------------------------------------

 # ================================================================== #
 This readme file only covers the configuration of protect.pl
 to read the full documentation and the FAQ visit
 http://www.maze.se/freeware and follow the link Perl CGI scripts 
 and then the link protect.pl Readme & FAQ.

 # ================================================================== #
 If you are upgrading from a previous version of protect.pl 
 and PasswordTool.pl see UPGRADE.txt
 
 # ================================================================== #
 Release Notes See 2035b2history.txt

 # ================================================================== #
 Configure the protect.pl V 2.035b2 script:
 
 If you are hosted on a Win95/NT server see the 
 "Can I run protect.pl on Windows NT?" question in the protect.pl FAQ.

 You can find the protect.pl FAQ at http://www:maze.se/freeware 
 , follow the link Perl CGI scripts and than the link protect.pl 
 Readme & FAQ.
 

 Required 
 

 1. Make sure that the top line of the script matches
    the location of you Perl interpreter (If you are hosted on an
	Win95/NT server you don't have to care about this).
�
   You can find the location of your perl interpreter on your system,
   by executing the command: 'which perl' at the Unix command prompt.
   A typical use of this command looks like this:
�
   $ which perl
   /usr/local/bin/perl
   $ 
�
   In this case, you have just found that the location of Perl on your
   system to be "/usr/local/bin/perl".
   To update the protect.pl script, you need to append this value to
   '#!'. So, for this example, the first line in the protect.pl
   script should look like:
�
   #!/usr/local/bin/perl
�
 2. Type in the CGI server name, e.g. http://www.myisp.com, 
    http://www.mydomain.com, http://cgi.myisp.com or whatever 
    that makes sense on your system.

    $script = "http://www.myisp.com"; 

 3. Type in the full URL to the login page e.g.
    http://myisp.com/~myname/login.html or 
    http://mydomain.com/login.html.

    $redir = "myisp.com/~myname/login.html"; 

 4. Type in your e-mail address to be used in "password expired" 
    error message.

    @my_email = ('me@myserviceprovider.com'); 

 5. Type in the address to your site after http://www and the 
    corresponding IP-address in this field e.g.

    @http_ref = qw(myserviceprovider.com/~myaddress 193.45.67.8);

    or

    @http_ref = qw(mydomain.com 193.45.67.8);

    If you don't now your IP adress see the 
    "Do I really need to enter the IP address?" question
	in the protect.pl FAQ.
   
    You can find the protect.pl FAQ at http://www:maze.se/freeware 
    , follow the link Perl CGI scripts and than the link protect.pl 
    Readme & FAQ.

 # ================================================================== #

 Optional

 This is the start page.
 $startfile = "index.html"; 

 This is the file extension on all protected pages except the start page.
 $file_ext = ".html"; 

 This is the password file.
 $pwfile = "pwd.dat"; 

 This is the error log file.
 $errlog = "errlog.dat";

 This is the temporary id file.
 $id_file = "id.dat";

 # ================================================================== #

 Configure the login.html file:
�
 Simply change the line 
 <FORM ACTION="http://???.com~???/cgi-bin/protect.pl" METHOD="POST">
�
 to match your address
�
 # ================================================================== #

 Configure the protected .html files 
 
 No configuring required, Protect.pl V 2.035b2 reads standard html files.

 # ================================================================== #

 Configure the pwd.dat file:
�
 This file contains your valid users and passwords.

 You can edit the pwd.dat file by hand in your favorite text editor or 
 use PasswordTool.pl. 

 The format is
 login name::password::date of expiry::/root

 The available characters for the user name are:
 A-Z a-z 0-9 
 
 The available characters for the password are:
 A-Z a-z 0-9 and -

 The date format is "yyyymmdd". 

 The root is a subdirectory to the protect.pl directory.

 In this way you can restrict access for different users to specified 
 subdirectories in the pwd.dat file. 

 A user can never move up to higher level directory than the specified
 root in the pwd.dat file. 

 For example, suppose that you want to add a user with user name
 "Michael", password "hello", date of expiry December 24 1998 and
 the root "/michael" than the pwd.dat file should look like this:
�
 Michael::hello::19981224::/michael 
�
�You can have unlimited number of users, simply type in one user on
 each line. 
�
 loginname1::password1::yyyymmdd::/rootaaa
 loginname2::password2::yyyymmdd::/rootaaa/directorybbb
 loginname3::password3::yyyymmdd::/rootbbb
 loginname4::password4::yyyymmdd::/

 # ================================================================== #

�
 Copy the files in this package to your web server: 
�
 1. MAKE SURE THAT YOUR FTP CLIENT IS SET TO ASCII MODE, if you use
    binary or auto the script will be messed up.
    This is one of the most usual reasons why scripts won't work and 
    cause a server error.
    I do this by mistake my self from time to time, so be sure to 
    check this twice if you having trouble to make the script work.
�
 2. Transfer a copy of the files protect.pl, pwd.dat, pwd-bak.dat, 
    id.dat, errlog.dat to your cgi-bin directory.
�
 3. Transfer a copy all your protected .html files to your cgi-bin
    directory or directories under the "protected root"
    ("protected root" = the protect.pl directory).
� 
 4. Transfer a copy of the login.html file to your web directory.
�
 # ================================================================== #

 Set the file access permissions when you are using a CGI wrapper:

�It's higly recomended to use a CGI wrapper, see the 
 "Can I run protect.pl without a CGI wrapper?" question in the FAQ.
 
 You can find the protect.pl FAQ at http://www:maze.se/freeware 
 , follow the link Perl CGI scripts and than the link protect.pl 
 Readme & FAQ.

 1. Login to your web server with your telnet client
 �
 2. Go to your cgi-bin directory and execute the command:
    chmod 600 *.txt
�
 3. Execute the command:
    chmod 600 *.dat

 4. Execute the command:
    chmod 700 protect.pl
�
�
 5. Execute the command:
    chmod 600 *.html in all directories where your protected .html pages lives.
�
 6. Verify the file access permission settings by execute the command:
    ls -l
�
 The important here is the file name to the right and file
 access permission settings to the left, there are also some
 information like file size etc in between but we don't have to take 
 notice on that for now. 
�
 -rw------- � errlog.dat
 -rw------- � ???.html
 -rwx------ � protect.pl
 -rw------- � pwd.dat
 -rw------- � pwd-bak.dat
�-rw------- � id.dat

# ================================================================== #
 Set the file access permissions when you don't have a CGI wrapper:
�
 It's higly recomended to use a CGI wrapper, see the 
 "Can I run protect.pl without a CGI wrapper?" question in the FAQ.
 
 You can find the protect.pl FAQ at http://www:maze.se/freeware 
 , follow the link Perl CGI scripts and than the link protect.pl 
 Readme & FAQ.

 1. Login to your web server with your telnet client
 �
 2. Go to your cgi-bin directory and execute the command:
    chmod 666 *.txt
�
 3. Execute the command:
    chmod 666 *.dat

 4. Execute the command:
    chmod 755 protect.pl
�
�
 5. Execute the command:
    chmod 644 *.html in all directories where your protected .html pages lives.
�
 6. Verify the file access permission settings by execute the command:
    ls -l
�
 The important here is the file name to the right and file
 access permission settings to the left, there are also some
 information like file size etc in between but we don't have to take 
 notice on that for now. 
�
 -rw-rw-rw- � errlog.dat
 -rw-r--r-- � ???.html
 -rwxr-xr-x � protect.pl
 -rw-rw-rw- � pwd.dat
 -rw-rw-rw- � pwd-bak.dat
�-rw-rw-rw- � id.dat

# ================================================================== #
 File descriptions:
�
 errlog.dat
 This is the log file that stores information on all failed logins.
 The only way to read this is to use your FTP client or your favorite 
 text editor on your UNIX server.
 Tip. read this from time to time to find out if there are users who 
 try to guess your password and if they are close change it :).
�
 ???.html
 This is your protected files in standard html format.

 Remember to use the full url to the images
 http://myserviceprovider.com/~myaddress/some_directory/image.gif

�
 protect.pl
 This is the the "protect.pl" perl script.
�
 pwd.dat
 This is the password file.
�
 pwd-bak.dat
 This is the password backup file.

 id.dat
 This is the temporary session id file.

# ================================================================== #
 PasswordTool.pl V 1.06b2 written by Michael Nilsson
 http://www.maze.se/freeware/
# ================================================================== #
 Configure the PasswordTool.pl V 1.06b2 script: 

 Required 

 1. Make sure that the top line of the script matches
    the location of you Perl interpreter
	(see Configure the protect.pl V 2.035b2 script for details).

 2. Unlock the script by setting "lock" to 0
    Use this security lock to switch the script on / off.
 $lock = 0; 

 3. Type in the CGI server name, e.g. http://www.myisp.com, 
    http://www.mydomain.com, http://cgi.myisp.com or whatever that 
    makes sense on your system.
 $script = "http://www.myisp.com"; 

 4. Type in a password, replace #lock# with a real password 
   like ZtpoDSO-52H-tUfp or somthing like that. 
   The available characters are: A-Z a-z 0-9 and -
$pass ="MyPassword"; 

 5. Run PasswordTool.pl by entering the URL to PasswordTool.pl in 
    your browser's location window e.g. 
    http://www.yourdomain.com/cgi-bin/maybe_some_subdirectory/PasswordTool.pl
    Bookmark this URL for future use.
 
 # ================================================================== #
 ImgProtect.pl V 1.02b2 written by Michael Nilsson
 http://www.maze.se/freeware/
 # ================================================================== #
 Configure the .html pages:

 No special configuring required, protect.pl reads standard .html pages.

 # ================================================================== #
 Protect.pl converting rules for images:

 When you don't want to use ImgProtect.pl start with back references
 or by using the full URL e.g.

 <BODY BACKGROUND="http://www.maze.se/freeware/img/back1.gif"> or 
 <IMG SRC="http://www.maze.se/freeware/img/mazelogo.gif" 
 WIDTH=100 HEIGHT=64 BORDER=0 ALIGN="LEFT">
 when linking to unprotected images outside your cgi-bin.

 just enter the images exactly like you do in standard HTML pages, 
 if you can browse your protected web locally by using Open File 
 in the browser the web are ok through protect.pl and ImgProtect.pl.

 # ================================================================== #
 Setting the file access permissions on your protected images
 after transferring the images to the protected directories:

 If you have a cgi wrapper execute the command chmod 600 *.gif 
 in your protected directories containing images
 (use your FTP client or log in by Telnet).

 If you don't have a cgi wrapper, see the 
 "Can I run protect.pl without a CGI wrapper?" 
 question in the FAQ.
 
 You can find the protect.pl FAQ at http://www:maze.se/freeware 
 , follow the link Perl CGI scripts and than the link protect.pl 
 Readme & FAQ.

# ================================================================== #
 Configure the ImgProtect.pl V 1.02b2 script:

 Required 

 1. Make sure that the top line of the script matches
    the location of you Perl interpreter
    (see Configure the protect.pl V 2.035b2 script for details).

 # ================================================================== #
 Optional

 You only have to change this if you using another name
 for the temporary id file in protect.pl and PasswordTool.pl.

 $id_file = "id.dat";

 *********************************************************************

				UNIX help:

			General File Management



 Description       		UNIX Command

 ---------------------------------------------------------------------
 List files in current
 directory        		ls, ls -l, ls -la                          
 ---------------------------------------------------------------------
 Change directory		cd directoryname
                                                 
 ---------------------------------------------------------------------
 What is my current		pwd
 working directory?  			                                        
 ---------------------------------------------------------------------
 Delete file			rm filename
                                
 ---------------------------------------------------------------------
 Rename file            mv oldname newname
                         
 ---------------------------------------------------------------------
 Copy file              cp oldname newname  
                       
 ---------------------------------------------------------------------
 Edit file              pico filename      
                       
 ---------------------------------------------------------------------
 Set File Access		chmod  
 Permissions                                    
 ---------------------------------------------------------------------
 Create Directory       mkdir directoryname 
                      
 ---------------------------------------------------------------------
