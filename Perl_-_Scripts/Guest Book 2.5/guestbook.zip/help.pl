path|Server path to directory containing this cgi program, not the url
image|The URL to the directory that will be containing the images used in the GuestBook program
timezone|The timezone to be displayed in posts
timzoneoffset|The offset between the displayed timezone and the server timezone
timedisplay|The display of the time in GuestBook, 12 hour or 24 hour
datedisplay|The display of the date in GuestBook, US short, US long, Europe short, Europe long
sitename|The name of your website
siteurl|The url of your website
replyemail|Choose if you want to send a thank you email to a person posting to your GuestBook
thankyou|The thank you message that will be sent as an email to a person posting to your GuestBook
field1name|The name of the first field in your guestbook
field1type|The type of the first field in your guestbook, test or text area, text for a short amount of text and text area for a box for lots of text
field2name|The name of the second field in your guestbook, leave blank if you don't want to use
field2type|The type of the second field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field3name|The name of the third field in your guestbook, leave blank if you don't want to use
field3type|The type of the third field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field4name|The name of the fourth field in your guestbook, leave blank if you don't want to use
field4type|The type of the fourth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field5name|The name of the fifth field in your guestbook, leave blank if you don't want to use
field5type|The type of the fifth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field6name|The name of the sixth field in your guestbook, leave blank if you don't want to use
field6type|The type of the sixth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field7name|The name of the seventh field in your guestbook, leave blank if you don't want to use
field7type|The type of the seventh field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field8name|The name of the eighth field in your guestbook, leave blank if you don't want to use
field8type|The type of the eighth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field9name|The name of the ninth field in your guestbook, leave blank if you don't want to use
field9type|The type of the ninth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field10name|The name of the tenth field in your guestbook, leave blank if you don't want to use
field10type|The type of the tenhth field in your guestbook, text or text area, text for a short amount of text and text area for a box for lots of text
field1req|Will this field be required to process the guestbook posting?
field2req|Will this field be required to process the guestbook posting?
field3req|Will this field be required to process the guestbook posting?
field4req|Will this field be required to process the guestbook posting?
field5req|Will this field be required to process the guestbook posting?
field6req|Will this field be required to process the guestbook posting?
field7req|Will this field be required to process the guestbook posting?
field8req|Will this field be required to process the guestbook posting?
field9req|Will this field be required to process the guestbook posting?
field10req|Will this field be required to process the guestbook posting?
showemail|Do you want to show the posters email on the guestbook page?
headingcolor|The background color of the headings bar
bordercolor|The color of the boarder around the guestbook fields
firstaltcolor|The first of 2 alternating colors used for background in guestbook fields
guestintro|The text printed at the top of the guestbook fields when viewing the guestbook
postintro|The text printed at the top of the guestbook fields when viewing the "sign guestbook" page
postbutton|The text that is shown on the submit button when viewing the "sign guestbook" page
finish|The text shown on the page after someone successfully posts to the guestbook
error|The message that is shown when someone attempts to post to the guestbook without filling in all required guestbook fields
censor|Choose to censor or not censor the posts made to the GuestBook
censorwords|Words to be removed from posts and replaced with ****, word would replace any match of "word" with **** (ie. words would be ****s) and [word] world replace any match of "word" on its own (ie. "word" would be **** but "words" would be words)
pagelength|The number of guestbook entries to be shown on a page at one time
lefttitle|The title in the heading bar over the left column of the guestbook
righttitle|The title in the heading bar over the right column of the guestbook
signtext|The text that is displayed on the guestbook for the hyperlink to sign the guestbook
fontsize|The font size for text of the guestbook
fontcolor|The font color for text of the guestbook
fontface|The font face(type) for the text of the guestbook
