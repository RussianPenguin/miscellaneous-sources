Program by Red Dragon Enterprises at http://www.red-dragon2.com

Installing Dragon GuestBook
unzip or untar your files
upload your images to the directory you create for them (upload in binary format)
upload your .cgi and .pl files to the directory you create for them (upload in ascii format)
set chmod 744 to your .pl files
set chmod 755 to your .cgi files
set chmod 777 to your directory containing the .pl and .cgi files
make a sub-directory "posts" in your cgi directory and chmod 777 this directory
from a browser run http://yoursite/cgi-bin/gbadmin.cgi, click configure variables and setup your guestbook
now your guestbook is ready to run just make a link to your gb.cgi and you have a guestbook

If you have problems with administration program not accepting passwords upload gbadminu.cgi in place of gbadmin
and rename it to gbadmin.cgi.  This is because some systems to not properly process a crypt command.
