$faq=qq(<UL>
<LI><FONT COLOR="#0000FF">If html is not allowed how do I add a web link?</FONT>
	<UL>
	<LI>You can use Internal Code to add a link.
	<LI>ex. [link]www.red-dragon2.com[/link]Red Dragon Enterprises[/name]</UL>
<LI><FONT COLOR="#0000FF">If html is not allowed how do I add an email link?</FONT>
	<UL>
	<LI>You can use Internal Code to add an email link.
	<LI>ex. [email]redragon\@red-dragon.com[/email]Red Dragon[/name]</UL>
<LI><FONT COLOR="#0000FF">If html is not allowed how do I highlight something</FONT>
	<UL>
	<LI>You can use Internal Code to highlight objects in your posts
	<LI>ex. [b]<B>bold type</B>[/b] [i]<I>italic type</I>[/i] [strike]<STRIKE>strike through</STRIKE>[/strike]</UL>
<LI><FONT COLOR="#0000FF">What about those fancy smily faces I see on all the other message boards?</FONT>
	<UL>
	<LI>You can use MBoard Code to create your smiley faces too.
	<LI>ex. :\) will be <IMG SRC="$imagedir/smile.gif">
	<LI>ex. ;\) will be <IMG SRC="$imagedir/wink.gif">
	<LI>ex. :\( will be <IMG SRC="$imagedir/frown.gif">
	<LI>ex. :D will be <IMG SRC="$imagedir/grin.gif">
	<LI>ex. :o will be <IMG SRC="$imagedir/emb.gif"></UL>
</UL>);
1;
