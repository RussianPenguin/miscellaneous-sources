#if !defined(AFX_FORMDEMO_H__CF97DAD6_E9D1_11D3_8D23_0000E8D9FD76__INCLUDED_)
#define AFX_FORMDEMO_H__CF97DAD6_E9D1_11D3_8D23_0000E8D9FD76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FormDemo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFormDemo form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CFormDemo : public CFormView
{
protected:
	CFormDemo();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFormDemo)

// Form Data
public:
	//{{AFX_DATA(CFormDemo)
	enum { IDD = IDD_FORMDEMO_FORM };
	CString	m_str;
	double	m_double;
	long	m_long;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormDemo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFormDemo();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFormDemo)
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
// CFormDemoDoc document

class CFormDemoDoc : public CDocument
{
protected:
	CFormDemoDoc();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFormDemoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFormDemoDoc)
	public:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
	protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFormDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFormDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORMDEMO_H__CF97DAD6_E9D1_11D3_8D23_0000E8D9FD76__INCLUDED_)
