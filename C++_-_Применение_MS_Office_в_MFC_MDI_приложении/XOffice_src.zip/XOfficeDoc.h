// XOfficeDoc.h : interface of the CXOfficeDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_XOFFICEDOC_H__04DE9784_E920_11D3_8D22_0000E8D9FD76__INCLUDED_)
#define AFX_XOFFICEDOC_H__04DE9784_E920_11D3_8D22_0000E8D9FD76__INCLUDED_

#include "resource.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CXOfficeCntrItem;

class CXOfficeDoc : public COleDocument,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CXOfficeDoc, &CLSID_Document>,
	public IConnectionPointContainerImpl<CXOfficeDoc>,
	public IDispatchImpl<IDocument, &IID_IDocument, &LIBID_XOfficeLib>
{
protected: // create from serialization only
	CXOfficeDoc();
	DECLARE_DYNCREATE_ATL(CXOfficeDoc)

public:

	CXOfficeCntrItem *m_ctrl;
	CString           m_template;
	CString           m_str;
	double            m_double;
	long              m_long;

	bool LoadTemplate();

DECLARE_REGISTRY_RESOURCEID(IDR_DOCUMENT)
DECLARE_NOT_AGGREGATABLE(CXOfficeDoc)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CXOfficeDoc)
	COM_INTERFACE_ENTRY(IDocument)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CXOfficeDoc)
END_CONNECTION_POINT_MAP()

// IDocument
public:

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CXOfficeDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	protected:
	virtual BOOL SaveModified();
	//}}AFX_VIRTUAL

// Implementation
public:
	STDMETHOD(get_PLong)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_PLong)(/*[in]*/ long newVal);
	STDMETHOD(get_PDouble)(/*[out, retval]*/ double *pVal);
	STDMETHOD(put_PDouble)(/*[in]*/ double newVal);
	STDMETHOD(get_PStr)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_PStr)(/*[in]*/ BSTR newVal);
  virtual ~CXOfficeDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
  //{{AFX_MSG(CXOfficeDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XOFFICEDOC_H__04DE9784_E920_11D3_8D22_0000E8D9FD76__INCLUDED_)
