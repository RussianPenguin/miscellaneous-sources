// FormDemo.cpp : implementation file
//

#include "stdafx.h"
#include "XOffice.h"
#include "FormDemo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFormDemo

IMPLEMENT_DYNCREATE(CFormDemo, CFormView)

CFormDemo::CFormDemo()
	: CFormView(CFormDemo::IDD)
{
	//{{AFX_DATA_INIT(CFormDemo)
	m_str = _T("");
	m_double = 0.0;
	m_long = 0;
	//}}AFX_DATA_INIT
}

CFormDemo::~CFormDemo()
{
}

void CFormDemo::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFormDemo)
	DDX_Text(pDX, IDC_EDIT1, m_str);
	DDX_Text(pDX, IDC_EDIT2, m_double);
	DDX_Text(pDX, IDC_EDIT3, m_long);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFormDemo, CFormView)
	//{{AFX_MSG_MAP(CFormDemo)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormDemo diagnostics

#ifdef _DEBUG
void CFormDemo::AssertValid() const
{
	CFormView::AssertValid();
}

void CFormDemo::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFormDemo message handlers
/////////////////////////////////////////////////////////////////////////////
// CFormDemoDoc

IMPLEMENT_DYNCREATE(CFormDemoDoc, CDocument)

CFormDemoDoc::CFormDemoDoc()
{
}

BOOL CFormDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CFormDemoDoc::~CFormDemoDoc()
{
}


BEGIN_MESSAGE_MAP(CFormDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CFormDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFormDemoDoc diagnostics

#ifdef _DEBUG
void CFormDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFormDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFormDemoDoc serialization

void CFormDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CFormDemoDoc commands

void NewXOfficeDoc(LPCTSTR,LPCTSTR,double,long);

void CFormDemo::OnButton1() 
{
	UpdateData();
	NewXOfficeDoc("XOffice.doc",m_str,m_double,m_long);
}

void CFormDemo::OnButton2()
{
	UpdateData();
	NewXOfficeDoc("XOffice.xls",m_str,m_double,m_long);
}
