//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XOffice.rc
//
#define IDI_WORD9                       5
#define IDR_XOFFICTYPE_CNTR_IP          6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_TO_CREATE            102
#define IDR_XOFFICE                     103
#define IDR_APPLICATION                 104
#define IDR_DOCUMENT                    105
#define IDD_FORMDEMO_FORM               106
#define IDR_FORMDEMO_TMPL               107
#define IDR_MAINFRAME                   128
#define IDR_XOFFICTYPE                  129
#define IDI_WORD8                       156
#define IDI_EXCEL8                      157
#define IDI_EXCEL9                      257
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define ID_CANCEL_EDIT_CNTR             32768

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
