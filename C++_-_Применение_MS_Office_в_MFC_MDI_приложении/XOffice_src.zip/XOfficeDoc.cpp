// XOfficeDoc.cpp : implementation of the CXOfficeDoc class
//

#include "stdafx.h"
#include "XOffice.h"

#include "XOfficeDoc.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static CString g_template;
static CString g_str;
static double  g_double;
static long    g_long;

void NewXOfficeDoc(LPCTSTR aTemplate,LPCTSTR aStr,
				   double aDouble,long aLong)
{
	CString   str;
	POSITION  pos = AfxGetApp()->GetFirstDocTemplatePosition();
	while (pos != NULL) {
		CDocTemplate *temp = AfxGetApp()->GetNextDocTemplate(pos);
		ASSERT(temp != 0);
		ASSERT_KINDOF(CDocTemplate,temp);

		if (temp->GetDocString(str,CDocTemplate::docName) &&
			str == _T("XOffice")) {
			g_template = aTemplate;
			g_str      = aStr;
			g_double   = aDouble;
			g_long     = aLong;
			temp->OpenDocumentFile(NULL);
			return;
		}
	}
}


/////////////////////////////////////////////////////////////////////////////
// CXOfficeDoc

IMPLEMENT_DYNCREATE_ATL(CXOfficeDoc, COleDocument)

BEGIN_MESSAGE_MAP(CXOfficeDoc, COleDocument)
  //{{AFX_MSG_MAP(CXOfficeDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, COleDocument::OnUpdatePasteMenu)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE_LINK, COleDocument::OnUpdatePasteLinkMenu)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_CONVERT, COleDocument::OnUpdateObjectVerbMenu)
	ON_COMMAND(ID_OLE_EDIT_CONVERT, COleDocument::OnEditConvert)
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, COleDocument::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, COleDocument::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, COleDocument::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXOfficeDoc construction/destruction

CXOfficeDoc::CXOfficeDoc()
: m_ctrl(0)
{
	// Use OLE compound files
	EnableCompoundFile();
}

CXOfficeDoc::~CXOfficeDoc()
{
}

BOOL CXOfficeDoc::OnNewDocument()
{
	if (!COleDocument::OnNewDocument())
		return FALSE;

	m_template = g_template;
	m_str      = g_str;
	m_double   = g_double;
	m_long     = g_long;

	return LoadTemplate();
}

/////////////////////////////////////////////////////////////////////////////
// CXOfficeDoc serialization

void CXOfficeDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring()) {
		ar << m_template << m_str << m_double << m_long;
	} else {
		ar >> m_template >> m_str >> m_double >> m_long;
	}

	// Calling the base class COleDocument enables serialization
	//  of the container document's COleClientItem objects.
//	COleDocument::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CXOfficeDoc diagnostics

#ifdef _DEBUG
void CXOfficeDoc::AssertValid() const
{
	COleDocument::AssertValid();
}

void CXOfficeDoc::Dump(CDumpContext& dc) const
{
	COleDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CXOfficeDoc commands

bool CXOfficeDoc::LoadTemplate()
{
	char path [_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir  [_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext  [_MAX_EXT];

	::GetModuleFileName(NULL,path,sizeof(path));
	_splitpath(path,      drive,dir,0,    0);
	_splitpath(m_template,0,    0,  fname,ext);
	_makepath (path,      drive,dir,fname,ext);

	{
		CWaitCursor cw;
		m_ctrl = new CXOfficeCntrItem(this,path);
	}
	if (m_ctrl == 0  ||  m_ctrl->m_isCreate == false) {
		CString str  = "Can not open the doc:\n";
		        str += path; 
		AfxMessageBox(str,MB_ICONSTOP);
		return false;
	}
	return true;
}

BOOL CXOfficeDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!COleDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	return LoadTemplate();
}

BOOL CXOfficeDoc::SaveModified() 
{
	return CDocument::SaveModified();
}

void CXOfficeDoc::OnCloseDocument() 
{
	if (m_ctrl)
	    m_ctrl->CloseDisp();
	COleDocument::OnCloseDocument();
}

STDMETHODIMP CXOfficeDoc::get_PStr(BSTR *pVal)
{
	METHOD_PROLOGUE_ATL;

	*pVal = m_str.AllocSysString();
	return S_OK;
}

STDMETHODIMP CXOfficeDoc::put_PStr(BSTR newVal)
{
	METHOD_PROLOGUE_ATL;

	if (m_str != newVal) {
		m_str = newVal;
		SetModifiedFlag();
	}
	return S_OK;
}

STDMETHODIMP CXOfficeDoc::get_PDouble(double *pVal)
{
	METHOD_PROLOGUE_ATL;

	*pVal = m_double;
	return S_OK;
}

STDMETHODIMP CXOfficeDoc::put_PDouble(double newVal)
{
	METHOD_PROLOGUE_ATL;

	if (m_double != newVal) {
		m_double = newVal;
		SetModifiedFlag();
	}
	return S_OK;
}

STDMETHODIMP CXOfficeDoc::get_PLong(long *pVal)
{
	METHOD_PROLOGUE_ATL;

	*pVal = m_long;
	return S_OK;
}

STDMETHODIMP CXOfficeDoc::put_PLong(long newVal)
{
	METHOD_PROLOGUE_ATL;

	if (m_long != newVal) {
		m_long = newVal;
		SetModifiedFlag();
	}
	return S_OK;
}
