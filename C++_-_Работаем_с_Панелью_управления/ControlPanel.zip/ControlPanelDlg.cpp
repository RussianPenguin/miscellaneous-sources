/***********************************************************************\
*																		*
*		File Name		: ControlPanelDlg.cpp							*
*		Purpose			: Implimentation file of ControlPanel Dialog	*
*		Environment		: Win9x/NT/2000									*
*		Date			: 10th December 2000							*
*		Author			: Farooque Khan (farooquek)						*
*		Company			: ConcretioIndia Pvt. Ltd.						*
*						  www.concretioindia.com						*
*		Update History	: 												*
\***********************************************************************/


#include "stdafx.h"
#include "ControlPanel.h"
#include "ControlPanelDlg.h"
#include "cpl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_DIALOGS 50
#define MAX_CPLINFO 50

// The CPlApplet function prototype
typedef long (APIENTRY* applet_function)(HWND cplhwnd, UINT msg, LONG lparam1, LONG lparam2);

struct dialog_info
{
	// Holds the name of the applet
	char	name[32];
	// Holds the tooltip of the applet
	char	tooltip[512];
	// Holds the HICON of the applet
	HICON	icon;

};

struct 
{
	// Holds the HINSTANCE of the cpl file
	HINSTANCE		hDll;
	// The path of the cpl file
	char			filename[MAX_PATH];
	// The pointer to the CPlApplet function of above cpl file
	applet_function	entry_func;
	// Some data
	long			lData;
	// Number of dialogs supported by the cpl file
	UINT			numDialog;
	// Info of each of the dialog box (Max 50);
	dialog_info		di[MAX_DIALOGS];

}cpl_info[MAX_CPLINFO];

// This will hold the total number of cpl files
int count = 0;

// end of my data
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlPanelDlg dialog

CControlPanelDlg::CControlPanelDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CControlPanelDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CControlPanelDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CControlPanelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CControlPanelDlg)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CControlPanelDlg, CDialog)
	//{{AFX_MSG_MAP(CControlPanelDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	ON_LBN_ERRSPACE(IDC_LIST1, OnErrspaceList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CControlPanelDlg message handlers

BOOL CControlPanelDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Initialize the cpl_info structures

	for(int j=0; j<MAX_CPLINFO; j++)
	{
		cpl_info[j].hDll = NULL;
		cpl_info[j].entry_func	= NULL;
		cpl_info[j].lData		= 0;
		cpl_info[j].numDialog	= 0;

		strcpy(cpl_info[j].filename, "");

		for(int k=0;k<MAX_DIALOGS;k++)
		{

			cpl_info[j].di[k].icon = NULL;

			strcpy(cpl_info[j].di[k].name, "");
			strcpy(cpl_info[j].di[k].tooltip, "");
		}
	}

	SetWindowText("ControlPanel - Ready");
	SetTimer(1, 50, NULL);
	
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		// TODO: Use one of the following forms to add controls:101, 252, 108
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), <string-table-id>);
		m_tooltip.SetTipBkColor(RGB(101, 252, 108));
		m_tooltip.AddTool(GetDlgItem(IDC_LIST1), "Displays the Control Panel applets");
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CControlPanelDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CControlPanelDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		RECT r;
		GetWindowRect(&r);

		SetWindowPos(&wndTopMost, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_SHOWWINDOW);
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CControlPanelDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


//
// Function name	: CControlPanelDlg::OnDblclkList1
// Description	    : Called when the list box item is double clicked
// Return type		: void 
//
void CControlPanelDlg::OnDblclkList1() 
{
	char name[1024];
	int index = m_list.GetCurSel();	
	
	SetWindowText("ControlPanel - Opening...");
	m_list.GetText(index, (LPTSTR)name);
	
	for(int i=0; i<MAX_CPLINFO; i++)
	{
		for(int k=0; k<MAX_DIALOGS; k++)
		{
			if(strcmp(cpl_info[i].di[k].name, name) == 0)
				if(cpl_info[i].entry_func != NULL)
					cpl_info[i].entry_func(GetSafeHwnd(), CPL_DBLCLK, k, cpl_info[i].lData);
		}
	}
	
	SetWindowText("ControlPanel - Ready");


}

//
// Function name	: CControlPanelDlg::PostNcDestroy
// Description	    : Some clean up is done here
// Return type		: void 
//
void CControlPanelDlg::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	for(int i=0; i<count; i++)
	{
		if(cpl_info[i].entry_func != NULL)
		{
			cpl_info[i].entry_func(GetSafeHwnd(), CPL_EXIT , NULL, NULL);
			cpl_info[i].entry_func = NULL;
		}

		if(cpl_info[i].hDll != NULL)
		{
			FreeLibrary(cpl_info[i].hDll);
			cpl_info[i].hDll = NULL;
		}
	}
	
	CDialog::PostNcDestroy();
}


//
// Function name	: CControlPanelDlg::OnSize
// Description	    : List box is resized here
// Return type		: void 
// Argument         : UINT nType
// Argument         : int cx
// Argument         : int cy
//
void CControlPanelDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	if(m_list.m_hWnd != NULL)
		m_list.MoveWindow(0, 0, cx, cy);
		
}


//
// Function name	: CControlPanelDlg::OnTimer
// Description	    : Timer callback
// Return type		: void 
// Argument         : UINT nIDEvent
//
void CControlPanelDlg::OnTimer(UINT nIDEvent) 
{
	//----------------------------------------------------------------
	// We are writing this in timer notification because we don't want the user to 
	// keep looking at blank screen while the cpl files are loaded
	KillTimer(nIDEvent);
	BeginWaitCursor();
	
	m_list.ResetContent();

	SetWindowText("ControlPanel - Initializing...");

	// Free everything
	for(int i=0; i<count; i++)
	{
		if(cpl_info[i].hDll != NULL)
		{
			FreeLibrary(cpl_info[i].hDll);
			cpl_info[i].hDll = NULL;
		}
	}

	// initialize it
	for(int j=0; j<MAX_CPLINFO; j++)
	{
		cpl_info[j].hDll = NULL;
		cpl_info[j].entry_func	= NULL;
		cpl_info[j].lData		= 0;
		cpl_info[j].numDialog	= 0;

		strcpy(cpl_info[j].filename, "");

		for(int k=0;k<MAX_DIALOGS;k++)
		{
			cpl_info[j].di[k].icon = NULL;

			strcpy(cpl_info[j].di[k].name, "");
			strcpy(cpl_info[j].di[k].tooltip, "");

		}
	}

	SetWindowText("ControlPanel - Finding Files...");

	// Find the .cpl files
	int					unknown = 0;
	BOOL				bSuccess = TRUE;
	char				szwindir[MAX_PATH];
	CString				strWinDir;
	HANDLE				handle;
	WIN32_FIND_DATA		wfd;


	// Get the directory containing .cpl files
	GetWindowsDirectory(szwindir, MAX_PATH);
	strWinDir += szwindir;
	strWinDir += "\\system32\\*.cpl";

	// Find the .cpl files
	handle = FindFirstFile((LPCTSTR)strWinDir, &wfd);
	if(INVALID_HANDLE_VALUE != handle)
	{
		while(TRUE == bSuccess)
		{
			strcpy(cpl_info[count].filename, wfd.cFileName);
			bSuccess = FindNextFile(handle, &wfd);
			count ++;
		}
	}
	FindClose(handle);


	SetWindowText("ControlPanel - Loading files...");

	// Fill the cpl_info structure and the list box with the control panel applets
	CPLINFO	temp_info;
	for(i=0; i<count ; i++)
	{
		char buffer[1024];

		cpl_info[i].hDll = LoadLibrary(cpl_info[i].filename);
		if(cpl_info[i].hDll != NULL)
		{
			// Get the address of CPlAppler function
			cpl_info[i].entry_func = (applet_function)GetProcAddress(cpl_info[i].hDll, "CPlApplet");

			if(cpl_info[i].entry_func != NULL)
			{
				// Init
				cpl_info[i].entry_func(GetSafeHwnd(), CPL_INIT, NULL, NULL);
				
				// Get Count
				cpl_info[i].numDialog = cpl_info[i].entry_func(GetSafeHwnd(), CPL_GETCOUNT, NULL, NULL);
				
				for(UINT k=0; k<cpl_info[i].numDialog; k++)
				{
					// Inquire
					cpl_info[i].entry_func(GetSafeHwnd(), CPL_INQUIRE, k, (long)&temp_info);
					if(temp_info.idName != CPL_DYNAMIC_RES)
					{
						cpl_info[i].lData = temp_info.lData;

						if(LoadString(cpl_info[i].hDll, temp_info.idName, buffer, 1024) != 0)
						{
							m_list.AddString((LPCTSTR) buffer);
							strcpy(cpl_info[i].di[k].name, buffer);
						}
						else
						{
							CString t;
							t+=cpl_info[i].filename;
							CString t2 = t.Left(t.GetLength() - 4);
							m_list.AddString(t2);
							strcpy(cpl_info[i].di[k].name, (LPCTSTR)t2);
						}

						if(LoadString(cpl_info[i].hDll, temp_info.idInfo, cpl_info[i].di[k].tooltip, 511) == 0)
							strcpy(cpl_info[i].di[k].tooltip, cpl_info[i].di[k].name);

						cpl_info[i].di[k].icon = LoadIcon(cpl_info[i].hDll, MAKEINTRESOURCE(temp_info.idIcon));
					}
					else
					{
						NEWCPLINFO	new_info;
				
						if(cpl_info[i].entry_func != NULL)
							cpl_info[i].entry_func(GetSafeHwnd(), CPL_NEWINQUIRE, k, (long)&new_info);
						
						cpl_info[i].lData = new_info.lData;
						if(strlen(new_info.szName) != 0)
						{
							char temp[1024];
							WideCharToMultiByte(CP_ACP, 0, (LPWSTR)new_info.szName, sizeof(new_info.szName), temp, 1023, NULL, NULL);
							{
								m_list.AddString(temp);
								strcpy(cpl_info[i].di[k].name, temp);
							}
						}
						else
						{
							CString t;
							t+=cpl_info[i].filename;
							CString t2 = t.Left(t.GetLength() - 4);
							m_list.AddString(t2);
							strcpy(cpl_info[i].di[k].name, (LPCTSTR)t2);
						}

						if(WideCharToMultiByte(CP_ACP, 0, (LPWSTR)new_info.szInfo, sizeof(new_info.szInfo), cpl_info[i].di[k].tooltip, 511, NULL, NULL) == 0)
							strcpy(cpl_info[i].di[k].tooltip, cpl_info[i].di[k].name);

						cpl_info[i].di[k].icon = new_info.hIcon;

					}
				}
			}
		}

		m_list.UpdateWindow();
	}
	
	EndWaitCursor();
	SetWindowText("ControlPanel - Ready");

	CDialog::OnTimer(nIDEvent);
}

void CControlPanelDlg::CallOpen()
{
	OnDblclkList1();
}

void CControlPanelDlg::CallDelete()
{
	char name[1024];

	int index = m_list.GetCurSel();	
	m_list.GetText(index, (LPTSTR)name);
	
	SetWindowText("ControlPanel - Deleting...");
	for(int i=0; i<MAX_CPLINFO; i++)
	{
		for(int k=0; k<MAX_DIALOGS; k++)
		{
			if(strcmp(cpl_info[i].di[k].name, name) == 0)
			{
				char windir[MAX_PATH];
				CString path;

				GetWindowsDirectory(windir, MAX_PATH);
				path += windir;
				path += "\\system32\\";
				path += cpl_info[i].filename;

				CString temp = path.Left(path.GetLength() - 4);

				FreeLibrary(cpl_info[i].hDll);
				rename((LPCTSTR)path, (LPCTSTR)temp);
				SetTimer(1, 50, NULL);
				return;

			}
		}
	}
}

void CControlPanelDlg::OnSelchangeList1() 
{
	char name[1024];

	int index = m_list.GetCurSel();
	if(index < 0)
	{
		SetWindowText("ControlPanel - Ready");
		return;
	}

	m_list.GetText(index, (LPTSTR)name);
	
	for(int i=0; i<MAX_CPLINFO; i++)
	{
		for(int k=0; k<MAX_DIALOGS; k++)
		{
			if(strcmp(cpl_info[i].di[k].name, name) == 0)
			{
				if(strlen(cpl_info[i].di[k].tooltip) > 0)
				{
					m_tooltip.DelTool(this);
					m_tooltip.AddTool(GetDlgItem(IDC_LIST1), cpl_info[i].di[k].tooltip);
					SetWindowText(cpl_info[i].di[k].tooltip);
				}
				else
				{
					m_tooltip.DelTool(this);
					m_tooltip.AddTool(GetDlgItem(IDC_LIST1), "No Info Available");
					SetWindowText("ControlPanel - No Info Available");
				}

				if(cpl_info[i].di[k].icon != NULL)
				{
					SetIcon(cpl_info[i].di[k].icon , FALSE);
				}
			}
		}
	}
}

BOOL CControlPanelDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

void CControlPanelDlg::OnErrspaceList1() 
{
	MessageBox("Not enough memory", "Error", MB_ICONERROR);	
}

void CControlPanelDlg::CallSelChange()
{
	OnSelchangeList1();
}


/***********************************************************************\
*																		*
*						End of File										*
*																		*
\***********************************************************************/
