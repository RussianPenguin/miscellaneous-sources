// MyListBox.cpp : implementation file
//

#include "stdafx.h"
#include "ControlPanel.h"
#include "ControlPanelDlg.h"
#include "MyListBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyListBox

CMyListBox::CMyListBox()
{
	// Pop up menu
	mymenu.CreatePopupMenu();
	mymenu.AppendMenu(MF_STRING, ID_F_OPEN, "Open");
	mymenu.AppendMenu(MF_STRING, ID_F_DELETE, "Delete");
	mymenu.AppendMenu(MF_SEPARATOR, (UINT)0, (LPCTSTR)NULL);
	mymenu.AppendMenu(MF_STRING, ID_ABOUT, "About...");

}

CMyListBox::~CMyListBox()
{
}


BEGIN_MESSAGE_MAP(CMyListBox, CListBox)
	//{{AFX_MSG_MAP(CMyListBox)
	ON_WM_RBUTTONDOWN()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_F_OPEN, OnFOpen)
	ON_COMMAND(ID_F_DELETE, OnFDelete)
	ON_COMMAND(ID_ABOUT, OnAbout)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyListBox message handlers

void CMyListBox::OnRButtonDown(UINT nFlags, CPoint point) 
{
	BOOL out;
	UINT index;

	index = ItemFromPoint(point, out);

	if(out == FALSE)
	{
		SetCurSel(index);

		CControlPanelDlg *pDlg = (CControlPanelDlg *)AfxGetMainWnd();
		pDlg->CallSelChange();
	}


	CListBox::OnRButtonDown(nFlags, point);
}



void CMyListBox::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	mymenu.TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this, NULL);
}

void CMyListBox::OnFOpen() 
{
	CControlPanelDlg *pDlg = (CControlPanelDlg *)AfxGetMainWnd();
	pDlg->CallOpen();
}

void CMyListBox::OnFDelete() 
{
	if(MessageBox("Are you sure you want to delete this applet?", "Confirm", MB_YESNO|MB_ICONQUESTION) == IDNO)
		return;

	CControlPanelDlg *pDlg = (CControlPanelDlg *)AfxGetMainWnd();
	pDlg->CallDelete();
	
}

void CMyListBox::OnAbout() 
{
	CDialog ad(IDD_ABOUTBOX);
	ad.DoModal();
}

void CMyListBox::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CListBox::OnLButtonDown(nFlags, point);
}

void CMyListBox::OnMouseMove(UINT nFlags, CPoint point) 
{
	CListBox::OnMouseMove(nFlags, point);

//	BOOL out;
//	UINT index;
//
//	index = ItemFromPoint(point, out);
//
//	if(out == FALSE)
//	{
//		SetCurSel(index);
//
//		CControlPanelDlg *pDlg = (CControlPanelDlg *)AfxGetMainWnd();
//		pDlg->CallSelChange();
//	}
}

HBRUSH CMyListBox::CtlColor(CDC* pDC, UINT nCtlColor) 
{
	return NULL;
}

HBRUSH CMyListBox::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CListBox::OnCtlColor(pDC, pWnd, nCtlColor);

	return hbr;
}

