Control Panel
--------------------------------------------------------

A small (32 kb) Control Panel duplicate. Use at ur own risk.

Farooque Khan
(farooquek@concretioindia.com)
www.concretioindia.com

