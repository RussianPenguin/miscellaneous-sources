/*
 * Copyright (C) 1993 by ISA Corp.  All Rights Reserved.
 *
 * $Header: $
 *
 * Name:        Windows Socket API for Wat-TCP 1.0
 * Author:
 * Date:        1993
 *
 * Description:
 *
 * This DLL implements the Windows Socket API version 1.1 for the
 * Waterloo TCP stack ver 1.0.
 *
 * Refer to the Windows Sockets Version 1.1 DRAFT 2 specification
 * for a complete description how to use the API.
 * 
 *
 *************************************************************************
 *                                                                       *
 *   THE DLL IS NOT WINSOCK COMPLIANT AS ONLY THOSE ROUTINES NEEDED      *
 *   TO IMPLEMENT THE CLIENT (PC) SIDE OF THE INTERFACE ARE SUPPORTED.   *
 *                                                                       *
 *************************************************************************
 *
 *
 */
#include <stdio.h>
#include <string.h>
#include "winsock.h"

static char     *version = "Wat-TCP version 1.0 Socket API";
static int      init = 0;
static int      lasterror = 0 ;

#define WSA_VERSION(major,minor) ((major) + 256*(minor))

extern int PASCAL FAR wattcp_init(void);
extern void sock_init();
extern int PASCAL FAR wat_socket(int domain, int tpye, int protocol);
extern int PASCAL FAR wat_connect(SOCKET s, struct sockaddr FAR *name, int namelen);
extern int PASCAL FAR wat_closesocket(SOCKET s);
extern int PASCAL FAR wat_select(int nfds, fd_set FAR *readfds,
    fd_set FAR *writefds, fd_set FAR *exceptfds, struct timeval FAR *timeout);
extern int PASCAL FAR wat_receive(SOCKET s, char FAR *buf, int len, int flags);
extern int PASCAL FAR wat_send(SOCKET s, char FAR *buf, int len, int flags);
extern struct hostent FAR * PASCAL FAR wat_gethostbyname(char FAR *name);
extern unsigned long PASCAL FAR wat_inet_addr(char FAR *cp);
extern u_long PASCAL FAR wat_htonl(u_long hostlong);
extern u_long PASCAL FAR wat_ntohl(u_long netlong);
extern u_short PASCAL FAR wat_htons(u_short hostshort);
extern u_short PASCAL FAR wat_ntohs(u_short netshort);
extern int PASCAL FAR wat_WSACleanup(void);

/* --- DLL initialization --- */
int PASCAL FAR LibMain(HANDLE hInstance, WORD wDataSeg, WORD wHeapSize, LPSTR lpCmdLine)
{
    return(1);
} /* LibMain */

void PASCAL FAR WEP(int nParameter)
{
} /* WEP */

int PASCAL FAR WSAStartup(WORD wVersionRequired, LPWSADATA lpWSAData)
{
    int major = LOBYTE(wVersionRequired);
    int minor = HIBYTE(wVersionRequired);
    
/* verify stack is loaded and WSA version is correct */
      if (wattcp_init() == 0 )   
	  return(WSASYSNOTREADY);         /* PC-NFS inittialize fails */
      
      if ( (major > 2) || ((major == 2) && (minor > 0)) ) 
	  return(WSAVERNOTSUPPORTED);     /* version not supported */
    
    /* return WSA status */
    lpWSAData->wVersion = WSA_VERSION(1,1);
    lpWSAData->wHighVersion = WSA_VERSION(1,1);
    memcpy(lpWSAData->szDescription, version, strlen(version)+1);
    lpWSAData->szSystemStatus[0] = '\0';
    lpWSAData->iMaxSockets = 8;
    lpWSAData->iMaxUdpDg = 0;
    lpWSAData->lpVendorInfo = (char FAR *) 0;

    init = 1;                             /* must be set according to spec */
    return(0);
} /* WSAStartup */



/* --- Windows Socket API --- */


/* socket - create a socket */
SOCKET PASCAL FAR socket(int domain, int type, int protocol)
{   
    if ( init == 0 ) {
	 lasterror = WSANOTINITIALISED;
	 return(INVALID_SOCKET) ;
    }
    lasterror = wat_socket(domain, type, protocol);
    if( lasterror > WSABASEERR )
	 return(INVALID_SOCKET);
    return(lasterror) ;
} /* socket */


/* connect - establish a connection to a peer */
int PASCAL FAR connect(SOCKET s, struct sockaddr FAR *name, int namelen)
{
    if ( init == 0 ) {
	 lasterror = WSANOTINITIALISED;
	 return(SOCKET_ERROR) ;
    }
    lasterror = wat_connect(s, name, namelen) ;
    if( lasterror > WSABASEERR )
	 return(SOCKET_ERROR);
    return(lasterror) ;
} /* connect */


/* closesocket - close a socket */
int PASCAL FAR closesocket(SOCKET s)
{
   if ( init == 0 ) {
	lasterror = WSANOTINITIALISED;
	return(SOCKET_ERROR) ;
   }
   lasterror =  wat_closesocket(s) ;
   if (lasterror > WSABASEERR)
	return(SOCKET_ERROR);
   return(lasterror);
} /* closesocket */



/* select - determine the status of one of more sockets */
int PASCAL FAR select(int nfds, fd_set FAR *readfds, fd_set FAR *writefds, fd_set FAR *exceptfds, struct timeval FAR *timeout)
{
   if ( init == 0 ) {
	lasterror = WSANOTINITIALISED;
	return(SOCKET_ERROR) ;
   }
   lasterror = wat_select(nfds, readfds, writefds, exceptfds, timeout) ;
   if( lasterror > WSABASEERR)
	return(SOCKET_ERROR) ;
   return(lasterror);
} /* select */


/* recv - receive data from a socket */
int PASCAL FAR recv(SOCKET s, char FAR *buf, int len, int flags)
{
   if ( init == 0 ) {
	lasterror = WSANOTINITIALISED;
	return(SOCKET_ERROR) ;
   }
   lasterror = wat_receive(s, buf, len, flags) ;
   if(lasterror > WSABASEERR)
	return(SOCKET_ERROR) ;
   return(lasterror);
} /* recv */


/* send - send data on a connected socket */
int PASCAL FAR send(SOCKET s, char FAR *buf, int len, int flags)
{
   if ( init == 0 ) {
	lasterror = WSANOTINITIALISED;
	return(SOCKET_ERROR) ;
   }
   lasterror = wat_send(s, buf, len, flags) ;
   if(lasterror > WSABASEERR)
	return(SOCKET_ERROR) ;
   return(lasterror);

} /* send */


/* gethostbyname - get host information corresponding to a hostname */
struct hostent FAR * PASCAL FAR gethostbyname(char FAR *name)
{
   if ( init == 0 ) {
	lasterror = WSANOTINITIALISED;
	return(NULL) ;
   }
   return( wat_gethostbyname(name)) ;
} /* gethostbyname */


/* inet_addr - convert a string containin a dotted address */
unsigned long PASCAL FAR inet_addr(char FAR *cp)
{
   unsigned long address ;
   if( !(address = wat_inet_addr(cp)) )
	return ( INADDR_NONE );
    return ( address ) ;
} /* inet_addr */


/* host to network byte order */
u_long PASCAL FAR htonl(u_long hostlong)
{
    return(wat_htonl(hostlong));
} /* htonl */

u_short PASCAL FAR htons(u_short hostshort)
{
    return(wat_htons(hostshort));
} /* htons */

/* network to host byte order */
u_long PASCAL FAR ntohl(u_long netlong)
{
    return(wat_ntohl(netlong));
} /* ntohl */

u_short PASCAL FAR ntohs(u_short netshort)
{
    return(wat_ntohs(netshort));
} /* ntohs */


/* FD_ISSET supporting function; not for use by applications */
int PASCAL FAR __WSAFDIsSet(SOCKET fd, fd_set FAR *set)
{
    int i;
    if (set == (fd_set FAR *) 0)
	return(0);
    i = set->fd_count;
    while (i--)
	if (set->fd_array[i] == fd)
	    return(1);
    return(0);
} /* __WSAFDIsSet */


int PASCAL FAR WSAGetLastError(void)
{
   return(lasterror) ;
}

/* --- %%% Unsupported Routines --- */

SOCKET PASCAL FAR accept(SOCKET s, struct sockaddr FAR *addr, int FAR *addrlen)
{
    return(INVALID_SOCKET);
} /* accept */

int PASCAL FAR bind(SOCKET s, struct sockaddr FAR *name, int namelen)
{
    return(SOCKET_ERROR);
} /* bind */

int PASCAL FAR getpeername(SOCKET s, struct sockaddr FAR *name, int FAR *namelen)
{
    return(SOCKET_ERROR);
} /* getpeername */

int PASCAL FAR getsockname(SOCKET s, struct sockaddr FAR *name, int FAR *namelen)
{
    return(SOCKET_ERROR);
} /* getsockname */

int PASCAL FAR getsockopt(SOCKET s, int level, int optname, char FAR *optval, int FAR *optlen)
{
    return(SOCKET_ERROR);
} /* getsockopt */

int PASCAL FAR ioctlsocket(SOCKET s, long cmd, u_long FAR *argp)
{
    return(SOCKET_ERROR);
} /* ioctlsocket */

char FAR * PASCAL FAR inet_ntoa(struct in_addr in)
{
    return((char FAR *) 0);
} /* inet_ntoa */

int PASCAL FAR listen(SOCKET s, int backlog)
{
    return(SOCKET_ERROR);
} /* listen */

int PASCAL FAR recvfrom(SOCKET s, char FAR *buf, int len, int flags, struct sockaddr FAR *from, int FAR *fromlen)
{
    return(SOCKET_ERROR);
} /* recvfrom */

int PASCAL FAR sendto(SOCKET s, char FAR *buf, int len, int flags, struct sockaddr FAR *to, int tolen)
{
    return(SOCKET_ERROR);
} /* sendto */

int PASCAL FAR setsockopt(SOCKET s, int level, int optname, char FAR *optval, int optlen)
{
    return(SOCKET_ERROR);
} /* setsockopt */

int PASCAL FAR shutdown(SOCKET s, int how)
{
    return(SOCKET_ERROR);  
} /* shutdown */;

struct hostent FAR * PASCAL FAR gethostbyaddr(char FAR *addr, int len, int type)
{
    return((struct hostent FAR *) 0);
} /* gethostbyaddr */

int PASCAL FAR gethostname(char FAR *name, int namelen)
{
    return(SOCKET_ERROR);
} /* gethostname */

struct protoent FAR * PASCAL FAR getprotobyname(char FAR *name)
{
    return((struct protoent FAR *) 0);
} /* getprotobyname */

struct protoent FAR * PASCAL FAR getprotobynumber(int number)
{
    return((struct protoent FAR *) 0);
} /* getprotobynumber */

struct servent FAR * PASCAL FAR getservbyname(char FAR *name, char FAR *proto)
{
    return((struct servent FAR *) 0);
} /* getservbyname */

struct servent FAR * PASCAL FAR getservbyport(int port, char FAR *proto)
{
    return((struct servent FAR *) 0);
} /* getservbyport */

HANDLE PASCAL FAR WSAAsyncGetHostByAddr(HWND hWnd, unsigned int wMsg, char FAR *addr, int len, int type, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetHostByAddr */

HANDLE PASCAL FAR WSAAsyncGetHostByName(HWND hWnd, unsigned int wMsg, char FAR *name, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetHostByName */

HANDLE PASCAL FAR WSAAsyncGetProtoByName(HWND hWnd, unsigned int wMsg, char FAR *name, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetProtoByName */

HANDLE PASCAL FAR WSAAsyncGetProtoByNumber(HWND hWnd, unsigned int wMsg, int number, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetProtoByNumber */

HANDLE PASCAL FAR WSAAsyncGetServByName(HWND hWnd, unsigned int wMsg, char FAR *name, char FAR *proto, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetServByName */

HANDLE PASCAL FAR WSAAsyncGetServByPort(HWND hWnd, unsigned int wMsg, int port, char FAR *proto, char FAR *buf, int buflen)
{
    return(0);
} /* WSAAsyncGetServByPort */

int PASCAL FAR WSAAsyncSelect(SOCKET s, HWND hWnd, unsigned int wMsg, long lEvent)
{
    return(SOCKET_ERROR);
} /* WSAAsyncSelect */

int PASCAL FAR WSACancelAsyncRequest(HANDLE hAsyncTaskHandle)
{
    return(SOCKET_ERROR);
} /* WSACancelAsyncRequest */

int PASCAL FAR WSACancelBlockingCall(void)
{
    return(SOCKET_ERROR);
} /* WSACancelBlockingCall */

int PASCAL FAR WSACleanup(void)
{
    init = 0 ;
    return(wat_WSACleanup()) ;
/*    return(SOCKET_ERROR);  */
} /* WSACleanup */


BOOL PASCAL FAR WSAIsBlocking(void)
{
    return(FALSE);
} /* WSAIsBlocking */

FARPROC PASCAL FAR WSASetBlockingHook(FARPROC lpBlockFunc)
{
    return((FARPROC) 0);
} /* WSASetBlockingHook */

void PASCAL FAR WSASetLastError(int iError)
{
  iError = iError ;
} /* WSASetLastError */

int PASCAL FAR WSAUnhookBlockingHook(void)
{
    return(SOCKET_ERROR);
} /* WSAUnhookBlockingHook */

