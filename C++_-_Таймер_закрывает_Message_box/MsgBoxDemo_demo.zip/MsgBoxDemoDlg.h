// MsgBoxDemoDlg.h : Header-Datei
//

#if !defined(AFX_MSGBOXDEMODLG_H__E78B502F_D8EE_4B39_8964_E9C93508BAEA__INCLUDED_)
#define AFX_MSGBOXDEMODLG_H__E78B502F_D8EE_4B39_8964_E9C93508BAEA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMsgBoxDemoDlg Dialogfeld

class CMsgBoxDemoDlg : public CDialog
{
// Konstruktion
public:
	CMsgBoxDemoDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CMsgBoxDemoDlg)
	enum { IDD = IDD_MSGBOXDEMO_DIALOG };
	BOOL	m_bStatus;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMsgBoxDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	HICON m_hIcon;

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CMsgBoxDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonNothread();
	afx_msg void OnButtonThread();
	afx_msg void OnButtonNormal();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MSGBOXDEMODLG_H__E78B502F_D8EE_4B39_8964_E9C93508BAEA__INCLUDED_)
