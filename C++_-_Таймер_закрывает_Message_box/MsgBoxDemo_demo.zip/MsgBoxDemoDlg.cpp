// MsgBoxDemoDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "timedmsgbox.h"

#include "MsgBoxDemo.h"
#include "MsgBoxDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsgBoxDemoDlg Dialogfeld

CMsgBoxDemoDlg::CMsgBoxDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMsgBoxDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsgBoxDemoDlg)
	m_bStatus = FALSE;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMsgBoxDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsgBoxDemoDlg)
	DDX_Check(pDX, IDC_CHECK_STATUS, m_bStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMsgBoxDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CMsgBoxDemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_NOTHREAD, OnButtonNothread)
	ON_BN_CLICKED(IDC_BUTTON_THREAD, OnButtonThread)
	ON_BN_CLICKED(IDC_BUTTON_NORMAL, OnButtonNormal)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsgBoxDemoDlg Nachrichten-Handler

BOOL CMsgBoxDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

void CMsgBoxDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMsgBoxDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

///////////////////////////////////////////////////////////////////////////77
//
// here it starts
//
///////////////////////////////////////////////////////////////////////////77
void ShowAMsgBox(char *szTitle, UINT time, HWND hWnd, BOOL bShowStatus)
{
	BOOL		stoppedByUser = FALSE;
	UINT		erg;
	CString		msg("Please press a button"),
				ret;
		
	if( time>0 )
		erg = ::TimedMessageBox(MB_YESNO|MB_ICONHAND, msg, szTitle, 
						time, IDYES, /*NULL*/"\nin the next %lu sec !", 
						hWnd, &stoppedByUser);
	else	
		erg = ::MessageBox(hWnd, msg, szTitle, MB_YESNO|MB_ICONHAND);

	if( !bShowStatus )
		return;


	switch(erg)
	{
		case IDOK:		ret = "IDOK";			break;
		case IDCANCEL:	ret = "IDCANCEL";		break;
		case IDABORT:	ret = "IDABORT";		break;
		case IDRETRY:	ret = "IDRETRY";		break;
		case IDIGNORE:	ret = "IDIGNORE";		break;
		case IDYES:		ret = "IDYES";			break;
		case IDNO:		ret = "IDNO";			break;
		default:		ret.Format("%d", erg);	break;
		
	}

	msg.Format("The MessageBox returned %s, User-Stop=%d", ret, stoppedByUser);
	::MessageBox(NULL, msg, "Info", MB_OK);
}

UINT ThreadMesssageBox(LPVOID pParam)
{
	CMsgBoxDemoDlg *pThis = (CMsgBoxDemoDlg*) pParam;
	ShowAMsgBox("Multi-Threaded", 8000, pThis->m_hWnd, pThis->m_bStatus);
	return 0;
}

void CMsgBoxDemoDlg::OnButtonNothread() 
{
	UpdateData(TRUE);

	ShowAMsgBox("Single-Threaded", 5000, m_hWnd, m_bStatus);
}

void CMsgBoxDemoDlg::OnButtonThread() 
{
	UpdateData(TRUE);

	AfxBeginThread(ThreadMesssageBox, this, THREAD_PRIORITY_NORMAL, 0, 0);
	ShowAMsgBox("Single-Threaded", 7000, m_hWnd, m_bStatus);
}

void CMsgBoxDemoDlg::OnButtonNormal() 
{
	UpdateData(TRUE);

	ShowAMsgBox("No Timer", 0, m_hWnd, m_bStatus);
}

