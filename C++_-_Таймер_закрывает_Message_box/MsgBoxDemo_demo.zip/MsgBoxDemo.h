// MsgBoxDemo.h : Haupt-Header-Datei f�r die Anwendung MSGBOXDEMO
//

#if !defined(AFX_MSGBOXDEMO_H__7F11C41F_A336_4852_A32E_5FAA3CA69765__INCLUDED_)
#define AFX_MSGBOXDEMO_H__7F11C41F_A336_4852_A32E_5FAA3CA69765__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CMsgBoxDemoApp:
// Siehe MsgBoxDemo.cpp f�r die Implementierung dieser Klasse
//

class CMsgBoxDemoApp : public CWinApp
{
public:
	CMsgBoxDemoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CMsgBoxDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CMsgBoxDemoApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_MSGBOXDEMO_H__7F11C41F_A336_4852_A32E_5FAA3CA69765__INCLUDED_)
