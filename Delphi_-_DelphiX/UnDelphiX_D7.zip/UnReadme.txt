Overview:

What is UnDelphiX? 

Quite simply, UnDelphiX is a unofficial version of DelphiX powered by the official JEDI DirectX headers. It also has various "Better English" error messages, comments, and samples. It also will include DXG and DXW editors with full source. 
The entire concept here is simple - make the best game development system for Delphi better, and try to do it with the most support and approval as possible. If I can draw support for this project, I feel that it will do the most good for the entire Delphi game development community. 

Why UnDelphiX? 

Why do this? DelphiX is by far the most complete freeware game development kit for Delphi, and has introduced myself as well as many others to the world of game development. For all its good points it does have a few significant drawbacks: 

1. Lack of official updates - DelphiX's development is the work of one individual (Hiroyuki Hori) and is updated infrequently. 

2. Non-standard headers - DelphiX uses it's own non-documented proprietary header format, which makes low level development difficult. 

3. No code repository - fixes and updates to DelphiX released by individuals are not included with new versions of DelphiX, and are scattered throughout the Internet. 

4. Translation issues - This affects everything from documentation to source comments to function and procedure naming conventions, and makes it difficult for a new user to get acquainted with the library. 

5. Lack of support - There is no official support network for DelphiX and with the latest version, English help files are discontinued. 
That said; there are major areas of DelphiX that can be improved for the greater good of the Delphi game development community. 
Status:

I'm currently distributing UnDelphiX as a patch for DelphiX

* The JEDI headers conversion is complete. And 99% of the samples (/Samples) that come with the Official DelphiX for DX7 will compile with little or no changes. Almost all demos that won't compile as-is simply need the DirectX in the USES clause to be replaced with the appropriate JEDI headers. (i.e. DirectDraw, DirectSound, DirectPlay etc.) 

* The update of the DXClass, DXDraws, and DXConst files are also complete. 

* The DXG editor is 85% complete and in beta, but the DXW editor has yet to be started. 

* The only major thing left to do is update the Help files. 
DelphiX Samples status under UnDelphiX 

* D3DIM - Mostly working except D3DIM Texture & D3DIM Video Texture Samples. Samples required some Rects to be PRects (just add a @). 

* D3DRM - Mostly working except D3DRM Wrap. Samples compiled nicely. 

* Graphic - 100% working. Samples compiled very nicely -- most samples ran without *any* changes. 

* Input - 100% working. Samples compiled very nicely -- most samples ran without *any* changes. Force feedback not tested and although it may be subject to DXInput errors with USB devices, ran better then DelphiX in my tests. 

* Network - 100% working. Samples compiled very nicely. 

* Sound - 100% working. Samples compiled very nicely -- most samples ran without *any* changes. 

* Sprites - 99% working (pixelchecking for all sprites is disabled). Samples compiled very nicely -- most samples ran without without *any* changes. The "Shoot" scroller demo/sample works flawlessly with no changes. 

Download:

Visit http://turbo.gamedev.net/undelphix.asp for download information...
 
Comments:

It only took 2 days to convert DelphiX for DX7 to the DX7 JEDI headers -- and the funny part is "UnDelphiX" is slightly *faster* than regular DelphiX. Why you ask? (I'm sure you're asking right?) Hori was passing TRects to his headers for almost every function. The JEDI headers wanted pointers to Rects -- and since a PRect is faster to pass within a function call, many things sped up. Go figure. 

The majority of the port was DXClass.pas, after that everything went smooth as silk. Most simple DelphiX Samples will compile with *no changes*, others need the JEDI headers added to the Uses Clause. A very small percentage need an "@" placed before a TRect variable. That's it. 