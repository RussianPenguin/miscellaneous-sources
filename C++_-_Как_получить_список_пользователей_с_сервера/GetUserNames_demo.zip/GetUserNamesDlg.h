// GetUserNamesDlg.h : header file
//

#if !defined(AFX_GETUSERNAMESDLG_H__36706992_444A_11D5_9EAD_000102FB9990__INCLUDED_)
#define AFX_GETUSERNAMESDLG_H__36706992_444A_11D5_9EAD_000102FB9990__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGetUserNamesDlg dialog

class CGetUserNamesDlg : public CDialog
{
// Construction
public:
	CGetUserNamesDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGetUserNamesDlg)
	enum { IDD = IDD_GETUSERNAMES_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetUserNamesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
private:
	CListCtrl	m_ctrlResults;	// List control to contain the results of the query
	CString		m_szServer;		// Server to be queried
	int			m_nLevel;		// Level of information required
	
	void DeleteAllColumns ();	// Deletes all items and columns in m_ctrlResults

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CGetUserNamesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButtonRetrieve();	// Handler for Retrieve button click
	afx_msg void OnRadioUser();			// Handler for User radio activation
	afx_msg void OnRadioMachines();		// Handler for Machines radio activation
	afx_msg void OnRadioGroups();		// Hadnler for Groups radio activation
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETUSERNAMESDLG_H__36706992_444A_11D5_9EAD_000102FB9990__INCLUDED_)
