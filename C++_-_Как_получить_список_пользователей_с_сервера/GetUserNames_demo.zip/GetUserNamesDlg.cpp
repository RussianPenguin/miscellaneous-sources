// GetUserNamesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GetUserNames.h"
#include "GetUserNamesDlg.h"
#include <lm.h>
#include "NetInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGetUserNamesDlg dialog

CGetUserNamesDlg::CGetUserNamesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGetUserNamesDlg::IDD, pParent) {
	//{{AFX_DATA_INIT(CGetUserNamesDlg)
	m_szServer = _T("");
	m_nLevel = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGetUserNamesDlg::DoDataExchange(CDataExchange* pDX) {
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetUserNamesDlg)
	DDX_Control(pDX, IDC_LIST_RESULTS, m_ctrlResults);
	DDX_Text(pDX, IDC_EDIT_SERVER, m_szServer);
	DDX_Radio(pDX, IDC_RADIO_USER, m_nLevel);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGetUserNamesDlg, CDialog)
	//{{AFX_MSG_MAP(CGetUserNamesDlg)
	ON_BN_CLICKED(IDC_BUTTON_RETRIEVE, OnButtonRetrieve)
	ON_BN_CLICKED(IDC_RADIO_USER, OnRadioUser)
	ON_BN_CLICKED(IDC_RADIO_MACHINES, OnRadioMachines)
	ON_BN_CLICKED(IDC_RADIO_GROUPS, OnRadioGroups)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetUserNamesDlg message handlers

BOOL CGetUserNamesDlg::OnInitDialog() {
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Initial radio option is User Accounts
	OnRadioUser ();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGetUserNamesDlg::OnButtonRetrieve() {
	if (FALSE == UpdateData(TRUE)) {
		return;
	}

	// Remove any existing entries in the list
	m_ctrlResults.DeleteAllItems ();

	// Check the requested level of information
	switch (m_nLevel + 1) {
	case LEVEL_USER : {
			// Create a list of NET_DISPLAY_USER structures
			USER_LIST* pUsers = new USER_LIST;
			// Get the information
			DWORD dwResult = ssl_net::CNetInfo::GetUserInfo (pUsers, m_szServer);
			if (ERROR_SUCCESS == dwResult) {
				// Process the results
				POSITION pos = pUsers->GetHeadPosition ();
				while (NULL != pos) {
					NET_DISPLAY_USER ndu = pUsers->GetNext (pos);
					CString szName, szComment, szFlags, szFullName, szUserID;
					szName.Format ("%S", ndu.usri1_name);
					szComment.Format ("%S", ndu.usri1_comment);
					szFlags.Format ("%d", ndu.usri1_flags);
					szFullName.Format ("%S", ndu.usri1_full_name);
					szUserID.Format ("%d", ndu.usri1_user_id);
					m_ctrlResults.InsertItem (0, szName);
					m_ctrlResults.SetItemText (0, 1, szComment);
					m_ctrlResults.SetItemText (0, 2, szFlags);
					m_ctrlResults.SetItemText (0, 3, szFullName);
					m_ctrlResults.SetItemText (0, 4, szUserID);
				}
			}
			else {
				// Handle any errors
				CString szErrMsg = ssl_net::CNetInfo::FormatMessage (dwResult);
				AfxMessageBox (szErrMsg);
			}
			delete pUsers;
		}
		break;
	case LEVEL_MACHINE: {
			// Create a list of NET_DISPLAY_MACHINE structures
			MACHINE_LIST* pMachines = new MACHINE_LIST;
			// Get the information
			DWORD dwResult = ssl_net::CNetInfo::GetMachineInfo (pMachines, m_szServer);
			if (ERROR_SUCCESS == dwResult) {
				// Process the results
				POSITION pos = pMachines->GetHeadPosition ();
				while (NULL != pos) {
					NET_DISPLAY_MACHINE ndm = pMachines->GetNext (pos);
					CString szName, szComment, szFlags, szUserID;
					szName.Format ("%S", ndm.usri2_name);
					szComment.Format ("%S", ndm.usri2_comment);
					szFlags.Format ("%d", ndm.usri2_flags);
					szUserID.Format ("%d", ndm.usri2_user_id);
					m_ctrlResults.InsertItem (0, szName);
					m_ctrlResults.SetItemText (0, 1, szComment);
					m_ctrlResults.SetItemText (0, 2, szFlags);
					m_ctrlResults.SetItemText (0, 3, szUserID);
				}
			}
			else {
				// Handle any errors
				CString szErrMsg = ssl_net::CNetInfo::FormatMessage (dwResult);
				AfxMessageBox (szErrMsg);
			}
			delete pMachines;
		}
		break;
	case LEVEL_GROUP: {
			// Create a list of NET_DISPLAY_GROUP structures
			GROUP_LIST* pGroups = new GROUP_LIST;
			// Get the information
			DWORD dwResult = ssl_net::CNetInfo::GetGroupInfo (pGroups, m_szServer);
			if (ERROR_SUCCESS == dwResult) {
				// Process the results
				POSITION pos = pGroups->GetHeadPosition ();
				while (NULL != pos) {
					NET_DISPLAY_GROUP ndg = pGroups->GetNext (pos);
					CString szName, szComment, szGroupID, szAttributes;
					szName.Format ("%S", ndg.grpi3_name);
					szComment.Format ("%S", ndg.grpi3_comment);
					szGroupID.Format ("%d", ndg.grpi3_group_id);
					szAttributes.Format ("%d", ndg.grpi3_attributes);
					m_ctrlResults.InsertItem (0, szName);
					m_ctrlResults.SetItemText (0, 1, szComment);
					m_ctrlResults.SetItemText (0, 2, szGroupID);
					m_ctrlResults.SetItemText (0, 3, szAttributes);
				}
			}
			else {
				// Handle any errors
				CString szErrMsg = ssl_net::CNetInfo::FormatMessage (dwResult);
				AfxMessageBox (szErrMsg);
			}
			delete pGroups;
		}
	}
}

void CGetUserNamesDlg::OnRadioUser() {
	if (FALSE == UpdateData (TRUE)) {
		return;
	}
	
	// Remove the existing columns
	DeleteAllColumns ();

	// Create the new columns
	m_ctrlResults.InsertColumn (0, "Name", LVCFMT_LEFT, 100);
	m_ctrlResults.InsertColumn (1, "Comment", LVCFMT_LEFT, 200);
	m_ctrlResults.InsertColumn (2, "Flags", LVCFMT_LEFT, 70);
	m_ctrlResults.InsertColumn (3, "Full Name", LVCFMT_LEFT, 150);
	m_ctrlResults.InsertColumn (4, "User ID", LVCFMT_LEFT, 70);
}

void CGetUserNamesDlg::OnRadioMachines() {
	if (FALSE == UpdateData (TRUE)) {
		return;
	}
	
	// Remove the existing columns
	DeleteAllColumns ();

	// Create the new columns
	m_ctrlResults.InsertColumn (0, "Name", LVCFMT_LEFT, 100);
	m_ctrlResults.InsertColumn (1, "Comment", LVCFMT_LEFT, 300);
	m_ctrlResults.InsertColumn (2, "Flags", LVCFMT_LEFT, 70);
	m_ctrlResults.InsertColumn (3, "User ID", LVCFMT_LEFT, 70);
}

void CGetUserNamesDlg::OnRadioGroups() {
	if (FALSE == UpdateData (TRUE)) {
		return;
	}
	
	// Remove the existing columns
	DeleteAllColumns ();

	// Create the new columns
	m_ctrlResults.InsertColumn (0, "Name", LVCFMT_LEFT, 100);
	m_ctrlResults.InsertColumn (1, "Comment", LVCFMT_LEFT, 300);
	m_ctrlResults.InsertColumn (2, "Group ID", LVCFMT_LEFT, 70);
	m_ctrlResults.InsertColumn (3, "Attributes", LVCFMT_LEFT, 70);
}

void CGetUserNamesDlg::DeleteAllColumns () {
	// Delete any entries from the list
	m_ctrlResults.DeleteAllItems ();

	int nColumnCount = m_ctrlResults.GetHeaderCtrl()->GetItemCount();

	// Delete all of the columns.
	for (int i = 0; i < nColumnCount; i++) {
	   m_ctrlResults.DeleteColumn (0);
	}
}