// AEtestView.h : Schnittstelle der Klasse CAEtestView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AETESTVIEW_H__7178FBBC_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
#define AFX_AETESTVIEW_H__7178FBBC_BA36_11D4_86A6_0050DA426F23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAEtestView : public CView
{
protected: // Nur aus Serialisierung erzeugen
	CAEtestView();
	DECLARE_DYNCREATE(CAEtestView)

// Attribute
public:
	CAEtestDoc* GetDocument();

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAEtestView)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CAEtestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CAEtestView)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // Testversion in AEtestView.cpp
inline CAEtestDoc* CAEtestView::GetDocument()
   { return (CAEtestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_AETESTVIEW_H__7178FBBC_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
