// AEtest.h : Haupt-Header-Datei f�r die Anwendung AETEST
//

#if !defined(AFX_AETEST_H__7178FBB4_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
#define AFX_AETEST_H__7178FBB4_BA36_11D4_86A6_0050DA426F23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CAEtestApp:
// Siehe AEtest.cpp f�r die Implementierung dieser Klasse
//

class CAEtestApp : public CWinApp
{
public:
	CAEtestApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAEtestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung
	//{{AFX_MSG(CAEtestApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_AETEST_H__7178FBB4_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
