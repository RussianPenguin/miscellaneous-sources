// AEtestDoc.cpp : Implementierung der Klasse CAEtestDoc
//

#include "stdafx.h"
#include "AEtest.h"

#include "AEtestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAEtestDoc

IMPLEMENT_DYNCREATE(CAEtestDoc, CDocument)

BEGIN_MESSAGE_MAP(CAEtestDoc, CDocument)
	//{{AFX_MSG_MAP(CAEtestDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAEtestDoc Konstruktion/Destruktion

CAEtestDoc::CAEtestDoc()
{
}

CAEtestDoc::~CAEtestDoc()
{
}

BOOL CAEtestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CAEtestDoc Serialisierung

void CAEtestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAEtestDoc Diagnose

#ifdef _DEBUG
void CAEtestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAEtestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAEtestDoc Befehle
