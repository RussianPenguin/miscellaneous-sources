#if !defined(AFX_TESTDLG_H__7178FBC4_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
#define AFX_TESTDLG_H__7178FBC4_BA36_11D4_86A6_0050DA426F23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestDlg.h : Header-Datei
//
#include "autoedit.h"

// define the Validation Interfaces

class CDayValidate : public CEditValidate 
{
    virtual CString validate(CString& str);
};

class CMonthValidate : public CEditValidate 
{
    virtual CString validate(CString& str);
};

class CYearValidate : public CEditValidate 
{
    virtual CString validate(CString& str);
};

class CBinValidate : public CEditValidate 
{
    virtual CString validate(CString& str);
};


/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTestDlg 

class CTestDlg : public CDialog
{
// Konstruktion
public:
	CTestDlg(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CTestDlg)
	enum { IDD = IDD_DIALOG1 };
	CAutoEdit	m_Edit4;
	CAutoEdit	m_Edit3;
	CAutoEdit	m_Edit2;
	CAutoEdit	m_Edit1;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()


    CDayValidate* m_dayValidate;
    CMonthValidate* m_monthValidate;
    CYearValidate* m_yearValidate;
    CBinValidate* m_binValidate;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TESTDLG_H__7178FBC4_BA36_11D4_86A6_0050DA426F23__INCLUDED_
