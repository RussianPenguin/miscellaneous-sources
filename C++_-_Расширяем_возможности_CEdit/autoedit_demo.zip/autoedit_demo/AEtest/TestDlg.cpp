// TestDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "AEtest.h"
#include "TestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CString CDayValidate::validate(CString& str)
{
    if (str.GetLength() == 1) str = _T("0") + str;
    if (str.GetLength() == 1) str = _T("0") + str; // just in case it was empty...

    if (atoi(str) > 31) {
        return("Day larger than 31 !");
    }
    if (atoi(str) == 0) {
        return("Day '00' does not make sense !");
    }
    return(_T(""));
}

CString CMonthValidate::validate(CString& str)
{
    if (str.GetLength() == 1) str = _T("0") + str;
    if (str.GetLength() == 1) str = _T("0") + str; // just in case it was empty...

    if (atoi(str) > 12) {
        return("Month larger than 12 !");
    }
    if (atoi(str) == 0) {
        return("Month '00' does not exist !");
    }
    return(_T(""));
}

CString CYearValidate::validate(CString& str)
{
    if (str.GetLength() == 0) str = _T("2000");
    if (str.GetLength() == 2) {
        if (atoi(str) < 90) {
            str = _T("20") + str;
        }
        else  {
            str = _T("19") + str;
        }
    }

    if (atoi(str) < 1900) {
        return("Century too small (before 1900) !");
    }
    if (atoi(str) > 2099) {
        return("To far in the future !");
    }
    return(_T(""));
}




CString CBinValidate::validate(CString& str)
{
    if (str.GetLength() > 0) {
        if (str.GetAt(0) == _T('0')) {
            return("first bit must be set (1....) !");
        }
    }
    return(_T(""));
}



/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTestDlg 


CTestDlg::CTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestDlg)
	//}}AFX_DATA_INIT
}


void CTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestDlg)
	DDX_Control(pDX, IDC_EDIT4, m_Edit4);
	DDX_Control(pDX, IDC_EDIT3, m_Edit3);
	DDX_Control(pDX, IDC_EDIT2, m_Edit2);
	DDX_Control(pDX, IDC_EDIT1, m_Edit1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTestDlg, CDialog)
	//{{AFX_MSG_MAP(CTestDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CTestDlg 

BOOL CTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    // Set up the behaviour for each edit field
	m_Edit1.SetMaxChars(2);
    m_Edit1.SetValidChar(_T("0123456789"));
    m_dayValidate = new CDayValidate;
    m_Edit1.SetValidationHandler(m_dayValidate);
    m_Edit1.SetDefaultValue(_T("01"));
    m_Edit1.SetText();
	
	m_Edit2.SetMaxChars(2);
    m_Edit2.SetValidChar(_T("0123456789"));
    m_monthValidate = new CMonthValidate;
    m_Edit2.SetValidationHandler(m_monthValidate);
    m_Edit2.SetDefaultValue(_T("01"));
    m_Edit2.SetText();

	m_Edit3.SetMaxChars(4);
    m_Edit3.SetValidChar(_T("0123456789"));
    m_yearValidate = new CYearValidate;
    m_Edit3.SetValidationHandler(m_yearValidate);
    m_Edit3.SetDefaultValue(_T("2000"));
    m_Edit3.SetText();

    
    m_Edit4.SetMaxChars(8);
    m_Edit4.SetValidChar(_T("10"));
    m_binValidate = new CBinValidate;
    m_Edit4.SetValidationHandler(m_binValidate);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CTestDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	delete m_dayValidate;
	delete m_monthValidate;
	delete m_yearValidate;
	delete m_binValidate;
}
