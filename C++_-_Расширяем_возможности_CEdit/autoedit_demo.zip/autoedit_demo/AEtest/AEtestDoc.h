// AEtestDoc.h : Schnittstelle der Klasse CAEtestDoc
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AETESTDOC_H__7178FBBA_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
#define AFX_AETESTDOC_H__7178FBBA_BA36_11D4_86A6_0050DA426F23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CAEtestDoc : public CDocument
{
protected: // Nur aus Serialisierung erzeugen
	CAEtestDoc();
	DECLARE_DYNCREATE(CAEtestDoc)

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAEtestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CAEtestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CAEtestDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_AETESTDOC_H__7178FBBA_BA36_11D4_86A6_0050DA426F23__INCLUDED_)
