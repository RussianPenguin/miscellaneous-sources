// AEtestView.cpp : Implementierung der Klasse CAEtestView
//

#include "stdafx.h"
#include "AEtest.h"

#include "AEtestDoc.h"
#include "AEtestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAEtestView

IMPLEMENT_DYNCREATE(CAEtestView, CView)

BEGIN_MESSAGE_MAP(CAEtestView, CView)
	//{{AFX_MSG_MAP(CAEtestView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAEtestView Konstruktion/Destruktion

CAEtestView::CAEtestView()
{
}

CAEtestView::~CAEtestView()
{
}

BOOL CAEtestView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CAEtestView Zeichnen

void CAEtestView::OnDraw(CDC* pDC)
{
	CAEtestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

/////////////////////////////////////////////////////////////////////////////
// CAEtestView Diagnose

#ifdef _DEBUG
void CAEtestView::AssertValid() const
{
	CView::AssertValid();
}

void CAEtestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAEtestDoc* CAEtestView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAEtestDoc)));
	return (CAEtestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAEtestView Nachrichten-Handler
