<html>
<head>
<title>Admin Guestbook - Admbook</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<style type="text/css">
<!--
a {color:#000000; text-decoration: none}
a:hover {color: #FFFFFF; text-decoration: none}
.text {font: 10pt "Arial Cyr", "Arial","Tahoma","Helvetica", sans-serif; color:#000000}
.text2 {font: 10pt "Arial Cyr", "Arial","Tahoma","Helvetica", sans-serif; color:#FFFFFF}
#line {color: #C0C0C0}
textarea {font-size: 10pt; font-family: Arial,sans-serif; color: #FFFFFF; background: #3a6ea5; border-style: ridge; width: 220px}
input {font-size: 10pt; font-family: Arial,sans-serif; color: #FFFFFF; background: #3a6ea5;}
input.field {border-style: ridge; width: 160px}
input.button { border-style: outset; width: 220px; cursor: hand}
-->
</style>
</head>
<body bgcolor="#3a6ea5" text="#FFFFFF" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" marginwidth="0" topmargin="0" marginheight="0">
<table width="760" border="0" cellpadding="0" cellspacing="0" align="center" height="100%">
<tr>
 <td valign="top" colspan="3">
<!-- Russian LinkExchange code START -->
     <iframe
     src=http://www.linkexchange.ru/cgi-bin/erle.cgi?43992?20
     frameborder=0 vspace=0 hspace=0 width=468 height=60
     marginwidth=0 marginheight=0 scrolling=no>
     <a href=http://www.linkexchange.ru/users/043992/goto.map target=_top>
     <img src=http://www.linkexchange.ru/cgi-bin/rle.cgi?43992?1
     alt="RLE Banner Network" border=0 height=60 width=468></a>
     </iframe>
<!-- Russian LinkExchange code END -->
 </td>
</tr>
<tr>
 <td colspan="3" height="20"><spacer height="20" width="1" type="block"></td>
</tr>
<tr>
<td valign="top" width="250">
<table width="220" border="0" cellpadding="0" cellspacing="0">
<form action="write.php" method="post">
<tr>
 <td width="50"><span class="text">Nick: </span></td>
 <td width="10"><spacer width="10" height="1" type="block"></td>
 <td width="160"><input type="text" size="12" name="nick" maxlength="30" class="field"></td>
</tr>
<tr>
 <td><span class="text">url: </span></td>
 <td width="10"><spacer width="10" height="1" type="block"></td>
 <td><input type="text" size="12" name="urla" maxlength="50" value="http://" class="field"></td>
</tr>
<tr>
 <td><span class="text">E-mail: </span></td>
 <td width="10"><spacer width="10" height="1" type="block"></td>
 <td><input type="text" size="12" name="emaila" maxlength="30" class="field"></td>
</tr>
<tr>
 <td colspan="3"><span class="text">Message:</span></td>
</tr>
<tr>
 <td colspan="3" align="right"><textarea name="mess" rows="9" cols="25" wrap="vitual" style="font-size: 10pt; font-family: Arial,sans-serif"></textarea></td>
</tr>
<tr>
 <td colspan="3"><input type="submit" value="Send" class="button"></td>
</tr>
<tr>
 <td colspan="3">
	<br><a href="admin.php" class="text">Administration Guestbook</a>
	<br><br><a href="http://www.mycgiserver.com/~sample/index.phps" class="text">see source index.php</a>
	<br><a href="http://www.mycgiserver.com/~sample/write.phps" class="text">see source  write.php</a>
	<br><a href="http://www.mycgiserver.com/~sample/admin.phps" class="text">see source  admin.php</a>
	<br><a href="http://www.mycgiserver.com/~sample/delete.phps" class="text">see source  delete.php</a>
	<br><br><a href="http://www.mycgiserver.com/~sample/guestbook.zip" class="text">download all</a>
	<br><br><a href="http://www.mycgiserver.com/~sample/discussion/index.php" class="text">Discussion / ����������</a>
 </td>
</tr>
</form>
</table>
<!-- Russian LinkExchange code START - BANNER #1 (100x100)-->
<!-- <iframe
  src=http://10e2.linkexchange.ru/cgi-bin/erle.cgi?44161-bn=0?1
  frameborder=0 vspace=0 hspace=0 width=100 height=100
  marginwidth=0 marginheight=0 scrolling=no>
  <a href=http://10e2.linkexchange.ru/users/044161/goto.map?bn=0 target=_top>
  <img src=http://10e2.linkexchange.ru/cgi-bin/rle.cgi?44161-bn=0?1
  alt="RLE Banner Network" border=0 height=100 width=100></a>
  </iframe> -->
<!-- Russian LinkExchange code END -->
&nbsp;&nbsp;
<!-- Russian LinkExchange code START - BANNER #2 (100x100)-->
<!-- <iframe
  src=http://10e2.linkexchange.ru/cgi-bin/erle.cgi?44161-bn=1?2
  frameborder=0 vspace=0 hspace=0 width=100 height=100
  marginwidth=0 marginheight=0 scrolling=no>
  <a href=http://10e2.linkexchange.ru/users/044161/goto.map?bn=1 target=_top>
  <img src=http://10e2.linkexchange.ru/cgi-bin/rle.cgi?44161-bn=1?2
  alt="RLE Banner Network" border=0 height=100 width=100></a>
  </iframe> -->
<!-- Russian LinkExchange code END -->
</td>
<td width="10"><spacer height="1" width="10" type="block"></td>
<td valign="top" width="520">
<?php
function printcontent() // ������� ���������� � ����������� �� ������ �������� - output content in relation to of number page
{
	global $page, $content, $mess2page;
	for($i=$mess2page*5*($page-1);$i<$mess2page*5*($page-1)+$mess2page*5;$i++)
	{
		print "$content[$i]";
	}
}

function print_num_of_pages($id) // ������� ���������� ������� �����  - output all quantity page
{
	global $allpages, $page, $lenpageline;
	if ($allpages>=2)
	{
	print "page: ";
		for ($i=$id;$i<=$allpages;$i++)
		{
			if(($i/$lenpageline)<ceil($i/$lenpageline))
			{
				if ($page!=$i)
				{
					print "<a href=index.php?page=$i>$i</a>&nbsp;&nbsp;";
				}
				else
				{
					print $i."&nbsp;&nbsp;";			
				}
			}
			else
			{
				print "<a href=index.php?page=$i>$i</a>&nbsp;&nbsp;";
				print "<br>";
				$id+=$lenpageline;
				print_num_of_pages($id);
				break;
			}
		}
	}
	print "<br>";
}

$filename = "gb.inc";
if(!file_exists($filename))
{
	$newfile = fopen($filename, "w");
	@chmod($filename, 0777);
	fwrite ($newfile,"",0);

	fclose($newfile);

}

$guestfile = fopen($filename,"r");

$guesttext = fread($guestfile, filesize ($filename));

fclose($guestfile);
if (!isset($page)) {$page = 1;}
$id = 1;
$content = split("<!-- reset line -->",$guesttext);
$sizearray = sizeof($content);
$mess2page = 3; // ���-�� ��������� �� ����� �������� - quantity messages of one page
$allmess = ($sizearray-1)/5; // ���-�� ��������� ����� - quantity all messages
$allpages = ceil($allmess/$mess2page); // ���-�� ������� ����� - quantity all pages
$lenpageline = 5; // ���-�� ������� ������� � ����� ����� - quantity numbers of pages in one line
printcontent();
?>
<br>
<div class="text2"><?php print_num_of_pages($id); ?>
</td>
</tr>
<tr>
 <td valign="bottom">
<!--TopList COUNTER--><a target=_top
href="http://top.list.ru/jump?from=145056"><script language="JavaScript"><!--
d=document;a='';a+=';r='+escape(d.referrer)
js=10//--></script><script language="JavaScript1.1"><!--
a+=';j='+navigator.javaEnabled()
js=11//--></script><script language="JavaScript1.2"><!--
s=screen;a+=';s='+s.width+'*'+s.height
a+=';d='+(s.colorDepth?s.colorDepth:s.pixelDepth)
js=12//--></script><script language="JavaScript1.3"><!--
js=13//--></script><script language="JavaScript"><!--
d.write('<img src="http://top.list.ru/counter'+
'?id=145056;t=56;js='+js+a+';rand='+Math.random()+
'" alt="TopList" '+ 'border=0 height=31 width=88>')
if(js>11)d.write('<'+'!-- ')//--></script><noscript><img
src="http://top.list.ru/counter?js=na;id=145056;t=56"
border=0 height=31 width=88
alt="TopList"></noscript><script language="JavaScript"><!--
if(js>11)d.write('--'+'>')//--></script></a><!--TopList COUNTER--><!--begin of Top100 logo--><a href="http://top100.rambler.ru/top100/" target=_top><img src="http://images.rambler.ru/top100/banner-88x31-rambler-darkblue2.gif" alt="Rambler's Top100" width=88 height=31 border=0></a><!--end of Top100 logo --><!-- SpyLOG --><a href="http://u1151.35.spylog.com/cnt?f=3&p=0" target=_top><img src="http://u1151.35.spylog.com/cnt?p=0&f=4" alt='SpyLog' border='0' width=88 height=31 ></a><!-- SpyLOG -->
 </td>
 <td colspan="2" valign="bottom" align="right">
  <span class="text">&copy;&nbsp;</span><a href="mailto:trent@id.ru" class="text2">trent</a>&nbsp;<a href="http://www.dagros.id.ru/" target="_blank" class="text">http://www.dagros.id.ru/</a>
 </td>
</tr>
</table>
</body>
<div id="count" style="position:absolute; left:0px; top:0px; visibility: hidden">
<layer visibility=hidden>
<!--begin of Top100-->
<a href="http://top100.rambler.ru/top100/" target=_top><img src="http://counter.rambler.ru/top100.cnt?208592" alt="Rambler's Top100" width=1 height=1 border=0></a>
<!--end of Top100 code-->
<!-- SpyLOG v2 f:0210 --> 
<script language="javascript"> 
u="u1151.35.spylog.com";d=document;nv=navigator;na=nv.appName;p=0;j="N"; 
d.cookie="b=b";c=0;bv=Math.round(parseFloat(nv.appVersion)*100); 
if (d.cookie) c=1;n=(na.substring(0,2)=="Mi")?0:1;rn=Math.random(); 
z="p="+p+"&rn="+rn+"&c="+c+"&tl=0&ls=0&ln=0";if (self!=top) {fr=1;} else {fr=0;} 
sl="1.0";</script><script language="javascript1.1"> 
pl="";sl="1.1";j = (navigator.javaEnabled()?"Y":"N");</script> 
<script language=javascript1.2> 
sl="1.2";s=screen;px=(n==0)?s.colorDepth:s.pixelDepth; 
z+="&wh="+s.width+'x'+s.height+"&px="+px; 
</script><script language=javascript1.3> 
sl="1.3"</script><script language="javascript"> 
y="";y+="<img src='http://"+u+"/cnt?"+z+"&j="+j+"&sl="+sl+ 
"&r="+escape(d.referrer)+"&fr="+fr+"&pg="+escape(window.location.href); 
y+="' border=0 width=1 height=1 alt='SpyLOG'>"; 
d.write(y);if(!n) { d.write("<"+"!--"); }//--></script><noscript> 
<img src="http://u1151.35.spylog.com/cnt?p=0" alt='SpyLOG' border='0' width=1 height=1 > 
</noscript><script language="javascript1.2"><!-- 
if(!n) { d.write("--"+">"); }//--></script> 
<!-- SpyLOG -->
<!--TalkCounter COUNTER-->
	<img src="http://counter.ugansk.sibintek.ru/cnt.asp?id=9" alt="" width=1 height=1 border=0>
<!--TalkCounter COUNTER-->
<img src="http://trent.v6.ru/counter/index.php" alt="" width=1 height=1 border=0>
<!-- InterSib counter -->
	<img src="http://intersib.ab.ru/cgi-bin/count.cgi?id=5212" border="0" WIDTH=88 HEIGHT=31 alt="������� �������� ������"></a>
<!-- InterSib counter -->
</layer>
</div>
</html>