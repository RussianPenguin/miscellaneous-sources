<?

$filename="gb.inc";
$data = fopen($filename,"r");
$mas = file($filename);
$len = sizeof($mas);
$vallen = $len/5;
for ($ie=0;$ie<=$vallen;$ie++)
{
	$lenvar = strlen($lala[$ie]);
	if ($lenvar==0)
	{
		for($n=0;$n<5;$n++)
		{
			$nn=$n+$ie*5;
			$newmas .= $mas[$nn];
		}
	}
}
fclose ($data);
$data = fopen($filename,"w+");
fwrite($data,"$newmas");
fclose ($data);
Header("Location: admin.php");exit;

?>