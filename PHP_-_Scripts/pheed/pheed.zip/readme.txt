#####################################
#####################################
#####                           #####
#####  PHEED - newsfeed engine  #####
#####          v.1.2            #####
#####################################
#####################################

========
Features
1) multilanguage  (English, French, German, Russian, Dutch, Portuguese)
2) multiple databases support (MySQL,ODBC) with an abstraction layer
3) fast
4) you can add news in plain text or rich HTML format
5) photo and link attachments
6) automatic archive support (montly or weekly)
7) print version of the news

============
Installation

1) unpack the files
2) open and edit pheedini.php3
3) copy pheedini.php3, the DB layer file and the lang file to the newsadmin directory
4) execute the SQL statement to make the table (NOTE: you can change the name of the table, but don't forget to update pheedini.php3)

CREATE TABLE news (
   id mediumint(7) NOT NULL auto_increment,
   date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   title varchar(255) NOT NULL,
   text blob NOT NULL,
   image varchar(255) NOT NULL,
   caption varchar(255) NOT NULL,
   view mediumint(7) NOT NULL,
   URL varchar(50) NOT NULL,
   urlname varchar(50) NOT NULL,
   KEY id (id),
   KEY id_2 (id)
)

5) upload the files to the server, make sure that access to newsadmin is restricted
6) add this to your file:
include "pheed.php3"; 
or you can use pheed.php3 as a standalone script
7) that's all
8) pheed_by_week.php3 is the weekly version of pheed


===========
Information

you may contribute to Pheed:
a) by translating the .lang file to other languages
b) by making an abstraction layer for other databases (like Oracle, Postgres etc.)

=======
Contact

Mike Baikov
mikebmv@hotmail.com
http://www.tourbase.ru/zink/