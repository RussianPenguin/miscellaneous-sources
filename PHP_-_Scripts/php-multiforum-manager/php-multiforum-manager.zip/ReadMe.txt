		############################################
		##                                        ##
		##       MULTIFORUM MANAGER v 1.2.1       ##
		##          by Daniel Williams            ##
		##                                        ##
		##      http://www.webscriptworld.com     ##
		##                                        ##
		############################################
					
Copyright 2000 Web Drive Limited. All Rights Reserved.

This program may be used and modified free of charge by anyone, so long as this
copyright notice and the header above remain intact.  By using this program you agree
to indemnify Web Drive Limited from any liability.

Selling the code for this program without prior written consent is expressly forbidden.
Obtain permission before redistributing this program over the Internet or in any other
medium.  In all cases copyright and header must remain intact.

Send support requests, bug reports, suggestions and feedback to daniel@webdrive.co.nz

########################################################################################

ABOUT THE MULTIFORUM MANAGER

The MultiForum Manager allows you to manage multiple message boards from a centralized
web-based administration system.

The notes below describe the features of the MultiForum Manager, as well as support notes.
Please read the following notes before setting up your MultiForum Manager.

QUICK FEATURES

* Manage multiple forums 
* Web-based interface
* Fully customisable layout
* Optional language filters
* Subscriber lists
* Simple and Advanced modes

Descriptions below...

########################################################################################

ABOUT SECURITY

Security Features:

* Max 3 Login attempts allowed. Upon 3 incorrect attempts the Password file is locked
  and an email message sent to the administrator informing of the breach.
* Subscriber lists are virtually impossible to read via the web.

########################################################################################

SETTING UP THE MULTILIST MANAGER FOR ADVANCED USERS

1. Create a directory called "forums" or something similar
2. Chmod this directory to 707
3. Upload FORUM.PHTML, SUBSCRIBE.PHTML and UNSUB.PHTML to this directory
4. Create a directory called "admin" inside the "forums" directory
5. Chmod this directory to 707
6. Upload INDEX.PHTML and ADMIN.PHTML to this directory
7. Access the admin from "yourdomain.com/forums/admin/login.phtml"
8. Set up the MFM from your web-based admin

########################################################################################

SETTING UP THE MULTIFORUM MANAGER FOR BEGINNERS

First you need to create a directory where you will store the MultiForum Manager.
"forums" is a good name to use. Now change the permissions of this directory (chmod) to 707.
You can do this in most FTP clients by selecting the directory and choosing the option
"Change File Attributes".

Upload these files to the directory you just created:
- forum.phtml
- subscribe.phtml
- unsub.phtml

Now create a directory called "admin" within the directory you just created. Chmod this
directory to 707.

Upload these files to the admin directory:
- index.phtml
- admin.phtml

Now via the Web go to the "yourdomain.com/forums/admin" directory you just created. 
You will be prompted to enter a password. You can choose anything you like, but ensure
you remember the password as you'll need to enter it every time you access the MultiForum
Manager.

Note: For added security it is a good idea to change the name of the index.phtml file 
to something else. This will make it even harder for hackers and crackers to find your
login page. A blank html file is created by the script to remove the directory listing
in the browser.

You can change the password at any time by selecting "Change Password" on the menu.

Once you have logged in for the first time you'll need to enter some information about 
your site and server.

The first is the "Path to Sendmail". We have included the general path for Linux, but 
this may be different for your server. To find out the exact location type the following
command into your Telnet client (without the quotes)

"whereis sendmail"

The second is the "URL to PHP MultiForum Manager". This is the URL where your MFM 
is on the Web. Your Domain and the directory will already be in the field.

The third is the server path to your MFM directory. This should already be in the field.

The fourth is your email address. This is the address that security messages will be 
sent if there is any suspected breaches of security, i.e., when an unauthorized person 
is trying to access your MultiForum Manager and is locked out.

Fifth is the option to view server messages. This will show a box with messages from 
our server to inform you of news and updates to the script. We'll also let you know about
support, bugs and future scripts.

You can change any of this information at any time by selecting "Set Up" from the menu.

########################################################################################

USING THE MULTIFORUM MANAGER

Now that you've gone through the initial set up process you'll be ready to start using the 
MultiForum Manager.

###########################################
* Simple and Advanced Mode *
###########################################

On the menu on the left you'll see the option "To Simple Mode". The default setting is 
Advanced Mode, but if you want to set the list up for clients who will be easily confused
by all the options you can switch to Simple Mode, which contains only the most common 
options.

###########################################
* Adding a Forum *
###########################################

To add a forum select "Add Forum" from the menu. Then proceed to complete the following 
fields:

Forum Name
 - The name of your forum
Short Name
 - A short ID name for your forum. Do not include spaces in your forum name
Messages to Display
 - This is the number of messages that will be displayed on your forum
Characters Allowed in Message
 - The number of characters allowed in message (to avoid overflow)
Text
 - Enter your text attributes for font, size, and color
Tables
 - Enter your color attributes for the display tables. Leave blank for no color
Include Subscriber List
 - Visitors can subscribe to reveive notification when a message is posted. This can
   be turned off at any time.
Language Filter
 - Leave blank for no filter, or enter words to filter (divided by | )

The "Header" and "Footer" files are what will be placed at the top and bottom of your
forum pages. This is so you can customize the look of the pages to match your site.
You can only use phtml files, so simply rename your header and footer files from "htm"
or "html" to "phtml" (if they aren't already).

###########################################
* Editing and Deleting Forums *
###########################################

To edit or delete a forum select "Edit Forum" from the menu. Select a forum and choose 
"Edit" or "Delete".

If you are editing a forum you can change any of the fields you completed when adding a 
list.

###########################################
* Editing Messages *
###########################################

Here you can remove messages from your forums. Select "Edit Messages" from the menu.

You'll be presented with a list of forums to choose from.

Once you've chosen a forum you'll see all the subjects currently on that board. You can
select the messages to remove here.

###########################################
* Viewing Subscribers *
###########################################

Use this option to view and edit the subscribers on your lists. You'll be presented with 
a list of your lists to edit.

Upon selecting a list to view you'll be presented with a text box that contains all the 
subscribers on your list. The addresses are listed alphabetically. Here you can add and 
remove subscribers and save them.

Note: Large lists become very big files. A list of 10,000 addresses is roughly 
200KB. If viewing lists and saving changes remember that this may take a long time or 
time out in your browser if the lists are too big.

###########################################
* Support *
###########################################

This script is provided "as is". If you need help with this script please post a message on the Support Forum at http://www.webscriptworld.com

########################################################################################

Copyright 2000 Web Drive Limited
