USE slooze;

ALTER TABLE Topics ADD Summary varchar(255);
ALTER TABLE Comments ADD IP varchar(96);

UPDATE Topics SET Summary = '';
UPDATE Topics SET ParentTopicID='/' WHERE TopicID='/';
UPDATE Comments SET IP = '';
