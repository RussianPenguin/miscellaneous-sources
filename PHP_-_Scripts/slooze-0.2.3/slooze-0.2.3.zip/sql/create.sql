create database slooze;
use slooze;
create table Rolls (
  RollID varchar(64) not null,
  primary key (RollID)
);
create table Topics (
  TopicID varchar(64) not null,
  ParentTopicID varchar(64) references Topics (TopicID),
  Description varchar(255),
  Summary varchar(255),
  primary key (TopicID)
);
create table Pictures (
  RollID varchar(64) not null references Rolls (RollID),
  FrameID varchar(64) not null,
  ParentTopicID varchar(64) references Topics (TopicID),
  Description varchar(255),
  Views INT DEFAULT 0,
  Rating float default 0.0,
  primary key (RollID, FrameID)
);
create table Comments (
  CommentID varchar(64) not null,
  RollID varchar(64) not null references Rolls (RollID),
  FrameID varchar(64) not null references Pictures (FrameID),
  Comment varchar(255),
  IP varchar(96),
  primary key (CommentID)
);
create table Ratings (
  RollID varchar(64) not null references Rolls (RollID),
  FrameID varchar(64) not null references Pictures (FrameID),
  Rating int,
  IP varchar(96),
  RateTime int
);
insert into Topics
  (TopicID, ParentTopicID, Description)
  values ('/','/','All Photos');
