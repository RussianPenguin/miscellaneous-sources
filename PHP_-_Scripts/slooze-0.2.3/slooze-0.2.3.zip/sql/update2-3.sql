use slooze;

create table Ratings (
  RollID varchar(64) not null references Rolls (RollID),
  FrameID varchar(64) not null references Pictures (FrameID),
  Rating int,
  IP varchar(96),
  RateTime int
);

alter table Pictures add Views int default 0;
alter table Pictures add Rating float default 0.0;

update Pictures set Views = 0;
update Pictures set Rating = 0.0;
