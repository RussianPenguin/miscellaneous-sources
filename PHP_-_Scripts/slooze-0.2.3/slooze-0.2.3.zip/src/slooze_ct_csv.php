<?php  /* -*- Mode: C++; indent-tabs-mode: nil; c-basic-indent: 2 -*- */
/*
 * Slooze PHP Web Photo Album
 * Copyright (c) 2000 Slooze developers (see AUTHORS file)
 * $Id: slooze_ct_csv.php,v 1.13 2000/12/27 22:06:06 mdkendall Exp $
 *
 * Container (Ct) class holding the photo data. Exactly where the data is
 * stored depends on which Ct class you use. In this implementation, the data
 * is held in CSV files reached via an encapsulating class.
 *
 * Function naming convention:
 * getBars()          SELECT * FROM Bars
 * getBarsInFoo($foo) SELECT * FROM Bars WHERE (Foo = $foo)
 * getBar($barID)     SELECT * FROM Bars WHERE (BarID = $barID) BarID is primary key
 *
 * getBars...() returns $bar[rows][fields]
 * getBar()     returns $bar[fields]
 *
 * addBar($bar)       INSERT INTO Bars VALUES $bar
 * updateBar($bar)    UPDATE Bars SET * = $bar WHERE (BarID = $bar[BarID])
 * deleteBar($barID)  DELETE FROM Bars WHERE (BarID = $barID)
 *
 */

class SloozeCtCsv {

  /* Redefine this parameter by deriving your own class */
  var $csvClass = "Csv";  /* type of csv file data store */
  var $csv;               /* csv file data store */
  var $errString;         /* if an error occurs, set this to the error */
  
  /* public: constructor */
  function SloozeCtCsv() {
    $name = $this->csvClass;
    $this->csv = new $name;
  }

  /* public: resetError() makes errString empty so errors don't carry over */
  function resetError() {
    $this->errString = "";
  }

  /* public: getError() returns errString */
  function getError() {
    return $this->errString;
  }

  /* public: getTopics() returns all the topics.
   * Logically: SELECT * FROM Topics */
  function getTopics() {
    return( $this->csv->read( 'topics' ) );
  }

  /* public: getTopicsInParentTopic() returns all the topics with the
   * given parent TopicID. Slash / is a magic TopicID meaning root.
   * Logically: SELECT * FROM Topics WHERE ( (ParentTopicID = $parentTopicID) 
   * and (TopicID != '/') ) */
  function getTopicsInParentTopic( $parentTopicID = "/" ) {
    $allTopics = $this->getTopics();
    $topics = array();
    reset($allTopics);
    while( list($key, $topic) = each($allTopics) ) {
      if( ($topic['ParentTopicID'] == $parentTopicID) &&
          ($topic['TopicID'] != "/") ) {
        $topics[] = $topic;
      }
    }
    return( $topics );
  }

  /* public: getTopic() returns a single topic.
   * Logically: SELECT * FROM Topics WHERE (TopicID = $topicID) */
  function getTopic( $topicID ) {
    $allTopics = $this->getTopics();
    reset($allTopics);
    while( list($key, $topic) = each($allTopics) ) {
      if( $topic['TopicID'] == $topicID ) {
        return( $topic );
      }
    }
    return FALSE;
  }

  /* public: addTopic() adds one single topic */
  function addTopic( $topic ) {
    if (is_array($topics = $this->csv->read('topics'))) {
      $topics[] = $topic;
      return($this->csv->write('topics', $topics));
    }
    return FALSE; /* read failed */
  }

  /* public: deleteTopic() deletes one single topic */
  function deleteTopic( $topicID ) {
    if (is_array($topics = $this->csv->read('topics'))) {
      $newTopics = array();
      reset($topics);
      while( list($key, $topic) = each($topics)) {
        if($topic['TopicID'] != $topicID) {
          $newTopics[] = $topic;
        }
      }
      return($this->csv->write('topics', $newTopics));
    }
    return FALSE; /* failed */
  }

  /* public: updateTopic() updates one single topic */
  function updateTopic( $topic ) {
    if ($this->deleteTopic($topic['TopicID'])) {
      return ($this->addTopic($topic));
    }
    return FALSE; /* delete failed */
  }

  /* public: getRolls() returns all the rolls.
   * Logically: SELECT * FROM Rolls */
  function getRolls() {
    return( $this->csv->read( 'rolls' ) );
  }

  /* public: addRoll() adds one single roll */
  function addRoll( $roll ) {
    if (is_array($rolls = $this->csv->read('rolls'))) {
      $rolls[] = $roll;
      return($this->csv->write('rolls', $rolls));
    }
    return FALSE; /* read failed */
  }

  /* public: deleteRoll() deletes one single roll */
  function deleteRoll( $rollID ) {
    if (is_array($rolls = $this->csv->read('rolls'))) {
      $newRolls = array();
      reset($rolls);
      while( list($key, $roll) = each($rolls)) {
        if($roll['RollID'] != $rollID) {
          $newRolls[] = $roll;
        }
      }
      return($this->csv->write('rolls', $newRolls));
    }
    return FALSE; /* failed */
  }

  /* public: updateRoll() updates one single roll */
  function updateRoll( $roll ) {
    if ($this->deleteRoll($roll['RollID'])) {
      return ($this->addRoll($roll));
    }
    return FALSE; /* delete failed */
  }

  /* public: getPictures() returns all the pictures.
   * Logically: SELECT * FROM Pictures */
  function getPictures() {
    return( $this->csv->read( 'pictures' ) );
  }

  /* public: getPicturesInRoll() returns all the Pictures in a given Roll.
   * Logically: SELECT * FROM Pictures WHERE (RollID = $rollID) */
  function getPicturesInRoll( $rollID ) {
    $allPictures = $this->getPictures();
    $pictures = array();
    reset($allPictures);
    while( list($key, $picture) = each($allPictures) ) {
      if( $picture['RollID'] == $rollID ) {
        $pictures[] = $picture;
      }
    }
    return( $pictures );
  }

  /* getPicturesInTopic() returns all the Pictures in a given Topic.
   * Logically: SELECT * FROM Pictures WHERE (ParentTopicID = $topicID) */
  function getPicturesInTopic( $topicID ) {
    $allPictures = $this->getPictures();
    $pictures = array();
    reset($allPictures);
    while( list($key, $picture) = each($allPictures) ) {
      if( $picture['ParentTopicID'] == $topicID ) {
        $pictures[] = $picture;
      }
    }
    return( $pictures );
  }

  /* getPicturesInSearch() returns all the Pictures where the given
   * search term occurs in the Description.
   * Logically: SELECT * FROM Pictures WHERE (Description LIKE $search) */
  function getPicturesInSearch( $search ) {
    $pictures = array();
    if( $search != "") {
      $allPictures = $this->getPictures();
      reset($allPictures);
      while( list($key, $picture) = each($allPictures) ) {
        if( stristr($picture['Description'], $search) ) {
          $pictures[] = $picture;
        }
      }
    }
    return( $pictures );
  }

  /* getPicture() returns a single picture.
   * Logically: SELECT * FROM Pictures WHERE (RollID = $rollID && FrameID = $frameID) */
  function getPicture( $rollID, $frameID ) {
    $allPictures = $this->getPictures();
    reset($allPictures);
    while( list($key, $picture) = each($allPictures) ) {
      if( $picture['RollID'] == $rollID && $picture['FrameID'] == $frameID) {
        return( $picture );
      }
    }
    return FALSE;
  }

  /* public: addPicture() adds one single picture */
  function addPicture( $picture ) {
    if (is_array($pictures = $this->csv->read('pictures'))) {
      $pictures[] = $picture;
      return($this->csv->write('pictures', $pictures));
    }
    return FALSE; /* read failed */
  }
  
  /* public: deletePicture() deletes one single picture */
  function deletePicture( $rollID, $frameID ) {
    if (is_array($pictures = $this->csv->read('pictures'))) {
      $newPictures = array();
      reset($pictures);
      while( list($key, $picture) = each($pictures)) {
        if(!(($picture['RollID'] == $rollID) &&
             ($picture['FrameID'] == $frameID))){
          $newPictures[] = $picture;
        }
      }
      return($this->csv->write('pictures', $newPictures));
    }
    return FALSE; /* read failed */
  }

  /* public: updatePicture() updates one single picture */
  function updatePicture( $picture ) {
    if( $allPictures = $this->getPictures() ) {
      reset($allPictures);
      while( list($currentkey, $currentpicture) = each($allPictures) ) {
        if( $currentpicture['RollID'] == $picture['RollID'] &&
            $currentpicture['FrameID'] == $picture['FrameID']) {
          while( list($key, $val) = each($picture) ) {
            $allPictures[$currentkey][$key] = $picture[$key];
          }
        }
      }
      return($this->csv->write('pictures', $allPictures));
    } else {
      return FALSE; /* getPictures failed */
    }
  }
 
  /* public: incrementPictureViews() add one to Views field of picture */
  function incrementPictureViews( $rollID, $frameID, $picture ) {
    $picture['Views'] += 1;
    $this->updatePicture($picture);
    return TRUE;
  }
  
  /* public: getComments() returns all the comments.
   * Logically: SELECT * FROM Comments */
  function getComments() {
    return( $this->csv->read( 'comments' ) );
  }
  
  /* getCommentsInPicture() returns all the Comments for the given picture.
   * Logically: SELECT * FROM Comments WHERE (RollID = $rollID && FrameID = $frameID) */
  function getCommentsInPicture( $rollID, $frameID ) {
    $comments = array();
    $allComments = $this->getComments();
    reset($allComments);
    while( list($key, $comment) = each($allComments) ) {
      if( $comment['RollID'] == $rollID && $comment['FrameID'] == $frameID) {
        $comments[] = $comment;
      }
    }
    return( $comments );
  }

  /* public: addComment() adds one single comment */
  function addComment( $comment ) {
    if (is_array($comments = $this->csv->read('comments'))) {
      $comments[] = $comment;
      return($this->csv->write('comments', $comments));
    }
    return FALSE; /* read failed */
  }

  /* public: deleteComment() deletes one single comment */
  function deleteComment( $commentID ) {
    if (is_array($comments = $this->csv->read('comments'))) {
      $newComments = array();
      reset($comments);
      while( list($key, $comment) = each($comments)) {
        if($comment['CommentID'] != $commentID) {
          $newComments[] = $comment;
        }
      }
      return($this->csv->write('comments', $newComments));
    }
    return FALSE; /* failed */
  }

  /* public: addRating() adds a rating */
  function addRating( $rating ) {
    if (is_array($ratings = $this->csv->read('ratings'))) {
      $ratings[] = $rating;
      $this->csv->write('ratings', $ratings);
      /* calculate the new rating for the picture */
      reset($ratings);
      $count = 0; $total = 0;
      while( list(,$oldRating) = each($ratings) ) {
        if ( $oldRating['RollID'] == $rating['RollID'] &&
             $oldRating['FrameID'] == $rating['FrameID'] ) {
          $count += 1;
          $total += $oldRating['Rating'];
        }
      }
      $score = ($count>0) ? $total/$count : 0;
      /* update the picture */
      $picture = $this->getPicture($rating['RollID'], $rating['FrameID']);
      $picture['Rating'] = $score;
      $this->updatePicture($picture);
    }
    return FALSE; /* read failed */
  }

  /* public: checkDataVersion() makes sure our database/csv has the right structure, and maybe fixes it if it doesn't */
  function checkDataVersion() {
  }

} /* end of class SloozeCtCsv */
?>
