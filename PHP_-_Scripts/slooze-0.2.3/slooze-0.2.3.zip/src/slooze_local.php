<?php
/*
 * Slooze PHP Web Photo Album
 * Copyright (c) 2000 Slooze developers (see AUTHORS file)
 * $Id: slooze_local.php,v 1.14 2001/01/15 00:40:58 mdkendall Exp $
 *
 * Local customisations - edit this file only
 * Uncomment and edit as required
 */

/* --------
 * Strings. Edit these definitions to customise the words used, or to
 * localise Slooze for lanugages other than English. These strings only affect
 * the displayed HTML, they have no effect on the operation of the script or
 * the names of tables and fields in the database. */

/* Display Text for Navigation */
define('SLZ_STR_NAV_FIRST','First');
define('SLZ_STR_NAV_PREVIOUS','Previous');
define('SLZ_STR_NAV_NEXT','Next');
define('SLZ_STR_NAV_LAST','Last');
define('SLZ_STR_NAV_TEXT_SEPARATOR','|');

/* Headings for forms */
define('SLZ_STR_HDR_UPDATE_TOPIC', 'Update topic'); /* heading for update topic form */
define('SLZ_STR_HDR_DELETE_TOPIC', 'Delete topic'); /* heading for delete topic form */
define('SLZ_STR_HDR_ADD_TOPIC', 'Add topic'); /* heading for add topic form */
define('SLZ_STR_HDR_UPDATE_PICTURE', 'Update picture'); /* heading for update picture form */
define('SLZ_STR_HDR_DELETE_PICTURE', 'Delete picture'); /* heading for delete picture form */
define('SLZ_STR_HDR_ADD_PICTURE', 'Add picture'); /* heading for add picture form */
define('SLZ_STR_HDR_ADD_ALL_PICTURES', 'Add all pictures'); /* heading for add all pictures form */
define('SLZ_STR_HDR_UPDATE_ROLL', 'Update roll'); /* heading for update roll form */
define('SLZ_STR_HDR_DELETE_ROLL', 'Delete roll'); /* heading for delete roll form */
define('SLZ_STR_HDR_ADD_ROLL', 'Add roll'); /* heading for add roll form */
define('SLZ_STR_HDR_ADD_COMMENT', 'Add comment'); /* heading for add comment form (disabled) */
define('SLZ_STR_HDR_DELETE_COMMENT', 'Delete comment'); /* heading for delete comment form (disabled) */
define('SLZ_STR_HDR_ADD_RATING', 'Add rating'); /* heading for add rating form (disabled) */

/* Headings for other page elements */
define('SLZ_STR_HDR_ROLL', 'Roll'); /* heading for single roll */
define('SLZ_STR_HDR_ROLLS', 'Rolls'); /* heading for list of rolls */
define('SLZ_STR_HDR_SEARCH', 'Search results'); /* heading for search results */

/* Displayed names of fields (mostly used on forms) */
define('SLZ_STR_DESCRIPTION', 'Description'); /* description field */
define('SLZ_STR_SUMMARY', 'Summary'); /* summary field */
define('SLZ_STR_COMMENT', 'Comment'); /* comment field */
define('SLZ_STR_RATING', 'Current rating'); /* rating field */
define('SLZ_STR_TOPICID', 'TopicID'); /* TopicID field */
define('SLZ_STR_PARENTTOPICID', 'Parent topic'); /* ParentTopicID field */
define('SLZ_STR_ROLLID', 'RollID'); /* RollID field */
define('SLZ_STR_FRAMEID', 'FrameID'); /* FrameID field */

/* Ratings */
define('SLZ_STR_RATING_M2', 'Dreadful');  /* rating -2 text */
define('SLZ_STR_RATING_M1', 'Poor');      /* rating -1 text */
define('SLZ_STR_RATING_0',  'Average');   /* rating 0 text */
define('SLZ_STR_RATING_P1', 'Good');      /* rating +1 text */
define('SLZ_STR_RATING_P2', 'Excellent'); /* rating +2 text */

/* Error messages */
define('SLZ_STR_ERR_DFLT', 'Unknown error'); /* default error message */

/* Miscellaneous text used in page bodies */
define('SLZ_STR_NO_DESC', 'No description'); /* default description for topic */
define('SLZ_STR_MOST_VIEWED', 'Most viewed'); /* link text for most viewed pictures*/
define('SLZ_STR_HIGHEST_RATED', 'Highest rated'); /* link text for highest rated pictures*/
define('SLZ_STR_SEARCH_TERM', 'Search term'); /* search term */
define('SLZ_STR_VIEWS', 'views'); /* views */

/* --------
 * To store data in text files use slooze_csv and slooze_ct_csv
 * Comment this entire section out if using an RDBMS (until 
 * end of MySloozeCtCsv) */

require("slooze_csv.php");
require("slooze_ct_csv.php");

class MyCsv extends Csv {
//var $path = "./";  /* path to csv files e.g. "/usr/foo/htdocs/photos/" */
//var $nl = "\n";  /* newline sequence, use "\r\n" for windows */
  /* public: constructor, call parent constructor */
  function MyCsv() {
    $this->Csv();
  }
}

class MySloozeCtCsv extends SloozeCtCsv {
  var $csvClass = "MyCsv";  /* type of csv file data store */
  /* public: constructor, call parent constructor */
  function MySloozeCtCsv() {
    $this->SloozeCtCsv();
  }
}

/* --------
 * To store data in an RDBMS use slooze_ct_sql and whichever db_*.inc
 * is applicable for your particular database. Uncomment as required.
 * Get the db_*.inc files from PHPLib - http://phplib.netuse.de/  */
 
//require("slooze_ct_sql.php");

//require("db_mysql.inc"); /* uncomment exactly one of these db_*.inc files */
//require("db_msql.inc");
//require("db_mssql.inc");
//require("db_oci8.inc");
//require("db_odbc.inc");
//require("db_oracle.inc");
//require("db_pgsql.inc");
//require("db_sybase.inc");
//require("db_usql.inc");

//class MyDB_Sql extends DB_Sql {
//  var $Host = "localhost";
//  var $Database = "slooze";
//  var $User = "";
//  var $Password = "";
//  /* public: constructor, call parent constructor */
//  function MyDB_Sql($query = "") {
//    $this->DB_Sql($query);
//  }
//}

//class MySloozeCtSql extends SloozeCtSql {
//  var $sqlClass = "MyDB_Sql";  /* type of RDBMS data store */
//  /* public: constructor, call parent constructor */
//  function MySloozeCtSql() {
//    $this->SloozeCtSql();
//  }
//}

/* --------
 * Always include slooze
 * Uncomment the $ctClass line below that applies to you
 * Uncomment other lines to customise */
 
require("slooze.php");

class MySlooze extends Slooze {
//  var $admin = FALSE;         /* enable full admin mode */
//  var $enableComments = TRUE; /* enable user addition of comments */
//  var $enableRatings = TRUE;  /* enable user rating of pictures */
//  var $enableViews = TRUE;    /* enable counting how many times a picture has been viewed */
//  var $enableNav = TRUE;      /* enable First|Prev|Next|Last navigation */
//  var $enableCache = FALSE;   /* enable caching of pages for speed */
//  var $allPathsLower = FALSE; /* make all image paths lower-case, no matter their recorded case */
//  var $showCommentIPs = FALSE; /* put IP of commenter before comment */
//  var $ownIPSubstring = "192.168.1."; /* don't count picture views coming from this address substring */
//  var $sortThreshold = 5;  /* number of pics in topic before sorting offered */
//  var $basePath = "./"; /* path to photos directory */
//  var $cachePath = "./cache/"; /* path to cache directory */
//  var $baseURL = "./";  /* URL of photos directory */
//  var $actionURL = "";  /* URL for further actions */
//  var $picture_suffix = ".jpg";  /* filename suffix for pictures */
//  var $thumb_suffix = "-t.jpg";  /* filename suffix for thumbnails */
//  var $nl = "\r\n";              /* newline sequence */

  var $ctClass = "MySloozeCtCsv";   /* store data in text files */
//var $ctClass = "MySloozeCtSql";   /* store data in RDBMS */

  /* public: constructor, call parent constructor */
  function MySlooze() {
    $this->Slooze();
  }
}

?>
