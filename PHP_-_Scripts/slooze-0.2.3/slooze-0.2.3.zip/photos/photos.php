<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Slooze Demo</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<p>This is a demonstration of <em>Slooze</em> PHP Web Photo Album.
For the latest information see
<a href="http://www.slooze.com">www.slooze.com</a>.</p>
<hr>

<?php
require("slooze_local.php");
$mySlooze = new MySlooze();
$vars = $mySlooze->validateInputs();
$msg = $mySlooze->renderPage($vars);
echo $msg;
?>

<hr>
<p>This is the view seen by browsers who do not have administrative
access. To make changes, use the <a href="admin.php">admin page</a>.</p>
</body>
</html>
