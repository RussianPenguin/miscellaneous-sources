
 Dynapic SE - dynamic image galleries

version 1.5 stable (read the disclaimer in the end of this file)

A PHP-driven image gallery

==========================
 features:
==========================

1) doesn't require a database
2) unlimited number of thumbnail galleries
3) customisable appearance
4) generates dynamically the galleries
5) prints the NEXT/PREV links
6) easy configuration
7) SE - prints the NEXT/PREV picture links AND thumbnails (SE means Slow Edition)
8) supports JPEG files by default (read HOW TO ADD TYPES)

==========================
 requirements:
==========================

PHP3 / web server

==========================
 was tested on:
==========================

Win98/PHP 4/Apache 1.3.6
FreeBSD/PHP 3.0.13/MySQL 3.22/Apache 1.3.9

==========================
 installation:
==========================
1) unpack

OK, you have unpacked it, the files you'll find:
index.php3 - the script which generates the thumbnail galleries
view.php3 - the script which shows the large view
conf.inc - the configuration file

2) copy those files to the server in a separate directory, for example /dynapic/

3) configure the conf.php3 file

$col=4; - the number of columns to be displayed
$row=3; - the number of rows to be displayed
$title[0]="Summer holidays"; - the title of the gallery
$dir[0]="/home/youtserverpath/holidays"; - the PATH to the pictures of the first gallery
$picurl[0]="http://www.yourserver.com/holidays"; - the URL to the pictures of the first gallery
$tndir[0]="http://www.yourserver.com/holidays/tn"; - the URL to the pictures of the first gallery
//$title[1]="Winter holidays"; - the title of the 2nd gallery
//$dir[1]="/home/youtserverpath/winter"; - the PATH to the pictures of the 2nd gallery
//$picurl[1]="http://www.yourserver.com/winter";
//$tndir[1]="http://www.yourserver.com/winter/tn";


4) make sure you have uploaded the thumbnails and the pictures to the appropriate locations. 

5) make the necessary links in your pages

for example, the URL to /dynapic/ is http://www.foo.com/user/dynapic/

if you make this link:
<a href="http://www.foo.com/user/dynapic/">My photos</a>
the user will see the list of the galleries

if you make this link:
<a href="http://www.foo.com/user/dynapic/?gal=1">My photos</a>
the user will see the first page of the 2nd gallery

if you make this link:
<a href="http://www.foo.com/user/dynapic/?gal=1&pg=4">My photos</a>
the user will see the fifth page of the second gallery

6) that's all

==========================
 how to add pictures:
==========================

just upload them, with the thumbnails.
WARNING ! The thumbnail must have the same name as the big image (file names are CASE SENSITIVE).
To make the thumbnails, I recommend IrfanView (http://www.irfanview.com/) - it has a very powerful batch conversion feature.

==========================
 how to add file types
==========================
in index.php3 find this line:

if (eregi("jpg$",$file)){

replace jpg$ by any extension you want
for multiple types support replace jpg$ by (jpg|gif|png|jpeg)$
beware, that the thumbnails must have the same extensions 

==========================
DISCLAIMER
==========================
 This software is distributed AS IS under the terms of the GPL licence. By using this software you agree to the terms of the licence (such as: not to change this disclaimer, to dustribute freely the source code, NOT to compile it or ask fees for this software and blah, blah, blah.)



Dynapic site:  http://www.tourbase.ru/zink
author: Mike Baikov (mikebmv@hotmail.com)