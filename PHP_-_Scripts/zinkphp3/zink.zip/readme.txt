
 ZINK - the link engine

version 1.2 stable

A free Yahoo-like link directory

 features:

1) unlimited depth of subcategories
2) unlimited number of categories / links
3) case incensitive search of the links database
4) multilanguage support (English, French, Russian, Spanish, Catalan in v1.1) for the end-user interface
5) visitors can add links & categories
6) customisable header & footer
7) easy admin interface

 requirements:

PHP3 / MySQL / web server

 was tested on: 

Win98/PHP 3.0.6/MySQL 3.19/Apache 1.3.6
FreeBSD/PHP 3.0.13/MySQL 3.22/Apache 1.3.9

 installation:

1) unpack
2) copy to the server
3) run install.php3
4) make sure access to the admin directory is protected
5) that's all

 how to use:

by default submitted URLs are requested authorization
go to the admin directory to approve submissions

 how to contribute:

You may contribute to Zink by translating it into the languages you know

For a demo see http://www.tourbase.ru/links (in russian)

Zink site:  http://www.tourbase.ru/zink
author: Mike Baikov (mikebmv@hotmail.com)