<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
$sql="select id from oboard_headers where parent is null and club=$CLUB order by id desc";
$counter=0;
$supcounter=1;
        if (($query=new query($db, $sql)) && $query->getrow() )
        {

                do
                {
                        if(!$tp) { $tp=$query->field("id"); }
                        $counter++;
                        if($counter==1)
                        {
                           if($tp==$query->field("id")) { $mmenu.="[<b>$supcounter</b>]&nbsp"; }
                           else
                           {
                              $mmenu.='[<a href="'.$PHP_SELF;
                              if($supcounter>1) { $mmenu.='?tp='.$query->field("id"); }
                              $mmenu.='">'.$supcounter.'</a>]&nbsp';
                           }
                        }
                        if($counter==$per_page) { $counter=0; $supcounter++; }
                } while ($query->getrow());
        }
        else { $mmenu= "������ � ���� ��������� �� �������"; }
        if($mmenu) { echo $mmenu; }
?>