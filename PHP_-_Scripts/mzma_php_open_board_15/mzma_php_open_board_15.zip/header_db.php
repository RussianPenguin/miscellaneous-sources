<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
require("db_lib.php");
$db=new db();
$db->open();
$db_included=1;
?>