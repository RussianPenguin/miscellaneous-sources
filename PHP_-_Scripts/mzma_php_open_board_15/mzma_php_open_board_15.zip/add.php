<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
if($url=="http://") { $url=""; }
if($url_pic=="http://") { $url_pic=""; }
$body=ereg_replace("\r",'<br>',$body);
if(!$body && !$url && !$url_pic) { $title.="(-)"; } else { $title.="(+)"; }
if(!$parent) { $sparent="null"; $cparent="is null"; } else { $sparent=$parent; $cparent="=$parent"; }
$sql="insert into oboard_headers (id,thread,club,parent,time,nick,email,title) values(null,".getThread($parent).",$CLUB,$sparent,".time().",'$nick','$email','$title')";
if (($query=new query($db, $sql)) && $query->result )
{
   if($body || $url || $url_pic)
   {
      if(!$url && $url_name) { $url_name=""; }
      $ssql="select id from oboard_headers where club=$CLUB and parent $cparent and time >".(time()-30)." and title='$title' and nick='$nick'";
      if (($query=new query($db, $ssql)) && $query->getrow() )
      {
         $subsql="insert into oboard_bodies (id,body,url,url_name,url_pic) values(".$query->field("id").",'$body','$url','$url_name','$url_pic')";
         if (($subquery=new query($db, $subsql)) && $subquery->result ) {}
      }
   }
}

?>