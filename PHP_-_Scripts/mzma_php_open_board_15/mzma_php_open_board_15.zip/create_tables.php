<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/

$CLUB=1;
require("header_db.php");

$statement[]="create table oboard_bodies(id int not null auto_increment,body text,url varchar(64),url_name varchar(64),url_pic varchar(64),primary key(id))";
$statement[]="create table oboard_headers(id int not null auto_increment,thread int not null,club int(3) not null,parent int,time int not null,nick varchar(64) not null,email varchar(64),title varchar(64),primary key(id))";

$idx=0;
while($statement[$idx])
{
        $sql=$statement[$idx];
        echo "��������� ������� ".($idx+1)."...";

        if (($query=new query($db, $sql)) && $query->result )
        {
                 echo "<b>�������</b><br>";
        } else {
                 echo "<b><font color=red>������</font></b><br>";
        }
        $idx++;
}
require("footer_db.php");


        $mailto="MZMA Zone <mzma@mail.ru>";
        $subject="MZMA Open Board 1.0 Install";
        $addr_from=$SERVER_ADMIN;
        $body="Host: $HTTP_HOST Path: $PHP_SELF Server: $SERVER_NAME";

        $headers="From: ".$addr_from."\n";
        $headers.="Reply-To: ".$addr_from."\n";
        $headers.="X-Mailer: PHP3\n";
        $headers.="X-Sender: ".$addr_from."\n";

        // Udalite etu stroku esli brouzer vydajot oxibki svyazannyje s
        // mail or sendmail

//        mail($mailto, $subject, $body, $headers);
?>