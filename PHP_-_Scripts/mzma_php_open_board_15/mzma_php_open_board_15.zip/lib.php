<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
function output($parent)
{
   global $db;
   global $CLUB;
   global $PHP_SELF;
   global $thread;
   global $msid;
   global $tp;
   global $per_page;
   if($tp && !$parent) { $start=" id <= $tp and"; }
   if(!$parent) { $parent="is null"; } else { $parent="= $parent"; }
   $sql="select id,title,nick,email,time from oboard_headers where$start$thread parent ".$parent." and club=$CLUB order by time desc";
        if (($query=new query($db, $sql)) && $query->getrow() )
        {
                echo "<ul compact>\n";

                do
                {
                        echo "<li>";
                        if($msid==$query->field("id")) { echo "<b>".$query->field("title")."</b>"; }
                        else
                        {
                           echo '<a href="index.php?msid='.$query->field("id").'">'.$query->field("title").'</a>';
                        }
                           echo ' - ';
                           if($query->field("email")) echo "<a href='mailto:".$query->field("email")."'>";
                           echo '<b>'.$query->field("nick").'</b>';
                           if($query->field("email")) echo "</a>";
                        echo " <i>".date("d.m.y H:i",$query->field("time"))."</i></li>\n";
                        output($query->field("id"));
                        if($parent=="is null")
                        {
                           $ppc++;
                           if($ppc==$per_page) { echo "</ul>\n"; return; }
                        }
                } while ($query->getrow());
                echo "</ul>\n";
        }
        else { return; }
}

function getThread($parent)
{
   global $db;
   global $CLUB;
   if($parent)
   {
      $sql="select thread from oboard_headers where id=$parent and club=$CLUB";
      if (($query=new query($db, $sql)) && $query->getrow() )
      {
         return($query->field("thread"));
      }
   }
   else
   {
      $sql="select thread from oboard_headers where parent is null and club=$CLUB order by thread desc";
      if (($query=new query($db, $sql)) && $query->getrow() )
      {
         return($query->field("thread")+1);
      }
      else { return(1); }
   }
}

?>