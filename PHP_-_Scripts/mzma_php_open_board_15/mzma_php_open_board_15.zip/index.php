<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
if($HTTP_POST_VARS)
{
 for(reset($HTTP_POST_VARS);$key=key($HTTP_POST_VARS);next($HTTP_POST_VARS))
 {
    $this = addslashes($HTTP_POST_VARS[$key]);
//    $this = strtr($this, ">", " ");
//    $this = strtr($this, "<", " ");
    $this = strtr($this, "|", " ");
    $this = trim($this);
    $$key = $this;
 }
}
if($HTTP_GET_VARS)
{
 for(reset($HTTP_GET_VARS);$key=key($HTTP_GET_VARS);next($HTTP_GET_VARS))
 {
    $this = addslashes($HTTP_GET_VARS[$key]);
    $this = strtr($this, ">", " ");
    $this = strtr($this, "<", " ");
    $this = strtr($this, "|", " ");
    $this = trim($this);
    $$key = $this;
 }
}
$CLUB=1;
$per_page=30;
require("lib.php");

require("header_db.php");
require("header.htm");
if($OK)
{
   require("validate.php");
   if(!$errors) { require("add.php"); }
}
?>
<table border=0 cellpadding=2 cellspacing=2 width=100%>
<tr>
<td class=subheader>
<a href="index.php">������</a>
 | <a href="index.php?view=form">����� ����</a></td>
</tr>
<?
if($errors) { echo "<tr><td class=regular>$errors</td></tr>\n"; }
if($msid) { require("message.php"); }
?>
</table>
<?
if(!$view || $thread)
{ ?>
<table border=0 cellpadding=2 cellspacing=2 width=100%>
<? if($thread) { echo "<tr><td class=subheader>��� ��������� �� ��� ����:</td></tr>"; } ?>
<tr><td class=small>
<? output(""); ?>
</td></tr>
<?
if(!$thread)
{
   echo "<tr><td class=subheader align=center>";
   require("menu.php");
   echo "</td></tr>\n";
}
?>
</table>
<? }
if($view=="form") { require("form.php"); }
?> <center><a href="http://www.mzma.net/scripts/">������� ������� ������� �������� �����</a></center> <?
require("footer_db.php"); 
require("footer.htm");
?>