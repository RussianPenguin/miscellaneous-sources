<?
/*
        Author: Dmitri Pronin
        E-mail: mzma@mail.ru ICQ: 2430600
        URL: http://www.mzma.net http://mzma.da.ru

        Etot i drugoj soft dostupen dlya svobodnogo otkachivanoja na
        http://www.mzma.net/scripts/ i http://mzma.da.ru/scripts/
*/
?>
<tr><td class=regular>
<?
$sql="select thread,time,nick,email,title from oboard_headers where id=$msid and club=$CLUB";
if (($query=new query($db, $sql)) && $query->getrow() )
{
   echo "<h3>".$query->field("title")."</h3>\n";
   echo "����������: ";
   if($query->field("email")) echo '<a href="mailto'.$query->field("email").'">';
   echo '<b>';
   echo $query->field("nick").'</b>';
   if($query->field("email")) echo '</a>';
   echo " <i>".date("d.m.Y � H:i",$query->field("time"))."</i>\n";
   $thread=$query->field("thread");
   $thread=" thread=$thread and";
   $title=$query->field("title");
   if(strstr($title,"(+)")) { $rmstr="(+)"; } else { $rmstr="(-)"; }
   $title=substr($title,0,strpos($title,$rmstr));
   if(!strstr($title,"Re:")) { $title="Re: ".$title; }
   if(strlen($title)>60) { $title=substr($title,0,57); $title.="..."; }
}

$sql="select body,url,url_name,url_pic from oboard_bodies where id=$msid";
if (($query=new query($db, $sql)) && $query->getrow() )
{
   echo "</td></tr>\n<tr><td class=regular>";
   echo ereg_replace("\r",'<br>',$query->field("body"));
   if($query->field("url"))
   {
      echo "</td></tr>\n<tr><td class=regular>";
      echo '<a href="'.$query->field("url").'" target="_new">';
      if($query->field("url_name")) { echo $query->field("url_name"); }
      else { echo $query->field("url"); }
      echo "</a>";
   }
   if($query->field("url_pic"))
   {
      echo "</td></tr>\n<tr><td class=regular>";
      echo '<img src="'.$query->field("url_pic").'">';
   }
}

$view="form";
?>
</td></tr>
