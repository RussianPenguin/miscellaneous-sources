<?

include "common.php";
/*
######################################################
 The script is based on Mark Napartovic's wwwboard.
 http://www.glasnet.ru/~nmark/

 Modifications by Oktay Ozturk
 http://www.bestweb.ca
 oktay@torontonian.com
 
 The Index Page modification by
 Zeke Rogers
 zrogers@sunset.net
######################################################
*/

$id = IntVal($id);
$icq = "icq.php?id=$id";
$prnt = "print.php?id=$id";
$rec = "rec.php?id=$id";
$sendmail="mail.php?id=$id";

$SQL = "SELECT * FROM messages WHERE id = $id";

$message = mysql_query($SQL);
if (!$message):
  NotAvailable();
  Exit;
endif;
if (mysql_numrows($message) == 0):
  NotAvailable();
  Exit;
endif;
$Message = mysql_fetch_array($message);
mysql_freeresult($message);

$boardid = $Message["boardid"];
$boardid = IntVal($boardid);

$SQL = "SELECT * FROM boards WHERE id = $boardid";
$board = mysql_query($SQL);

if (mysql_numrows($board) == 0):
  NotAvailable();
  Exit;
endif;

$Board = mysql_fetch_array($board);

$RO = CheckRO($boardid);

if ($Board["rdonly"] == "Y"):
  $RO = 1;
endif;

if ($NoAds):
  $Board[pagesize] = 50;
endif;

mysql_freeresult($board);

if ("$Action" != ""):
  if (!$Notification):
    $Notification = "N";
  endif;
  PostMessage ($Must, $MustName, $id, $boardid, $Author, $Subject,
		$Msg, $Url, $Email, $UrlName, $UrlImage, $Notification);
  Reload("forum.php?board=$boardid");
  Exit;
endif;

$prev = $Message["prev"];
$posted = $Message["posted"];
$author = $Message["author"];
$subject = $Message["subject"];
$url =  $Message["url"];
$urlname =  $Message["urlname"];
$urlimage =  $Message["urlimage"];
$msg = $Message["msg"];
$email = $Message["email"];

$LIMIT = $Board["pagesize"];

$root = FindRootMessage($id);
$SQL = "SELECT count(*) FROM messages WHERE boardid = $boardid AND prev = 0 AND id > $root";
$res = mysql_query($SQL);
$row = mysql_fetch_row($res);
$pcount = $row[0];

$Offset = IntVal($pcount / $LIMIT) * $LIMIT;
MessageHeader($boardid, $Board["name"] . " - $subject", $Offset);

?>
<table align="center" border="0" cellPadding="1" cellSpacing="0" class="border" width="100%">
    <tr>
      <td>
        <table border="0" cellPadding="4" cellSpacing="1" width="100%">
            <tr class="category">
              <td colSpan="2">
                <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                    <tr>
                      <td valign="bottom">
					  <img alt="<?echo($Board[name]);?>" border="0" hspace="3" src="images/forum_ico.gif" width="16" height="16">
					  &nbsp;<font class="subject"><b><A HREF="<? echo ("forum.php?board=$boardid");?>"><? echo ($Board[name]);?></A><b></font></td>
 					  <td align="right" noWrap>
	                     <table border="0" cellPadding="0" cellSpacing="0">
                            <tr>
                              <td><a href=<?echo ("forum.php?board=$boardid#New");?>><img alt="Post a new topic" border="0" src="images/post.gif" width="54" height="22"></a></td>
                              <td><img alt border="0" height="22" src="images/1.gif" width="4"></td>
                              <td><A HREF="#Reply"><img alt="<?echo $__Reply;?>" border="0" src="images/reply.gif" width="58" height="22"></A></td>
                              <td><img alt border="0" height="22" src="images/1.gif" width="4"></td>
                              <td><a href="<? echo $prnt; ?>" target="popup" onClick="popup=window.open('<? echo $prnt; ?>','popup','toolbar=no,status=no,width=600,height=450,scrollbars=yes');"><img alt="Printable Version of this Topic" border="0" src="images/print.gif" width="22" height="22"></a></td>
                              <td><img alt border="0" height="22" src="images/1.gif" width="4"></td>
                              <td><a href="<?echo $rec; ?>" target="popup" onClick="popup=window.open('<?echo $rec; ?>','popup','toolbar=no,status=no,width=500,height=450,scrollbars=yes');"><img alt="Forward this Topic to your Friend" border="0" src="images/forward.gif" width="22" height="22"></a></td>
                              <td><img alt border="0" height="22" src="images/1.gif" width="4"></td>
                            </tr>
                        </table>
					 </td>
                    </tr>
                </table>
              </td>
            </tr>
            <tr class="row">
<td class="odd" noWrap rowSpan="2" vAlign="top" width="100">
<img border="0" hspace="3" src="images/author.gif" width="15" height="20">
<font class="subject"><?echo $__PostedBy;?></font><br>
<img align="absMiddle" border="0" height="1" src="images/1.gif" width="5">
<font class="subject"><?echo $author;?></font><br>
<img align="absMiddle" border="0" height="1" src="images/1.gif" width="5">
<?if ($email):?>
<a href="<?echo $sendmail;?>" target="popup" onClick="popup=window.open('<?echo $sendmail;?>','popup','toolbar=no,status=no,width=500,height=450,scrollbars=yes');">
<img align="absMiddle" alt="Send an e-mail to <?echo$author;?>" border="0" src="images/email.gif" vspace="10" width="14" height="14"></A>
<?endif;?>
<img align="absMiddle" border="0" height="10" src="images/1.gif" width="6">
<?if ($url):?>
<?$frm="url.php?r=1&url="?>
 <a href="<?echo$frm;echo $url;?>" target="popup" onClick="popup=window.open('<?echo $url;?>','popup','toolbar=no,status=yes,scrollbars=yes');">
  <img align="absMiddle" alt="<?echo $url;?>" border="0" src="images/profile.gif" vspace="10" width="14" height="14"></A>
<?endif;?>
<img align="absMiddle" border="0" height="10" src="images/1.gif" width="5">
<?if ($urlname):?>
<a href="<?echo $icq;?>" target="popup" onClick="popup=window.open('<?echo $icq;?>','popup','toolbar=no,status=no,width=450,height=350,scrollbars=no');">
<img src="http://wwp.icq.com/scripts/online.dll?icq=<?echo $urlname;?>&img=5" align="absMiddle" border="0" alt="ICQ#= <?echo $urlname;?>" vspace="10" width="14" height="14" >
</A>
	  <?else:?>
<img align="absMiddle" border="0" height="10" src="images/1.gif" width="5">
	 <?endif;?>
          </td>
              <td class="subject" width="90%">
			  <table border="0" cellPadding="0" cellSpacing="0" width="100%">
					<tr>
					<td align="left" valign="bottom" width="10%"><p align="left"><font class="subject"><? echo $__Subject; ?></font></p></td>
					<td align="left" valign="bottom" width="90%"><p align="left"><font class="category">&nbsp;<?echo $subject;?></font></p></td>
					<td align="right"><img alt border="0" height="22" src="images/1.gif" width="4"></td>
					</tr>
				</table>
				<table border="0" cellPadding="0" cellSpacing="0" width="100%">	
					<tr>
					<td align="left" valign="bottom" noWrap><font class="status"><b><?echo $__Date;?></b> <?echo $posted;?></font></td>
					<td align="center" valign="bottom"><img alt border="0" height="22" src="images/1.gif" width="4"></td>
					<td align="right" valign="bottom" noWrap><font class="status">Viewed <b><? $pageid= $id; include("count.php"); ?></b> times.</font></td>
					</td>
					</tr>    
                </table>
              </td>
            </tr>
            <tr class="row">
              <td class="body" vAlign="top">
                <table border="0" cellPadding="2" cellSpacing="2" height="100" width="100%">
                    <tr>
                      <td vAlign="top">
					  <font class="body">
<?
if ($urlimage):
?>

<center>
<IMG SRC="<?echo $urlimage;?>">
</center>  

<?
endif;
?> 


					<?
					
					if ($Board["notags"] == "Y"):
  					$dmsg = HighlightURLs($msg);
					else:
  					$dmsg = $msg;
					endif;?>

					<?
					echo nl2br($dmsg);
					?>
				
					  </font>
					  </td>
                    </tr>
                  </table>
                <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                  <tr>
                     <td valign="bottom" align="right"><?include("vote.php")?></td>
                    </tr>                  
                </table>
              </td>
            </tr>
            <tr class="category">
              <td colSpan="2">
                <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                  

                    <tr>
                      <td valign="top" noWrap><img border="0" hspace="3" src="images/thread.gif" width="22" height="22">
					  <font class="category">
					  <b>
<?echo "$__Replies\n";?>
</b></font><font class="sub-body">
<?
PrintMessages($boardid, -$root, $id);
$Author = "GlasnetWBAuthor$boardid";
$Author = $$Author;
$Email = "GlasnetWBEmail$boardid";
$Email = $$Email;
$Url = "GlasnetWBUrl$boardid";
$Url = $$Url;
$UrlName = "GlasnetWBUrlName$boardid";
$UrlName = $$UrlName;
$UrlImage = "GlasnetWBUrlImage$boardid";
$UrlImage = $$UrlImage;
?>
			   </b></font>
					  </td>
                      <td valign="top" align="right" noWrap>
<?
$SQL = "SELECT * FROM messages WHERE id = $prev";
$prevmsg = mysql_query($SQL);
if (mysql_numrows($prevmsg)):
  $previd = mysql_result($prevmsg, 0, "id");
  $subj = mysql_result($prevmsg, 0, "subject");
?>
  <font class="status"><A HREF="<?echo "$PHP_SELF?id=$previd";?>"><?echo $__ThreadTop; ?></A></font>
    <?endif;?>        </td>
                    </tr>
               </table>
              </td>
            </tr>
			</table>
  <table border="0" width="100%" cellspacing="0" cellpadding="4">

      <tr class="header">
		 <td noWrap width="96%" valign="bottom"><font class="header"><font color="#FF0000" size="1"><sup>*</sup></font><b><? echo$__Asterix ;?></b></font></td>
   		 <td valign="top" width="2%" align="center"><img border="0" src="images/1.gif" width="1" height="1"></td>
		 <td align="left" width="2%" align="right" valign="bottom"><a href="<? echo $credits;?>"><img alt="Credits" border="0" hspace="3" src="images/panda.gif" width="16" height="16"></a></td>
    </tr>
  </table>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
            <tr class="status">
			 <td colSpan="2">
                <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                  
				   <tr>
                   <td width="20%" valign="top"><img border="0"  vspace="3" hspace="5" src="images/reply1.gif" width="23" height="22"><font class="category"><A NAME="Reply"></A><?echo $__Reply;?>:</font></td>
				   <td width="60% valign="top"><font class="status">
<?
if (!$RO):
  PrintReplyForm($Board, $Message);
endif;
?>
					</font></td>
                    <td width="20% valign="top" align="right"></td>
                   </tr>			
				   <tr>
                   <td valign="bottom"><font class="status"><? echo $__Timezone;?></font></td>
				   <td valign="bottom" align="right" colspan="2"><p><font class="status">&lt; <A HREF="<?echo $HTTP_REFERER;?>"><?echo $__Back;?></A> | <a href="<?echo ("forum.php?board=$boardid"); ?> "><?echo $__Main;?></a> &gt;</font></p></td>
                   </tr>
                  
                </table>
              </td>
            </tr>
          
        </table>
      </td>
    </tr>
  </table>
  &nbsp;
<?
MessageFooter($boardid);
?>
