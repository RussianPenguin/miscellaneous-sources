<? 
include "common.php"; 

//////////////////////////////////////////////////////////////////////////////
//////// EDITION SPECIALE DU FRAME POUR WEBEXPERT 2000 : www.visic.com ///////
//////////////////////////////////////////////////////////////////////////////
//// Version 1.0  R�aliser par K�vin Lab�cot. D�veloppeur Php             ////
//// www.connexion-mcdo.com & www.phpfrance.com                           ////
//////////////////////////////////////////////////////////////////////////////
/////////////////////INSTALLATION  DU SCRIPT FRAME////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//// 1�) Ce script permet d'afficher un frame qui permet de revenir sur   ////
//// 1a�)votre site lorsque un visiteur le quitte.			  ////
//// 2�) Configurez les param�tres ci dessous.  			  ////
//// 3�) Pour afficher la frame : 				          ////
//// 3a�)En haut : index.php3?ou=haut&url=Adresse_De_La_Page_Affiche_en_Bas
//// 3a�)En bas : index.php3?ou=bas&url=Adresse_De_La_Page_Affiche_en_Haut
//// 3a�)A gauche : index.php3?ou=gauche&url=Adresse_De_La_Page_Affiche_�_Droite
//// 3a�)A droite : index.php3?ou=droite&url=Adresse_De_La_Page_Affiche_�_Gauche
//// 4�)Si vous avez renommez ce fichier changer index.php3 situ� plus    ////
//// 4a�)haut par le nom que vous avez donn�.				  ////
//// 5�) Si vous d�sirez configurer votre propre page de la frame d�cendez////
//// 5a�) plus bas dans cette page pour arriver � la partie concernant la ////
//// 5a) frame.								  ////
//////////////////////////////////////////////////////////////////////////////
////////////////PARAMETRES DE CONFIGURATION DU FRAME//////////////////////////
//////////////////////////////////////////////////////////////////////////////
//// Police du lien dans la frame	                                  ////
$police = "verdana";                                                      ////
//// Taille du lien dans la frame                                        ////
$police1 = "2";                                                           ////
//// Couleur du lien dans la frame			                  ////
$police2 = "#000000";                        			          ////
//// Texte du lien dans la frame                                          ////
$police3 ="Back to Torontonian.com Forums";                                         ////
//// Adresse du lien dans la frame          			          ////
$police4 = "http://www.torontonian.com/forum";                                    ////
//// Couleur de l'arri�re plan dans la frame                              ////
$police5 = "#FFFFFF";                                                     ////
//// Alignement du texte dans la Frame                                    ////
$police6 = "<p align=\"center\">";                                        ////
//// Titre de votre site						  ////
$title = "Torontonian.com Forums";								  ////
//// Message d'erreur � afficher si le navigateur n'accepte pas les frames////
$noframe = "This page requires frames to be viewed properly.";	  ////
//////////////////////////////////////////////////////////////////////////////
?>
<?
switch($r){
case "0":
?>
<html>

<head>
<title><? echo $title; ?></title>
</head>

<frameset rows="9%,*">
  <frame name="haut" src="<?echo $PHP_SELF;?>">
  <frame name="main" src="<? echo $url; ?>">
  <noframes>
  <body>
  <p><? echo $noframe; ?></p>
  </body>
  </noframes>
</frameset>
</html>
<?
break;
case "1":
?>
<html>

<head>
<title><? echo $title; ?></title>
</head>
<frameset border="0" rows="28,90%" frameborder="0" framespacing="0">
  <frame name="top" scrolling="no" noresize target="top" src="<?echo $PHP_SELF;?>">
  <frame name="main" src="<? echo $url; ?>">
  <noframes>
  <body>
  <p><? echo $noframe; ?></p>
  </body>
  </noframes>
</frameset>
</html>
<?
break;
case "2":
?>
<html>

<head>
<title><? echo $title; ?></title>
</head>

<frameset cols="94%,*">
  <frame name="haut" src="<? echo $url; ?>">
  <frame name="main" src="<?echo $PHP_SELF;?>">
  <noframes>
  <body>
  <p><? echo $noframe; ?></p>
  </body>
  </noframes>
</frameset>
</html>
<?
break;
case "3":
?>
<html>

<head>
<title><? echo $title; ?></title>
</head>

<frameset cols="6%,*">
  <frame name="haut" src="<?echo $PHP_SELF;?>">
  <frame name="main" src="<? echo $url; ?>">
  <noframes>
  <body>
  <p><? echo $noframe; ?></p>
  </body>
  </noframes>
</frameset>
</html>
<?
break;
default:
?>
<html>
<head>
<title><?echo $title; ?></title>
<? StyleSheet (); ?>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" width="100%" cellspacing="0" cellpadding="5">
  <tr class="header">
    <td width="30" valign="top" align="left"><a href="<? echo $credits;?>" target="_top"><img alt="Credits" border="0" hspace="3" src="images/panda.gif" width="16" height="16"></a></td>
    <td width="40%" valign="bottom" align="left"><?$referer = getenv("HTTP_REFERER");?><a href="<?echo $referer;?>" target="_top"><font class="header"><?echo $__Back2Forum;?> <?echo $title;?></font></a></td>
    <td width="25%" valign="bottom" align="left"><img border="0" src="images/1.gif" width="1" height="1"></td>
    <td width="35%" valign="bottom" align="right"><a href="<?echo $url;?>" target="_top"><font class="header"><?echo$__CloseFrame;?></font></a></td>
  </tr>
</table>
</body>
</html>
<?
break;
}
?>