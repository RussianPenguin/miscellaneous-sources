<?
include "common.php";

PrintHead($Board["name"]);
?>

<table border="0" width="100%" cellspacing="0" cellpadding="1">
  <tr class="body">
    <td width="100%" valign="top" colspan="2">
<table border="0" width="100%" cellspacing="0" cellpadding="5">
<tr class="header">
<td width="96%" valign="top" align="left"><font class="header"><font size="3" face="Verdana">Thank
      you for choosing BESTWEB 2.0 Deluxe</font></font></td>
<td width="40" valign="bottom" align="right">
<img alt="Credits" border="0" hspace="3" src="http://www.bestweb.ca/images/credits/panda.gif" width="32" height="32">
</td>
</tr>
</table>
  
    </td>
  </tr>
  <tr class="body">
    <td width="50%" valign="top"><font size="2" face="Verdana">BestWeb 2.0&nbsp;
      by <a href="mailto:oktay@torontonian.com"> Oktay
      Ozturk</a><br>
      <a href="http://www.bestweb.ca/">http://www.bestweb.ca/</a></font></td>
    <td width="50%" valign="top"><font size="2" face="Verdana">Original script by
      <a href="mailto:nmark@glasnet.ru"> Mark Napartovic</a><br>
      <a href="http://www.glasnet.ru/~nmark/">http://www.glasnet.ru/~nmark/</a></font></td>
  </tr>
  <tr class="body">
    <td width="50%" valign="top">
      <p align="left"><font size="2" face="Verdana" class="red">If you like to use this
      script on your site please visit<br>
      <a href="http://www.bestweb.ca/download/">http://www.bestweb.ca/download/</a>
      to obtain the source code.</font></td>
    <td width="50%" valign="top">&nbsp;</td>
  </tr>
</table>
<div align="center=">
<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST"><input type="hidden" name="ID" value="8389"><table BORDER="0" width="130" CELLSPACING="0" bgcolor="#CCCC99"><tr><td align="center"><font face="arial, verdana" size="2"><b>Rate Bestweb 1.0</b><br><a href="http://www.hotscripts.com"><small>@ HotScripts.com</small></a></font></td></tr><tr><td align="center"><table border="0" cellspacing="0" width="100%" bgcolor="#FFFFEA"><tr><td><input type="radio" value="5" name="ex_rate"></td><td><font face="arial, verdana" size="2">Excellent!</font></td></tr><tr><td><input type="radio" value="4" name="ex_rate"></td><td><font face="arial, verdana" size="2">Very Good</font></td></tr><tr><td><input type="radio" value="3" name="ex_rate"></td><td><font face="arial, verdana" size="2">Good</font></td></tr><tr><td><input type="radio" value="2" name="ex_rate"></td><td><font face="arial, verdana" size="2">Fair</font></td></tr><tr><td><input type="radio" value="1" name="ex_rate"></td><td><font face="arial, verdana" size="2">Poor</font></td></tr></table></td></tr><tr><td align="center"><input type="submit" value="Vote!"></td></tr></table></form>
<p>
<center>
</center>
</div>
<?
PrintFoot();
?>