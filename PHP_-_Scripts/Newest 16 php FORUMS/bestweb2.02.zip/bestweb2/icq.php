<?
include "common.php";
$id = IntVal($id);
$SQL = "SELECT * FROM messages WHERE id = $id";
$message = mysql_query($SQL);
if (!$message):
  NotAvailable();
  Exit;
endif;
$Message = mysql_fetch_array($message);
mysql_freeresult($message);
$boardid = $Message["boardid"];
$boardid = IntVal($boardid);
$SQL = "SELECT * FROM boards WHERE id = $boardid";
$board = mysql_query($SQL);
if (mysql_numrows($board) == 0):
  NotAvailable();
  Exit;
endif;
$Board = mysql_fetch_array($board);
$prev = $Message["prev"];
$posted = $Message["posted"];
$author = $Message["author"];
$subject = $Message["subject"];
$url =  $Message["url"];
$urlname =  $Message["urlname"];
$urlimage =  $Message["urlimage"];
$msg = $Message["msg"];
$email = $Message["email"];

$ICQForm = "
<table BORDER=0 CELLSPACING=0 CELLPADDING=5 width=\"100%\">
<TR class=\"header\">
<TD with=\"90%\" valign=\"top\"><a href=\"#\"><font class=\"header\">$__ICQMsgTo $author</font></a>
<INPUT TYPE=Hidden NAME=icqnumber value=\"$urlname\">
</TD>
<td width=\"30\" valign=\"top\" align=\"right\"><a href=\"$credits\" target=\"_new\"><img alt=\"Credits\" border=\"0\" hspace=\"3\" src=\"images/panda.gif\" width=\"16\" height=\"16\"></a></td>
</TR>
</table>
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 width=\"100%\">
<TR><TD><img src=\"images/1.gif\" height=\"5\"></TD></TR></table>

<div align=\"center\">
<center>
<table border=0 width=96% cellspacing=0 cellpadding=1>
    <tr>
      <td width=96% bgcolor=#000000 valign=top>     
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5 width=\"100%\">
<FORM ACTION=\"icq_send.php\" METHOD=post>
<input type=\"hidden\" name=\"author\" value=$author>
<input type=\"hidden\" name=\"urlname\" value=$urlname>
<TR class=\"category\"><TD><FONT class=\"formfields\">$__Subject</TD>
<TD><INPUT TYPE=text name=subj SIZE=25></TD>
<TR class=\"category\"><TD><FONT class=\"formfields\">$__Message</TD>
<TD><TEXTAREA NAME=PagerMsg COLS=24 ROWS=8 WRAP=virtual></TEXTAREA></TD>
<TR class=\"category\"><TD><FONT class=\"formfields\">$__ICQYourname</TD>
<TD><INPUT TYPE=text NAME=\"navn\" SIZE=25></TD>
<TR class=\"category\"><TD><FONT class=\"formfields\">$__ICQYourmail</TD>
<TD><INPUT TYPE=text NAME=eMail SIZE=25></TD>
<TR class=\"category\"><TD>&nbsp;</TD>
<TD><FONT class=\"formfields\"><INPUT TYPE=submit NAME=submit VALUE=\"$__ICQSendButton\"></td>
</FORM>
</TABLE>
      </td>
    </tr>
  </table>
</center></div>
";
		echo "<html><head><title>$__ICQMsgTo $author</title>\n";
		StyleSheet ();
		echo "<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0>\n";
	    echo "$ICQForm";
		echo "<body></html>";
?>

