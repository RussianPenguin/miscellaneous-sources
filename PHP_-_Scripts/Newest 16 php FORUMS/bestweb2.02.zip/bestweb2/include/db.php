<?
$DB = "bestweb";
$DBUSER = "root";
$DBHOST = "localhost";
$DBPASS = "";
?>