<? include "common.php"; 

$id = IntVal($id);
$SQL = "SELECT * FROM messages WHERE id = $id";
$message = mysql_query($SQL);
if (!$message):
  NotAvailable();
  Exit;
endif;
$Message = mysql_fetch_array($message);
mysql_freeresult($message);
$boardid = $Message["boardid"];
$boardid = IntVal($boardid);
$SQL = "SELECT * FROM boards WHERE id = $boardid";
$board = mysql_query($SQL);
if (mysql_numrows($board) == 0):
  NotAvailable();
  Exit;
endif;
$prev = $Message["prev"];
$posted = $Message["posted"];
$author = $Message["author"];
$subject = $Message["subject"];
$url =  $Message["url"];
$urlname =  $Message["urlname"];
$urlimage =  $Message["urlimage"];
$msg = $Message["msg"];
$email = $Message["email"];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <title>Send mail to <?echo $author;?></title>
   <? StyleSheet (); ?>
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" width="100%" cellspacing="0" cellpadding="6">
 <tr class="header">
  <td noWrap width="100%" valign="bottom"><font class="header"><b>You can send a brief message to <?echo $author;?>, by filling out the form below.</b></font></td>
  </tr>
</table>
<table border=0 cellspacing=0 cellpadding=0 width="100%">
<tr><td><img src="images/1.gif" height="5"></td></tr></table>
<div align="center">
<center>
<table border="0" width="96%" cellspacing="0" cellpadding="1">
    <tr>
    <td bgcolor="#000000">
<table border="0" width="100%" cellspacing="0" cellpadding="6">
    <tr class="category">
	<td> 
	<table border="0" width="100%" cellspacing="0" cellpadding="6">
    <tr class="odd">
 		<td class="body" width="100%" valign="bottom">
	<font class="body"> 
	  <?echo$__EmailText;?>
	 </font>
	 </td>
	 </tr>
	 </table> 
      <form method="POST" action="mail_send.php">
	  <input type="hidden" name="author" value=<?echo$author;?>>
      <input type="hidden" name="urlname" value=<?echo$urlname;?>>
         <table border="0" cellspacing="3" cellpadding="3">
            <tr>
               <td valign="top">
                 <font class="formfields"><?echo$__ICQYourname;?></font>
               </td>
               <td valign="TOP">
                <input type="text" name="yname">
               </td>
            </tr>
            <tr>
               <td valign="TOP">
				<font class="formfields"><?echo$__ICQYourmail;?></font>
               </td>
               <td valign="top">
                <input type="text" name="yemail">
				</td>
            </tr>
            <tr>
               <td valign="TOP" colspan="2">
                  <font class="formfields"><?echo$__Message;?></font>
               </td>
            </tr>
            <tr>
               <td valign="top" colspan="2">
                  <textarea name="comments" rows="3" cols="30">
                  </textarea>
               </td>
            </tr>
            <tr>
               <td valign="top" colspan="2">
			    <input type="hidden" name="<? echo "$email"; ?>">
                <input type="hidden" name="url" value="<? echo "$referer"; ?>">
				<input type="submit" name="action" value="<?echo $__ICQSendButton;?>">
               </td>
            </tr>
         </table>
      </form>
	  </td>
   </tr>
</table>
 </tr>
</table>
</center>
</div>
</body>
</html>