<? /* Style sheets for use by Dreamweaver... ?> 
<link rel="stylesheet" href="styles/ie5.css" type="text/css">
<? */
include "common.php";

PrintHead($Board["name"]);

// Get the board names, descriptions and message counts
$SQL = "SELECT boards.id, name, description, newdays, COUNT(*) as num_messages 
	FROM boards LEFT JOIN messages ON boards.id = messages.boardid
	GROUP BY boards.id, boards.name, boards.description ORDER BY id ASC";
$result = mysql_query($SQL)
	or die("Couldn't execute query: ".mysql_error());
?>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr> 
    <td> 
      <table border="0" width="100%" cellspacing="0" cellpadding="3">
        <tr class="header"> 
          <td width="50%" valign="bottom" align="left"><font class="header"> 
            <?echo $__BoardName; ?>
            </font></td>
          <td width="30" valign="bottom" align="center"> 
           <font class="header"> 
              <?echo $__Threads; ?>
              </font>
          </td>
          <td  width="30" valign="bottom" align="center"> 
            <font class="header"> 
              <?echo $__Posts; ?>
              </font>
          </td>
          <td width="100" valign="bottom" align="center"> 
            <font class="header">
              <? echo $__LastMessage; ?>
              </font>
          </td>
          <td width="20" align="right" valign="bottom"><a href="<? echo $credits;?>"><img alt="Credits" border="0" hspace="3" src="images/panda.gif" width="16" height="16"></a></td>
        </tr>
<!--tr>
<td colspan=5>
<img border="0" src="images/1.gif" width="1" height="1">
</td>
</tr-->
        <?
// format results by row
while ($row = mysql_fetch_array($result)) {
	$id = $row["id"];
	$boardname = $row["name"];
	$newhours = $row["newdays"]*12;
	$description = $row["description"];
	$lastmessage="";
	$posts=$row["num_messages"];

	// Get the number of new messages
	$SQL = "SELECT COUNT(*) FROM messages WHERE boardid = $id AND 
		((UNIX_TIMESTAMP() - UNIX_TIMESTAMP(posted))/3600 < $newhours)";
	$newresult = mysql_query($SQL)
		or die("Couldn't execute query: ".mysql_error());
	$newmess = mysql_fetch_row($newresult);
	$newposts = IntVal($newmess[0]);
	mysql_free_result($newresult);

	// Get the number of threads
	$SQL = "SELECT COUNT(*) FROM messages WHERE boardid = $id AND prev = 0";
	$newresult = mysql_query($SQL)
		or die("Couldn't execute query: ".mysql_error());
	$newmess = mysql_fetch_row($newresult);
	$threads = IntVal($newmess[0]);
	mysql_free_result($newresult);

	// Get the newest message
	$SQL = "SELECT * FROM messages WHERE boardid = $id ORDER BY posted DESC LIMIT 1";
	$newresult = mysql_query($SQL)
		or die("Couldn't execute query: ".mysql_error());
	$newmess = mysql_fetch_array($newresult);
	$lastmessage = '"'.$newmess["subject"].'"';
	mysql_free_result($newresult);

?>
        <tr class="body"> 
          <td valign="top"><span class="forumlink"><a href="forum.php?board=<?echo $id ;?>"> 
            <u><?echo $boardname;?></u>
            </a> </span><br><font class=red><? echo "$newposts new messages.";?></span>        
            <br><font class="category"><?echo $description;?></font>
          </td>
          <td valign="top" class="odd"> 
            <p align="center"> 
              <font class="category"><?echo $threads;?></font>
            </p>
          </td>
          <td valign="top"> 
            <p align="center"> 
              <font class="category"><?echo $posts;?></font>
            </p>
          </td>
          <td valign="top" class="odd"> 
            <p align="center"> 
              <font class=current><? echo $lastmessage;?></font>
            </p>
          </td>
          <td valign="top">&nbsp;</td>
        </tr>
		<tr>
		<td colspan="5">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%" bgcolor="#000000"><img border="0" src="images/1.gif" width="1" height="1"></td>
  </tr>
</table>
		</td>
		</tr>
        <?		}   ?>
      </table>
    </td>
  </tr>
</table>
<?
mysql_free_result($result);
PrintFoot();
?>
