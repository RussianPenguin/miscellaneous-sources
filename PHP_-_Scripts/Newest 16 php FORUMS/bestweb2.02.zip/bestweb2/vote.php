<? 
$ficdest=explode(".",basename($PHP_SELF)); 
$ficdest="votes/".$id.".dat";

if(file_exists($ficdest)) { 
     $compteur=fopen($ficdest, "r"); 
     $old_stats=file($ficdest); 
     $stats=explode("|", $old_stats[0]); 
     fclose($compteur); 
     $new_count=$stats[0]; 
     if ($stats[3] != $REMOTE_ADDR) { 
         $new_count +=1; 
     } 
     $ip_hit=$REMOTE_ADDR; 
     $compteur=fopen($ficdest, "w"); 
     fputs($compteur, "$new_count|$stats[1]|$stats[2]|$ip_hit|$stats[4]"); 
     fclose($compteur); 
} 
else { 
     $nouveau_compteur=fopen($ficdest, "w"); 
     fputs($nouveau_compteur, "1|||$REMOTE_ADDR|"); 
     fclose($nouveau_compteur); 
} 

if (!empty($envoi)) { 
     $vote=fopen($ficdest, "r"); 
     $old_stats=file($ficdest); 
     $stats=explode("|", $old_stats[0]); 
     fclose($vote); 
     $nbr_votes=$stats[1]; 
     $moy_votes=$stats[2]; 
     if ($stats[4] != $REMOTE_ADDR) { 
         $nbr_votes +=1; 
         $moy_votes=((($stats[1]*$stats[2])+$note)/$nbr_votes); 
     } 
else { echo "<font face=Verdana size=1 color=red>You have already voted</font>"; } 
     $ip_vote=$REMOTE_ADDR; 
     $vote=fopen($ficdest, "w"); 
     $new_stats=fputs($vote, "$new_count|$nbr_votes|$moy_votes|$stats[3]|$ip_vote"); 
     fclose($vote); 
} 

print ("<table border=\"0\" width=\"100%\">
  <tr><td align=\"right\"><form method=\"post\">"); 
$old_stats=file($ficdest); 
$stats=explode("|", $old_stats[0]); 
print ("<font size=1 face=Verdana color=#999999>Votes: $stats[1] |
Average vote: "); 
if (!empty($stats[2])) { printf("%.1f", $stats[2]); } 
print ("&nbsp;&nbsp; <input type=hidden name=envoi value=1><input type=submit
value=Vote>"); 
print ("&nbsp;<select name=note>"); 
for ($i=1; $i<=10; $i++) { 
    print ("<option value=$i>$i"); 
} 
print ("</select></font></td></form>
  </tr>
</table>"); 
?>