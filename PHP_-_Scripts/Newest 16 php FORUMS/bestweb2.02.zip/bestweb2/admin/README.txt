The temporary password and username for admin are:
test
test

Don't forget to change it..!
