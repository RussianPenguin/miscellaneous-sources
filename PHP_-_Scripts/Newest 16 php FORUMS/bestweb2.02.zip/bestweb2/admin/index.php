<?
include "access.php";

$LIMIT = 50;
$Offset = IntVal($Offset);

$BgColor = "#FFFFFF";

error_reporting(7);

function PrintAHead($title ) {
Global $BgColor;
Global $Action;
Global $__WebBoard;
?>
  <HTML>
  <HEAD>
  <TITLE>
  <?echo "$__WebBoard: $title: $Action";?>
  </TITLE>
  <BODY BGCOLOR="<?echo $BgColor;?>">
<?
}

function PrintHeader() {
  Global $Action;
  Global $ValidBoards;
  Global $PHP_SELF;
  Global $__NewWebboard;
  Global $__Help;
  Global $__AdminPage;
?>
  <CENTER>
  <TABLE>
  <TR ALIGN="CENTER" VALIGN="TOP">
  <TD>
<?
  if (!$ValidBoards):
?>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="SUBMIT" VALUE="<?echo $__NewWebboard;?> ">
    <INPUT TYPE="HIDDEN" NAME="Action" VALUE="New">
    </FORM>
<?
  endif;
?>
  [ <A HREF="../help.php"><?echo $__Help;?></A> ]
  </TD>
<?
  if ($Action):
?>
  	<TD>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="SUBMIT" VALUE="<?echo $__AdminPage;?>">
  	</TD>
<?
  endif;
?>
  </TR>
  </TABLE>
  </CENTER>
<?
}

function PrintMessageRows($boardid, $prev, $indent) {
  Global $DB;
  Global $LIMIT;
  Global $Offset;
	
  $boardid = IntVal($boardid);
  $prev = IntVal($prev);
  if (!$prev):
    $SQL = "SELECT * FROM messages WHERE prev = $prev AND boardid = $boardid ORDER by posted DESC LIMIT $Offset,$LIMIT";
  else:
    $SQL = "SELECT * FROM messages WHERE prev = $prev AND boardid = $boardid ORDER by posted DESC";
  endif;
  $messages = mysql_query($SQL);
  $num_messages = mysql_num_rows($messages);
  if ($num_messages):
    echo "<UL>";
    while ($row = mysql_fetch_array($messages)):
      $id = $row["id"];
      $subject = $row["subject"];
      $author = $row["author"];
      $posted = $row["posted"];
      $prev = $row["prev"];
      $remotehost = $row["remotehost"];
      if (!$prev):
        $hasprev = "No";
      else:
        $hasprev = $prev;
      endif;
      echo "<TR><TD>$id</TD><TD>$author</TD>";
      echo "<TD>$indent<A HREF=\"../message.php?id=$id\" TARGET=\"msgpreview\">$subject</A></TD>";
      echo "<TD>$posted</TD><TD><a href=\"http://www.checkdomain.com/cgi-bin/checkdomain.pl?domain=$remotehost\">$remotehost</a></TD><TD>$hasprev</TD>";
      echo "<TD bgcolor=red><INPUT TYPE=\"Checkbox\" NAME=\"DeleteID[]\" VALUE=\"$id\"></TD>";
      if (!$prev):
        echo "<TD bgcolor=green><INPUT TYPE=\"Checkbox\" NAME=\"MoveID[]\" VALUE=\"$id\"></TD>";
      else:
        echo "<TD><INPUT TYPE=\"Checkbox\" NAME=\"MoveID[]\" VALUE=\"$id\"></TD>";
      endif;
      echo "</TR>\n";
      PrintMessageRows($boardid, $id, "+$indent");
    endwhile;
    echo "</UL>";
  endif;
  mysql_free_result($messages);
}

function MoveMessages($MoveID, $board ) {
  Global $DB;

  /* Create comma separated messages list first */
  $msglist = "";
  $MoveCount = count($MoveID);
  $i = 0;
  while ($i < $MoveCount):
    $emsg = EnumMessages($MoveID[$i]);
    if ($msglist):
      $msglist = "$msglist, $emsg";
    else:
      $msglist = $emsg;
    endif;
    $i++;
  endwhile;
  /* Move messages */
  $SQL = "UPDATE messages SET boardid = $board WHERE id IN ($msglist)";
  mysql_query($SQL);
  return mysql_affected_rows();
}

function PrintNewBoard() {
  Global $PHP_SELF;
  Global $User;
  Global $__NewWebboard;
  Global $__Name;
  Global $__Description;
  Global $__HomePageTitle;
  Global $__HomePageURL;
  Global $__BgColor;
  Global $__BgImageURL;
  Global $__TextColor;
  Global $__LinkColor;
  Global $__VisitedLinkColor;
  Global $__ActiveLinkColor;
  Global $__PageHeader;
  Global $__PageFooter;
  Global $__PageSize;
  Global $__DisableTags;
  Global $__KeepMessagesDays;
  Global $__MarkNewWith;
  Global $__MarkAsNew;
  Global $__NotifyOwner;
  Global $__Disable;
  Global $__AddBoard;
  	PrintAHead("New");
?>
  <H1 ALIGN="CENTER"><?echo $__NewWebboard;?></H1>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="HIDDEN" NAME="Action" VALUE="AddNew">
  <CENTER>
  <TABLE>
  <TR>
  <TD VALIGN=TOP><?echo $__Name;?></TD>
  <TD>
  <INPUT TYPE="TEXT" MAXLENGTH="40" NAME="_name">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__Description;?></TD>
  <TD>
  <TEXTAREA NAME="_description" COLS="40" ROWS="4"></TEXTAREA>
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__HomePageTitle;?></TD>
  <TD>
  <INPUT TYPE="TEXT" NAME="_homename" VALUE="Home" size="60">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__HomePageURL;?></TD>
  <TD>
  <INPUT TYPE="Text" NAME="_homeaddress" VALUE="<?echo "http://torontonian.com/forums/";?>" size="60">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__BgColor;?></TD>
  <TD>
  <INPUT TYPE="TEXT" MAXLENGTH="40" NAME="_bgcolor" VALUE="#FFFFFF">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__BgImageURL;?></TD>
  <TD>
  <INPUT TYPE="TEXT" MAXLENGTH="40" NAME="_bgimage">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__TextColor;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_textcolor">
  </TD>
  </TR>
  <TR>
  <TR>
  <TD VALIGN=TOP><?echo $__LinkColor;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_linkcolor">
  </TD>
  </TR>
  <TR>
  <TR>
  <TD VALIGN=TOP><?echo $__VisitedLinkColor;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_vlinkcolor">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__ActiveLinkColor;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_alinkcolor">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP>&nbsp;</TD>
  <TD>
  &nbsp;
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__PageHeader;?></TD>
  <TD>
  <TEXTAREA NAME="_header" COLS="40" ROWS="4"><?echo $_header;?></TEXTAREA>
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__PageFooter;?></TD>
  <TD>
  <TEXTAREA NAME="_footer" COLS="40" ROWS="4"><?echo $footer;?></TEXTAREA>
  </TD>
  </TR>
  <TR>
  <TD><?echo $__PageSize;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" MAXLENGTH="16" NAME="_pagesize" VALUE=10>
  </TD>
  </TR>
	<TR>
	<TD VALIGN=TOP><?echo $__DisableTags;?></TD>
	<TD>
	<INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_notags">
	</TD>
	</TR>
  <TR>
  <TD><?echo $__KeepMessagesDays;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_expiredays" VALUE=0>
  </TD>
  </TR>
  <TR>
  <TD><?echo $__MarkNewWith;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="80" "MAXLENGTH="100" NAME="_newmark" VALUE="<font color=Red>new</font>">
  </TD>
  </TR>
  <TR>
  <TD><?echo $__MarkAsNew;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="80" MAXLENGTH="100" NAME="_newdays" VALUE="1">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__NotifyOwner;?></TD>
  <TD>
  <INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_notify">
  </TD>
  </TR>

  <TR>
  <TD VALIGN=TOP><?echo $__Disable;?></TD>
  <TD>
  <INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_disabled">
  </TD>
  </TR>
  </TABLE>
  <INPUT TYPE="Submit" VALUE="<?echo $__AddBoard;?>">
  </FORM>
<?
}

$board = IntVal($board);
if ($ValidBoards):
  $Restrict = "AND id IN ($ValidBoards)";
else:
  $Restrict = "";
endif;
if ($board):
  $SQL = "SELECT * FROM boards WHERE id = $board AND owner = '$User' $Restrict";
else:
  $SQL = "SELECT * FROM boards WHERE owner = '$User' $Restrict";
endif;
$boards = mysql_query($SQL);
if (!$boards):
  NotAvailable();
  Exit;
endif;

if ($board):
  if (!mysql_num_rows($boards)):
    NotAvailable();
    Exit;
  endif;
endif;

/* security check */
if (IsSet($boardid)):
  $SQL = "SELECT owner FROM boards WHERE id=$boardid";
  $owresult = mysql_query($SQL);
  $row = mysql_fetch_array($owresult);
  $realowner = $row["owner"];
  mysql_free_result($owresult);

  if ("$realowner" != "$PHP_AUTH_USER"):
    $SQL = "SELECT login FROM coadmins WHERE owner='$realowner'";
    $owresult = mysql_query($SQL);
    $realowner = $row["login"];
    mysql_free_result($owresult);
  endif;
endif;
/* /security check */

if ("$Action" == "New"):
  PrintNewBoard();
elseif (("$Action" == "$__Manage") && ("$realowner" == "$PHP_AUTH_USER")):

  PrintAHead("$__ManageMessages");
  $PageNum = $Offset / $LIMIT + 1;
  echo "<H3 ALIGN=\"CENTER\">$__PageNumber $PageNum</H3>\n";
?>
  <CENTER>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
  <INPUT TYPE="Hidden" NAME="boardid" VALUE="<?echo $boardid;?>">
  <P>
  <TABLE BORDER="1">
  <TR><TH>ID</TH><TH><?echo $__Author;?></TH><TH><?echo $__Topic;?></TH><TH><?echo $__Posted;?></TH><TH>IP</TH>
  <!--TH>Has children</TH--><TH><?echo $__Parent;?></TH><TH><?echo $__Delete;?></TH>
  <TH><?echo $__Move;?></TH></TR>
<?
  PrintMessageRows($boardid, 0, "");
?>
  </TABLE>
  </P>
  <SELECT NAME="toboard">
  <OPTION VALUE="0"><?echo $__NoBoard;?>
<?
  $SQL = "SELECT * FROM boards WHERE owner = '$User'";
  $toboards = mysql_query($SQL);
  while ($row = mysql_fetch_array($toboards)):
    $toid = $row["id"];
    $toname = $row["name"];
    if ($boardid != $toid):
      echo "<OPTION VALUE=\"$toid\">$toname\n";
    endif;
  endwhile;
  mysql_free_result($toboards);
?>
  </SELECT>
  <P>
  <INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__DeleteMarked;?>">
  <INPUT TYPE="RESET" value="<?echo $__ResetMarks;?>">
  </P>
  </FORM>
  </CENTER>
  <TABLE WIDTH="100%">
  <TR VALIGN="TOP">
  <TD ALIGN="LEFT">
<?
  if ($Offset > 0):
    $POffset = $Offset - $LIMIT;
?>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="HIDDEN" NAME="Action" VALUE="<?echo $Action;?>">
    <INPUT TYPE="HIDDEN" NAME="Offset" VALUE="<?echo $POffset;?>">
    <INPUT TYPE="HIDDEN" NAME="boardid" VALUE="<?echo $boardid;?>">
    <INPUT TYPE="Submit" VALUE="<?echo $__Previous;?>">
    </FORM>
<?
  endif;
?>
  </TD>
  <TD>
  <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
<?
  echo $__GotoPage;
?>
  <INPUT TYPE="HIDDEN" NAME="Action" VALUE="<?echo $Action;?>">
  <INPUT TYPE="HIDDEN" NAME="boardid" VALUE="<?echo $boardid;?>">
  <SELECT NAME="Offset" VALUE="<?echo $Ofs;?>">
<?
  $SQL = "SELECT count(*) as msgs FROM messages WHERE boardid = $boardid AND prev = 0";
  $res = mysql_query($SQL);
  $row = mysql_fetch_row($res);
  $Pages = $row[0];
  mysql_free_result($res);
  $Ofs = 0;
  $Page = 1;
  while ($Ofs < $Pages):
    if (($Offset / $LIMIT) == ($Page - 1)):
      echo "<OPTION VALUE=\"$Ofs\" SELECTED>$Page\n";
    else:
      echo "<OPTION VALUE=\"$Ofs\">$Page\n";
    endif;
    $Page++;
    $Ofs += $LIMIT;
  endwhile;
?>
  </SELECT>
  <INPUT TYPE="Submit" VALUE="<?echo $__Go;?>">
  </FORM>
  </TD>
  <TD ALIGN="RIGHT">
<?
  $NOffset = $Offset + $LIMIT;
  $SQL = "SELECT id FROM messages WHERE boardid = $boardid AND prev = 0 ORDER BY posted DESC LIMIT $NOffset,1";
  $NextMessages = mysql_query($SQL);
  if (mysql_num_rows($NextMessages)):
?>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="HIDDEN" NAME="Action" VALUE="<?echo $Action;?>">
    <INPUT TYPE="HIDDEN" NAME="Offset" VALUE="<?echo $NOffset;?>">
    <INPUT TYPE="HIDDEN" NAME="boardid" VALUE="<?echo $boardid;?>">
    <INPUT TYPE="Submit" VALUE="<?echo $__Next;?>">
    </FORM>
<?
  endif;
  mysql_free_result($NextMessages);
?>
  </TD>
  </TR>
  </TABLE>
<?

elseif (("$Action" == "$__DeleteMarked") && ("$realowner" == "$PHP_AUTH_USER")):
  $DeleteCount = count($DeleteID);
  if ($DeleteCount):
    $i = 0;
    $Ids = "";
    /*Make a list of messages to delete */
    while ($i < $DeleteCount):
      $ID = $DeleteID[$i];

	/* Move child messages one level up */
	$SQL = "SELECT prev FROM messages WHERE id = $ID";
	$message = mysql_query($SQL);
	$prev = $row["prev"];
	mysql_free_result($message);
	$SQL = "UPDATE messages SET prev = $prev WHERE prev = $ID";
	$result = mysql_query($SQL);

	if ($i):
		$Ids = "$Ids,";
	endif;
	$Ids .= $ID;
	$i++;
    endwhile;
    $SQL = "DELETE FROM messages WHERE id IN ($Ids)";
    $result = mysql_query($SQL);
  endif;
  $MoveCount = count($MoveID);
  if ($MoveCount && $toboard):
    MoveMessages($MoveID, $toboard);
  endif;
  Reload();
elseif (("$Action" == "$__DeleteBoard") && ("$realowner" == "$PHP_AUTH_USER")):
  $SQL = "DELETE FROM boards WHERE id = $boardid AND owner = '$User'";
  mysql_query($SQL);
  if (mysql_affected_rows() == 1):
  $SQL = "DELETE FROM messages WHERE boardid = $boardid";
  mysql_query($SQL);
  Reload();
  PrintAHead("Deleted");
?>
  <H1><?echo $__MessagesDeleted;?></H1>
<?
 else:
endif;
?>
<?
elseif (("$Action" == "$__Edit") && ("$realowner" == "$PHP_AUTH_USER")):
  PrintAHead("$__Edit");
  PrintHeader();
  $boardid = IntVal($boardid);
  $SQL = "SELECT * FROM boards WHERE id = $boardid AND owner = '$User'";
  $board = mysql_query($SQL);
  if ($row = mysql_fetch_array($board)):
    $name = $row["name"];
    $description = $row["description"];
    $homename = $row["homename"];
    $homeaddress = $row["homeaddress"];
    $bgcolor = $row["bgcolor"];
    $bgimage = $row["bgimage"];
    $textcolor = $row["textcolor"];
    $linkcolor = $row["linkcolor"];
    $alinkcolor = $row["alinkcolor"];
    $vlinkcolor = $row["vlinkcolor"];
    $_header = $row["header"];
    $footer = $row["footer"];
    $notags = $row["notags"];
    $expiredays = $row["expiredays"];
    $pagesize = $row["pagesize"];
    $newmark = $row["newmark"];
    $notify = $row["notify"];
    $private = $row["private"];
    $rdonly = $row["rdonly"];
    $disabled = $row["disabled"];
    $newdays = $row["newdays"];
    if ("$disabled" == "Y"):
      $CHECKED = "CHECKED";
    else:
      $CHECKED = "";
    endif;
    if ("$notags" == "Y"):
      $NOTAGSCHECKED = "CHECKED";
    else:
      $NOTAGSCHECKED = "";
    endif;
    if ("$notify" == "Y"):
      $NOTIFYCHECKED = "CHECKED";
    else:
      $NOTIFYCHECKED = "";
    endif;
?>
    <H1 ALIGN="CENTER"><?echo $__EditYourBoard;?></H1>
    <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
    <INPUT TYPE="HIDDEN" NAME="Action" VALUE="<?echo $__Update;?>">
    <INPUT TYPE="HIDDEN" NAME="boardid" VALUE="<?echo $boardid;?>">
    <CENTER>
    <TABLE>
    <TR>
    <TD VALIGN=TOP><?echo $__Name;?></TD>
    <TD>
    <INPUT TYPE="TEXT" MAXLENGTH="40" NAME="_name" VALUE="<?echo $name;?>">
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__Description;?></TD>
    <TD>
    <TEXTAREA NAME="_description" COLS="40" ROWS="4"><?echo $description;?></TEXTAREA>
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__HomePageTitle;?></TD>
    <TD>
    <INPUT TYPE="TEXT" MAXLENGTH="40" NAME="_homename" VALUE="<?echo $homename;?>">
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__HomePageURL;?></TD>
    <TD>
    <INPUT TYPE="TEXT" MAXLENGTH="140" NAME="_homeaddress" VALUE="<?echo $homeaddress;?>">
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__BgColor;?></TD>
	  <TD>
	  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_bgcolor" VALUE="<?echo $bgcolor;?>">
	  </TD>
	  </TR>
	  <TR>
	  <TD VALIGN=TOP><?echo $__BgImageURL;?></TD>
	  <TD>
	  <INPUT TYPE="Text" NAME="_bgimage" VALUE="<?echo $bgimage;?>" SIZE="60" MAXLENGTH="255">
	  </TD>
	  </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__TextColor;?></TD>
	  <TD>
	  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_textcolor" VALUE="<?echo $textcolor;?>">
	  </TD>
	  </TR>
	  <TR>
    <TR>
    <TD VALIGN=TOP><?echo $__LinkColor;?></TD>
	  <TD>
	  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_linkcolor" VALUE="<?echo $linkcolor;?>">
	  </TD>
	  </TR>
	  <TR>
    <TR>
    <TD VALIGN=TOP><?echo $__VisitedLinkColor;?></TD>
	  <TD>
	  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_vlinkcolor" VALUE="<?echo $vlinkcolor;?>">
	  </TD>
	  </TR>
	  <TR>
    <TR>
    <TD VALIGN=TOP><?echo $__ActiveLinkColor;?></TD>
	  <TD>
	  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_alinkcolor" VALUE="<?echo $alinkcolor;?>">
	  </TD>
	  </TR>
    <TR>
    <TD VALIGN=TOP>&nbsp;</TD>
    <TD>
&nbsp;
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__PageHeader;?></TD>
    <TD>
    <TEXTAREA NAME="_header" COLS="40" ROWS="4"><?echo $_header;?></TEXTAREA>
    </TD>
    </TR>
    <TR>
    <TD VALIGN=TOP><?echo $__PageFooter;?></TD>
    <TD>
    <TEXTAREA NAME="_footer" COLS="40" ROWS="4"><?echo $footer;?></TEXTAREA>
    </TD>
    </TR>
  <TR>
  <TD><?echo $__PageSize;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_pagesize" VALUE="<?echo $pagesize;?>">
  </TD>
  </TR>
	  <TR>
	  <TD VALIGN=TOP><?echo $__DisableTags;?></TD>
	  <TD>
	  <INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_notags" <?echo $NOTAGSCHECKED;?>>
	  </TD>
	  </TR>
  <TR>
  <TD><?echo $__KeepMessagesDays;?></TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="16" "MAXLENGTH="16" NAME="_expiredays" VALUE="<?echo $expiredays;?>">
  </TD>
  </TR>
  <TR>
  <TD>
  <?echo $__MarkNewWith;?>
  </TD>
  <TD>
<!--   <INPUT TYPE="TEXT" SIZE="80" "MAXLENGTH="100" NAME="_newmark" VALUE="<?echo HtmlSpecialChars($newmark);?>"> -->
  <INPUT TYPE="TEXT" SIZE="80" "MAXLENGTH="100" NAME="_newmark" VALUE="<?echo HtmlSpecialChars($newmark);?>">
  </TD>
  </TR>
  <TR>
  <TD>
  <?echo $__MarkAsNew;?>
  </TD>
  <TD>
  <INPUT TYPE="TEXT" SIZE="80" "MAXLENGTH="100" NAME="_newdays" VALUE="<?echo $newdays;?>">
  </TD>
  </TR>
  <TR>
  <TD VALIGN=TOP><?echo $__NotifyOwner;?></TD>
  <TD>
  <INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_notify" <?echo $NOTIFYCHECKED;?>>
  </TD>
  </TR>
	  <TD VALIGN=TOP><?echo $__Disable;?></TD>
	  <TD>
	  <INPUT TYPE="CHECKBOX" VALUE="Y" NAME="_disabled" <?echo $CHECKED;?>>
	  </TD>
	  </TR>
	  </TABLE>
	  <INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__Update;?>">
	  </FORM>
<?	
	else:
	  NotAvailable();
	endif;
	
elseif ("$Action" == "AddNew"):
  if (!$_disabled):
    $_disabled = 'N';
  endif;
  if (!$_notags):
    $_notags = 'N';
  endif;
  $_expiredays = IntVal($_expiredays);
  $_pagesize = IntVal($_pagesize);
  $_newdays = IntVal($_newdays);
  $SQL = "INSERT INTO boards (owner, name, description, homename, homeaddress, " .
        "created, disabled, bgcolor, bgimage, textcolor, linkcolor, alinkcolor, vlinkcolor, " .
        "header, footer, notags, expiredays, newmark, notify, pagesize, newdays) " .
        "VALUES ('$User', '$_name', '$_description', '$_homename', '$_homeaddress', " .
        "now(), '$_disabled', '$_bgcolor', '$_bgimage', '$_textcolor', " .
        "'$_linkcolor', '$_alinkcolor', '$_vlinkcolor', '$_header', '$_footer', " .
        "'$_notags', $_expiredays, '$_newmark', '$_notify', $_pagesize, $_newdays)";
  mysql_query($SQL);
  Reload();
/*  echo "$SQL\n";*/
elseif ("$Action" == "DisablePost"):
  $boardid = IntVal($boardid);
  $SQL = "SELECT name FROM boards WHERE id = $boardid AND owner = '$User'";
  $board = mysql_query($SQL);
  if ($board != -1):
    if (mysql_num_rows($board)):
      
    endif;
  endif;
elseif (("$Action" == "$__Update") && ("$realowner" == "$PHP_AUTH_USER")):
  $boardid = IntVal($boardid);
  if (!$_disabled):
    $_disabled = 'N';
  endif;
  if (!$_notags):
    $_notags = 'N';
  endif;
  $_expiredays = IntVal($_expiredays);
  $_pagesize = IntVal($_pagesize);
  $_newdays = IntVal($_newdays);
  $SQL = "UPDATE boards SET name = '$_name', description = '$_description', " .
		"homename = '$_homename', homeaddress = '$_homeaddress', " .
		"disabled = '$_disabled', bgcolor = '$_bgcolor', bgimage = '$_bgimage', " .
		"textcolor = '$_textcolor', linkcolor = '$_linkcolor', " .
		"alinkcolor = '$_alinkcolor', vlinkcolor = '$_vlinkcolor', " .
		"header = '$_header', footer = '$_footer', notags = '$_notags', " .
		"expiredays = $_expiredays, newmark = '$_newmark', notify = '$_notify' ," .
		"pagesize = '$_pagesize', newdays = $_newdays " .
		"WHERE id = $boardid AND owner = '$User'";
  mysql_query($SQL);
  Reload();
/*  echo "$SQL\n";*/
else:
  $boards_num = mysql_num_rows($boards);
  if (!$boards_num):
    PrintNewBoard();
  else:
	  PrintAHead("$__AdminPage");
?>
<SCRIPT LANGUAGE="JavaScript">
<!--
function ConfDelete() {
	if (confirm("<?echo $__DeleteThisBoard;?>"))
		return(true);
	else
		return(false);
}
// -->
</SCRIPT>
    <H1 ALIGN="CENTER"><?echo $__WebboardAdministration;?></H1>
<?
    PrintHeader();
?>
    <H2><?echo $__SelectBoard;?></H2>
    <UL>
<?
    $i = 0;
    while ($row = mysql_fetch_array($boards)):
      $id = $row["id"];
      $name = $row["name"];
      $description = $row["description"];
      $created = $row["created"];
      $disabled = $row["disabled"];
?>
      <LI><A HREF="<?echo "../forum.php?board=$id";?>"><?echo $name;?></A><BR>
	 
<?
      echo "$description<BR>\n";
      echo "$__Created: $created<BR>\n";
      if ("$disabled" == 'Y'):
        echo "<STRONG>$__Disabled</STRONG><BR>\n";
      endif;
?>
 <?echo $__BoardID;?>: <B><FONT COLOR="Red"><?echo "$id";?></FONT></B><BR>
      <TABLE>
	<TR>
<?
      if (!$ValidBoards):
?>
	<TD>
        <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST"  OnSubmit="return (ConfDelete())">
	<INPUT TYPE="Hidden" NAME="boardid" VALUE="<?echo $id;?>">
	<INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__DeleteBoard;?>">
	</FORM>
	</TD>
	<TD>
        <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
	<INPUT TYPE="Hidden" NAME="boardid" VALUE="<?echo $id;?>">
	<INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__Edit;?>">
	</FORM>
	</TD>
<?
      endif;
?>
			<TD>
      <FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST">
      <INPUT TYPE="Hidden" NAME="boardid" VALUE="<?echo $id;?>">
      <INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__Manage;?>">
      </FORM>
      </TD>
      </TR>
      </TABLE>
<?
    endwhile;
?>
    </UL>
<?

  endif;
endif;
?>
