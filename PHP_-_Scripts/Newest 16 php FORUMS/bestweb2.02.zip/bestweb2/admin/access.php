<?
include "../common.php";

function NotAuthorized () {
  Global $__SorryYouDoNotHavePermissions;
  Header("HTTP/1.0 401 Unauthorized");
  Header("WWW-authenticate: basic realm=\"WebBoard Admin\"");
  echo "<H2>$__SorryYouDoNotHavePermissions</H2>\n"; 
}

/*
function NotAvailable () {
  Global $__AccessDenied;
?>
<HTML>
<HEAD>
<TITLE>
<? echo $__AccessDenied; ?>
</TITLE>
</HEAD>
<BODY BGCOLOR="#CCFFFF">
<H1 align="center">
<? echo $__AccessDenied; ?>
</H1>
</BODY>
</HTML>
<?
}
*/

 function getpwnam ($user) {
    $fp = fopen(".passwd", "r");
    if (!$fp){
      return "";
    }
    while ($str = fgets($fp, 1024)) {
         $str = chop($str);
      if (ereg("^$user:", $str)) {
           return $str;
      }
    }
    fclose($fp);
       return "";
}




function TryCoAdmin ($User, $Pass) {
  $SQL = "SELECT * FROM coadmins WHERE login = '$User'";
  $coadmin = mysql_query($SQL);
  if ($coadmin):
    if ($row = mysql_fetch_row($coadmin)):
      $passwd = $row["pass"];
      $owner = $row["owner"];
      $boards = $row["boards"];
      $SQL = "SELECT password('$Pass') as pass";
      $pass = mysql_query($SQL);
      $passwd1 = mysql_result($pass, 0, "pass");
      mysql_free_result($pass);
      if ($passwd1 == $passwd):
        return "$owner:$boards";
      endif;
    endif;
  endif;
  return "";
}

if(!$PHP_AUTH_USER):
  NotAuthorized();
  exit;
endif;
$AuthUser=strtok($PHP_AUTH_USER, "@");

$pw = getpwnam($AuthUser);
if (!$pw):
  $UserBoards = TryCoAdmin($AuthUser, $PHP_AUTH_PW);
  if (!$UserBoards):
    NotAuthorized();
    exit;
  endif;
endif;
if (!$UserBoards):
  $login = strtok($pw, ":");
  $passwd = strtok(":");
  $tmp = strtok(":");
  $tmp = strtok(":");
  $tmp = strtok(":");
  $tmp = strtok(":");
  if (!$Name):
    $Name = strtok(":");
  endif;
  if (crypt($PHP_AUTH_PW, substr($passwd, 0, 2)) != $passwd):
    $UserBoards = TryCoAdmin($AuthUser, $PHP_AUTH_PW);
    if (!$UserBoards):
      NotAuthorized();
      exit;
    endif;
  endif;
  $User = $AuthUser;
endif;
if ($UserBoards):
  $User = strtok($UserBoards, ":");
  $ValidBoards = strtok(":");
endif;
?>