<?

include "common.php";

function PagerMsg($PagerMsg) {
	echo "<html><head><title>$__ICQMsgTo $author</title>\n";
	StyleSheet ();
	echo "<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0>\n";
    echo "
	<table BORDER=0 CELLSPACING=0 CELLPADDING=5 width=\"100%\">
	<tr class=\"header\">
	<td with=\"90%\" valign=\"top\"><a href=\"#\"><font class=\"header\">Sent</font></a>
	</td>
	<td width=\"30\" valign=\"top\" align=\"right\"><a href=\"$credits\" target=\"_new\"><img alt=\"Credits\" border=\"0\" hspace=\"3\" src=\"images/panda.gif\" width=\"16\" height=\"16\"></a></td>
	</tr>
	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=\"100%\">
	<tr><td><img src=\"images/1.gif\" height=\"5\"></td></tr></table>
	
	<div align=\"center\">
	<center>
	<table border=0 width=96% cellspacing=0 cellpadding=1 heigth=100%>
	    <tr>
	      <td width=96% bgcolor=#000000>     
	<table border=0 cellspacing=0 cellpadding=5 width=\"100%\">
	<tr class=\"category\">
	<td><font class=\"body\">$PagerMsg<p>
	<center><a href=\"#\" onClick=\"window.close()\"><font class=\"red\">";
	echo "Close";
	echo"</font></a>
	</td>
	    </tr>
	  </table>
	</td>
	    </tr>
	  </table>
	</center>
	</div>
";
	echo "</body></html>\n";
}


if ($submit) {
	if (!$subj) $subj = "[No subject]";
	if (!$navn) $navn = "[No name]";

	# If the user did not write a PagerMsg...
	elseif (!$PagerMsg) {
		PagerMsg($__ICQForgotMessage);
	}
	# The PagerMsg body cannot contain more than 450 characters.
	elseif (strlen($PagerMsg) > 450) {
		PagerMsg($__ICQMsgTooLong);
	}
	# If the user did not specify his/her email address...
	elseif (!$eMail) {
		PagerMsg($__ICQForgotEmail);
	}
	# Sending the PagerMsg:
	else {
		mail("$icqnumber@pager.icq.com", $subj, $PagerMsg, "From: $navn <$email>");
		PagerMsg($__ICQMessageSent);
	}
}
?>
