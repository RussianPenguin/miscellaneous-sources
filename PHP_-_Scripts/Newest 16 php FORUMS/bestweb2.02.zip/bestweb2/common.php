<?
/*
######################################################
 The script is based on Mark Napartovic's wwwboard.
 http://www.glasnet.ru/~nmark/

 Modifications by Oktay Ozturk
 http://www.bestweb.ca
 oktay@torontonian.com
 
 The Index Page modification by
 Zeke Rogers
 zrogers@sunset.net
######################################################
*/

include "/home/toronto/public_html/forums/include/db.php";
include "/home/toronto/public_html/forums/lang/eng.php";

//This is the notification email to be sent when messages posted
$moderator = "oktay@torontonian.com";
//If your sendmail is located somewhere else fix this
$MP = "/usr/bin/sendmail";

// This is the server name of your site so that the script can only 
//be executed from your server not somebody else's home machine
$referrer ="209.15.18.43|torontonian.com";

//Please leave this intact since this is a free and collaborative project
$credits = "credits.php";

//You might want to create a directory called temp if you're on a virtual hosting
//Chmod it 777
$CACHE_DIR = "temp";
$CACHE_TMPL = "$CACHE_DIR/wb_";
$CACHE_EXT = ".tmp";


$Board["bgcolor"] = "#FFFFFF";
$Board["textcolor"] = "#000000";
$Board["linkcolor"] = "#000080";
$Board["alinkcolor"] = "#000080";
$Board["vlinkcolor"] = "#000080";
$Board["notags"] = "N";

$ExpireInterval = 8640000;

Error_Reporting(0);

$UniqueNum = Time() + GetMyPid();
$UniqueNum = StrVal($UniqueNum);

mysql_pconnect($DBHOST, $DBUSER, $DBPASS);
mysql_select_db($DB);

setlocale("LC_ALL", "en");
setlocale ("LC_TIME", "en");

function CleanUp() {
  setlocale("LC_ALL", "en");
}

register_shutdown_function("CleanUp");

function stylesheet (){
              $browser_type = getenv("HTTP_USER_AGENT");
              if (preg_match("/compatible; MSIE/i", "$browser_type")) {
                      echo "<link rel=\"stylesheet\" href=\"styles/ie5.css\">\n";
              } else  if (preg_match("/Mozilla/i", "$browser_type")) {
                      echo "<link rel=\"stylesheet\" href=\"styles/nets4.css\">\n";
              } else {
                     echo "<link rel=\"stylesheet\" href=\"styles/nets4.css\">\n";
              }
     }

function ValidateInput() {
?>
<SCRIPT>
<!-- Hide script from old browsers
function CheckEmpty(f, theName) {
   if (f.value == "") {
      alert(theName + "field is blank");
      f.focus();
      f.select();
      return false;
   } else {
       return true;
   }
}

//end hiding from old browsers -->
</SCRIPT>
<?
}

function SendMail($from, $to, $subject, $msg, $headers = "") {
  Global $__Author;
  Global $__Message;
  Global $MP;
//If your sendmail is located somewhere else fix this
//  $MP = "/usr/bin/sendmail";
  if (!$from):
    $from = "root@nobody.com";
  endif;
  $fd = popen($MP,"w");
  if ($fd):
    fputs($fd, "To: $to\n");
    fputs($fd, "From: $from\n");
    fputs($fd, "Subject: $title\n");
    fputs($fd, "Reply-to: $from\n");
    fputs($fd, "X-Mailer: Bestweb.ca Forums\n");
    fputs($fd, "Content-Type: text/plain; charset=iso-8859-9\n");
    if ($headers):
      fputs($fd, $headers . "\n\n");
    else:
      fputs($fd, "\n");
    endif;
    fputs($fd, "$msg");
    pclose($fd);
  endif;
  return $fd;
}

function FirstConnect($SQL) {
  Global $DB;
  Global $DBHOST;

  $result = mysql_query($SQL);
  if (!$result):
    mysql_pconnect($DBHOST, $DBUSER, $DBPASS);
    mysql_select_db($DB);
    $result = mysql_query($DB, $SQL);
  endif;
  return $result;
}

function Reload ($URL = "") {
  Global $PHP_SELF;
  
  if (!$URL):
    $URL = $PHP_SELF;
  endif;
  Header("Location: $URL");
  Header("Refresh: 0; URL=$URL");
?>
<!--HTML>
<HEAD>
<TITLE>
Redirector page. Please wait a second....
</TITLE>
<!--META HTTP-EQUIV="REFRESH" CONTENT="0; URL=<?echo $URL;?>"-->
<!--/HEAD>
</HTML-->
<?

}

function PrintHead ($title) {
  Global $Board;
  Global $UniqueNum;
  Global $__WebBoard;
  Global $Msg;
?>
 <HTML>
 <HEAD>
 <TITLE><?echo "$__WebBoard: $title";?></TITLE>
 <META NAME="ROBOTS" CONTENT="ALL">
 <META NAME="ROBOTS" CONTENT="FOLLOW">
 <META HTTP-EQUIV="KEYWORDS" CONTENT="<?echo $title;?>">
 <META HTTP-EQUIV="DESCRIPTION" CONTENT="<?echo $title;?>">
 <META http-equiv="Content-Type" content="text/html; charset=ISO-8859-59">
 <meta http-equiv="Content-Type" content="text/html; charset=windows-1254">
 <link rel="shortcut icon" href="http://torontonian.com/images/ico/redir.ico">
 <?ValidateInput();?>
 <?StyleSheet();?>
 </HEAD>
<body topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" bgcolor="#FFFFFF" text="#000000" link="#000080" vlink="#000080" alink="#000080">
<table border="0" width="100%" height="100%" cellspacing="10" cellpadding="0">
    <tr>
      <td width="150" valign="top" align="left">
	  <img border="0" src="images/1.gif" width="150" height="1"><br>
        <?include ("include/sidenav.php");?>
      </td>
      <td width="90%" valign="top" align="left">
<!-- Forum Starts -->
<?
  $Board["header"] = ereg_replace("%uid", $UniqueNum, $Board["header"]);
  echo $Board["header"];
}

function PrintFoot($Extra = "") {
  Global $HTTP_REFERER;
  Global $Board;
  Global $UniqueNum;
  Global $__Back;

  $Board["footer"] = ereg_replace("%uid", $UniqueNum, $Board["footer"]);
  echo $Board["footer"];
?>
<!-- Forum Ends   -->
    </td>
  </tr>
</table> 
	  </td>
      <td width="20" valign="top" align="right"><img border="0" src="images/1.gif" width="20" height="0"></td>
    </tr>
  </table>
<? 
} 

function NotAvailable() {
  Global $__SorryNotAvailable; 
  Header("HTTP/1.0 404 Object Not Found");
  PrintHead("$__NotAvailable");
?>
  <H1 ALIGN="CENTER"><? echo $__SorryNotAvailable; ?></H1>
<?
  PrintFoot();
}

function HighlightURLs($msg) {
  return ereg_replace("(h?[tf]tp://[-~a-zA-Z_0-9/.+;%&?|=:]+)([^-~a-zA-Z_0-9/.+%&?|=:]|$)",
	"<A HREF=\"\\1\" TARGET=\"_blank\">\\1</A>\\2", $msg);
}

function PrintIt($str, $file = 0) {
  if ($file):
    return fputs($file, $str);
  else:
    echo $str;
    return 0;
  endif;
}

function PrintMessage($Messages, $current = 0, $op = 0) {
  Global $Board;
  $id = $Messages["id"];
  $subject = $Messages["subject"];
  $author = $Messages["author"];
  $posted = strftime("%e/%m/%y", $Messages["posted"]);
  $daysold = $Messages["daysold"];
  $cache = 0;
  if ($op):
    $cache = $current;
    $current = 0;
  endif;
  //start
  PrintIt($Board["tstart"], $cache);
  if ($id == $current):
    echo "<font class=\"current\"><B>";
//end	
  else:
    PrintIt("<A HREF=\"message.php?id=$id\" TARGET=\"$Board[msgtarget]\">", $cache);
  endif;
  PrintIt("$subject", $cache);
  if ($id == $current):
    echo "</B></font>";
  else:
    PrintIt("</A>", $cache);
  endif;
  PrintIt(" - <b>$author</b> $posted\n", $cache);
  if ($Board["newdays"]):
    if($daysold < $Board["newdays"]):
      PrintIt($Board["newmark"], $cache);
    endif;
  endif;
  PrintIt($Board["tend"] . "\n", $cache);

  return $id;
}

function PrintMessages($boardid, $prev = 0, $current = 0) {
  Global $Board;
  Global $Offset;
  Global $Settings;
  
  $boardid = IntVal($boardid);
  $prev = IntVal($prev);
  if ($prev < 0): //$prev == root message
    $prev = -$prev;
    $SQL = "SELECT id, subject, author, UNIX_TIMESTAMP(posted) as posted, " .
      "(TO_DAYS(now()) - TO_DAYS(posted)) AS daysold FROM messages WHERE id = $prev";
    $message = mysql_query($SQL);
    if ($Message = mysql_fetch_array($message)):
      $CloseTag = "</UL>";
      echo "<UL>";
      PrintMessage($Message, $current);
    endif;
  endif;
  if ($prev || (!$Board[pagesize])):
    $LIMIT = "";
  else:
    $LIMIT = "LIMIT $Offset," . $Board[pagesize];
  endif;
  switch ($Settings["Order"]):
    case "threadupdated":
      $ORDER = "threadupdated DESC, posted DESC";
      break;
    default:
      $ORDER = "posted DESC";
      break;
  endswitch;
  if (!$prev && $LIMIT):
    $SQL = "SELECT id FROM messages WHERE prev = 0 AND boardid = $boardid ORDER BY $ORDER $LIMIT";
    $messages = mysql_query($SQL);
    while ($row = mysql_fetch_row($messages)):
      $ids[] = $row[0];
    endwhile;
    mysql_free_result($messages);
    $Ids = implode(",", $ids);
    $IDIN = "AND id IN ($Ids)";
  else:
    $IDIN = "";
  endif;
  $SQL = "SELECT id, subject, author, UNIX_TIMESTAMP(posted) as posted, (TO_DAYS(now()) - TO_DAYS(posted)) AS daysold " .
  	"FROM messages WHERE prev = $prev $IDIN AND boardid = $boardid ORDER BY $ORDER";
  $messages = mysql_query($SQL);
  $num_messages = mysql_numrows($messages);
  if ($num_messages):
    echo "<UL COMPACT>\n";
    while ($Messages = mysql_fetch_array($messages)):
      $id = PrintMessage($Messages, $current);
      PrintMessages($boardid, $id, $current);
    endwhile;
    echo "</UL>";
  endif;
  mysql_freeresult($messages);
  echo $CloseTag;
  return $num_messages;
}

function PrintMessagesFile($boardid, $prev = 0, $cache = 0) {
  Global $Board;
  Global $Offset;
  Global $Settings;

  if ($prev || (!$Board[pagesize])):
    $LIMIT = "";
  else:
    $LIMIT = "LIMIT $Offset," . $Board[pagesize];
  endif;
  switch ($Settings["Order"]):
    case "threadupdated":
      $ORDER = "threadupdated DESC, posted DESC";
      break;
    default:
      $ORDER = "posted DESC";
      break;
  endswitch;
  if (!$prev && $LIMIT):
    $SQL = "SELECT id FROM messages WHERE prev = 0 AND boardid = $boardid ORDER BY $ORDER $LIMIT";
    $messages = mysql_query($SQL);
    while ($row = mysql_fetch_row($messages)):
      $ids[] = $row[0];
    endwhile;
    mysql_free_result($messages);
    $Ids = implode(",", $ids);
    $IDIN = "AND id IN ($Ids)";
  else:
    $IDIN = "";
  endif;
  $SQL = "SELECT id, subject, author, UNIX_TIMESTAMP(posted) as posted, (TO_DAYS(now()) - TO_DAYS(posted)) AS daysold " .
  	"FROM messages WHERE prev = $prev $IDIN AND boardid = $boardid ORDER BY $ORDER";
  $messages = mysql_query($SQL);
  $num_messages = mysql_numrows($messages);
  if ($num_messages):
    fputs($cache, "<UL COMPACT>\n");
    while ($Message = mysql_fetch_array($messages)):
      $id = PrintMessage($Message, $cache, 1);
      PrintMessagesFile($boardid, $id, $cache);
    endwhile;
    fputs($cache, "</UL>");
  endif;
  mysql_freeresult($messages);
  fputs($cache, $CloseTag);
  return $num_messages;
}

function MessageHeader($boardid, $Title, $Offset = 0) {
  Global $Board;
  Global $__WebBoard;
  PrintHead($Title);
?>
<!--<P ALIGN="CENTER">
[<A HREF="forum.php?board=<?echo $boardid;?>&Offset=<?echo $Offset;?>" TARGET="<?echo $Board["boardtarget"];?>"><?echo $__WebBoard;?></A>]
</P>-->
<?
}

/*function MessageFooter($boardid) {
  Global $Board; Global $__WebBoard;
  PrintFoot("[<A HREF=\"forum.php?board=$boardid\" TARGET=\"" . 
		$Board["boardtarget"] . "\">$__WebBoard</A>]");
 }*/
 function MessageFooter($boardid) {
  Global $Board; Global $__WebBoard;
  PrintFoot();
 }


/*
function GetRemoteHost () {
  Global $HTTP_X_FORWARDED_FOR;
  Global $REMOTE_HOST;
  
  if ("$HTTP_X_FORWARDED_FOR" != ""):
    $remotehost = strtok($HTTP_X_FORWARDED_FOR, ",");
    $remotehost = getHostByAddr($remotehost);
  else:
    $remotehost = getHostByAddr($REMOTE_HOST);
  endif;
  return $remotehost;
}
*/
function GetRemoteHost () {

//if (getenv(HTTP_CLIENT_IP)){ 
//$remotehost=getenv(HTTP_CLIENT_IP); 
//} 
//else { 
$remotehost=getenv(REMOTE_ADDR); 
//}
}

function PostMessage ($Must, $MustName, $id, $boardid, $Author, $Subject,
    $Msg, $Url, $Email, $UrlName, $UrlImage, $Notification = "N") {
  Global $HTTP_REFERER;
  //Global $REMOTE_ADDR;
  //Global $HTTP_USER_AGENT;
  //Global $HTTP_ACCEPT_LANGUAGE;
  //Global $REMOTE_PORT;
  Global $referrer;
  Global $security;
  Global $ExpireInterval;
  Global $Board;
  Global $CACHE_TMPL;
  Global $CACHE_EXT;
  Global $__MailNewMessage; 
  Global $__Author;
  Global $__Message;
  Global $__CannotPost; 
  Global $moderator; 
  
  if (!eregi($referrer, $HTTP_REFERER)):
    MessageHeader($boardid, "Webboard antispam filter");
    echo "<H1>$__CannotPost</H1>\n";
    MessageFooter($boardid);
  else:
    $ExpireTime = time() + $ExpireInterval;
    if ("$Author" != ""):
      SetCookie("GlasnetWBAuthor$boardid", $Author, $ExpireTime);
    endif;
    if ("$Email" != ""):
      SetCookie("GlasnetWBEmail$boardid", $Email, $ExpireTime);
    endif;
    SetCookie("GlasnetWBUrl$boardid", $Url, $ExpireTime);
    SetCookie("GlasnetWBUrlName$boardid", $UrlName, $ExpireTime);
    SetCookie("GlasnetWBUrlImage$boardid", $UrlImage, $ExpireTime);
    $MustCount = count($Must);
    $i = 0;
    $Ok = 1;
    while ($i < $MustCount):
      $MustVar = $Must[$i];
      if (!$$MustVar):
        if ($Ok):
          MessageHeader($boardid, "Some fields missing");
        endif;
    ?>
        <H2 ALIGN="CENTER"><?echo $MustName[$i],$__NotSpecified;?></H2>
    <?
        $Ok = 0;
      endif;
      $i++;
    endwhile;
    if ($Ok):
      @unlink("$CACHE_TMPL$boardid$CACHE_EXT");
      if (ereg("@", $Email)):
        $From = "\"$Author\" <$Email>";
      else:
        $From = "($Author) <moderator@demokratik.net>";
      endif;

$t_ip=getenv(REMOTE_ADDR);
$t_port=getenv(REMOTE_PORT);
$t_brow=getenv(HTTP_USER_AGENT);
$t_lang=getenv(HTTP_ACCEPT_LANGUAGE);
$t_ref=getenv(HTTP_REFERER);
$track = "$t_ip $t_port $t_brow $t_lang";

	  
      if ($Board["notify"] == "Y"):
        //Mail($Board["owner"] . "@torontonian.com",
		Mail($moderator,
          "$__MailNewMessage $name - $boardid:  $Subject", 
          "$__Author: $Author\n Email: $Email\n$__Message:\n$Msg\n\n$track\n$t_ref\n",
          "From: $From\nContent-Type: text/plain; charset=iso-8859-2");
      endif;
	  
	  
      $oMsg = "$Msg\n\n----------------------------------\n" .
      $Board["homename"] . " - " . $Board["homeaddress"] . "\n";
      $oAuthor = $Author;
      $oSubject = $Subject;
      $Author = HtmlSpecialChars($Author);
      $Subject = HtmlSpecialChars($Subject);
      $Email = HtmlSpecialChars($Email);
      $Url = HtmlSpecialChars($Url);
      $UrlName = HtmlSpecialChars($UrlName);
      $UrlImage = HtmlSpecialChars($UrlImage);
      $Msg = substr($Msg, 0, 32000);
	
      if ($Board["notags"] == "Y"):
        $Msg = HtmlSpecialChars($Msg);
      endif;
	  
      $remotehost = getenv(REMOTE_ADDR);
      $SQL = "INSERT INTO messages " .
        "(prev, boardid, posted, author, subject, msg, url, email, urlname, urlimage, remotehost, notify, threadupdated)" .
        "VALUES ($id, $boardid, now(), '$Author', '$Subject', '$Msg', '$Url', '$Email', " .
        "'$UrlName', '$UrlImage', '$remotehost', '$Notification', now())";
      mysql_query($SQL);
      
      $SQL = "UPDATE boards SET modtime = now() WHERE id = $boardid";
      mysql_query($SQL);
      if ($id):
        // Send email notifications to all previous authors if needed and update thread modified flag
        $root = FindRootMessage($id);
        $msglist = EnumMessages($root);
        $SQL = "UPDATE messages SET threadupdated = now() WHERE id IN ($msglist)";
        mysql_query($SQL);
        $SQL = "SELECT SQL_SMALL_RESULT DISTINCT email FROM messages WHERE id IN ($msglist) AND notify = 'Y'";
        $emailr = mysql_query($SQL);
        while ($row = mysql_fetch_row($emailr)):
          $emails[] = $row[0];
        endwhile;
        mysql_free_result($emailr);
      endif;
      $subject = "$__MailNewMessage \"" . $Board["name"] . "\": $oSubject";
      if (count($emails)):
        $bcc = implode($emails, ";");
        SendMail($From, "", $subject, "$__Author: $Author\nEmail: $Email\n$__Message:\n$oMsg",
          "Bcc: $bcc");
      endif;
//      Reload("forum.php?board=$boardid");
    else:
      MessageFooter($boardid);
    endif;
  endif;
}

function EnumMessages($id) {
  $msglist = "$id";
  $SQL = "SELECT id FROM messages WHERE prev = $id";
  $msgs = mysql_query($SQL);
  while ($row = mysql_fetch_array($msgs)):
    $id = $row["id"];
    $msl = EnumMessages($id);
    $msglist = "$msglist,$msl";
  endwhile;
  mysql_free_result($msgs);
  return $msglist;
}

function FindRootMessage($id) {
  $prev = $id;
  while ($prev):
    $id = $prev;
    $SQL = "SELECT prev from messages where id = $prev";
    $res = mysql_query($SQL);
    $row = mysql_fetch_row($res);
    $prev = $row[0];
    mysql_free_result($res);
  endwhile;
  return $id;
}

function PrintReplyForm($Board, $Message = 0) {
  Global $__YourName;
  Global $__Topic;
  Global $__Message;
  Global $__Link;
  Global $__LinkTitle;
  Global $__PicURL;
  Global $__SendRepliesByEmail;
  Global $__InsertOriginal;
  Global $__PostMessage;
  Global $PHP_SELF;
  Global $Author;
  Global $Email;
  Global $Url;
  Global $UrlName;
  Global $UrlImage;
  Global $__Optional;
  Global $__Email;
  if (!$Message):
    $Message = array();
  endif;
?>

<FORM ACTION="<?echo $PHP_SELF;?>" METHOD="POST"onSubmit="return (CheckEmpty(this.Author, '<?echo $__YourName;?>') && CheckEmpty(this.Subject, '<?echo $__Subject;?>')&& CheckEmpty(this.Msg, '<?echo $__Message;?>'))">
<INPUT TYPE="Hidden" NAME="id" VALUE="<?echo $Message["id"];?>">
<INPUT TYPE="Hidden" NAME="board" VALUE="<?echo $Board["id"];?>">
<TABLE>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__YourName;?></TD>
<TD><INPUT TYPE="Text" NAME="Author" VALUE="<?echo $Author;?>" SIZE="22" maxlength="120">
<INPUT TYPE="Hidden" NAME="Must[]" VALUE="Author">
<INPUT TYPE="Hidden" NAME="MustName[]" VALUE="Name">
<FONT COLOR="Red">*</FONT></TD></TR>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__Email;?></TD>
<TD><INPUT TYPE="Text" NAME="Email" VALUE="<?echo $Email;?>" SIZE="22" maxlength="120"></TD></TR>

<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__Topic;?></TD><TD>
<?
if (eregi("^Re:", $subject)):
  $Subject = $subject;
else:
  $Subject = "Re: $subject";
endif;
?>
<INPUT TYPE="Text" NAME="Subject" VALUE="<?echo $Message["subject"];?>" SIZE="22" maxlength="70">
<INPUT TYPE="Hidden" NAME="Must[]" VALUE="Subject">
<INPUT TYPE="Hidden" NAME="MustName[]" VALUE="Subject">
<FONT COLOR="Red">*</FONT></TD></TR>
<TR><TD COLSPAN="2"><font class="formfields"><STRONG><?echo $__Message;?></STRONG></font><BR>
<?
if ($Board["notags"]):
  $indent_char = "> ";
else:
  $indent_char = "| ";
endif;
$reply = ereg_replace("^", $indent_char, $Message["msg"]);
$reply = ereg_replace("\n", "\n$indent_char", $reply);
$reply = ereg_replace("\r", "", $reply);
$UrlName = ereg_replace("\\'", "'", $UrlName);
?>
<INPUT TYPE="HIDDEN" NAME="OrigMessage" VALUE="<?echo "\n" . HtmlSpecialChars($reply);?>">
<TEXTAREA NAME="Msg" COLS="38" ROWS="10" WRAP="PHYSICAL"></TEXTAREA>
<INPUT TYPE="Hidden" NAME="Must[]" VALUE="Msg">
<INPUT TYPE="Hidden" NAME="MustName[]" VALUE="Message">
<FONT COLOR="Red">*</FONT></TD></TR>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__Link;?></TD>
<TD><INPUT TYPE="Text" NAME="Url" VALUE="<?echo $Url;?>" SIZE="25" maxlength="120"></TD></TR>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__LinkTitle;?></TD>
<TD><INPUT TYPE="Text" NAME="UrlName" VALUE="<?echo $UrlName;?>" SIZE="25" maxlength="120"></TD></TR>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><?echo $__PicURL;?></TD>
<TD><INPUT TYPE="Text" NAME="UrlImage" VALUE="<?echo $UrlImage;?>" SIZE="25" maxlength="120"></TD></TR>
<TR><TD WIDTH=30% ALIGN="LEFT"><font class="formfields"><? echo $__SendRepliesByEmail;?></TD>
<TD><INPUT TYPE="CHECKBOX" VALUE="Y" NAME="Notification"></TD></TR>
<TR></TR>
<TR><TD><INPUT TYPE="Submit" NAME="Action" VALUE="<?echo $__PostMessage;?>">
</TD>
<TD>
<?
if (count($Message)):
?>
<INPUT TYPE="BUTTON" VALUE="<?echo $__InsertOriginal;?>" 
onClick="this.form.Msg.value=this.form.OrigMessage.value;">
<?
endif;
?>
</TD></TR>
</TABLE>


</FORM>
<?  
}

function CheckRO ($boardid) {
  $remotehost = getenv(REMOTE_ADDR);
  $SQL = "SELECT * FROM badips WHERE ip = '$remotehost' AND boardid = $boardid";
  $badip = mysql_query($SQL);
  if (mysql_num_rows($badip)):
    $RO = 1;
  else:
    $RO = 0;
  endif;
  mysql_free_result($badip);

// inserted by mvl
//  if (ereg("dialup.cl.spb.ru",$remotehost)) { $RO = 1; }
// inserted by mvl

  return $RO;
}
?>
