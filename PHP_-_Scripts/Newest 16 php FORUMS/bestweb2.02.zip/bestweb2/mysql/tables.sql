# phpMyAdmin MySQL-Dump
# http://phpwizard.net/phpMyAdmin/
#
# Host: localhost Database : db8906e

# --------------------------------------------------------
#
# Table structure for table 'badips'
#

DROP TABLE IF EXISTS badips;
CREATE TABLE badips (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   boardid int(11) DEFAULT '0' NOT NULL,
   ip varchar(64) NOT NULL,
   PRIMARY KEY (id),
   KEY boardid (boardid),
   KEY ip (ip),
   KEY boardid_2 (boardid, ip),
   UNIQUE boardid_3 (boardid, ip)
);

#
# Dumping data for table 'badips'
#


# --------------------------------------------------------
#
# Table structure for table 'boards'
#

DROP TABLE IF EXISTS boards;
CREATE TABLE boards (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   owner varchar(127) NOT NULL,
   name varchar(40) NOT NULL,
   description text,
   created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   disabled enum('Y','N') DEFAULT 'Y' NOT NULL,
   bgcolor varchar(16) DEFAULT 'white' NOT NULL,
   bgimage varchar(255) NOT NULL,
   homeaddress varchar(255),
   homename varchar(255),
   textcolor varchar(16),
   linkcolor varchar(16),
   vlinkcolor varchar(16),
   alinkcolor varchar(16),
   header text,
   footer text,
   notags enum('Y','N') DEFAULT 'N' NOT NULL,
   rdonly enum('Y','N') DEFAULT 'N' NOT NULL,
   expiredays int(11) DEFAULT '0' NOT NULL,
   newmark varchar(100) DEFAULT '<font color="red">new</font>',
   notify enum('Y','N') DEFAULT 'N',
   private enum('Y','N') DEFAULT 'N' NOT NULL,
   pagesize int(11) DEFAULT '20' NOT NULL,
   newdays int(11) DEFAULT '1' NOT NULL,
   tstart varchar(127) DEFAULT '<li>' NOT NULL,
   tend varchar(127) DEFAULT '</li>' NOT NULL,
   boardtarget varchar(20) DEFAULT '_self' NOT NULL,
   msgtarget varchar(20) DEFAULT '_self' NOT NULL,
   view enum('webboard','guestbook','other') DEFAULT 'webboard' NOT NULL,
   topnavigator enum('Y','N') DEFAULT 'N' NOT NULL,
   keywords text,
   metadesc text,
   modtime datetime,
   PRIMARY KEY (id),
   KEY owner (owner),
   KEY name (name),
   KEY created (created),
   KEY disabled (disabled),
   KEY expiredays (expiredays),
   KEY private (private),
   KEY pagesize (pagesize),
   KEY view (view)
);

#
# Dumping data for table 'boards'
#

INSERT INTO boards VALUES ( '1', 'test', 'First Forum', 'This is where forum description goes. It can be used for many functions', '2000-12-17 14:23:29', 'N', '', '', '', '', '', '', '', '', '', '', 'N', 'N', '120', '<font class=\"red\">new</font>', 'N', 'N', '10', '1', '<li>', '</li>', '', '', 'webboard', 'Y', 'Bestweb.ca, PHP, discussion forums, mysql', 'Only php forum that has threaded style unlike the UBB style forum', '2000-12-17 14:36:57');
# --------------------------------------------------------
#
# Table structure for table 'counter'
#

DROP TABLE IF EXISTS counter;
CREATE TABLE counter (
   start date,
   count int(20) unsigned,
   pageid char(255) NOT NULL,
   PRIMARY KEY (pageid)
);

#
# Dumping data for table 'counter'
#

INSERT INTO counter VALUES ( '2000-12-17', '5', '1');
INSERT INTO counter VALUES ( '2000-12-17', '2', '2');

# --------------------------------------------------------
#
# Table structure for table 'messages'
#

DROP TABLE IF EXISTS messages;
CREATE TABLE messages (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   prev int(11) DEFAULT '0' NOT NULL,
   boardid int(11) DEFAULT '0' NOT NULL,
   posted datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   author varchar(127) NOT NULL,
   subject varchar(127) NOT NULL,
   msg text,
   url varchar(255),
   email varchar(127) NOT NULL,
   urlname varchar(127),
   urlimage varchar(127),
   notify enum('Y','N','A') DEFAULT 'N' NOT NULL,
   remotehost varchar(127) NOT NULL,
   threadupdated datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   threadid int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (id),
   KEY prev (prev),
   KEY boardid (boardid),
   KEY posted (posted),
   KEY author (author),
   KEY subject (subject),
   KEY email (email),
   KEY remotehost (remotehost),
   KEY threadupdated (threadupdated),
   KEY prev_2 (prev, boardid, posted),
   KEY prev_3 (prev, boardid),
   KEY threadid (threadid)
);

#
# Dumping data for table 'messages'
#


# --------------------------------------------------------
#
# Table structure for table 'msgtypes'
#

DROP TABLE IF EXISTS msgtypes;
CREATE TABLE msgtypes (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   boardid int(11) DEFAULT '0' NOT NULL,
   name varchar(64) NOT NULL,
   icon varchar(255),
   PRIMARY KEY (id),
   KEY boardid (boardid),
   KEY name (name),
   UNIQUE boardid_2 (boardid, name)
);

#
# Dumping data for table 'msgtypes'
#


# --------------------------------------------------------
#
# Table structure for table 'users'
#

DROP TABLE IF EXISTS users;
CREATE TABLE users (
   id int(11) DEFAULT '0' NOT NULL auto_increment,
   login varchar(32) NOT NULL,
   password varchar(32) NOT NULL,
   name varchar(80) NOT NULL,
   boardid int(11) DEFAULT '0' NOT NULL,
   access set('R','W','M') NOT NULL,
   PRIMARY KEY (id),
   KEY login (login),
   KEY password (password),
   KEY boardid (boardid),
   UNIQUE login_2 (login, boardid)
);

#
# Dumping data for table 'users'
#

