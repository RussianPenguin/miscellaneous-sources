This is a GPL software use it on your own risk.
You'll need PHP3 and MySQL to run this webboard.
In case you managed to install and use it write me please at nmark@glasnet.ru address.
I'd also appriciate if you place a link to my home page http://www.glasnet.ru/~nmark/
somewhere on your site.
To install run (within your web data space root):
tar xzf webboard.tgz
cd webboard
mysqladmin -p create webboard
mysql < webboard.mysql
Then you should edit access.php - change getpwnam function to succeed your needs.
Then access webboard/admin.php through http://www.youserver.com/webboard/admin.php and enter your
login and password (NIS, passwd file or whatever you plan to use in getpwnam function) and create
boards.
To support autoclear feature one should put clearboard.pl script into crontab
