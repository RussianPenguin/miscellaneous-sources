<?
include "common.php";

$id = IntVal($id);

$SQL = "SELECT * FROM messages WHERE id = $id";
$message = mysql_query($SQL);
if (!$message):
  NotAvailable();
  Exit;
endif;
if (mysql_numrows($message) == 0):
  NotAvailable();
  Exit;
endif;
$Message = mysql_fetch_array($message);
mysql_freeresult($message);

$boardid = $Message["boardid"];
$boardid = IntVal($boardid);

$SQL = "SELECT * FROM boards WHERE id = $boardid";
$board = mysql_query($SQL);

if (mysql_numrows($board) == 0):
  NotAvailable();
  Exit;
endif;

$Board = mysql_fetch_array($board);

$RO = CheckRO($boardid);

if ($Board["rdonly"] == "Y"):
  $RO = 1;
endif;

if ($NoAds):
  $Board[pagesize] = 50;
endif;

mysql_freeresult($board);

if ("$Action" != ""):
  if (!$Notification):
    $Notification = "N";
  endif;
  PostMessage ($Must, $MustName, $id, $boardid, $Author, $Subject,
		$Msg, $Url, $Email, $UrlName, $UrlImage, $Notification);
  Reload(".?board=$boardid");
  Exit;
endif;

$prev = $Message["prev"];
$posted = $Message["posted"];
$author = $Message["author"];
$subject = $Message["subject"];
$url =  $Message["url"];
$urlname =  $Message["urlname"];
$urlimage =  $Message["urlimage"];
$msg = $Message["msg"];
$email = $Message["email"];

$LIMIT = $Board["pagesize"];

$root = FindRootMessage($id);
$SQL = "SELECT count(*) FROM messages WHERE boardid = $boardid AND prev = 0 AND id > $root";
$res = mysql_query($SQL);
$row = mysql_fetch_row($res);
$pcount = $row[0];

$Offset = IntVal($pcount / $LIMIT) * $LIMIT;
?>
<html>
<head>
 <title>Print: <?echo $subject;?></title>
 <? StyleSheet (); ?>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div align="left">
  <table border="0" width="100%" cellspacing="0" cellpadding="4">
    <tr class="header">
      <td width="50%" valign="bottom"><a href="#" onClick="window.print()"><font class="header"><?echo $__Click2Print;?></font></a></td>
      <td width="50%" valign="bottom"><a href="#" onClick="window.close()"><font class="header"><?echo $__Click2Close;?></font></a></td>
	</tr>
  </table>
</div>
<h1 align="center"><?echo $subject;?></h1>

<table border="0" width="100%" cellpadding="2">
  <tr>
    <td width="100" align="left">&nbsp;<font class="formfields"><?echo $__PostedBy;?></font></td>
    <td width="90%" align="left"><font class="body"><?echo $author;?></td>
  </tr>
  <tr>
    <td width="100" align="left">&nbsp;<font class="formfields"><?echo $__Date;?></font></td>
    <td width="90%" align="left"><font class="body"><?echo $posted;?></td>
  </tr>
</table>
<p>

<blockquote>
<font class="body">
<?
	if ($Board["notags"] == "Y"):
			$dmsg = HighlightURLs($msg);
	else:
			$dmsg = $msg;
	endif;
	echo nl2br($dmsg);
?>
</font>
</blockquote>
</body>
</html>