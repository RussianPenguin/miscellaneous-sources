<?
include "common.php";
/*
######################################################
 The script is based on Mark Napartovic's wwwboard.
 http://www.glasnet.ru/~nmark/

 Modifications by Oktay Ozturk
 http://www.bestweb.ca
 oktay@torontonian.com
 
 The Index Page modification by
 Zeke Rogers
 zrogers@sunset.net
######################################################
*/

//error_reporting(7);

function PrintPageChanger($Offset, $PagesNum, $Pages, $cache = 0) {
  Global $Board;
  Global $PHP_SELF;
  Global $__Topics;
  Global $__Previous;
  Global $__GotoPage;
  Global $__Next;
  Global $__Go;
  Global $__ThreadTop;
  Global $LIMIT;
  
  PrintIt("<TABLE BORDER=0 WIDTH=\"100%\">", $cache);
  PrintIt("<TR VALIGN=\"Top\"><TD>", $cache);
  if ($Offset > 0):
    $PrevOffset = $Offset - $Board["pagesize"];
    PrintIt("<font class=\"sub-body\">[ <A HREF=\"$PHP_SELF?board=$Board[id]&Offset=$PrevOffset\">", $cache);
    PrintIt("$__Previous $Board[pagesize]</A> ]</font>", $cache);
  endif;
  PrintIt("</TD>", $cache);
  if ($PagesNum > 2):
    PrintIt("<TD ALIGN=\"CENTER\">", $cache);
    PrintIt("<FORM ACTION=\"$PHP_SELF\" METHOD=\"GET\">", $cache);
    PrintIt("<font class=\"subject\">$__GotoPage</font>", $cache);
    PrintIt("<INPUT TYPE=\"HIDDEN\" NAME=\"board\" VALUE=\"$Board[id]\">", $cache);
    PrintIt("<SELECT NAME=\"Offset\">", $cache);
    $Ofs = 0;
    $Page = 1;
    while ($Ofs < $Pages):
      if (($Offset / $LIMIT) == ($Page - 1)):
        PrintIt("<OPTION VALUE=\"$Ofs\" SELECTED>$Page\n", $cache);
      else:
        PrintIt("<OPTION VALUE=\"$Ofs\">$Page\n", $cache);
      endif;
      $Page++;
      $Ofs += $LIMIT;
    endwhile;
    PrintIt("</SELECT>\n", $cache);
    PrintIt("<INPUT TYPE=\"Submit\" VALUE=\"$__Go\">\n", $cache);
    PrintIt("</FORM>\n</TD>\n", $cache);
  endif;
  PrintIt("<TD ALIGN=\"RIGHT\">\n", $cache);
  $NextOffset = $Offset + $Board["pagesize"];
  if ($Pages >= $NextOffset):
    PrintIt(" <font class=\"sub-body\">[ <A HREF=\"$PHP_SELF?board=$Board[id]&Offset=$NextOffset\">", $cache);
    PrintIt("$__Next $Board[pagesize]</A> ]</font>", $cache);
  endif;
  PrintIt("</TD></TR>\n</TABLE>\n<P>\n", $cache);
}

$boardid = IntVal($board);
$SQL = "SELECT *, UNIX_TIMESTAMP(modtime) AS umodtime FROM boards WHERE id = $boardid AND disabled <> 'Y'";
$boards = FirstConnect($SQL);
if (!$boards):
  NotAvailable();
  Exit;
endif;
if (mysql_numrows($boards) == 0):
  NotAvailable();
  Exit;
endif;

$Board = mysql_fetch_array($boards);

$RO = CheckRO($boardid);

if ($Board["rdonly"] == "Y"):
  $RO = 1;
endif;

$Offset = IntVal($Offset);
mysql_freeresult($boards);

$SQL = "SELECT count(*) as msgs FROM messages WHERE boardid = $boardid AND prev = 0";
$res = mysql_query($SQL);
$row = mysql_fetch_row($res);
mysql_free_result($res);

$Pages = $row[0];
$LIMIT = $Board["pagesize"];
$PagesNum = IntVal($Pages / $LIMIT) + 1;

if ("$Action" != ""):
  PostMessage ($Must, $MustName, 0, $boardid, $Author, $Subject,
		$Msg, $Url, $Email, $UrlName, $UrlImage);
  Reload("$PHP_SELF?board=$boardid");
  Exit;
endif;

PrintHead($Board["name"]);

$owner = $Board["owner"];
  
$CACHE_FILE = "$CACHE_TMPL$boardid$CACHE_EXT";

$cache = 0;
$cachedone = 0;
  
if (!$Offset):
/* //Uncomment this for single server mode
  if (@readfile($CACHE_FILE)):
    $cachedone = 1;
  else:
/* Comment this (till 'commentend') for single server mode */
  if (IntVal($Board["umodtime"]) > IntVal(@filemtime($CACHE_FILE))):
    @unlink($CACHE_FILE);
  elseif (@readfile($CACHE_FILE)):
    $cachedone = 1;
  endif;
  if (!$cachedone):
/* commentend */
    $cache = fopen($CACHE_FILE, "w");
    if ($cache):
      if (!flock($cache, 2)):  // wait for file
        fclose($cache);
        unlink($CACHE_FILE);
        $cache = 0;
      endif;
    endif;
  endif;
endif;


if (!$cachedone):
  if ($Board["topnavigator"] == "Y"):
    PrintIt("<DIV ALIGN=\"CENTER\">", $cache);
    PrintIt("<form name=\"forums\">", $cache);
    PrintIt("<p>", $cache);
    PrintIt("<select name=\"all\" size=\"1\">", $cache);
    PrintIt("<option selected value=\"index.php\">$__OtherForums</option>", $cache);
	
    $SQL = "SELECT id, name FROM boards where owner = '$owner' AND id <> $board and disabled <> 'Y'";
    $res = mysql_query($SQL);
	
    while ($row = mysql_fetch_array($res)):
    PrintIt("<option value=\"forum.php?board=$row[id]\">$row[name]</option> ", $cache);
    endwhile;
    
	PrintIt("</select>", $cache);
    PrintIt("<input type=\"button\" value=\"$__Go\"  onClick=\"location=document.forums.all.options[document.forums.all.selectedIndex].value\">", $cache);
    PrintIt("</p>", $cache);
    PrintIt("</form>", $cache);
    PrintIt("</DIV>", $cache);
  endif;
  
  $Author = "GlasnetWBAuthor$boardid";
  $Author = $$Author;
  $Email = "GlasnetWBEmail$boardid";
  $Email = $$Email;
  $Url = "GlasnetWBUrl$boardid";
  $Url = $$Url;
  $UrlName = "GlasnetWBUrlName$boardid";
  $UrlName = $$UrlName;
  $UrlImage = "GlasnetWBUrlImage$boardid";
  $UrlImage = $$UrlImage;
  $NextOffset = $Offset + $Board["pagesize"];  
?>

<table align="center" border="0" cellPadding="0" cellSpacing="0" class="border" width="100%">
   <tr>
      <td>
        <table border="0" cellPadding="4" cellSpacing="1" width="100%">
          <tr class="category">
          <td colSpan="2" bgcolor="#EEEEEE">
		  <font class="body">
<?
  PrintIt("<P ALIGN=\"CENTER\"><font class=\"subject\"><b><A HREF=\"$REQUEST_URI\">$Board[name]</A></b></font></P>\n", $cache);
  PrintIt("<BLOCKQUOTE>$Board[description]</BLOCKQUOTE>\n", $cache);
  PrintIt("<P ALIGN=\"LEFT\">", $cache);
  PrintIt("<A HREF=\"#New\"><img alt=\"$__NewTopic\" src=\"images/post2.gif\" width=\"143\" height=\"22\" border=\"0\"></A>&nbsp;&nbsp;", $cache);
  PrintIt("<A class=\"header\" HREF=\"help.php\" ", $cache);
  PrintIt("TARGET=\"_blank\"><img alt=\"$__Help\" src=\"images/help.gif\" width=\"140\" height=\"22\" border=\"0\"></A></P>", $cache);
  
  /*
  PrintIt("[<A HREF=\"#New\">$__NewTopic</A>]&nbsp;&nbsp;", $cache);
  PrintIt("[<A HREF=\"help.html\" ", $cache);
  PrintIt("TARGET=\"_blank\">$__Help</A>]</P>", $cache);
  */
  
  PrintPageChanger($Offset, $PagesNum, $Pages, $cache);
  if ($cache):
    $Messages = PrintMessagesFile($boardid, 0, $cache);
  else:
    $Messages = PrintMessages($boardid);
  endif;
  PrintPageChanger($Offset, $PagesNum, $Pages, $cache);
  if ($cache):
    flock($cache, 3);
    fclose($cache);
  endif;
  if (!$Offset):
    readfile($CACHE_FILE);
  endif;
endif;
if (!$RO):
?>	


	
</font>
			</td>
            </tr>
            <tr class="header">
              <td noWrap width="98%"><font class="header"><font color="#FF0000" size="1"><sup>*</sup></font><b><? echo$__Asterix ;?></b></font></td>
              <td width="2%" align="right" valign="bottom"><a href="<?echo $credits;?>"><img alt="Credits" border="0" hspace="3" src="images/panda.gif" width="16" height="16"></a></td>
            </tr>
            <tr class="status">
              <td colSpan="2">
                <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                  
                    <tr>
                      <td valign="bottom" colspan="2">



			  <table border="0" cellPadding="0" cellSpacing="0" width="100%">
                  
				   <tr>
                   <td valign="top"><img border="0" hspace="3" src="images/post1.gif" width="23" height="20"><font class="category"><A NAME="New"></A><?echo $__NewTopic;?>:</font></td>
				   <td valign="top">
				   <font class="status">
<?
  PrintReplyForm($Board);
endif;
?>
					</font>
					</td>
                    <td valign="top" align="right">
					</td>
                    </tr>			
						  
                   <tr>
                   <td valign="bottom"><font class="status">&nbsp;</font></td>
				   <td valign="bottom"></td>
                   <td valign="bottom" align="right">&nbsp;</p></td>
                   </tr>
                  
                </table>
              
</td>
                    </tr>
                    <tr>
                      <td valign="bottom"><font class="status"><? echo $__Timezone;?></font></td>
                      <td align="right">&nbsp;
                        <p><font class="status"><? echo $__Cookiewarning ;?></p>
                      </td>
                    </tr>
                  
                </table>
              </td>
            </tr>
        </table>
      </td>
    </tr>
 </table>
&nbsp;				
<?
PrintFoot("&nbsp;");
?>
