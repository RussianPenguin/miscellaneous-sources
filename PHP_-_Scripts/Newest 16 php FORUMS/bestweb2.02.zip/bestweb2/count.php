<? 
include "db.php";
mysql_connect("$DBHOST","$DBUSER","$DBPASS")
	or die("Unable to connect to SQL server!");
@mysql_select_db("$DB")
	or die("Unable to select database!");
if(!$pageid) { $pageid = "default"; }
$query = mysql_query("select * from counter where pageid=\"$pageid\"");
while ($row  =  mysql_fetch_array($query)) {
		$start = $row[start];
		$count = $row[count];
}
if(!$count) {
	mysql_query("insert into counter values (current_date()+0,\"1\",\"$pageid\")");
	$count = "1";
}
print ("$count");
$count++;
mysql_query("update counter set count=\"$count\" where pageid=\"$pageid\"");
?>
