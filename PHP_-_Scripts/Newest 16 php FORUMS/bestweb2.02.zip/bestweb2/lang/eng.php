<?
 $__AccessDenied="Access denied.";
 $__ActiveLinkColor="Active link color";
 $__AddBoard="Add this forum";
 $__AdminPage="Admin page";
 $__Asterix="All fields that are marked with a red star are required.";
 $__Author="Author: ";
 $__Back="Back";
 $__Back2Forum ="Back to";
 $__BgColor="Background color";
 $__BgImageURL="Background image URL";
 $__BoardID="Board ID";
 $__BoardName="Board Name";
 $__CannotPost="Under service!";
 $__CloseFrame="Close Frame";
 $__Cookiewarning="Cookies are in use to store userdata.";
 $__Created="Created";
 $__Date="Date:";
 $__Delete="Delete";
 $__DeleteBoard="Delete board";
 $__DeleteMarked="Delete/Move marked";
 $__DeleteThisBoard="Delete this board?";
 $__Description="Description";
 $__Disable="Disable";
 $__Disabled="Disabled";
 $__DisableTags="Disable HTML tags";
 $__Edit="Edit";
 $__EditYourBoard="Edit your board";
 $__Email="Email: ";
 $__Go="Go";
 $__GotoPage="Goto page: ";
 $__Help="Help";
 $__HomePageTitle="Home page title";
 $__InsertOriginal="Insert original message";
 $__KeepMessagesDays="Keep messages (days)";
 $__LastMessage="Last Message";
 $__Link="Link URL: ";
 $__LinkColor="Link color";
 $__LinkTitle="Your ICQ#: ";
 $__MailNewMessage="Forum";
 $__Main="Main";
 $__Manage="Manage";
 $__ManageMessages="Manage messages";
 $__MarkAsNew="Mark as new if younger than (days)";
 $__MarkNewWith="How to mark new messages";
 $__Message="Message:";
 $__Messages="messages";
 $__MessagesDeleted="All messages have been deleted!";
 $__Move="Move";
 $__MustBeFilled="must be filled!";
 $__Name="Title";
 $__NewTopic="New Message";
 $__NewTopic="New Message";
 $__NewWebboard="New Forum";
 $__Next="Next";
 $__NoBoard="Don't move";
 $__NotAvailable="Not available";
 $__NotifyOwner="Notify owner about new messages";
 $__NotSpecified=" is not specified!";
 $__Optional="Optional Info:";
 $__OtherForums ="Other Forums";
 $__Page="Page: ";
 $__PageFooter="Page footer";
 $__PageHeader="Page header";
 $__Pagenumber="Page number";
 $__PageSize="Page size";
 $__Parent="Parent";
 $__PicURL="Picture URL: ";
 $__Posted="Posted";
 $__PostedBy="Author: ";
 $__PostMessage="Post message";
 $__Posts="Messages";
 $__Previous="Previous";
 $__Replies="Replies:";
 $__Reply="Reply";
 $__Reset="Reset";
 $__ResetMarks="Reset marks";
 $__SelectBoard="Select a forum to edit/manage/delete";
 $__SendRepliesByEmail="Send replies by e-mail:";
 $__SorryNotAvailable="Sorry, forum is not available.";
 $__SorryYouDoNotHavePermissions="Sorry, you do not have permissions to access this page";
 $__StyleSheet="Style sheet";
 $__Subject="Subject: ";
 $__TextColor="Plain text color";
 $__Thread="Replies";
 $__Threads="Threads";
 $__ThreadTop="Thread";
 $__Timezone="All times are EST.";
 $__Topic="Subject: ";
 $__Topics="";
 $__Update="Update";
 $__VisitedLinkColor="Visited link color";
 $__WebBoard="Torontonian.com Forums";
 $__WebboardAdministration="Forum administration";
 $__YourName="Name: ";
 ///ICQ & Mail, Recommend Form Stuff
 $__ICQYourname="Your Name:";
 $__ICQYourmail="Your Email:";
 $__ICQSendButton="Send";
 $__ICQForgotMessage="You forgot to write a message.";
 $__ICQMsgTooLong="The message is too long. Maximum is 450 characters.";
 $__ICQForgotEmail="You forgot to fill in your email address.";
 $__ICQMessageSent="The message has been sent.";
 $__ICQMsgTo="Send an ICQ message to";
 $__EmailText="To send the URL of this page and a brief message to a friend who might like it, just fill out the form below.<br>
      <br><b>NOTE:</b> We only request your name and email address so that the person you are sending the email to know that who you are.<br>";

//Vote Stuff
/*
  $__Vote="Vote";
  $__VotedAlready="You have already voted";
  $__Votes="Votes:";
  $__AverageVote="Average vote:";
 */
 //Print Page Stuff
  $__Click2Print="Click to Print";
  $__Click2Close="Click to Close";
 
 //Recommend a Page Stuff
  $__RecFriendName="Friend's Name:";
  $__RecFriendMail="Friend's Email:";
  $__RecText="To send the URL of this page and a brief message to a friend who might like it, just fill out the form below.<br>
      <br><b>NOTE:</b> We only request your name and email address so that the person you are recommending the page to knows that you wanted them to see it, and that it is not junk mail.<br>";
  $__Rec2aFriend="Recommend this page to a friend!";
//Send Mail Stuff
  $__MailMsgTo="Send a Message to";
?>