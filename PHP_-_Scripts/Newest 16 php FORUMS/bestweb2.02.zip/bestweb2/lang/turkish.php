<?
 $__AccessDenied="Access denied.";
 $__ActiveLinkColor="Active link color";
 $__AddBoard="Add this webboard";
 $__AdminPage="Admin page";
 $__Asterix="K�rm�z� y�ld�z ile i�aretli alanlar mecburidir.";
 $__Author="G�nderen: ";
 $__Back="Geri";
 $__Back2Forum ="Geri";
 $__BgColor="Background color";
 $__BgImageURL="Background image URL";
 $__BoardID="Board ID";
 $__BoardName="Board Name";
 $__CannotPost="Forum Bak�mda!";
 $__CloseFrame="�er�eveyi kapat";
 $__Cookiewarning="Kullan�c� bilgilerini hat�rlamak i�in cookie kullan�lmaktadir.";
 $__Counter_1="Bu sayfa ";
 $__Counter_2=" kez g�r�lm��t�r.";
 $__Created="Created";
 $__Date="Tarih:";
 $__Delete="Delete";
 $__DeleteBoard="Delete board";
 $__DeleteMarked="Delete/Move marked";
 $__DeleteThisBoard="Delete this board?";
 $__Description="Description";
 $__Disable="Disable";
 $__Disabled="Disabled";
 $__DisableTags="Disable HTML tags";
 $__Edit="Edit";
 $__EditYourBoard="Edit your board";
 $__Email="E-Posta: ";
 $__Go="Git";
 $__GotoPage="Ar�iv Sayfas�: ";
 $__Help="Yard�m";
 $__HomePageTitle="Home page title";
 $__InsertOriginal="Orjinal Mesaj� Ekle";
 $__KeepMessagesDays="Keep messages (days)";
 $__Link="Link URL: ";
 $__LinkColor="Link color";
 $__LinkTitle="ICQ No'su: ";
 $__MailNewMessage="Forum";
 $__Main="Ana Sayfa";
 $__Manage="Manage";
 $__ManageMessages="Manage messages";
 $__MarkAsNew="Mark as new if younger than (days)";
 $__MarkNewWith="How to mark new messages";
 $__Message="Mesaj:";
 $__Messages="mesajlar";
 $__MessagesDeleted="All messages have been deleted!";
 $__Move="Move";
 $__MustBeFilled=" b�l�m� bo�";
 $__Name="Title";
 $__NewTopic="Yeni Mesaj";
 $__NewWebboard="New Webboard";
 $__Next="Sonraki";
 $__NoBoard="Don't move";
 $__NotAvailable="Not available";
 $__NotifyOwner="Notify owner about new messages";
 $__NotSpecified=" is not specified!";
 $__Optional="Istege Bagli:";
 $__OtherForums ="Di�er Forumlar";
 $__Page="Sayfa: ";
 $__PageFooter="Page footer";
 $__PageHeader="Page header";
 $__Pagenumber="Page number";
 $__PageSize="Page size";
 $__Parent="Parent";
 $__PicURL="Resim URL: ";
 $__Posted="Posted";
 $__PostedBy="Yazar: ";
 $__PostMessage="Mesaj G�nder";
 $__Posts="&nbsp;";
 $__Previous="Onceki";
 $__Replies="Cevaplar:";
 $__Reply="Cevapla";
 $__Reset="Reset";
 $__ResetMarks="Reset marks";
 $__SelectBoard="Select a webboard to edit/manage/delete";
 $__SendRepliesByEmail="Cevaplar� E-Posta �zerinden ula�t�r:";
 $__SorryNotAvailable="Sorry, webboard is not available.";
 $__SorryYouDoNotHavePermissions="Bu sayfa erisime kapalidir";
 $__StyleSheet="Style sheet";
 $__Subject="Ba�l�k: ";
 $__TextColor="Plain text color";
 $__Thread="Cevaplar";
 $__ThreadTop="Zincirdeki ilk mesaj";
 $__Timezone="Butun saatler TS�.";
 $__Topic="Konu-Ba�lik: ";
 $__Topics="Konu-Ba�lik: ";
 $__Update="Update";
 $__VisitedLinkColor="Visited link color";
 $__WebBoard="Demokratik.Net Forumlar�";
 $__WebboardAdministration="Webboard administration";
 $__YourName="�sim: ";
 ///ICQ & Mail, Recommend Form Stuff
 $__ICQYourname="�sminiz:";
 $__ICQYourmail="E-Posta:";
 $__ICQSendButton="G�nder";
 $__ICQForgotMessage="Mesaj yazmay� unuttunuz.";
 $__ICQMsgTooLong="Mesaj�niz �ok uzun. En fazla 450 karakterle s�n�rl� tutunuz.";
 $__ICQForgotEmail="E-Posta adresini unuttunuz.";
 $__ICQMessageSent="Mesaj�n�z g�nderildi.";
 $__ICQMsgTo="ICQ mesaj� g�nderilen ki�i:";
 $__EmailText="To send the URL of this page and a brief message to a friend who might like it, just fill out the form below.<br>
      <br><b>NOTE:</b> We only request your name and email address so that the person you are sending the email to know that who you are.<br>";

//Vote Stuff

  $__Vote="Oyla";
  $__VotedAlready="Oyunuzu �nceden kullanm��t�n�z";
  $__Votes="Oylar:";
  $__AverageVote="Ortalama Oy:";

 //Print Page Stuff
  $__Click2Print="Yaz�c�ya Aktar";
  $__Click2Close="Kapat";
 
 //Recommend a Page Stuff
  $__RecFriendName="Arkadas��n�z�n �smi:";
  $__RecFriendMail="E-Posta adresi:";
  $__RecText="To send the URL of this page and a brief message to a friend who might like it, just fill out the form below.<br>
      <br><b>NOTE:</b> We only request your name and email address so that the person you are recommending the page to knows that you wanted them to see it, and that it is not junk mail.<br>";
  $__Rec2aFriend="Recommend this page to a friend!";
//Send Mail Stuff
  $__MailMsgTo="Mesaj g�nderdi�iniz ki�i";
?>