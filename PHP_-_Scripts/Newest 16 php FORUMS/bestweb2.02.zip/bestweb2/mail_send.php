<?  
include "common.php";

 mail("$femail","From: $ymail <$ymail>", "went to $sitename and recommended you check this out","$yname  
 stopped by $sitename and thought you would find the following URL of interest: 

 URL: $url 

 Additional Comments: 
 ------------------------------------ 
 $comments 
 ------------------------------------ 

 Thank you! 

 $sitename 
 $adminaddress 
 $siteaddress","FROM:$yemail"); 

	echo "<html><head><title>$__ICQMsgTo $author</title>\n";
	StyleSheet ();
	echo "<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0>\n";
    echo "
	<table BORDER=0 CELLSPACING=0 CELLPADDING=5 width=\"100%\">
	<tr class=\"header\">
	<td with=\"90%\" valign=\"top\"><a href=\"#\"><font class=\"header\">Sent</font></a>
	</td>
	<td width=\"30\" valign=\"top\" align=\"right\"><a href=\"$credits\" target=\"_new\"><img alt=\"Credits\" border=\"0\" hspace=\"3\" src=\"images/panda.gif\" width=\"16\" height=\"16\"></a></td>
	</tr>
	</table>
	<table border=0 cellspacing=0 cellpadding=0 width=\"100%\">
	<tr><td><img src=\"images/1.gif\" height=\"5\"></td></tr></table>
	
	<div align=\"center\">
	<center>
	<table border=0 width=96% cellspacing=0 cellpadding=1 heigth=100%>
	    <tr>
	      <td width=96% bgcolor=#000000>     
	<table border=0 cellspacing=0 cellpadding=5 width=\"100%\">
	<tr class=\"category\">
	<td><font class=\"body\">$PagerMsg<p>
	<center><a href=\"#\" onClick=\"window.close()\"><font class=\"red\">Close</font></a>
	</td>
	    </tr>
	  </table>
	</td>
	    </tr>
	  </table>
	</center>
	</div>
";
	echo "</body></html>\n";
	?>