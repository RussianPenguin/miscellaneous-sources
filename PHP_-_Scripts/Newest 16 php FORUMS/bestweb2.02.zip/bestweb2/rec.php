<? include "common.php"; ?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
   <title>Recommend: <?echo $subject;?></title>
   <? StyleSheet (); ?>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" width="100%" cellspacing="0" cellpadding="6">
 <tr class="header">
  <td noWrap width="100%" valign="bottom"><font class="header"><b></b><? echo $__Rec2aFriend; ?></b></font></td>
  </tr>
  <tr>
  <td width="100%" valign="bottom">
<? $referer = getenv("HTTP_REFERER");  print "<font class=\"red\"><b>$referer</b></font>"; ?>
  </td>
  </tr>
</table>
<div align="center">
<center>
<table border="0" width="96%" cellspacing="0" cellpadding="1">
    <tr>
    <td bgcolor="#000000">
<table border="0" width="100%" cellspacing="0" cellpadding="6">
    <tr class="category">
	<td> 
	<table border="0" width="100%" cellspacing="0" cellpadding="6">
    <tr class="odd">
 		<td class="body" width="100%" valign="bottom">
	<font class="body">   
	<?echo $__RecText;?>
	 </font>
	 </td>
	 </tr>
	 </table> 
      <form method="POST" action="mail_send.php">
         <table border="0" cellspacing="3" cellpadding="3">
            <tr>
               <td valign="top">
                <font class="formfields"><?echo$__ICQYourname;?></font>
               </td>
               <td valign="TOP">
                <input type="text" name="yname">
               </td>
            </tr>
            <tr>
               <td valign="TOP">
				<font class="formfields"><?echo$__ICQYourmail;?></font>
               </td>
               <td valign="top">
                <input type="text" name="yemail">
               </td>
            </tr>
            <tr>
               <td valign="top">
                 <font class="formfields"><?echo$__RecFriendName;?></font>
               </td>
               <td valign="top">
                  <input type="text" name="fname">
               </td>
            </tr>
            <tr>
               <td valign="top">
                  <font class="formfields"><?echo$__RecFriendMail;?></font>
               </td>
               <td valign="TOP">
                  <input type="text" name="femail">
               </td>
            </tr>
            <tr>
               <td valign="TOP" colspan="2">
                  <font class="formfields"><?echo$__Message;?></font>
               </td>
            </tr>
            <tr>
               <td valign="top" colspan="2">
                  <textarea name="comments" rows="3" cols="30">
                  </textarea>
               </td>
            </tr>
            <tr>
               <td valign="top" colspan="2">
                <input type="hidden" name="url" value="<? echo "$referer"; ?>">
				<input type="submit" name="action" value="<?echo $__ICQSendButton;?>">
               </td>
            </tr>
         </table>
      </form>
	  </td>
   </tr>
</table>
 </tr>
</table>
</center>
</div>
</body>
</html>

