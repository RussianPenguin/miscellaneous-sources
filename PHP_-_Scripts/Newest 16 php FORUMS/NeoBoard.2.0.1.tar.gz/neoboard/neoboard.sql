#
# Table structure for table 'master_table'
#


CREATE TABLE master_table (
  tablename varchar(30) binary DEFAULT '' NOT NULL,
  tablefullname varchar(70) binary DEFAULT '' NOT NULL,
  groups varchar(25) DEFAULT '' NOT NULL,
  group_intro varchar(70) DEFAULT '' NOT NULL,
  board_intro varchar(200) DEFAULT '' NOT NULL,
  PRIMARY KEY (tablename)
);

#
# Table structure for table 'user_table'
#
CREATE TABLE user_table (
  userid varchar(8) binary DEFAULT '' NOT NULL,
  username varchar(30) DEFAULT '' NOT NULL,
  userpassword varchar(25) binary DEFAULT '' NOT NULL,
  useremail varchar(70) binary DEFAULT '' NOT NULL,
  groups varchar(25) DEFAULT '' NOT NULL,
  userprofile text NOT NULL,
  PRIMARY KEY (userid)
);

#
# Table structure for table 'demo_board'
#


CREATE TABLE demo_board (
  userid varchar(25) binary DEFAULT '' NOT NULL,
  msg_id mediumint(10) DEFAULT '0' NOT NULL,
  thread_id mediumint(10) DEFAULT '0' NOT NULL,
  thread_depth mediumint(10) DEFAULT '0' NOT NULL,
  thread_info varchar(200) DEFAULT '' NOT NULL,
  msg_subject varchar(200) DEFAULT '' NOT NULL,
  msg_body text NOT NULL,
  msg_hit mediumint(10) DEFAULT '0' NOT NULL,
  msg_date datetime,
  PRIMARY KEY (msg_id),
  KEY userid (userid),
  KEY thread_id (thread_id),
  KEY thread_info (thread_info)
);



#
# Dumping data for table 'master_table'
#

INSERT INTO master_table VALUES ('demo_board','NeoBoard 2.0 Demo','demo_users','Demo Users','NeoBoard 2.0 Demo Board');

#
# Dumping data for table 'user_table'
#

INSERT INTO user_table values('guest', 'GUEST', Encrypt('guest', '.v'), 'nobody@nowhere.com', 'demo_users', 'Just a tester.');
