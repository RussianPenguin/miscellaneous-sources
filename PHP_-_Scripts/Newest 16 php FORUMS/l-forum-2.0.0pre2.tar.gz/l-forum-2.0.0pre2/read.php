<?

include "lib/init.inc";

if($use_cookies){
   if(empty($cookie_read))
      $ca=Array();
   else
      $ca=unserialize($cookie_read);
   $ca[$i]=1;
   setcookie("cookie_read", serialize($ca), time()+99999999);
}

echo ereg_replace("__TITLE__", $lang[read_message], $design[head]);

include "themes/".$theme."/header.inc";

if(!isset($f))
	error_f($lang[nofid]);

if(empty($i)){
   error($lang[no_mess_id]);
}
else{
   $q=new Query("select * from articles where id=$i");
   if($q->nr()!=1)
      error($lang[bad_res]);
   $r=$q->row();
   $newrows = $r[views]+1;
   if($count_view)
      $q=new Query("update articles set views=".$newrows." where id=$i");
?>

<table border=0 width="<?echo $design[readwidth]?>"><tr><td align=left>
<a href="new.php?f=<?echo $f?>&r=<?echo $i?>" class=list><?echo $lang[reply]?></a>

<? echo $design[readhead] ?>

<tr><td bgcolor="<? echo $design[oddcolor] ?>" class=readhead width=25%>
<? echo $lang[from] ?>:</td><td  bgcolor="<? echo $design[oddcolor] ?>">
<? echo $r[author] ?></td></tr>
<tr><td bgcolor="<? echo $design[evencolor] ?>" class=readhead>
<? echo $lang[email] ?>:</td><td bgcolor="<? echo $design[evencolor] ?>">
<? echo $r[email] ?></td></tr>
<tr><td bgcolor="<? echo $design[oddcolor] ?>" class=readhead>
<? echo $lang[date] ?>:</td><td bgcolor="<? echo $design[oddcolor] ?>">
<? echo $r[time] ?></td></tr>
<tr><td bgcolor="<? echo $design[evencolor] ?>" class=readhead>
<? echo $lang[subject] ?>:</td><td bgcolor="<? echo $design[evencolor] ?>">
<? echo $r[subject] ?></td></tr>
<tr><td bgcolor="<? echo $design[oddcolor] ?>" colspan=2>
<table border=0 width="100%"><tr><td bgcolor="<? echo $design[evencolor] ?>">
<? echo nl2br($r[body]) ?></td></tr></table></td></tr>
<tr><td bgcolor="<? echo $design[evencolor] ?>" colspan=2>
<? 

if($thrinmess){
   $type=1;
   $mess_id = $r[root];
   $href=false;
   include "list_thr.inc";
}

?></td></tr>

<? echo $design[readfoot] ?>

</td></tr></table><br>
<div align=center><a class="list" href="list.php?f=<?echo "$f\">$lang[back]"?></a></div>
<?

   include "themes/".$theme."/footer.inc";
   echo $design[footer];
}
?>
