<?

$nosql = 1;

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if(!isset($f)){
?>

<table border=0 width=<?echo $design[list_width]?> cellspacing=0 
cellpadding=<? echo $design[borderwidth]?>><tr>
<td bgcolor=<? echo $design[bordercolor] ?>>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td class=head>&nbsp;<?echo $lang[forum_name]?></td>
<td class=head><?echo $lang[desc]?></td></tr>
<?

$count = 0;
if(!empty($forum_array)){
   while(list($x, ) = each($forum_array)){
      $bgcolor=($count%2==0||$count==0?$design[oddcolor]:$design[evencolor]);
      echo "<tr><td bgcolor=\"$bgcolor\"><a href=\"$PHP_SELF?f=$x\">".
	 $forum_array[$x][name]."</a></td>";
      echo "<td bgcolor=\"$bgcolor\">".$forum_array[$x][desc]."</td></tr>";
      $count++;
   }
}

?>
</table>
</td></tr></table>

<?
} else if($HTTP_POST_VARS['m']!=1){
	$forum = $forum_array[$f];
?>

<form method=post action="<?echo $PHP_SELF?>">
<input type=hidden name=m value=1>
<input type=hidden name=f value=<?echo $f?>>
<table border=0 width=80% cellspacing=0 cellpadding=2 bgcolor=black><tr><td>

<table border=0 width=100% cellspacing=1>
<tr><td colspan=2 bgcolor="<?echo $design[headercolor]?>" align=center>
<div style="font-size : 14pt">Modify forum data</div>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Forum name
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name="forum_name" value="<?echo $forum[name]?>">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Forum description
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<textarea rows="4" cols="60" name="desc"><?echo $forum[desc]?></textarea>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Allow uploads
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name="uploads">
<option value="1">Yes
<option value="0"<? echo ($forum[uploads]?'':' SELECTED')?>>No
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Moderation
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name="moderation">
<option value="1">Yes
<option value="0"<? echo ($forum[moderation]?'':' SELECTED')?>>No
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Moderator's password
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input type=text name="mod_pass" value="<?echo $forum[mod_pass]?>">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Theme for this forum
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=forum_theme>
<?
while(list($k, $v) = each($themes)){
	echo "<option value=\"$k\"";
	if($forum[theme]==$k) echo ' SELECTED';
	echo ">$v\n";
}	
?>
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Threads per page
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input type=text name="tpp" value="<?echo $forum[tpp]?>">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Messages per page
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input type=text name="mpp" value="<?echo $forum[mpp]?>">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center colspan=2>
<input type=submit value="Save">
</td></tr>
</table>
</td></tr></table>
</form>
<?
}
else{
   include "save_m.inc";
}
include "themes/".$theme."/footer.inc";
echo $design[footer];
?>
