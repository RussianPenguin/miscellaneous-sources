<?

$nosql = 1;

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if($HTTP_POST_VARS['f']!=1){
?>

<form method=post action="<?echo $PHP_SELF?>">
<input type=hidden name=f value=1>
<table border=0 width=80% cellspacing=0 cellpadding=2 bgcolor=black><tr><td>

<table border=0 width=100% cellspacing=1>
<tr><td colspan=2 bgcolor="<?echo $design[headercolor]?>" align=center>
<div style="font-size : 14pt">Add forum</div>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Forum name
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name="forum_name">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Forum description
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<textarea rows="4" cols="60" name="desc"></textarea>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Allow uploads
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name="uploads">
<option value="1">Yes
<option value="0">No
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Moderation
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name="moderation">
<option value="0">No
<option value="1">Yes
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Moderator's password
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input type=text name="mod_pass">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Theme for this forum
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=forum_theme>
<?while(list($k, $v) = each($themes)) echo "<option value=\"$k\">$v\n";?>
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Threads per page
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input type=text name="tpp" value=10>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Messages per page
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input type=text name="mpp" value=30>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center colspan=2>
<input type=submit value="Save">
</td></tr>
</table>
</td></tr></table>
</form>
<?
}
else{
   include "save_n.inc";
}
include "themes/".$theme."/footer.inc";
echo $design[footer];
?>
