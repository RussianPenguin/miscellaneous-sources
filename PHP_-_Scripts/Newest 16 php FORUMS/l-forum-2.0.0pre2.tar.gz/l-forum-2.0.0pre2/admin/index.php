<?

$nosql = 1;

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
?>

<table border=0 width=80% cellspacing=0 cellpadding=2 bgcolor=black><tr><td>

<table border=0 width=100% cellspacing=1>
<tr><td bgcolor="<?echo $design[headercolor]?>" align=center>
<div style="font-size : 14pt">Administration Tools</div>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
<a href="add.php">Add Forum</a></td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<a href="modify.php">Modify Forum configuration</a></td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
<a href="rem_forum.php">Remove Forum</a></td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<a href="conf.php">L-Forum Administration</a></td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
<a href="remove.php">Message removal</a></td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<a href="blacklist.php">IP blacklist management</a>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
<a href="add_th.php">Add theme</a></td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<a href="add_ln.php">Add language</a>
</td></tr></table>

</td></tr></table>
<?
include "themes/".$theme."/footer.inc";

echo $design[footer];

?>
