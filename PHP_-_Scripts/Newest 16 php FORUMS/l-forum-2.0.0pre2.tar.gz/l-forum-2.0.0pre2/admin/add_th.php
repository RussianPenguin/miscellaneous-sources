<?

$nosql = 1;

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if($HTTP_POST_VARS['f']!=1){
?>

<form method=post action="<?echo $PHP_SELF?>">
<input type=hidden name=f value=1>
<table border=0 width=80% cellspacing=0 cellpadding=2 bgcolor=black><tr><td>

<table border=0 width=100% cellspacing=1>
<tr><td colspan=2 bgcolor="<?echo $design[headercolor]?>" align=center>
<div style="font-size : 14pt">Add theme</div>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Theme name
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name="th_name">
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Theme directory (subdir to themes/)
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input name="th_dir">
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center colspan=2>
<input type=submit value="Add">
</td></tr>
</table>
</td></tr></table>
</form>
<?
}
else{
   include "save_t.inc";
}
include "themes/".$theme."/footer.inc";
echo $design[footer];
?>
