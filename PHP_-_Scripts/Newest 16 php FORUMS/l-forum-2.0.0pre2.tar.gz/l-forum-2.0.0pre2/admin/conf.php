<?

$nosql = 1;

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if($HTTP_POST_VARS['f']!=1){
?>

<form method=post action="<?echo $PHP_SELF?>">
<input type=hidden name=f value=1>
<table border=0 width=80% cellspacing=0 cellpadding=2 bgcolor=black><tr><td>

<table border=0 width=100% cellspacing=1>
<tr><td colspan=2 bgcolor="<?echo $design[headercolor]?>" align=center>
<div style="font-size : 14pt">L-Forum configuration</div>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Administrator's username
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name=nadmin_name value=<?echo $admin_name?>>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Administrator's password
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input name=nadmin_pass value=<?echo $admin_pass?>>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Administrator's reserved name
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name=nadmin_res value=<?echo $admin_res?>>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Database type
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=ndb_type>
<option value=postgres>PostgreSQL
<option value=mysql<?echo ($db_type=='mysql'?' SELECTED':'')?>>MySQL
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Database hostname
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name=ndb_host value=<?echo $db_host?>>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Database name
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input name=ndb_name value=<?echo $db_name?>>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Database username
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<input name=ndb_user value=<?echo $db_user?>>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Database password
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input name=ndb_pass value=<?echo $db_pass?>>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Default language
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=nlang_d>
<?while(list($k, $v) = each($langlist)){
   echo "<option value=\"$k\"";
   if($k == $lang_d)
      echo " SELECTED";
   echo ">$v\n";
}?>
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Current theme
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=ntheme>
<?while(list($k, $v) = each($themes)) echo "<option value=\"$k\">$v\n";?>
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Enable HTML in messages
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=nenable_html>
<option value=1>TRUE
<option value=0<?echo ($enable_html?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Display long week and month names (not used for now)
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=nlong_names>
<option value=1>TRUE
<option value=0<?echo ($long_names?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Cite messages when replying
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=ncite>
<option value=1>TRUE
<option value=0<?echo ($cite?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Use cookies
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=nuse_cookies>
<option value=1>TRUE
<option value=0<?echo ($use_cookies?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Require valid e-mail address
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=nreq_email>
<option value=1>TRUE
<option value=0<?echo ($req_email?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Maximal line length in messages
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<input name=nwrapsize value="<?echo $wrapsize?>">
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Use denying of posting for certain IP addresses
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=nblock_ip>
<option value=1>TRUE
<option value=0<?echo ($block_ip?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Count number of views for each message
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=ncount_view>
<option value=1>TRUE
<option value=0<?echo ($count_view?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center>
Initially all threads are collapsed
</td><td bgcolor="<?echo $design[oddcolor]?>" align=center>
<select name=ncoll_thr>
<option value=1>TRUE
<option value=0<?echo ($coll_thr?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[evencolor]?>" align=center>
Show thread's tree in message
</td><td bgcolor="<?echo $design[evencolor]?>" align=center>
<select name=nthrinmess>
<option value=1>TRUE
<option value=0<?echo ($thrinmess?'':' SELECTED')?>>FALSE
</select>
</td></tr>
<tr><td bgcolor="<?echo $design[oddcolor]?>" align=center colspan=2>
<input type=submit value="Save">
</td></tr>
</table>
</td></tr></table>
</form>
<?
}
else{
   include "save.inc";
}
include "themes/".$theme."/footer.inc";
echo $design[footer];
?>
