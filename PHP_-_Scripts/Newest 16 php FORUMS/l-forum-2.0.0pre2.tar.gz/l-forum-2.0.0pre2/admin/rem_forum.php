<?

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if(!isset($f)){
?>

<table border=0 width=<?echo $design[list_width]?> cellspacing=0 
cellpadding=<? echo $design[borderwidth]?>><tr>
<td bgcolor=<? echo $design[bordercolor] ?>>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td class=head>&nbsp;<?echo $lang[forum_name]?></td>
<td class=head><?echo $lang[desc]?></td></tr>
<?

$count = 0;
if(!empty($forum_array)){
   while(list($x, ) = each($forum_array)){
      $bgcolor=($count%2==0||$count==0?$design[oddcolor]:$design[evencolor]);
      echo "<tr><td bgcolor=\"$bgcolor\"><a href=\"$PHP_SELF?f=$x\">".
	 $forum_array[$x][name]."</a></td>";
      echo "<td bgcolor=\"$bgcolor\">".$forum_array[$x][desc]."</td></tr>";
      $count++;
   }
}

?>
</table>
</td></tr></table>

<?
}else{
	$q=new Query("delete from articles where forum = $f");
	include "save_r.inc";
}
include "themes/".$theme."/footer.inc";
echo $design[footer];
?>
