<?

include "lib/init.inc";

auth();

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
if(!isset($f)){
?>

<table border=0 width=<?echo $design[list_width]?> cellspacing=0 
cellpadding=<? echo $design[borderwidth]?>><tr>
<td bgcolor=<? echo $design[bordercolor] ?>>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td class=head>&nbsp;<?echo $lang[forum_name]?></td>
<td class=head><?echo $lang[desc]?></td></tr>
<?

$count = 0;
if(!empty($forum_array)){
   while(list($x, ) = each($forum_array)){
      $bgcolor=($count%2==0||$count==0?$design[oddcolor]:$design[evencolor]);
      echo "<tr><td bgcolor=\"$bgcolor\"><a href=\"$PHP_SELF?f=$x\">".
	 $forum_array[$x][name]."</a></td>";
      echo "<td bgcolor=\"$bgcolor\">".$forum_array[$x][desc]."</td></tr>";
      $count++;
   }
}

?>
</table>
</td></tr></table>

<?
}else if(empty($i)){
?>
<table border=0 width=80%><tr><td>
<div align=center style="font-size : 14pt">Remove messages</div>
Select thread or sub-thread for removal
<?$type=1;$href=0;include "../list_thr.inc"?>
</td></tr></table>

<?
}
else{
   
   $q=new Query("select id, time, author, subject, email, parent, is_parent, subs, level from articles order by time");

   for($x=0; $x<$q->nr(); $x++){
      $row=$q->row();
      $array[$row[id]]=$row;
   }
   
   function make_list_recursive($mess_id){
      global $array, $out_array, $level;

      $level[$array[$mess_id][level]]++;

      $out_array[]=$mess_id;

      $subs = unserialize($array[$mess_id][subs]);

      for($i=0; $i<count($subs); $i++){
	 make_list_recursive($subs[$i]);
      }
   }

   $out_array = Array();

   make_list_recursive($i);
   
   for($x=0; $x < count($out_array); $x++)
      $q=new Query("delete from articles where id = $out_array[$x]");

   $parent_id = $array[$i][parent];
   $subs = unserialize($array[$parent_id][subs]);
   $subs_new = Array();
   for($x=0; $x < count($subs); $x++)
      if($subs[$x]!=$i)
	 $subs_new[] = $subs[$x];
   if(count($subs_new)==0)
      $query = ", is_parent = FALSE ";
   $subs_new = serialize($subs_new);
   $q=new Query("update articles set subs = '$subs_new' $query where id = $parent_id");
?>
<table border=0 width="80%"><tr><td>
<div align=center style="font-size : 14pt">
Removed articles
</div><br>
<table border=0 width=<?echo $design[list_width]?> cellspacing=0 cellpadding=<? echo $design[borderwidth]?>><tr>
<td bgcolor=<? echo $design[bordercolor] ?>>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td class=head>ID</td>
<td class=head><?echo $lang[subject]?></td>
<td class=head><?echo $lang[from]?></td>
<td class=head><?echo $lang[date]?></td></tr>
<?
   for($x=0; $x<count($out_array); $x++){
      $bgcolor=( ($x+1)%2==0 ? $design[evencolor] : $design[oddcolor] );
      $id = $out_array[$x];
      echo "<td bgcolor=\"$bgcolor\">$id</td><td bgcolor=\"$bgcolor\">".
	 $array[$id][subject]."</td><td bgcolor=\"$bgcolor\" width=\"20%\">".
	 $array[$id][author]."</td><td class=date bgcolor=\"$bgcolor\" width=200>".
	 $array[$id][time]."</td></tr>\n";
   }
   echo "</table></td></tr></table></td></tr></table>\n";
}
include "themes/".$theme."/footer.inc";

echo $design[footer];

?>
