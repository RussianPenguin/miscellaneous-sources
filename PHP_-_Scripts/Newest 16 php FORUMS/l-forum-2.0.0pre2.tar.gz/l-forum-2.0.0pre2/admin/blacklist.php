<?
/* Commands:
   1 - remove ip from blacklist
   2 - add ip to blacklist
*/
include "lib/init.inc";

auth();

if(empty($ip)||empty($cmd)){

$head = ereg_replace("__TITLE__", $lang[administration], $design[head]);

echo $head;

include "themes/".$theme."/header.inc";
?>

<table border=0 width=80%><tr><td>
<form method="POST" action="<?echo $PHP_SELF?>">
<div align=center style="font-size : 14pt">IP blacklist management<br><br>
<?
$q=new Query("select * from block_ip");
for($x=0; $x<$q->nr(); $x++){
   $row[$x] = $q->get($x, 'ip');
   echo "<li>".$row[$x];
}
br();br();
$q->movefirst();
?>
<div align=center style="font-size : 12pt">
Remove IP
</div>
<select name=ip>
<?
for($x=0; $x<count($row); $x++)
   echo "<option value=\"".$row[$x]."\">".$row[$x]."\n";

?>
</select><input type=hidden name=cmd value=1>
<input type=submit value="Remove">
</form><br><br>
<form method="POST" action="<?echo $PHP_SELF?>">
<div align=center style="font-size : 12pt">
Add IP
</div>
<input type=hidden name=cmd value=2>
<input type=text name=ip size=16>&nbsp;
<input type=submit value="Add">
</form>
</td></tr></table>

<?
include "themes/".$theme."/footer.inc";
echo $design[footer];
}

else{
   if(ereg("[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}", $ip)){
      switch($cmd){
	 case 1:
	    $q=new Query("delete from block_ip where ip = '$ip'");
	    break;
	 case 2:
	    $q=new Query("insert into block_ip values('$ip')");
	    break;
      }
      header("Location: $PHP_SELF");
   }
   else
      error_f($lang[notip]);
}

?>
