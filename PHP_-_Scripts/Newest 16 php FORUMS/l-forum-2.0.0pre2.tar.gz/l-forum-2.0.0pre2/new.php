<?

include "lib/init.inc";

if(!isset($f)){
	$head = ereg_replace("__TITLE__", $lang[new_message], $design[head]);
	echo $head;
	include "themes/".$theme."/header.inc";
	error_f($lang[nofid]);
}

if(!empty($r)){
   $q=new Query("select * from articles where id = $r");
   $prow=$q->row();
   $subj=(ereg("^Re: ", $prow[subject]) ? $prow[subject] : "Re: ".$prow[subject] );
}

if(empty($GLOBALS["HTTP_VIA"])){
   $ip = $GLOBALS["REMOTE_ADDR"];
   if(!$ip)
      $ip = $GLOBALS["REMOTE_HOST"];
}
else{
   $z = split(",", $GLOBALS["HTTP_X_FORWARDED_FOR"]);
   $ip = $z[0];
}

if($block_ip){
   $q=new Query("select * from block_ip where ip = '$ip'");
   if($q->nr()>0)
      error_f($lang[ban]);
}


if(empty($p)){
   $head = ereg_replace("__TITLE__", $lang[new_message], $design[head]);
   echo $head;
   include "themes/".$theme."/header.inc";
?>

<form method=post action="<? echo $PHP_SELF ?>">
<input type=hidden name=f value=<?echo $f?>>
<? echo $design[posthead] ?>

<tr><td bgcolor="<? echo $design[oddcolor] ?>">
<? echo $lang[from] ?>:</td><td  bgcolor="<? echo $design[oddcolor] ?>">
<input type=text size=20 name="from" value="<?echo $f_from?>"></td></tr>
<tr><td  bgcolor="<? echo $design[evencolor] ?>">
<? echo $lang[email] ?>:</td><td bgcolor="<? echo $design[evencolor] ?>">
<input type=text size=20 name="email" value="<?echo $f_mail?>"></td></tr>
<tr><td bgcolor="<? echo $design[oddcolor] ?>">
<? echo $lang[subject] ?>:</td><td bgcolor="<? echo $design[oddcolor] ?>">
<input type=text size=20 name="subject" value="<? echo $subj ?>"></td></tr>
<tr><td bgcolor="<? echo $design[evencolor] ?>" colspan=2 align=center>
<textarea name=body cols=60 rows=20>
<? if(!empty($r)&&$cite) echo ereg_replace("^", "> ", ereg_replace("\n", "\n> ", $prow[body]))."\n" ?>
</textarea></td></tr>
<tr><td bgcolor="<? echo $design[oddcolor] ?>" colspan=2 align=center>
<input type=submit value="<? echo $lang[send] ?>"></td></tr>
<input type=hidden name=p value=1>
<? 
echo $design[postfoot];
if(!empty($r))
   echo "<input type=hidden name=r value=$r>";
?>

</form>

<?

   echo $design[footer];
}
else{

// Errors
   if($req_email&&empty($email)){
      $err[]=$lang[no_email];
   }
   else if(!empty($email)&&!validate_email($email)){
      $err[]=$lang[not_proper_email];
   }
   if(empty($from))
      $err[]=$lang[no_from];

   if(eregi("^".$admin_res."$", $from))
      auth(true);
   
   if($use_cookies){
      setcookie("f_from", $from, time()+999999999);
      setcookie("f_mail", $email, time()+999999999);
   }
   
   if(empty($subject))
      $err[]=$lang[no_subject];
   if(!empty($err))
      error_f($err);
   
   if(!$enable_html)
      $body=htmlspecialchars($body);

   $body = wrap($body, $wrapsize);

   if(!get_magic_quotes_gpc()){
      $subject = addslashes($subject);
      $from = addslashes($from);
      $body = addslashes($body);
      $email = addslashes($email); // This is just for sequrity
   }
   
   $level=0;
   switch($db_type){
      case 'postgres':
	 $q = new Query("select * from articles_id_seq");
	 $row = $q->row();
	 if($row[is_called]=='f')
	    $lastval = 1;
	 else
	    $lastval = $row[last_value]+1;
	 break;
      case 'mysql':
	 $q=new Query("select id from articles order by id desc limit 1");
	 if($q->nr()>0)
	    $lastval = ($q->get(0, 'id'))+1;
	 else
	    $lastval = 1;
	 break;
   }
   $root = $lastval;
   
   if(!empty($r)){
      
      $level = $prow[level]+1;
      $subs = unserialize($prow[subs]);
      $subs[] = $lastval;
      $subs = serialize($subs);

      $root = $prow[root];

      $q = new Query("update articles set subs = '$subs', is_parent = '1' where id = $r");
   }
   
   $subs = serialize(Array());
   switch($db_type){
      case 'postgres':
	 $inc = "NEXTVAL('articles_id_seq')";
	 $now = "'now'";
	 break;
      case 'mysql':
	 $inc = "0";
	 $now = "NOW()";
         break;
   }
   $q=new Query("insert into articles (id, time, author, email, subject, body, is_parent, subs, parent, level, root, ip, views, forum) values($inc, $now, '$from', '$email', '$subject', '$body', '$false', '$subs', '$r', $level, '$root', '$ip', 0, $f)");

   header("Location: ./list.php?f=$f");

}
?>
