<?

  include "lib/init.inc";

  $head = ereg_replace("__TITLE__", $lang[title], $design[head]);

  echo $head;

  include "themes/".$theme."/header.inc";
  
  if(!isset($f))
  	error_f($lang[nofid]);
  
?>

<table border=0 width="<? echo $design[list_width] ?>"><tr><td>
<table border=0 width=100%><tr><td align=left><br>
<a href="new.php?f=<?echo $f?>" class=list><? echo $lang[post] ?></a>
<? 
if($t!='l')
  echo "&nbsp;&nbsp;<a href=\"$PHP_SELF?f=$f&lng=$lng&t=$t&cmd=1\">".
  $lang[openall]."</a>";
?>
</td><td align=right>
<?
if($t=='l'){
   echo "<br><a class=\"list\" style=\"font-size : 8pt\" href=\"./list.php?f=$f&nt=t\">".
      $lang[sort_thr]."</a>";
   echo "</td></tr></table>";
   include "list_msgs.inc";
}
else{
   echo "<br><a class=\"list\" style=\"font-size : 8pt\" href=\"./list.php?f=$f&nt=l\">".
      $lang[sort_dat]."</a>";
   echo "</td></tr></table>";
   include "list_thr.inc";
}

include "langs.inc";

echo "</td></tr></table>";
  
include "themes/".$theme."/footer.inc";
  
echo $design[footer];

?>
