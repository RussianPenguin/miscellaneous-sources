electrifiedForum v.90 (Beta)
README File
###############################


This is still a beta release of electrifiedForum, and havent had time to write really good documentation, but here is a quick rundown of how to install and setup.

NOTE: This does not cover upgrading from version .80 data. Please see the web site for more information as it is posted!

Step 1: Copy files to web server.

Using the same directories as in the zip file, copy all files from this zip file to somewhere on your server, a subdirectory like 'forum' will be sufficient.

Step 2: Configure default realm.

Open up the default realm file, realm.default.php in a text editor, and modify the settings to match your site. For now, we need to change only the following settings:

$config['title'] 		= 	'Change to the name of your forums'; 
$config['dbhost'] 		= 	'change to the name of your database (mysql) server';							
$config['dbuser'] 		= 	'change to the username of a user with read/write access to the database';
$config['dbpass'] 		= 	'change to the password for that database user';							
$config['dbname'] 		= 	'change to the name of the mysql database where the forum tables will be';

There are other options in there for graphics, colors, etc, but for now we will leave them at default. Feel free to change them, some are not yet used. 


Step 3: Import MySQL tables.

in the db subdirectory, there is 1 file, forums.sql, that needs imported into the database.

Usually, the command for unix is mysqlimport --password=yourpass databasename forums.sql

for more information, check http://www.mysql.com or with your system/db administrator

Step 4: Test!

To test the forums, go to the forum directory in your web browser. If you see no errors, and 1 forum 'chat', then everything is good to go.

There is a sample message in the messages table, and 1 user account has been pre-created: admin, with a password of penguin56
I highly recommend changing the password ASAP.


Optionals:

Adding forums:

That can now be done through a web interface. Login with an admistrator level account, click on the 'Manage Forums' link under administrative tools, and create/edit forums as necessary.

Adding custom HTML:

To add custom HTML to the top/bottom of the forums, and/or change the colors used with electrifiedForum, open the default realm file, realm.default.php (or a custom realm file), and there are three sets of things that can be changed:


Variables:
-----------
$config['reply_butn']	=	'art/grayreply.gif'    You can change this to a different reply button if you would like
$config['post_butn']	=	'art/graypost.gif';		  You can change this to a different new topic button if you would like
$config['avatar_dir']	=	'art/avatars/';	   You can change what directory to get avatars from (MUST be on same server- NO Urls)
$config['msgicons_dir']	=	'art/msgicons/';	You can change the directory for icons to choose from on messages
$config['msgicon']		=	'icon1.gif';			You can change the default message icon (must be in msgicons_dir)
$config['forumicon']	=	'art/msgicons/icon37.gif';		You can change the icon displayed on the main index page for each forum

$config['color_top']	=	'#3300ff';
$config['color_top_font']	=	'#ffffff';
$config['color_a']		=	'#e5e5e5';			Color of table rows
$config['color_b']		=	'#d7d7d7';			Alternate table row colors
$config['tcolor']		=	'#808080';			Background (border) color for tables

function htmlstart()
-----------

You can modify the stylesheet within this function to match colors, fonts, etc, but DO NOT add or remove HTML code here

function mainblock()
-----------

You can place custom header html within the ?> and the <?

function mainend()
-----------

You can place custom footer html within the ?> and the <?



###############

Common Issues:

If you get errors such as 'call to undefined function mysql_connect', then MySQL support is not enabled or compiled into PHP.

If you get a unable to save session file error on a windows server, its usually because php.ini has not been configured properly.


###############

If you need assistance, feel free to contact me via email at lordvolt@electrifiedpenguin.com or through our forums at http://www.electrifiedpenguin.com/forums/





Thanks!
-LV

Wednesday, March 14, 2001							

