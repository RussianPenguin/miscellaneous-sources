<?

function db_connect(){

	global $config;
	
	mysql_connect($config[dbhost],$config[dbuser],$config[dbpass]);

	return;
}

function db_disconnect(){

	global $config;
	
	@mysql_close();

	return;
}

function db_select($conditions){

	global $config;
	
	$result = mysql_db_query($config[dbname],$conditions);
	
	return $result;

}

function db_getarray($result){

	global $config;

	// mysql_connect($config[dbhost],$config[dbuser],$config[dbpass]);
	
	//$result = mysql_db_query($config[dbname],$conditions);
	
	$bob = @mysql_fetch_array($result);
	
	//db_disconnect();
	
	return $bob;
		
}

function db_getvar($table,$condition,$column){

	global $config;

	db_connect();
	
	$result = mysql_db_query($config[dbname],"SELECT $column FROM $table WHERE $condition LIMIT 0,1");
	
	while ($row = mysql_fetch_array($result)){
		
		$tvar = $row[$column];
		
	}
	
	db_disconnect();
	
	return $tvar;	
	
}

function db_getrow($table,$condition){

	global $config;
	
	db_connect();
	
	$result = mysql_db_query($config[dbname],"SELECT * FROM $table WHERE $condition LIMIT 0,1");
	
	db_disconnect();
	
	while ($row = mysql_fetch_array($result)){
		
		return $row;
	
	}
	
}

function db_insert($table,$columns,$values){
	
	global $config,$lastid;
	
	db_connect();
	
	if (mysql_db_query($config[dbname],"INSERT INTO $table ($columns) values($values)")){
	
		$lastid = mysql_insert_id();
		
		db_disconnect();
	
		return true;
	} else {
		db_disconnect();
		return false;
	}

}



function db_update($table,$condition,$columns,$values){

	global $config;
	
	$set = "";
	
	for ($i = 0;$i < sizeof($columns);$i++){
	
		$set .= "$columns[$i]='$values[$i]'";
		
		if (!(($i+1)==sizeof($columns))){ $set .= ","; }
					
	}
	
	db_connect();
	
	$result = mysql_db_query($config[dbname],"UPDATE $table SET $set WHERE $condition");
	
	db_disconnect();
	
	return true;

}

function db_numrows($table,$condition){

	global $config;
	
	$result = @mysql_db_query($config[dbname],"SELECT * FROM $table WHERE $condition");
	
	$rows = @mysql_num_rows($result);
	
	return $rows;

}

function db_numrows_all($table){

	global $config;
	
	$result = @mysql_db_query($config[dbname],"SELECT * FROM $table");
	
	$rows = @mysql_num_rows($result);
	
	return $rows;

}

function db_remove($table,$condition){

	global $config;
	
	db_connect();
	
	$result = mysql_db_query($config[dbname],"DELETE FROM $table WHERE $condition");
	
	db_disconnect();
	
	return true;
}
?>