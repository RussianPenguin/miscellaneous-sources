<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the default realm file.

ONLY MAKE CHANGES TO THIS FILE

To add a new realm, just copy this file and change as necessary
***************************************/
$config['title'] 		= 	'electrifiedForum'; 	// Title of the realm
$config['dbhost'] 		= 	'change to mysql host';	// Database Host
$config['dbuser'] 		= 	'change to dbuser';		// Database User (with at least read/write access to db)
$config['dbpass'] 		= 	'change to pass';		// Database Password
$config['dbname'] 		= 	'change to db name';	// Database Name


$config['use_buttons'] 	=	TRUE;						// Use Buttons like Post New Topic, etc
$config['reply_butn']	=	'art/grayreply.gif';		// Filename of 'post reply' button
$config['post_butn']	=	'art/graypost.gif';			// Filename of 'new topic' button
$config['avatar_dir']	=	'art/avatars/';				// Directory containing avatars
$config['msgicons_dir']	=	'art/msgicons/';			// Directory containing icons for messages
$config['msgicon']		=	'icon1.gif';					// Default Icon for messages
$config['forumicon']	=	'art/msgicons/icon37.gif';		// Default Forum Icon

$config['color_top']	=	'#3300ff';					// color of table header rows
$config['color_top_font']	=	'#ffffff';				// color of text in header rows
$config['color_a']		=	'#e5e5e5';					// Row alt color a
$config['color_b']		=	'#d7d7d7';					// Row alt color b
$config['tcolor']		=	'#808080';					// Color of background table (table borders)


function htmlstart($subtitle){
	global $config,$HTTP_SERVER_VARS;
	?>
	
	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
		
		<html>
		<head>
		<title><? print $config['title']." : ".$subtitle; ?></title>
	<style>
		<? if (eregi("MSIE",$HTTP_SERVER_VARS["HTTP_USER_AGENT"])){
			?>
			BODY,TD,.content {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.menu {
				font-size: 11px;
			}
			.rightbox {
				font-size: 11px;
			}
			.large {
				font-size: 36px;
				font-weight: bold;
			}
			.menu A {
				text-decoration: none;
				color: #0000ff;
			}
			.menu A:HOVER {
				text-decoration: none;
				color: white;
				background-color: purple;
			}
			.newsHead {
				color: white;
				font-weight: bold;
				padding-left: 3px;
			}
			.newsContent {
				padding-left: 3px;
			}
			.menu A.heading {
				text-decoration: none;
				color: black;
			}
			.menu A.heading:HOVER {
				text-decoration: underline;
				color: black;
				background-color: white;
			}
			.error {
				color: red;
			}
			.messages {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.tabletop, .tabletop A {
				color: white;
				font-size: 11px;
				text-decoration: none;
			}
			.ftitle {
				color: white;
				font-size: 12px;
				font-weight: bold;
			}
			.messagebody {
				padding : 4px;
			}
			.messagetitle {
				font-size: 11px;
				padding : 2px;
			}
			.forumtitle {
				font-size: 16px;
				font-weight: bold;
			}
			<?

		} else {
			?>
			BODY,TD,.content {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.menu {
				font-size: 11px;
			}
			.rightbox {
				font-size: 11px;
			}
			.large {
				font-size: 36px;
				font-weight: bold;
			}
			.menu A {
				text-decoration: none;
				color: purple;
			}
			.menu A:HOVER {
				text-decoration: none;
				color: white;
				background-color: purple;
			}
			.newsHead {
				color: white;
				font-weight: bold;
				padding-left: 3px;
			}
			.newsContent {
				padding-left: 3px;
			}
			.menu A.heading {
				text-decoration: none;
				color: black;
			}
			.menu A.heading:HOVER {
				text-decoration: underline;
				color: black;
				background-color: white;
			}
			.error {
				color: red;
			}
			.messages {
				font-family : Verdana, Geneva, Arial, Helvetica, sans-serif;
				font-size : 12px;
			}
			.tabletop {
				color: white;
				font-size: 11px;
			}
			.ftitle {
				color: white;
				font-size: 12px;
				font-weight: bold;
			}
			.messagebody {
				padding : 4px;
			}
			.messagetitle {
				font-size: 11px;
				padding : 2px;
			}
			.forumtitle {
				font-size: 14px;
				font-weight: bold;
			}
			<?
		}
		?>		
		</style>
	</head>
	
	<body bgcolor="#FFFFFF" text="#000000" link="#0000FF" vlink="#0000FF" alink="#0000FF">
	
	

	<?

}

function mainblock(){

	?>

	<?
}

function mainend(){

	?>

	<?

}

function htmlend(){
	
	?>
	
	</body>
	</html>
	<?


}

function loginbox2(){
	global $realm,$config;
	?>
	
<form action=index.php?realm=<?=$realm?> method=post>
<input type=hidden name=action value=login>

		<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Login</strong> </td>

			</tr>



<tr bgcolor=<?=$config['color_a']?>>
	<td width=120>Username:</td>
	<td width=120><input type="text" name="username"></td>
</tr>
<tr bgcolor=<?=$config['color_b']?>>
	<td>Password:</td>
	<td><input type="password" name="password"></td>
</tr>
<tr bgcolor=<?=$config['color_a']?>>

	<td align=left colspan=2><input type="submit" value="Login"></td>
</tr>


</td>
</tr>
</table>

	
</td>
</tr>
</table>
</form>
<?

}


?>