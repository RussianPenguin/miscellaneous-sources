<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the admin functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function manageusers(){
	global $forumsess,$config,$realm,$sortby;

	if (admincheck($forumsess[$realm][username])){
	
		//print "<a href='index.php?action=adduser&realm=$realm'>Add User</a> | <a href='index.php?action=addmanyusers&realm=$realm'>Add Multiple</a><br><br>";
		
		db_connect();
				
		if (db_numrows_all('fusers')>0){
			
			if ($sortby)		
				$result = db_select("SELECT * FROM fusers ORDER BY $sortby ASC");
			else 
				$result = db_select("SELECT * FROM fusers ORDER BY username ASC");
				
			print "<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='$config[tcolor]'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
			
			print "<tr bgcolor='".$config['color_top']."'>

			<td class=tabletop width=150> <strong><a href='index.php?action=manageusers&realm=$realm&sortby=username'>Username</a></strong> </td>
			<td class=tabletop> <strong><a href='index.php?action=manageusers&realm=$realm&sortby=level'>Level</a></strong> </td>
			<td class=tabletop> <strong>Msgs</strong> </td>
			<td class=tabletop> <strong>Actions</strong> </td>
			</tr>";
			
			$i = 0;
			
			while($row = db_getarray($result)){
							
				$i = $i + 1;
		
				if ($i % 2) $bgcolor = $config['color_b'];
				else  $bgcolor = $config['color_a'];
			
				if ($row[level] == 10){
					$level = "Administrator";
					$actions = "";
				} else {
					$level = "Member &nbsp;&nbsp; <a href='index.php?action=promoteuser&user=$row[username]&realm=$realm&'>Promote</a>";
					//$actions = "<a href='index.php?action=disableuser&user=".$row[username]."&realm=$realm'>Disable</a>";
					$actions = "";
				}
				
				print "<tr bgcolor='$bgcolor'>

					<td valign=top><a href='index.php?action=userinfo&user=$row[username]&realm=$realm'>".$row[username]."</a></td>
					<td valign=top> $level </td>
					<td valign=top align=center>
					<a href='index.php?action=searchnow&realm=$realm&search%5Bkey%5D=".$row[username]."&search%5Btype%5D=poster'>
					".usermessagecount($row[username])."</a></td>
					<td valign=top>
					$actions
					</td>
					</tr>";
			}
			
			print "</table></td></tr></table>";

			
		} else {
			print "No users available<br>";
		}
		
		db_disconnect();
	
	} else {
		print "You do not have sufficient access to manage users.<br>";
	}
	
}


function manageforums(){
	global $forumsess,$config,$realm;
	
	if (admincheck($forumsess[$realm][username])){
		
		print "<a href='index.php?action=addforum&realm=$realm'>Add Forum</a><br><br>";
		
		db_connect();
				
		if (db_numrows_all('forums')>0){
		
			$result = db_select("SELECT cat FROM forums GROUP BY cat");
			
			while($cat = db_getarray($result)){
			
				$result2 = db_select("SELECT * FROM forums WHERE cat='$cat[cat]' ORDER BY ftitle ASC");
				
				print "<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
				<td bgcolor='$config[tcolor]'>
				<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
				
				if (!$cat[cat])
					$cat[cat] = "General Forums";
				
				print "<tr bgcolor='".$config['color_top']."'>

				<td class=tabletop colspan=5> <strong>$cat[cat]</strong> </td>

				</tr>";
				print "<tr bgcolor='".$config['color_top']."'>
				<td>&nbsp;</td>
				<td class=tabletop width=150> <strong>Forum</strong> </td>
				<td class=tabletop> <strong>Topics</strong> </td>
				<td class=tabletop> <strong>Messages</strong> </td>
				<td class=tabletop> <strong>Actions</strong> </td>
				</tr>";
				
				$i = 0;
				
				while($row = db_getarray($result2)){
								
					$i = $i + 1;
			
					if ($i % 2) $bgcolor = $config['color_b'];
					else  $bgcolor = $config['color_a'];
				
					if ($row[icon]) 
						$icon = "<img src='$row[icon]'>";
					else
						$icon = "<img src='$config[forumicon]'>";
					
					print "<tr bgcolor='$bgcolor'>
						<td valign=top>$icon</td>
						<td valign=top><a href='index.php?forum=$row[fname]&realm=$realm'>".$row[ftitle]."</a></td>
						<td valign=top>".topiccount($row[fname])."</td>
						<td valign=top>".messagecount($row[fname])."</td>
						<td valign=top>
						<a href='index.php?action=editforum&forum=".$row[fname]."&realm=$realm'>Edit</a>
						<a href='index.php?action=deleteforum&forum=".$row[fname]."&realm=$realm'>Delete</a>
						</td>
						</tr>";
				}
				
				print "</table></td></tr></table>";
			}
			
		} else {
			print "No forums available<br>";
		}
		
		db_disconnect();
		
		
	} else {
		print "You do not have sufficient access to manage forums.<br>";
	}

}

function addforum(){
	global $forumsess,$config,$realm;
	
	if (admincheck($forumsess[$realm][username])){
		?>
		
		<form action='index.php?action=saveforum&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
				<td bgcolor='<?=$config[tcolor]?>'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>
			<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Create New Forum</strong> </td>
	
				</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Forum Name (all lowercase, no spaces)</strong></td>
			<td><input type="text" name="post[fname]" size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_b']?>">
			<td valign=top width=120><strong>Forum Title</strong></td>
			<td><input type="text" name="post[ftitle]" size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Category</strong></td>
			<td><input type="text" name="post[cat]" size=30></td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td valign=top><strong>Description</strong></td>
			<td><textarea cols="30" rows="4" name="post[fdesc]" wrap="soft" style="width: 90%;"></textarea></td>
		</tr>
		
		<tr bgcolor="<?=$config['color_a']?>">
			<td>&nbsp;</td>
			<td><input type="submit" value="Save!" name="post[submit]"></td>
		</tr>
		</table>
		</td>
		</tr>
		</table>
		</form>
		
		<?
	} else {
		print "You do not have sufficient access to add forums.<br>";
	}

}

function makeforum(){
	global $forumsess,$config,$realm,$post;
	
	if (admincheck($forumsess[$realm][username])){
		
		$columns = "fname,ftitle,cat,fdesc,owner";
		$values = "'$post[fname]','$post[ftitle]','$post[cat]','$post[fdesc]','".$forumsess[$realm][username]."'";
	
		db_insert('forums',$columns,$values);
	
		print "Successfully saved forum $post[ftitle]! ($post[fname])<br><br>";
		
		manageforums();
	} else {
		print "You do not have sufficient access to add forums.<br>";
	}

}

function editforum($fname){
	global $forumsess,$config,$realm;
	
	$row = db_getrow('forums',"fname='$fname'");
	
	if (admincheck($forumsess[$realm][username])){
		?>
		
		<form action='index.php?action=saveforumchange&forum=<?=$fname?>&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
				<td bgcolor='<?=$config[tcolor]?>'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>
			<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Edit Forum</strong> </td>
	
				</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Forum Name</strong></td>
			<td><?=$fname?></td>
		</tr>
		<tr  bgcolor="<?=$config['color_b']?>">
			<td valign=top width=120><strong>Forum Title</strong></td>
			<td><input type="text" name="post[ftitle]" value='<?=$row[ftitle]?>' size=30></td>
		</tr>
		<tr  bgcolor="<?=$config['color_a']?>">
			<td valign=top width=120><strong>Category</strong></td>
			<td><input type="text" name="post[cat]" value='<?=$row[cat]?>' size=30></td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
			<td valign=top><strong>Description</strong></td>
			<td><textarea cols="30" rows="4" name="post[fdesc]" wrap="soft" style="width: 90%;"><?=$row[fdesc]?></textarea></td>
		</tr>
		
		<tr bgcolor="<?=$config['color_a']?>">
			<td>&nbsp;</td>
			<td><input type="submit" value="Save!" name="post[submit]"></td>
		</tr>
		</table>
		</td>
		</tr>
		</table>
		</form>
		
		<?
	} else {
		print "You do not have sufficient access to edit forums.<br>";
	}

}

function saveforumchanges($fname){
	global $forumsess,$config,$realm,$post;
	
	if (admincheck($forumsess[$realm][username])){
		
		$columns = array("ftitle","cat","fdesc");
		$values = array($post[ftitle],$post[cat],$post[fdesc]);
		db_update('forums',"fname='$fname'",$columns,$values);
		
		print "Successfully saved changes to forum $post[ftitle]! ($fname)<br><br>";
		
		manageforums();
	} else {
		print "You do not have sufficient access to edit forums.<br>";
	}

}

function removeforum($fname){
	global $forumsess,$config,$realm;
	
	if (admincheck($forumsess[$realm][username])){
		
		db_remove('forums',"fname='$fname'");
	
		print "Successfully removed forum $fname!<br><br>";
		
		manageforums();
	} else {
		print "You do not have sufficient access to remove forums.<br>";
	}

}

function userinfo($user){
	global $forumsess,$realm,$config;

	if (admincheck($forumsess[$realm][username])){
		
		$row = db_getrow('fusers',"username='$user'");
		
		$options = $row[options];
		$birthyear = substr($row[birthday],0,4);
		$birthday = substr($row[birthday],6,2);
		$birthmonth = substr($row[birthday],4,2);
	
		?>
		<FORM NAME="editprofile" ACTION="#">
		<table border=0 cellpadding=0 cellspacing=0 width="95%">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Profile</strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			This is <?=$user?>'s Profile<br></FONT>
			</td></tr>

			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name</B></FONT></TD>
			<TD><?=$row[username]?></TD>
			</TR>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email</B></FONT></TD>
				<TD><?=$row[email]?></TD>
			</TR>
	
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
				<TD><?=$row[icq]?></TD>
			</tr>
	
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
				<TD><?=$row[aim]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
				<TD><?=$row[yahoo]?></TD>
			</tr>		
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
				<TD><?=$row[location]?></TD>
			</tr>
	
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
				<TD><? print "$birthmonth-$birthday-$birthyear";?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
				<TD><?=$row[gender]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_b']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
				<TD><?=$row[homepage]?></TD>
			</tr>
			
			<TR bgcolor="<?=$config['color_a']?>">
				<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
				<TD>
				<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1" <? if ($options & 1) print "CHECKED";?>> Display email address<br>
				<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2" <? if ($options & 2) print "CHECKED";?>> Display ICQ Number<br>
				<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4" <? if ($options & 4) print "CHECKED";?>> Display AIM Screen Name<br>
				<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8" <? if ($options & 8) print "CHECKED";?>> Display Yahoo ID<br>
				<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16" <? if ($options & 16) print "CHECKED";?>> Display Age<br>
				<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32" <? if ($options & 32) print "CHECKED";?>> Display Homepage URL
				</TD>
			</TR>
	
			 <TR bgcolor="<?=$config['color_b']?>">
				<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
				<TD><?=$row[sig]?></TD>
			</tr>
			</TABLE></td></tr></table>
			</form>
		<?
	
	
	} else {
		print "You do not have sufficient access to view user profiles.<br>";
	}
}

function userpromote($user){
	global $forumsess,$realm,$config;
	if (admincheck($forumsess[$realm][username])){

		$columns = array("level");
		$values = array('10');
		
		db_update('fusers',"username='$user'",$columns,$values);

	
		print "Successfully promoted $user to admin status!<br><br>";
		
		manageusers();
	} else {
		print "You do not have sufficient access to upgrade users forums.<br>";
	}
}

function userdisable($user){

}
?>