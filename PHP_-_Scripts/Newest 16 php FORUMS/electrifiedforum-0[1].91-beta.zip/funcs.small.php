<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the misc functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/
function age_from_bday($birthdate){

	$birthyear = substr($birthdate,0,4);
	$birthday = substr($birthdate,4,4);
	$age = date("Y") - $birthyear;
	if (date("md") < $birthday)
		$age = $age - 1;
	return $age;
}

function convert($n) {
	if ($n < 10) 
		return "0".$n;
	else
		return $n;
}

function forumtitle($forumname){
/* Return the title for a $forumname */
	return db_getvar('forums',"fname='$forumname'",'ftitle');
}

function threadtitle($forumname,$threadid){
	return db_getvar('messages',"fname='$forumname' AND threadid='$threadid' AND threadindex='0'",'title');
}

function sql_to_unix_time($timeString) { 
	return mktime(substr($timeString, 8,2), substr($timeString, 10,2), substr($timeString, 12,2), substr($timeString,4,2), substr($timeString, 6,2), substr($timeString, 0,4)); 
}

function forumcount(){

	return db_numrows_all('forums');

}

function tmsgcount(){

	return db_numrows_all('messages');

}

function usercount(){

	return db_numrows_all('fusers');

}

function verifyforum($forumname){
/* verify forum $forumname exists */

	db_connect();
	if (db_numrows('forums',"fname='$forumname'")>0)
		return TRUE;
	else
		return FALSE;

}

function verifythread($forumname,$threadid){
/* verify forum $forumname exists with a thread id od $threadid */

	db_connect();
	if (db_numrows('messages',"fname='$forumname' AND threadid='$threadid'")>0)
		return TRUE;
	else
		return FALSE;

}

function topiccount($forumname){
/* count number of messages in a forum */

	db_connect();
	return db_numrows('messages',"fname='$forumname' AND threadindex='0'");

}

function threadcount($forumname,$threadid){
/* count number of messages in a thread */

	db_connect();
	return db_numrows('messages',"fname='$forumname' AND threadid='$threadid'");


}

function messagecount($forumname){
/* count number of messages in a forum */

	db_connect();
	return db_numrows('messages',"fname='$forumname'");

}

function usermessagecount($user){
/* count number of messages in a forum */

	db_connect();
	return db_numrows('messages',"poster='$user'");

}

function ownercheck($mid,$username){

	$owner = db_getvar('messages',"id='$mid'","poster");
	
	if ($username == $owner) return TRUE;
	else return FALSE;

}

function admincheck($username){

	$level = db_getvar('fusers',"username='$username'","level");
	
	if ($level == 10) return TRUE;
	else return FALSE;

}

function usercheck($username){

	$user = db_getvar('fusers',"username='$username'","username");
	
	if ($user) return TRUE;
	else return FALSE;

}

function avatar($username){
	global $config;
	
	$avatar = db_getvar('fusers',"username='$username'","avatar");
	
	if ($avatar)
		return "<img src='$config[avatar_dir]$avatar' border=0 alt=''>";
	else
		return "";
}

?>