<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the main index file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/
$disable = FALSE;

if (!$realm)
	$realm = "default";

if (($realm)&&(file_exists("realm.$realm.php")))
	include "realm.$realm.php";
else
	include "realm.default.php";

include "funcs.forum.php";
include "funcs.mysql.php";
include "funcs.files.php";
include "funcs.small.php";
include "funcs.forms.php";
include "funcs.admin.php";

if ($disable) shut_down();

session_start("forums");

if ($action == "login") login($username,$password);
else if ($action == "logout") logout();

if ($action == "displaythread") htmlstart(forumtitle($forum));
elseif ($forum) htmlstart(forumtitle($forum));
else htmlstart("Main Forums");

mainblock("");

if ($autherror){
	print "<div class=error>Authentication Error: $autherror</div>";
	$action = "loginbox";
}

forumheader();

if ($action == "loginbox") 				loginbox2();
elseif ($action == "register") 			signup_form();
elseif ($action == "profile") 			editprofile();
elseif ($action == "savereg") 			saveuser("new");
elseif ($action == "updateprofile") 	saveuser("edit");
elseif ($action == "post")				postform($forum);
elseif ($action == "postsave") 			postsave($forum);
elseif ($action == "reply") 			replyform($forum,$id);
elseif ($action == "replyquote") 		replyquote($forum,$mid);
elseif ($action == "editmsg") 			editmsg($forum,$mid);
elseif ($action == "editsave") 			editsave($forum,$mid);
elseif ($action == "replysave") 		replysave($forum,$id);
elseif ($action == "displaythread") 	displaythread($forum,$id);
elseif ($action == "search") 			searchform();
elseif ($action == "searchnow")			search();

elseif (($action == "manageusers")&&($forumsess[$realm]["admin"]))	manageusers();
elseif (($action == "manageforums")&&($forumsess[$realm]["admin"]))	manageforums();
elseif (($action == "editforum")&&($forumsess[$realm]["admin"]))	editforum($forum);
elseif (($action == "deleteforum")&&($forumsess[$realm]["admin"]))	removeforum($forum);
elseif (($action == "addforum")&&($forumsess[$realm]["admin"]))		addforum();
elseif (($action == "saveforum")&&($forumsess[$realm]["admin"]))		makeforum();
elseif (($action == "saveforumchange")&&($forumsess[$realm]["admin"]))	saveforumchanges($forum);
elseif (($action == "userinfo")&&($forumsess[$realm]["admin"]))			userinfo($user);
elseif (($action == "promoteuser")&&($forumsess[$realm]["admin"]))		userpromote($user);

elseif ($forum) 						displayforum($forum);

else mainforums();

forumfooter();

mainend();
htmlend();

?>