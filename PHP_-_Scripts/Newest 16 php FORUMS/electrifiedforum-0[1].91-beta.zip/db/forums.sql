#
# Table structure for table 'forums'
#

CREATE TABLE forums (
  fname varchar(20) NOT NULL default '',
  ftitle varchar(30) NOT NULL default '',
  fdesc varchar(200) NOT NULL default '',
  cat varchar(40) NOT NULL default '',
  owner varchar(100) NOT NULL default '',
  icon varchar(100) NOT NULL default '',
  PRIMARY KEY (fname),
  UNIQUE KEY fname(fname),
  KEY fname_2(fname)
) TYPE=MyISAM;

#
# Dumping data for table 'forums'
#

INSERT INTO forums VALUES ('chat','Chat','A forum to talk about anything and everything!','General','admin','');

#
# Table structure for table 'fusers'
#

CREATE TABLE fusers (
   username varchar(20) NOT NULL,
   password varchar(20) NOT NULL,
   level smallint(6) DEFAULT '0' NOT NULL,
   options tinyint(4) DEFAULT '0' NOT NULL,
   location varchar(100) NOT NULL,
   email varchar(100) NOT NULL,
   homepage varchar(200) NOT NULL,
   showemail tinyint(4) DEFAULT '0' NOT NULL,
   icq varchar(20) NOT NULL,
   showicq tinyint(4) DEFAULT '0' NOT NULL,
   aim varchar(40) NOT NULL,
   showaim tinyint(1) DEFAULT '0' NOT NULL,
   yahoo varchar(80) NOT NULL,
   showyahoo tinyint(1) DEFAULT '0' NOT NULL,
   realname varchar(100) NOT NULL,
   age smallint(6) DEFAULT '0' NOT NULL,
   birthday varchar(8) NOT NULL,
   showbirthday tinyint(4) DEFAULT '0' NOT NULL,
   gender varchar(10) NOT NULL,
   avatar varchar(60) NOT NULL,
   sig text NOT NULL,
   disabled tinyint(1) DEFAULT '0' NOT NULL,
   PRIMARY KEY (username),
   UNIQUE username (username),
   KEY username_2 (username)
);

#
# Dumping data for table 'fusers'
#

INSERT INTO fusers VALUES ( 'admin', 'penguin56', '10', '0', '', '', '', '0', '', '0', '', '0', '', '0', '', '', '', '0', '', '', '', '0');


#
# Table structure for table 'messages'
#

CREATE TABLE messages (
  id smallint(6) NOT NULL auto_increment,
  fname varchar(20) NOT NULL default '',
  threadid smallint(6) NOT NULL default '0',
  threadindex smallint(6) NOT NULL default '0',
  poster varchar(100) NOT NULL default '',
  title varchar(120) NOT NULL default '',
  content text NOT NULL,
  icon varchar(60) NOT NULL default '',
  ip varchar(60) NOT NULL default '',
  posttime timestamp(14) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY id(id),
  KEY forumname(fname)
) TYPE=MyISAM;

#
# Dumping data for table 'messages'
#

INSERT INTO messages VALUES (1,'chat',0,0,'admin','Welcome to electrifiedForum!','If you see this message, electrifiedForum is properly installed and configured!!','','','');

