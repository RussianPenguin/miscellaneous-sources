<?
/**************************************

electrifiedForum
Version 0.91 - March 22, 2001

Changes - 3-23-01: Added check for a title for a post
Also fixed a bug affecting replies 


Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the main functions file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function forummenu(){
/* print a menu of basic forum functions, based on being logged in or not */
	global $forumsess,$realm,$config;
	
	if ($forumsess[$realm][username])
		print "<a href='index.php?action=profile&realm=$realm'>Profile</a> | <a href='index.php?action=logout&realm=$realm'>Logout</a> | <a href='index.php?action=search&realm=$realm'>Search</a>";
		
	else
		print "<a href='index.php?action=register&realm=$realm'>Register</a> | <a href='index.php?action=loginbox&realm=$realm'>Login</a> | <a href='index.php?action=search&realm=$realm'>Search</a>";

}



function forumheader(){
/* Create a table for the top of the forum... */
	global $config,$forum,$id,$realm,$HTTP_SERVER_VARS,$action;

	?>
	<table width="90%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align=left width=75% valign=top>
		<div class="forumtitle"><?=$config[title]?></div>
		<div class=content>
		<a href="index.php?realm=<?=$realm?>">Index</a>
		<? if ($forum) print " - <a href='index.php?forum=$forum&realm=$realm'>".forumtitle($forum)."</a>"; ?>
		<? if (isset($id)) print " - ".threadtitle($forum,$id); ?>
		<br><br>
		
		<?forummenu();?><br>
		</td>
		<td align=right width=25% valign=top>

		<?
		if ($config['use_buttons']){
				if (isset($id)) 
					print "<a href='index.php?action=reply&forum=$forum&id=$id&realm=$realm'><img src='$config[reply_butn]' border=0 alt='Post Reply'></a><br>";
				elseif ($forum)
					print "<a href='index.php?action=post&forum=$forum&realm=$realm'><img src='$config[post_butn]' border=0 alt='Post New Message'></a><br>";
			} else {		
				if (isset($id))
					print "<a href='index.php?action=reply&forum=$forum&id=$id&realm=$realm'>Post Reply</a><br>";
				elseif ($forum)
					print "<a href='index.php?action=post&forum=$forum&realm=$realm'>Post Message</a><br>";
		}
	
		?>
		</div>
		</td>
	</tr>
	</table>

	<?
	if (eregi("MSIE",$HTTP_SERVER_VARS["HTTP_USER_AGENT"])) print "<br>";

}

function forumfooter(){
/* Create a table for the bottom of the forum... */
	global $forumsess,$realm;
	?>
	<br><br>
	<table width="90%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align=left valign=top>
		<u>Forum-wide Stats</u><br>
		<br>
		<? db_connect(); ?>
		Total Forums: <? print forumcount(); ?><br>
		Total Messages: <? print tmsgcount(); ?><br>
		Total Users: <? print usercount(); ?><br>
		<? db_disconnect(); ?>
		</td>
		<td align=right valign=top>
		<?
		if ($forumsess[$realm][admin])
			print "<u>Administrative Tools</u><br><br><a href='index.php?action=manageusers&realm=$realm'>Manage Users</a> | <a href='index.php?action=manageforums&realm=$realm'>Manage Forums</a><br><br>";
		?>
		<div style="font-size: 11px; font-style: italic;">
		Powered By: electrifiedForum v.91<br>
		Copyright &copy; 2001 <a href="http://www.electrifiedpenguin.com">electrifiedpenguin.com</a></div>
		</td>
	</tr>
	</table>
	<?
}

function mainforums(){
/* Display all known forums in a nice table */
	global $config,$realm;
			
		print "<div class=messages>Currently available forums:</div><br>";
		db_connect();
				
		if (db_numrows_all('forums')>0){
		
			print "<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
				<td bgcolor='$config[tcolor]'>
				<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
				
			
			$result = db_select("SELECT cat FROM forums GROUP BY cat");
			
			while($cat = db_getarray($result)){
			
				$result2 = db_select("SELECT * FROM forums WHERE cat='$cat[cat]' ORDER BY ftitle ASC");
				

				if (!$cat[cat])
					$cat[cat] = "General Forums";
				
				print "<tr bgcolor='".$config['color_top']."'>

				<td class=ftitle colspan=6> <strong>$cat[cat]</strong> </td>

				</tr>";
				print "<tr bgcolor='".$config['color_top']."'>
				<td>&nbsp;</td>
				<td class=tabletop width=150> <strong>Forum</strong> </td>
				<td class=tabletop> <strong>Description</strong> </td>
				<td class=tabletop> <strong>Topics</strong> </td>
				<td class=tabletop> <strong>Msgs</strong> </td>
				<td class=tabletop> <strong>Most Recent</strong> </td>
				</tr>";
				
				$i = 0;
				
				while($row = db_getarray($result2)){
								
					$i = $i + 1;
			
					if ($i % 2) $bgcolor = $config['color_b'];
					else  $bgcolor = $config['color_a'];
				
					if ($row[icon]) 
						$icon = "<img src='$row[icon]'>";
					else
						$icon = "<img src='$config[forumicon]'>";
					
					$date[$i] = lastdate($row[fname]);
					if ($date[$i])
						$datetext = $datetext = date("l, F j g:i a",sql_to_unix_time($date[$i]));
					else
						$datetext = FALSE;
					print "<tr bgcolor='$bgcolor'>
						<td valign=top>$icon</td>
						<td valign=top><a href='index.php?forum=$row[fname]&realm=$realm'>".$row[ftitle]."</a></td>
						<td valign=top>".$row[fdesc]."</td>
						<td valign=top align=center>".topiccount($row[fname])."</td>
						<td valign=top align=center>".messagecount($row[fname])."</td>
						<td valign=top>".$datetext."</td>
						</tr>";
				}
								
			}
			
			print "</table></td></tr></table>";
		} else {
			print "No forums available<br>";
		}
		
		db_disconnect();
}

function displayforum($forumname){
/* Take forumname, and get all threadnames for it... */
	global $realm,$config;
	
	if (verifyforum($forumname)){
	
		$forum = db_getrow('forums',"fname='$forumname'");
		
		//print "<b>".$forum[ftitle]."</b><br>";
		print "<div class=content>";
		print $forum[fdesc]."<br><br>";
		print "<b>Owner:</b> ".$forum[owner]."<br><br>";
	
		db_connect();
		
		if (db_numrows('messages',"fname='$forumname' AND threadindex='0'")>0){
			$result = db_select("SELECT * FROM messages WHERE fname='$forumname' AND threadindex='0' ORDER BY id DESC");
			$i = 0;
			print "<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='$config[tcolor]'>
			<table border=0 cellspacing=1 cellpadding=4 width='100%'>";
			print "<tr bgcolor='".$config['color_top']."'>
			<td class=tabletop> <strong>Title</strong> </td>
			<td class=tabletop> <strong>Poster</strong> </td>
			<td class=tabletop> <strong>Msgs</strong> </td>
			<td class=tabletop> <strong>Most Recent</strong> </td></tr>";
			
			while($row = db_getarray($result)){
				
				$i = $i + 1;
		
				if ($i % 2) $bgcolor = $config['color_b'];
				else  $bgcolor = $config['color_a'];
		
		
				if ($row[icon]) 
					$icon = "<img src='$config[msgicons_dir]$row[icon]'>";
				else
					$icon = "<img src='$config[msgicons_dir]$config[msgicon]'>";
		
				$date[$i] = lastthreaddate($forumname,$row[threadid]);
					if ($date[$i])
						$datetext = date("m-d-Y g:i a",sql_to_unix_time($date[$i]));
					else
						$datetext = FALSE;
					
				print "<tr bgcolor='$bgcolor'>
					<td>$icon <a href='index.php?action=displaythread&forum=$forumname&id=$row[threadid]&realm=$realm'>$row[title]</a></td>
					<td>$row[poster]</td>
					<td align=center>".threadcount($forumname,$row[threadid])."</td>
					<td>$datetext</td>
					</tr>";

			}
			print "</table></td></tr></table>";
		} else {
			print "No messages available for this forum. <a href='index.php?action=post&forum=$forumname&realm=$realm'>Post one!</a><br>";
		}
		
		print "</div>";
		
		db_disconnect();
	
	} else {
	
		print "Error- No forum with id of $forumname available<br>";

	}

}

function displaythread($forumname,$threadid){
	global $config,$realm,$forumsess;
	
	if (verifythread($forumname,$threadid)){
		
		print "<div class=content>";
		db_connect();
		$result = db_select("SELECT * FROM messages WHERE fname='$forumname' AND threadid='$threadid' ORDER BY threadindex ASC");
				
		$i = 0;
		print "<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='$config[tcolor]'><table border=0 cellspacing=1 cellpadding=4 width='100%'>";
		print "<tr bgcolor='".$config['color_top']."'>

			<td class=tabletop> <strong>Poster</strong> </td>
			<td class=tabletop> <strong>Topic</strong> </td>
			</tr>";
		while($row = db_getarray($result)){
			$i = $i + 1;
		
			$userdat = db_getrow("fusers","username='$row[poster]'");
			$options = $userdat[options];
			if ($i % 2) $bgcolor = $config['color_b'];
			else  $bgcolor = $config['color_a'];
		
			$datetext = date("l, F j Y g:i A",sql_to_unix_time($row[posttime]));
			?>
			<tr bgcolor="<?=$bgcolor?>">
			<TD width=18% valign=top rowspan=3>
			<FONT SIZE="2" face="Verdana, Arial">
			<B><?=$row[poster]?></B>
			</font>
			<BR>
			<FONT SIZE="1" face="Verdana, Arial">
			<?
			if (admincheck($row[poster]))
				print "Administrator<br>";
			else
				print "Member<br>";
			
			if (($userdat[showbirthday])||($options & 16)){
				$age = age_from_bday($userdat[birthday]);				
				print "Age: $age<br>";
			}
			
			if ($userdat[gender])
				print "$userdat[gender]<br>";
			
			if ($userdat[location])
				print "$userdat[location]<br>";
			
			?>		
			</FONT>
			<br>
			<? print avatar($row[poster]); ?>
			</td>
			<td class=messagetitle>
			<?
			if ($row[icon]) 
				print "<img src='$config[msgicons_dir]$row[icon]'>";
			else
				print "<img src='$config[msgicons_dir]$config[msgicon]'>";
			?>
			<strong><?=$row[title]?></strong>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>">
			<TD class=messagebody>
			<!-- <IMG SRC="/art/icons/icon3.gif" BORDER=0 ALIGN=ABSCENTER> -->
			<FONT SIZE="1" face="Verdana, Arial">
			<b>Posted:</b>
			<?=$datetext?>
			&nbsp; &nbsp; &nbsp;&nbsp;
			<A HREF='index.php?action=editmsg&forum=<?=$forumname?>&mid=<?=$row[id]?>&realm=<?=$realm?>'>
			<IMG SRC="art/icons/edit.gif"  align=absmiddle BORDER=0 ALT="Edit/Delete Message"></A>
			&nbsp;&nbsp;
			<A HREF='index.php?action=replyquote&forum=<?=$forumname?>&mid=<?=$row[id]?>&realm=<?=$realm?>'>
			<IMG SRC="art/icons/quote.gif" align=absmiddle BORDER=0 ALT="Reply w/Quote"></A>

			</FONT>
			<HR noshade size=1 width=100%>
			<FONT SIZE="2" FACE="Verdana, Arial">
			<!-- Message -->
			<?=$row[content]?>
			<!-- end message -->
			<!-- sig -->
			<?
			if ($userdat[sig])
				print "<br><hr noshade width=100 size=1 align=left>$userdat[sig]<br>";
				
			?>
			<!-- end sig -->
			</FONT>
			<p>
			</td>
			</tr>
			<tr bgcolor="<?=$bgcolor?>">
			<td>
			<?
			if (($userdat[showemail])||($options & 1))
				print "&nbsp;
					<A HREF='mailto:$userdat[email]'>
					<IMG SRC='art/icons/email.gif' BORDER=0 ALT='Email' align=absmiddle></A>";
			
			if ($options & '32')
				print "&nbsp;
					<a href='$userdat[homepage]' target='_blank'>
					<img src='art/icons/homepage.gif' alt='Visit $userdat[username]`s homepage!' border=0 align=absmiddle></a>";

			if (($userdat[showaim])||($options & 4))
				print "&nbsp;
					<A HREF='aim:goim?screenname=$userdat[aim]&message=Hello'>
					<IMG SRC='art/icons/aim.gif' BORDER=0 ALT='$userdat[aim]' align=absmiddle></A>";
			
			if (($userdat[showyahoo])||($options & 8))
				print "&nbsp;
					<a href='http://edit.yahoo.com/config/send_webmesg?.target=$userdat[yahoo]' target='_blank'>
					<img src='art/icons/yahoo.gif' alt='Send a Yahoo! message to $userdat[yahoo]' border=0 align=absmiddle></a>";
			
			if (($userdat[showicq])||($options & 2))
				print "&nbsp;<a href='http://wwp.icq.com/$userdat[icq]' target='_blank'><IMG SRC='http://wwp.icq.com/scripts/online.dll?icq=$userdat[icq]&img=5' BORDER=0 ALT='ICQ: $userdat[icq]' align=absmiddle><img src='art/icons/icq_text.gif' border=0 align=absmiddle></a>";

			if ($forumsess[$realm][admin])
				print "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT SIZE=1><IMG SRC='art/icons/ip.gif' BORDER=0 align=absmiddle> $row[ip]</font>";
			?>
			&nbsp;
			</td>
			</tr>
			<?
			
			
		}
		print "</table></td></tr></table>";
		db_disconnect();
		print "</div>";
	} else {
	
		print "Error- No thread with id of $threadid available<br>";

	}

}



function login($username,$password){
	global $config,$forumsess,$autherror,$realm;
	
	db_connect();
	if (db_numrows("fusers","username='$username'")==1){
		if (db_getvar("fusers","username='$username'","password")==$password){
			$forumsess[$realm] = array();
			
			if (!session_is_registered("forumsess"))
				session_register("forumsess");
			
			$forumsess[$realm][username] = $username;
			
			if (db_getvar("fusers","username='$username'","level")==10)
				$forumsess[$realm][admin] = TRUE;
				
		} else {
			$autherror = "Bad Password";
		}
	} else {
		$autherror = "Bad Username";
	}
	db_disconnect();

}

function verifyuser($username,$password){
/* similar to login, but will return true/false */
	global $config,$forumsess,$autherror,$realm;
	
	db_connect();
	if (db_numrows("fusers","username='$username'")==1){
		if (db_getvar("fusers","username='$username'","password")==$password){
			$forumsess[$realm] = array();
			
			if (!session_is_registered("forumsess"))
				session_register("forumsess");
			
			$forumsess[$realm][username] = $username;
			
			if (db_getvar("fusers","username='$username'","level")==10)
				$forumsess[$realm][admin] = TRUE;
			return TRUE;
		} else {
			$autherror = "Bad Password";
			return FALSE;
		}
	} else {
		$autherror = "Bad Username";
		return FALSE; 
	}
	db_disconnect();

}

function logout(){
	global $config,$forumsess,$realm;
	
	unset($forumsess[$realm]);
	//session_unregister("forumsess");
	//session_unset();
	//session_destroy();
	//$forumsess[$realm] = FALSE;
}



function process($data){
/* Process message data with various conversions/filters */

	$data = nl2br(htmlentities($data,ENT_QUOTES));
	$data = str_replace("\n","",$data);
	$data = str_replace("\r","",$data);

	$data = str_replace(":)","<IMG src=\"art/smileys/smile.gif\">",$data);
	$data = str_replace(":D","<IMG src=\"art/smileys/biggrin.gif\">",$data);
	$data = str_replace(":P","<IMG src=\"art/smileys/tongue.gif\">",$data);
	$data = str_replace(":?:","<IMG src=\"art/smileys/confused.gif\">",$data);
	
	$data = str_replace(";)","<IMG src=\"art/smileys/wink.gif\">",$data);
	
	$data = preg_replace("/\[quote\](.*?)\[\/quote]/si", "<br><TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
	<font style=\"font-size: 11px;\">Quote</font>
	<HR noshade size=1></TD></TR><TR><TD>\\1</TD></TR><TR><TD><HR noshade size=1></TD></TR></TABLE>", $data);
	$data = preg_replace("/\[b\](.*?)\[\/b\]/si", "<B>\\1</B>", $data);
	$data = preg_replace("/\[i\](.*?)\[\/i\]/si", "<I>\\1</I>", $data);
	$data = preg_replace("/\[u\](.*?)\[\/u\]/si", "<U>\\1</U>", $data);
	$data = preg_replace("/\[url\](http:\/\/)?(.*?)\[\/url\]/si", "<A HREF=\"http://\\2\" TARGET=\"_blank\">\\2</A>", $data);
	$data = preg_replace("/\[url=(http:\/\/)?(.*?)\](.*?)\[\/url\]/si", "<A HREF=\"http://\\2\" TARGET=\"_blank\">\\3</A>", $data);
	$data = preg_replace("/\[email\](.*?)\[\/email\]/si", "<A HREF=\"mailto:\\1\">\\1</A>", $data);
	$data = preg_replace("/\[img\](.*?)\[\/img\]/si", "<IMG SRC=\"\\1\">", $data);
		
	/*
	$post = str_replace(":lick:","<IMG src=\"icons/lick.gif\">",$post);
	$post = str_replace(":mad:","<IMG src=\"icons/mad.gif\">",$post);
	$post = str_replace(":yawn:","<IMG src=\"icons/yawn.gif\">",$post);
	$post = str_replace(":rolleyes:","<IMG src=\"icons/rolleyes.gif\">",$post);
	$post = str_replace(":o","<IMG src=\"icons/shocked.gif\">",$post);
	$post = str_replace(":(","<IMG src=\"icons/sad.gif\">",$post);
	*/

	
	return $data;

}

function reverse_process($data){
/* reverse Process message data with various conversions/filters */

	//$data = nl2br(htmlentities($data,ENT_QUOTES));
	
	//$data = str_replace("\r","",$data);

	
	$data = str_replace("<IMG src=\"art/smileys/smile.gif\">",":)",$data);
	$data = str_replace("<IMG src=\"art/smileys/biggrin.gif\">",":D",$data);
	$data = str_replace("<IMG src=\"art/smileys/tongue.gif\">",":P",$data);
	$data = str_replace("<IMG src=\"art/smileys/confused.gif\">",":?:",$data);
	$data = str_replace("<IMG src=\"art/smileys/wink.gif\">",";)",$data);
	
	$data = preg_replace("/<TABLE border=0 align=center width=85% cellpadding=0><TR><TD>
	<font style=\"font-size: 11px;\">Quote<\/font>
	<HR noshade size=1><\/TD><\/TR><TR><TD>(.*?)<\/TD><\/TR><TR><TD><HR noshade size=1><\/TD><\/TR><\/TABLE>/si","[quote]\\1[/quote]", $data);

	$data = preg_replace("/<B>(.*?)<\/B>/si", "[B]\\1[/B]", $data);
	$data = preg_replace("/<I>(.*?)<\/I>/si", "[I]\\1[/I]", $data);
	$data = preg_replace("/<U>(.*?)<\/U>/si", "[U]\\1[/U]", $data);
	

	$data = preg_replace("/\<A HREF=\"(http:\/\/)?(.*?)\" TARGET=\"_blank\"\>(.*?)\<\/A\>/si", "[url=http://\\2]\\3[/url]", $data);
	$data = preg_replace("/\<A HREF=\"mailto:(.*?)\">(.*?)<\/A>/si", "[email]\\1[/email]", $data);
	$data = preg_replace("/\<IMG SRC=\"(.*?)\">/si", "[img]\\1[/img]", $data);
	

	/*
	$post = str_replace(":lick:","<IMG src=\"icons/lick.gif\">",$post);
	$post = str_replace(":mad:","<IMG src=\"icons/mad.gif\">",$post);
	$post = str_replace(":yawn:","<IMG src=\"icons/yawn.gif\">",$post);
	$post = str_replace(":rolleyes:","<IMG src=\"icons/rolleyes.gif\">",$post);
	$post = str_replace(":o","<IMG src=\"icons/shocked.gif\">",$post);
	$post = str_replace(":(","<IMG src=\"icons/sad.gif\">",$post);
	*/

	$data = str_replace("<br>","\n",$data);
	
	return $data;

}

function postsave($forum){
/* Process a submitted post */
	global $forumsess,$config,$post,$realm,$HTTP_SERVER_VARS;
	
	$post[content] = process($post[content]);
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username])){
		if ($post[title]){
			$threadid = lastthread($forum) + 1;
		
			$columns = "fname,threadid,title,content,poster,ip,icon";
			$values = "'$forum','$threadid','$post[title]','$post[content]','".$forumsess[$realm][username]."','$HTTP_SERVER_VARS[REMOTE_ADDR]','$post[icon]'";
		
			db_insert('messages',$columns,$values);
		
			print "Successfully saved your post! (Threadid: $threadid)<br>";
		
			displayforum($forum);
		} else {
			print "Error - You did not use a title for your post. <br>";
		}
	} else {
		if (($post[username])&&($post[password])){
			if (verifyuser($post[username],$post[password])){
				if ($post[title]){
					$threadid = lastthread($forum) + 1;
		
					$columns = "fname,threadid,title,content,poster,ip,icon";
					$values = "'$forum','$threadid','$post[title]','$post[content]','".$forumsess[$realm][username]."','$HTTP_SERVER_VARS[REMOTE_ADDR]','$post[icon]'";
						
					db_insert('messages',$columns,$values);
						
					print "Successfully saved your post! (Threadid: $threadid)<br>";
						
					displayforum($forum);
				} else {
					print "Error - You did not use a title for your post. <br>";
				}
			} else {
				print "Invalid username or password!<br>";
			}
		} else {
			print "Username or password not entered!<br>";
		}
	}
}





function replysave($forum,$threadid){
/* Process a submitted post */
	global $forumsess,$config,$post,$realm,$HTTP_SERVER_VARS;
	
	$post[content] = process($post[content]);
	
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username])){
		$threadindex = lastindex($forum,$threadid) + 1;
	
		$columns = "fname,threadid,threadindex,title,content,poster,ip,icon";
		$values = "'$forum','$threadid','$threadindex','$post[title]','$post[content]','".$forumsess[$realm][username]."','$HTTP_SERVER_VARS[REMOTE_ADDR]','$post[icon]'";
	
		db_insert('messages',$columns,$values);
	
		print "Successfully saved your post! (Threadid: $threadid)<br><br>";
	
		displaythread($forum,$threadid);
	} else {
		if (($post[username])&&($post[password])){
			if (verifyuser($post[username],$post[password])){
				$threadindex = lastindex($forum,$threadid) + 1;
	
				$columns = "fname,threadid,title,content,poster,ip,icon";
				$values = "'$forum','$threadid','$post[title]','$post[content]','".$forumsess[$realm][username]."','$HTTP_SERVER_VARS[REMOTE_ADDR]','$post[icon]'";
					
				db_insert('messages',$columns,$values);
					
				print "Successfully saved your post! (Threadid: $threadid)<br><br>";
					
				displaythread($forum,$threadid);
			} else {
				print "Invalid username or password!<br>";
			}
		} else {
			print "Username or password not entered!<br>";
		}
	}
}



function editsave($forum,$mid){
/* Save an edited message */
	global $forumsess,$config,$edit,$realm;
	$threadid = db_getvar('messages',"id='$mid'","threadid");
	$edit[content] = process($edit[content]);
	if ((session_is_registered("forumsess"))&&($forumsess[$realm][username])){
		if ((ownercheck($mid,$forumsess[$realm][username]))||($forumsess[$realm][admin])){
			if ($edit[delete]){
				db_remove('messages',"id='$mid'");
				print "Successfully deleted post id $mid<br><br>";
			} else {	
				$columns = array("title","content");
				$values = array($edit[title],$edit[content]);
				db_update('messages',"id='$mid'",$columns,$values);
				print "Successfully edited post id $mid<br><br>";
			}
		} else {
			print "You do not have permission to edit this message!<br>";
		}
		
		if ($edit[delete])
			displayforum($forum);
		else
			displaythread($forum,$threadid);
	} else {
		if (($edit[username])&&($edit[password])){
			if (verifyuser($edit[username],$edit[password])){
				if ((ownercheck($mid,$forumsess[$realm][username]))||($forumsess[$realm][admin])){
					if ($edit[delete]){
						db_remove('messages',"id='$mid'");
						print "Successfully deleted post id $mid<br><br>";
					} else {	
						$columns = array("title","content");
						$values = array($edit[title],$edit[content]);
						db_update('messages',"id='$mid'",$columns,$values);
						print "Successfully edited post id $mid<br><br>";
					}
					if ($edit[delete])
						displayforum($forum);
					else
						displaythread($forum,$threadid);
				} else {
					print "You do not have permission to edit this message!<br>";
				}
			} else {
				print "Invalid username or password!<br>";
			}
		} else {
			print "Username or password not entered!<br>";
		}
	}
}


function lastthread($forum){
/* Return the last used thread id for a given $forum */
/* Will return -1 for no available threadids */

	db_connect();
	
	if (db_numrows('messages',"fname='$forum'")>0){
		$result = db_select("SELECT * FROM messages WHERE fname='$forum' ORDER BY threadid DESC LIMIT 0,1");
	
		while($row = db_getarray($result)){
			$lastid=$row[threadid];
		}
	} else {
		$lastid = -1;
	}
	db_disconnect();
	
	return $lastid;
}

function lastindex($forum){
/* Return the last used thread index for a given $forum and $threadid */
/* Will return -1 for no available threadids */

	db_connect();
	
	if (db_numrows('messages',"fname='$forum'")>0){
		$result = db_select("SELECT * FROM messages WHERE fname='$forum' AND threadid='$threadid' AND ORDER BY threadindex DESC LIMIT 0,1");
	
		while($row = db_getarray($result)){
			$lastid=$row[threadindex];
		}
	} else {
		$lastid = -1;
	}
	db_disconnect();
	
	return $lastid;
}

function lastthreaddate($forum,$threadid){
/* Return the most recent date for a given $forum */
/* Will return -1 for no available threadids */

	db_connect();
	
	$result = db_select("SELECT posttime FROM messages WHERE fname='$forum' AND threadid='$threadid' ORDER BY posttime DESC LIMIT 0,1");
	
	while($row = db_getarray($result)){
		$date=$row[posttime];
	}

	db_disconnect();
	
	return $date;
}

function lastdate($forum){
/* Return the most recent date for a given $forum */
/* Will return -1 for no available threadids */

	db_connect();
	
	$result = db_select("SELECT posttime FROM messages WHERE fname='$forum' ORDER BY posttime DESC LIMIT 0,1");
	
	while($row = db_getarray($result)){
		$date=$row[posttime];
	}

	db_disconnect();
	
	return $date;
}


function saveuser($method){
	global $config,$forumsess,$realm,$reg;
	
	$options = $reg[showemail] + $reg[showicq] + $reg[showaim] + $reg[showyahoo] + $reg[showbirthday] + $reg[showhomepage];
	$birthday = $reg[year].convert($reg[month]).convert($reg[day]);
	
	if ($method == "new"){
	
		$columns = "username,password,location,email,avatar,sig,icq,aim,yahoo,birthday,gender,homepage,options";
		$values = "'$reg[username]','$reg[password]','$reg[location]','$reg[email]','$reg[avatar]','$reg[sig]','$reg[icq]','$reg[aim]','$reg[yahoo]','$birthday' ,'$reg[gender]','$reg[homepage]','$options'";
	
		if (db_insert('fusers',$columns,$values)){
	
			if (!session_is_registered("forumsess"))
				session_register("forumsess");
		
			$forumsess[$realm]["username"] = $reg[username];
	
			print "Successfully saved your registration!<br><br>";
			
		} else {
			
			print "There was an error with your registration!<br><br>";
	
		}
		
	} elseif ($method == "edit") {
		$columns = array("location","email","avatar","sig","icq","aim","yahoo","gender","birthday","homepage","options");
		$values = array($reg[location],$reg[email],$reg[avatar],$reg[sig],$reg[icq],$reg[aim],$reg[yahoo],$reg[gender],$birthday,$reg[homepage],$options);
		
		db_update('fusers',"username='".$forumsess[$realm][username]."'",$columns,$values);
		print "Successfully edited your profile!<br><br>";
	
	} else {
	
		print "An error has occured.<br><br>";
	
	}
	
	mainforums();
	
	
}

function savepass(){
	global $config,$forumsess,$realm,$pass;
	$row = db_getrow('fusers',"username='".$forumsess[$realm][username]."'");
	if ($pass[old]==$row[password]){
		$columns = array("password");
		$values = array($pass['new']);
		
		db_update('fusers',"username='".$forumsess[$realm][username]."'",$columns,$values);
		print "Successfully saved your new password!<br><br>";
		mainforums();
	} else {
		print "You have entered an incorrect password!<br><br>";
		passwordform();
	}
	
	
	
}

function listavatars($currav){
	global $config;
	
	$avatars = dir_list($config['avatar_dir']);

	?>
	<script>
	/*
	Dynamic Image selector Script- � Dynamic Drive (www.dynamicdrive.com)
	*/
	
	function generateimage(which){
	if (document.all){
		if(which!=''){
			dynamic3.innerHTML='<center>Loading image...</center>'
			dynamic3.innerHTML='<img src="<?=$config[avatar_dir]?>'+which+'">'
		} else {
			dynamic3.innerHTML='&nbsp;'
		}
	}
	else if (document.layers){
		if(which!=''){
			document.dynamic1.document.dynamic2.document.write('<img src="<?=$config[avatar_dir]?>'+which+'">')
		} else {
			document.dynamic1.document.dynamic2.document.write('&nbsp;')
		}
		document.dynamic1.document.dynamic2.document.close()
	}
	else
	alert('You need NS 4 or IE 4 to view the images!')
	}
	</script>
	<select name="reg[avatar]" onChange="generateimage(this.options[this.selectedIndex].value)">
	<option value="" Selected>None
	<?
		
	for ($i=0;$i<sizeof($avatars);$i++){
		if ($avatars[$i] == $currav)
			print "<option value='$avatars[$i]' SELECTED>$avatars[$i]</option>";
		else
			print "<option value='$avatars[$i]'>$avatars[$i]</option>";
	}
	
	?>
	
	</select>
	<?
}

function listmsgicons(){
	global $config;
	
	$icons = dir_list($config['msgicons_dir']);

	for ($i=0;$i<sizeof($icons);$i++){
			print "<input type=radio name='post[icon]' value='$icons[$i]'><img src='$config[msgicons_dir]$icons[$i]'>";
		$c = $i+1;
		if ($c%6==0) print "<br>";
	}
	
	?>
	
	</select>
	<?
}



function search(){
	global $config,$realm,$search;
	
	//$forum = db_getrow('forums',"fname='$forumname'");
	
	//print "<b>".$forum[ftitle]."</b><br>";
	//print "<div class=content>";
	//print $forum[fdesc]."<br><br>";
	//print "<b>Owner:</b> ".$forum[owner]."<br><br>";

	db_connect();
	
	if (db_numrows('messages',"$search[type] RLIKE '$search[key]' ")>0){
		$result = db_select("SELECT * FROM messages WHERE $search[type] RLIKE '$search[key]' ORDER BY id DESC");
		$i = 0;

		print "<table width=90%  bgcolor=$config[tcolor] cellpadding=4 border=0>";
		print "<tr bgcolor='".$config['color_top']."'>
		<td class=tabletop> <strong>Forum</strong> </td>
		<td class=tabletop> <strong>Title</strong> </td>
		<td class=tabletop> <strong>Poster</strong> </td>
		<td class=tabletop> <strong>Messages</strong> </td></tr>";
		
		while($row = db_getarray($result)){
			
			$i = $i + 1;
	
			$forumname = $row[fname];
			$forum = db_getrow('forums',"fname='$forumname'");
	
			if (!$forum)
				$forum[ftitle] = "<i>Old/Removed Forum</i>";
			
			if ($i % 2) $bgcolor = $config['color_b'];
			else  $bgcolor = $config['color_a'];
	
			if ($row[icon]) 
				$icon = "<img src='$config[msgicons_dir]$row[icon]'>";
			else
				$icon = "<img src='$config[msgicons_dir]$config[msgicon]'>";
				
			print "<tr bgcolor='$bgcolor'>
				<td>$forum[ftitle]</td>
				<td>$icon <a href='index.php?action=displaythread&forum=$forumname&id=$row[threadid]&realm=$realm'>$row[title]</a></td>
				<td>$row[poster]</td>
				<td>".threadcount($forumname,$row[threadid])."</td>
				</tr>";

		}
		print "</table>";
	} else {
		print "No messages found matching your search<br>";
		searchform();
	}
	
	print "</div>";
	
	db_disconnect();

}

?>