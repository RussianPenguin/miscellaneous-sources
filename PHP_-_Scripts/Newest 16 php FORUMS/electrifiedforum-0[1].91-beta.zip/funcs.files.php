<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the filesystems function file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/

function dir_list($dirname){
	$handle=opendir($dirname);
	while (($file = readdir($handle))!==false){
   		if($file=='.'||$file=='..') continue;
   		$result_array[]=$file;
   	}
 	closedir($handle);
 	return $result_array;
};

?>