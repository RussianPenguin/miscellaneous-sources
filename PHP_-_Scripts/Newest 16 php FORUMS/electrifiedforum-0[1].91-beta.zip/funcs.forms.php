<?
/**************************************

electrifiedForum
Version 0.90 - March 22, 2001

Copyright 2001- electrifiedpenguin.com

This is free software, please leave all
copyright notices intact, thanks!

This is the html forms file

MAKE NO CHANGES TO THIS FILE
Customizing options are in the realm files!!!

***************************************/
function passwordform(){
/* change password form */
	global $forumsess,$config,$realm;

		$row = db_getrow('fusers',"username='".$forumsess[$realm][username]."'");
		
	
		?>
		<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=passwordsave&realm=<?=$realm?>">
		<table border=0 cellpadding=0 cellspacing=0 width="95%">
		<TR>
		<td bgcolor="<?=$config['tcolor']?>">
			<table border=0 cellspacing=1 cellpadding=4 width="100%">
					<tr bgcolor='<?=$config[color_top]?>'>
	
				<td class=tabletop colspan=2> <strong>Change Password</strong> </td>
	
			</tr>
			<tr>
			<td bgcolor="<?=$config['color_a']?>" colspan=2>
			<FONT SIZE="2" FACE="Verdana, Arial">
			You can change your password using this form.  
			<BR></FONT>
			</td></tr>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name</B></FONT></TD>
			<TD><?=$row[username]?></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Old Password</B></FONT></TD>
			<TD><input type="password" name="pass[old]"></TD>
			</TR>
	
			<tr bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>New Password</B></FONT></TD>
			<TD><input type="password" name="pass[new]"></TD>
			</TR>	
	
			 </TABLE>
		</td>
		</tr>
		</table>
		<BR><BR>
		<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
		</form>
		<?
	

}

function postform($forum){
/* HTML Form for posting a new message */
	global $forumsess,$config,$realm;
	
	?>
	
	<form action='index.php?action=postsave&forum=<?=$forum?>&realm=<?=$realm?>' method=post>
		<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Post New Topic</strong> </td>

			</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong>Title</strong></td>
		<td><input type="text" name="post[title]" size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Icon</strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Message</strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;"></textarea></td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm]))){
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	
	<?
	
}

function replyform($forum,$threadid){
/* HTML Form for posting a new message */
	global $forumsess,$config,$realm;
	
	$retitle = threadtitle($forum,$threadid);
	?>
	
	<form action='index.php?action=replysave&forum=<?=$forum?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
		<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Reply to topic: <?=$retitle?></strong> </td>

			</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong>Title</strong></td>
		<td><input type="text" name="post[title]" value='RE: <?=$retitle?>' size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Icon</strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Message</strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;"></textarea></td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm]))){
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	<br>
	<?
	
	displaythread($forum,$threadid);
	
}

function replyquote($forum,$mid){
/* HTML Form for replying to a message with quote */
	global $forumsess,$config,$realm;
	
	$threadid = db_getvar('messages',"id='$mid'","threadid");
	
	$retitle = db_getvar('messages',"id='$mid'","title");

	?>
	
	<form action='index.php?action=replysave&forum=<?=$forum?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
	<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
	<td bgcolor='<?=$config[tcolor]?>'>
	<table border=0 cellspacing=1 cellpadding=4 width='100%'>
	<tr bgcolor='<?=$config[color_top]?>'>
		<td class=tabletop colspan=2> <strong>Reply to topic: <?=$retitle?></strong> </td>
	</tr>
	<tr  bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong>Title</strong></td>
		<td><input type="text" name="post[title]" value='RE: <?=$retitle?>' size=30></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Icon</strong></td>
		<td>
		<? listmsgicons(); ?>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Message</strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td>
<textarea cols="30" rows="6" name="post[content]" wrap="soft" style="width: 90%;">

[quote]
<? print reverse_process(db_getvar('messages',"id='$mid'","content")); ?>
[/quote]
</textarea>	
	
		</td>
	</tr>
	
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm]))){
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="post[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="post[password]"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="post[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	<br>
	<?
	displaythread($forum,$threadid);
}

function editmsg($forum,$mid){
/* Display a box for editing a message */
	global $forumsess,$config,$realm;
	
	$threadid = db_getvar('messages',"id='$mid'","threadid");
	
	$title = db_getvar('messages',"id='$mid'","title");

	?>
	
	<form action='index.php?action=editsave&forum=<?=$forum?>&mid=<?=$mid?>&id=<?=$threadid?>&realm=<?=$realm?>' method=post>
			<table border=0 cellpadding=0 cellspacing=0 width='90%'><TR>
			<td bgcolor='<?=$config[tcolor]?>'>
		<table border=0 cellspacing=1 cellpadding=4 width='100%'>
		<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Edit Message: <?=$title?></strong> </td>

			</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top width=120><strong>Title</strong></td>
		<td><input type="text" name="edit[title]" size=30 value='<?=$title?>'></td>
	</tr>
	<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Message</strong><br>
		<FONT SIZE="1" FACE="Verdana, Arial"><a href="#" onclick="window.open('efcode.html','efcode','toolbars=no,scrollbars=yes');" >eF Code & Smilies Guide</a></td>
		<td><textarea cols="30" rows="6" name="edit[content]" wrap="soft" style="width: 90%;"><? print reverse_process(db_getvar('messages',"id='$mid'","content")); ?></textarea>
		</td>
	</tr>
	<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Options</strong></td>
		<td>
		<input type="checkbox" name="edit[delete]" value="TRUE"> Delete this message
		</td>
	</tr>
	<?
	
	if ((!session_is_registered("forumsess"))||(!isset($forumsess[$realm]))){
		?>
		<tr bgcolor="<?=$config['color_b']?>">
		<td valign=top><strong>Username</strong></td>
		<td><input type="text" name="edit[username]"></td>
		</tr>
		<tr bgcolor="<?=$config['color_a']?>">
		<td valign=top><strong>Password</strong></td>
		<td><input type="password" name="edit[password]"></td>
		</tr>
		<?
	}
	?>
	
	
	<tr bgcolor="<?=$config['color_b']?>">
		<td>&nbsp;</td>
		<td><input type="submit" value="Save!" name="edit[submit]"></td>
	</tr>
	</table>
	</td>
	</tr>
	</table>
	</form>
	
	<?

}

function signup_form(){
	global $config,$realm;
	?>
	<FORM NAME="Register" METHOD="POST" ACTION="index.php?action=savereg&realm=<?=$realm?>">
	<table border=0 cellpadding=0 cellspacing=0 width="95%">
	<TR>
	<td bgcolor="<?=$config['tcolor']?>">
		<table border=0 cellspacing=1 cellpadding=4 width="100%">
		<tr bgcolor='<?=$config[color_top]?>'>
			<td class=tabletop colspan=2> <strong>Register</strong> </td>
		</tr>
		<tr>
		<td bgcolor="<?=$config['color_b']?>" colspan=2>
		<FONT SIZE="2" FACE="Verdana, Arial">
		In order to use all features of the Forums, you must register.  
		<BR><BR>
		Note: Required fields are marked by an asterisk.</FONT>
		</td></tr>
		<tr bgcolor="<?=$config['color_a']?>" valign=top>
		<td height="44">
				<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr valign="top">
					<td>
					<FONT SIZE="2" FACE="Verdana, Arial">
					<B>Avatar</B>
					</FONT><BR>
					<FONT SIZE="1" FACE="Verdana, Arial">Optional image you may use to appear with each of your posts.
					</td>
					<td align="right" width="100">
					<ilayer id="dynamic1" width="100%" height="100">
					<layer id="dynamic2" width="100%" height="100">
					<div id="dynamic3"></div></layer></ilayer>
					</td>
					</tr>
				</table>
				</td>
				<td valign="top">
				
				<? listavatars(""); ?>
				<br>
		</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
		<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name*</B></FONT></TD>
		<TD><INPUT TYPE="TEXT" NAME="reg[username]" VALUE="" SIZE=18 MAXLENGTH=18></TD>
		</TR>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Password*</B></FONT></TD>
			<TD><INPUT TYPE="password" NAME="reg[password]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		 </tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email*</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[email]" VALUE="" SIZE=30 MAXLENGTH=150></TD>
		</TR>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[icq]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[aim]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[yahoo]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>		
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[location]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
			<TD>
			<?
			print "<SELECT name='reg[month]'>";
			for ($i = 1; $i < 13; $i++) {
				$n = convert($i);
				print "<OPTION value=$i>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[day]'>";
			for ($i = 1; $i < 32; $i++) {
				$n = convert($i);
				print "<OPTION value=$i>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[year]'>";
			for ($i = 87; $i >= 0; $i--) {
				$n = $i + date("Y")-100;
				print "<OPTION value=$n>$n</OPTION>";
			}
			print "</SELECT>";
			?>		
			
			</TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[gender]" VALUE="" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[homepage]" VALUE="http://" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
			<TD>
			<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1"> Display email address<br>
			<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2"> Display ICQ Number<br>
			<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4"> Display AIM Screen Name<br>
			<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8"> Display Yahoo ID<br>
			<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16"> Display Age<br>
			<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32"> Display Homepage URL
			</TD>
		</TR>
		 <TR bgcolor="<?=$config['color_a']?>">
			<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
			<TD><TEXTAREA NAME="reg[sig]" ROWS=3 COLS=25 WRAP=soft></TEXTAREA>
		 </TD></tr>
		 </TABLE>
	</td>
	</tr>
	</table>
	<BR><BR>
	<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Registration">
	</form>
	<?
}

function editprofile(){
	global $config,$forumsess,$realm;
	
	$row = db_getrow('fusers',"username='".$forumsess[$realm][username]."'");
	
	$options = $row[options];
	$birthyear = substr($row[birthday],0,4);
	$birthday = substr($row[birthday],6,2);
	$birthmonth = substr($row[birthday],4,2);

	?>
	<FORM NAME="editprofile" METHOD="POST" ACTION="index.php?action=updateprofile&realm=<?=$realm?>">
	<table border=0 cellpadding=0 cellspacing=0 width="95%">
	<TR>
	<td bgcolor="<?=$config['tcolor']?>">
		<table border=0 cellspacing=1 cellpadding=4 width="100%">
				<tr bgcolor='<?=$config[color_top]?>'>

			<td class=tabletop colspan=2> <strong>Profile</strong> </td>

		</tr>
		<tr>
		<td bgcolor="<?=$config['color_b']?>" colspan=2>
		<FONT SIZE="2" FACE="Verdana, Arial">
		You can edit your forum profile.<BR>
		<br>
		To change your password, <a href="index.php?action=changepass&realm=<?=$realm?>">use this form</a>.<br>
		<BR>
		Note: Required fields are marked by an asterisk.</FONT>
		</td></tr>
		<tr bgcolor="<?=$config['color_a']?>" valign=top>
		<td height="44">
				<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr valign="top">
					<td>
					<FONT SIZE="2" FACE="Verdana, Arial">
					<B>Avatar</B>
					</FONT><BR>
					<FONT SIZE="1" FACE="Verdana, Arial">Optional image you may use to appear with each of your posts.
					</td>
					<td align="right" width="100">
					<ilayer id="dynamic1" width="100%" height="100">
					<layer id="dynamic2" width="100%" height="100">
					<div id="dynamic3"></div></layer></ilayer>
					</td>
					</tr>
				</table>
				</td>
				<td valign="top">
				
				<? listavatars($row[avatar]); ?>
				<br>
		</td>
		</tr>
		<tr bgcolor="<?=$config['color_b']?>">
		<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>User Name*</B></FONT></TD>
		<TD><?=$row[username]?></TD>
		</TR>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Email*</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[email]" VALUE="<?=$row[email]?>" SIZE=30 MAXLENGTH=150></TD>
		</TR>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>ICQ Number</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[icq]" VALUE="<?=$row[icq]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>AIM Screen Name</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[aim]" VALUE="<?=$row[aim]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Yahoo ID</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[yahoo]" VALUE="<?=$row[yahoo]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>		
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>City, State, Country</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[location]" VALUE="<?=$row[location]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>

		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Birthday</B></FONT></TD>
			<TD>
			<?
			print "<SELECT name='reg[month]'>";
			for ($i = 1; $i < 13; $i++) {
				$n = convert($i);
				if ($n == $birthmonth) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$i $c>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[day]'>";
			for ($i = 1; $i < 32; $i++) {
				$n = convert($i);
				if ($n == $birthday) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$i $c>$n</OPTION>";
			}
			print "</SELECT>&nbsp;&nbsp;";
			
			print "<SELECT name='reg[year]'>";
			for ($i = 87; $i >= 0; $i--) {
				$n = $i + date("Y")-100;
				if ($n == $birthyear) 
					$c = "SELECTED";
				else 
					$c = '';
					
				print "<OPTION value=$n $c>$n</OPTION>";
			}
			print "</SELECT>";
			?>		
			
			</TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Gender</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[gender]" VALUE="<?=$row[gender]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_b']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Homepage URL</B></FONT></TD>
			<TD><INPUT TYPE="TEXT" NAME="reg[homepage]" VALUE="<?=$row[homepage]?>" SIZE=30 MAXLENGTH=50></TD>
		</tr>
		
		<TR bgcolor="<?=$config['color_a']?>">
			<TD><FONT SIZE="2" FACE="Verdana, Arial"><B>Privacy Options</B></FONT></TD>
			<TD>
			<INPUT TYPE="checkbox" NAME="reg[showemail]" VALUE="1" <? if ($options & 1) print "CHECKED";?>> Display email address<br>
			<INPUT TYPE="checkbox" NAME="reg[showicq]" VALUE="2" <? if ($options & 2) print "CHECKED";?>> Display ICQ Number<br>
			<INPUT TYPE="checkbox" NAME="reg[showaim]" VALUE="4" <? if ($options & 4) print "CHECKED";?>> Display AIM Screen Name<br>
			<INPUT TYPE="checkbox" NAME="reg[showyahoo]" VALUE="8" <? if ($options & 8) print "CHECKED";?>> Display Yahoo ID<br>
			<INPUT TYPE="checkbox" NAME="reg[showbirthday]" VALUE="16" <? if ($options & 16) print "CHECKED";?>> Display Age<br>
			<INPUT TYPE="checkbox" NAME="reg[showhomepage]" VALUE="32" <? if ($options & 32) print "CHECKED";?>> Display Homepage URL
			</TD>
		</TR>

		 <TR bgcolor="<?=$config['color_b']?>">
			<TD valign=top><FONT SIZE="2" FACE="Verdana, Arial"><B>Signature</B></font><BR></TD>
			<TD><TEXTAREA NAME="reg[sig]" ROWS=3 COLS=25 WRAP=soft><?=$row[sig]?></TEXTAREA>
		 </TD></tr>
		 </TABLE>
	</td>
	</tr>
	</table>
	<BR><BR>
	<INPUT TYPE="SUBMIT" NAME="Submit" VALUE="Submit Changes">
	</form>
	<?


}

function searchform(){
	global $config,$realm;
	
	?>
	
	<form action="index.php" method=get>
	<input type=hidden name=action value=searchnow>
	<input type=hidden name=realm value=<?=$realm?>>
	Search for <input type=text name='search[key]'>
	in <select name='search[type]'>
	<option value=title> Thread Title
	<option value=content> Message
	<option value=poster> Poster
	</select>
	<input type=submit>
	</form>
	
	
	<?
}

?>