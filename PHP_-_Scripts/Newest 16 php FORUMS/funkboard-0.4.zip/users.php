<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

if($profile) {

$myhtml->top_html("$boardname > Member Profile","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Member Profile");
?>

<p>
<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr>
<td align="center" bgcolor="<? echo "$trcolor"; ?>" colspan="2"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Profile</font></span>
</b></td></tr>

<?

list($fmail,$posts,$homepage,$icq,$regdate,$location,$random)=$funk->mul_vals("SELECT email,posts,www,icq,regdate,location,random FROM members WHERE uid='$profile'");

list($name,$status)=user_stuff($profile);

if($location=='') {
$location='&nbsp;';
}
if($homepage=='') {
$homepage='&nbsp;';
}
if($random=='') {
$random='&nbsp;';
}
if($icq=='') {
$icq='&nbsp;';
}

$regdate=date("M Y",$regdate);

echo "
<tr>
<td bgcolor=\"$alt1\" width=\"20%\">Name</td>
<td bgcolor=\"$alt2\">$name</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Status</td>
<td bgcolor=\"$alt2\">$status</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Email</td>
<td bgcolor=\"$alt2\"><a href=\"users.php?mail=$profile\">Email $name</a></td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Date Registered</td>
<td bgcolor=\"$alt2\">$regdate</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Posts</td>
<td bgcolor=\"$alt2\">$posts</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Homepage</td>
<td bgcolor=\"$alt2\"><a href=\"$homepage\" target=\"_blank\">$homepage</a></td>
</tr>
<tr>
<td bgcolor=\"$alt1\">ICQ</td>
<td bgcolor=\"$alt2\">$icq</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Location</td>
<td bgcolor=\"$alt2\">$location</td>
</tr>
<tr>
<td bgcolor=\"$alt1\">Hobbies/Interests</td>
<td bgcolor=\"$alt2\">$random</td>
</tr>
";

echo "</table></p>";


} elseif($mail) {

$myhtml->top_html("$boardname > Mail Member","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Mail Member");

list($name,$email)=$funk->mul_vals("SELECT name,email FROM members WHERE uid='$mail'");
?>

<p>
<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr>
<td align="center" bgcolor="<? echo "$trcolor"; ?>" colspan="2"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Email user</font></span>
</b></td></tr>
<tr><td bgcolor="<?echo $alt1;?>">
The email address <?echo $name;?> has entered is:
<a href="mailto:<?echo $email;?>"><?echo $email;?></a>.
</td></tr>
</table>
</p>

<?
}

$myhtml->end_html();
?>
