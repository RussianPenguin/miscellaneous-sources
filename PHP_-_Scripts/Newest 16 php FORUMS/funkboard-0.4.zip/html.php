<?php

class MyHTML {

	function top_html($title,$location) {

	// get some colours and stuff
	$alt1=templates(alt1);
	$style=templates(tophtml);
	$bodytags=templates(style);

	echo "<html>
<head><title>$title</title>
$style
</head>
$bodytags
<table cellspacing=\"1\" cellpadding=\"2\" border=\"0\" width=\"100%\">
<tr><td align=\"left\" rowspan=\"3\">
<img src=\"images/logo.jpg\" border=\"0\"></td>
<td bgcolor=\"$alt1\" align=\"right\">
[<a href=\"index.php?skipcookie=1\">Home</a>]
[<a href=\"search.php\">Search</a>]
[<a href=\"faq.php\" target=\"_blank\">FAQ</a>]
</td>
</tr>
<tr><td>
$location
</td></tr>
<tr><td bgcolor=\"$alt1\" align=\"right\">
<span class=\"ms\">
[<a class=\"ms\" href=\"register.php\">register</a>]
[<a class=\"ms\" href=\"profile.php\">profile</a>]
[<a class=\"ms\"href=\"memberlist.php\">member list</a>]
[<a class=\"ms\"href=\"prefs.php\">preferences</a>]
[<a class=\"ms\"href=\"logout.php\">logout</a>]
</span>
</td></tr>
</table>
	";

	}

	function end_html() {

	// get some stuff from the db
	$footer=templates(footer);
	$copy=templates(copyright);
	$endhtml=templates(endhtml);

	// stuff can be added manually if necessary (not necessary...)
	echo "$footer $copy $endhtml";
	
	}

}

?>
