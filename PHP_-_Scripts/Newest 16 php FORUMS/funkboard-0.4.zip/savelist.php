<?php 

require("global.php");

$funk->ins_vals("INSERT INTO list VALUES('1','2','helloooooooo, out there- tiberius','10','4','0','1','982983949','1'");
$funk->ins_vals("INSERT INTO list VALUES('1','3','where is everyone?- night-train','9','6','0','1','982983984','1'");
$funk->ins_vals("INSERT INTO list VALUES('1','4','WTF Member List- Wzeib','11','10','0','1','982984020','1'");
$funk->ins_vals("INSERT INTO list VALUES('1','5','change','9','37','1','1','983074848','1'"); 
$funk->ins_vals("INSERT INTO list VALUES('2','6','a quick note:','9','67','4','1','984094102','1'"); 
$funk->ins_vals("INSERT INTO list VALUES('2','7','cool','0','15','1','3','984621556','1'"); 

funkdie("yay","good work");
?>
