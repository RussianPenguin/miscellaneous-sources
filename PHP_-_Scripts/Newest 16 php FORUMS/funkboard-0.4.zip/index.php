<?php

require("global.php");

check_bb_status();

if($skipcookie!=1) {
time_cookies();
}

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html($boardname,$boardname);

// print when the user last visited (from the cookie)
$lastvisit=date("D M d, Y H:i",$nbbvisit);
echo "<p><span class=\"ms\">You last visited on $lastvisit.</span></p>";
?>

<p>
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<tr>
<td>&nbsp;</td>
<td bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Forum</font></span></b>
</td>
<td bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Posts</font></span></b>
</td>
<td bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Last Post</font></span></b>
</td>
<td bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Moderator(s)</font></span></b>
</td>
</tr>

<?php

$cats = $funk->num_vals("SELECT catid FROM funkcats ORDER BY order_by");

$catbg=templates(catbg);

while(list($ind,$cat)=each($cats)) {

$namecat=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$cat'");
echo "<tr><td colspan=\"5\" bgcolor=\"$catbg\">$namecat</td></tr>";

$c = $funk->num_vals("SELECT forumid FROM forums WHERE category='$cat' ORDER BY order_by");

while(list($i,$value)=each($c)) {

unset($mods);

list($forumid,$name,$info,$order_by,$replies,$lastpost,$moderators)=$funk->mul_vals("SELECT * FROM forums WHERE forumid='$value'");

// new icon if there are new messages
if($lastpost < $nbbvisit) {
$image='off';
} else {
$image='on';
}

if($lastpost=='0') {
$postdate='There are no posts yet.';
} else {
$postdate=date("d M Y @ H:i",$lastpost);
}

$moderators=explode(",",$moderators);

while(list($ind,$mod)=each($moderators)) {
list($uname,$stat)=user_stuff($mod);
$mods.="$uname ";
}

echo "<tr>
<td align=\"center\" bgcolor=\"$alt1\">
<img src=\"images/$image.gif\">
</td>
<td bgcolor=\"$alt2\" width=\"60%\">
<a href=\"forums.$ext?id=$forumid\">$name</a>
<br>
<span class=\"ms\">
$info
</span>
</td>
<td bgcolor=\"$alt1\" align=\"center\">$replies</td>
<td bgcolor=\"$alt2\" align=\"center\">$postdate</td>
<td bgcolor=\"$alt1\">$mods</td>
</tr>";
}

}
?>

</table>
</p>

<table cellspacing="1" cellpadding="2" border="0" width="100%">
<tr>
<td><img src="images/on.gif" align="right"></td>
<td><span class="ms"><b>New posts since your last visit</b></span></td>
</tr>
<tr>
<td><img src="images/off.gif" align="right"></td>
<td><span class="ms"><b>No new posts since your last visit</b></span></td>
</tr>
</table>

<?
$myhtml->end_html();
?>
