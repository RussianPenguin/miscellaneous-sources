<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > Member List","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Member List");
?>

<p>
<table cellspacing="0" border="0" cellpadding="0" width="100%">
<tr><td align="right">
<form action="memberlist.<? echo "$ext"; ?>" method="GET">
<p><b>Sort by:</b>
<select name="sort">
<option value="toppost">By Top Posters
<option value="registered">By Date Registered
</select>
<input type="submit" value="List">
</form>
</td></tr></table>

<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr>
<td align="center" bgcolor="<? echo "$trcolor"; ?>" width="22%"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">User</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">E-mail</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Location</font></span></b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Status</font></span></b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center" width="10%"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Posts</font></span></b></td>
</tr>

<?

if(!$sort) {
$q="SELECT * FROM members ORDER BY uid";
} else {
	if($sort=='toppost') {
$q="SELECT * FROM members ORDER BY posts DESC";
	} elseif($sort=='registered') {
$q="SELECT * FROM members ORDER BY regdate";
	}
}

$num=$funk->num_vals($q);

while(list($i,$val)=each($num)) {
list($location,$status,$posts)=$funk->mul_vals("SELECT location,status,posts FROM members WHERE uid='$val'");

list($name,$status)=user_stuff($val);

if($location=='') {
$location='&nbsp;';
}

echo "
<tr align=\"center\">
<td bgcolor=\"$alt1\"><a href=\"users.php?profile=$val\">$name</a></td>
<td bgcolor=\"$alt2\"><a href=\"users.php?mail=$val\"><img src=\"images/email.gif\" border=\"0\" alt=\"Email $name\"></a></td>
<td bgcolor=\"$alt1\">$location</td>
<td bgcolor=\"$alt2\">$status</td>
<td bgcolor=\"$alt1\">$posts</td></tr>";
}
echo "</table></p>";

$myhtml->end_html();
?>
