<?php

class db_sql {

var $dbserver="localhost";
var $name="";
var $user="";
var $pass="";
var $admin="";
var $array=array();

	function connect() {
	$conn=mysql_connect($this->dbserver,$this->user,$this->pass) or $this->db_die();
	return $conn;
	}

	function db_query($query) {
	$get=mysql_db_query($this->name,$query,$this->connect()) or $this->db_die();
	list($result)=mysql_fetch_row($get);
	return $result;
	}

	function num_vals($query) {
	$get=mysql_db_query($this->name,$query,$this->connect()) or $this->db_die();
	$this->array=array();
		while($row=mysql_fetch_array($get)) {
		$this->array[]=$row[0];
		}
	return $this->array;	
	}

	function mul_vals($query) {
	$get=mysql_db_query($this->name,$query,$this->connect()) or $this->db_die();
	$this->array=array();
	$this->array=mysql_fetch_array($get);
	return $this->array;
	}

	function ins_vals($query) {
	$do=mysql_db_query($this->name,$query,$this->connect()) or $this->db_die();
	}
	
	function db_die() {
	die("<p>There has been an error with the database. Please contact the <a href=\"mailto:$this->admin\">administrator</a> if the problem is not solved.");
	}
}

?>
