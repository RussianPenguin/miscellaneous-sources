<?php

class db_sql {

var $dbserver="";
var $name="";
var $user="";
var $pass="";
var $port="";
var $admin="";
var $array=array();

	function connect() {
	$conn=pg_connect("dbname=$this->name user=$this->user password=$this->pass") or $this->db_die();
	return $conn;
	}

	function db_query($query) {
	$get=pg_exec($this->connect(),$query);
	list($result)=pg_fetch_row($get,0);
	return $result;
	}

	function num_vals($query) {
	$get=pg_exec($this->connect(),$query);
	$num=pg_numrows($get);
	$this->array=array();
		for($x=0; $x < $num; $x++) {
		list($forumid)=pg_fetch_row($get,$x);
		$this->array[]=$forumid;
		}
	return $this->array;
	}

	function mul_vals($query) {
	$get=pg_exec($this->connect(),$query);
	$this->array=array();
	$this->array=pg_fetch_row($get,0);
	return $this->array;
	}

	function ins_vals($query) {
	$do=pg_exec($this->connect(),$query);
	}

	function db_die() {
	die("There has been an error with the database. Please contact the <a href=\"mailto:$this->admin\">administrator</a> if the problem is not solved.");
	}
}

?>
