<?php

require("global.php");
check_bb_status();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > BB Code","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > BB Code");
?>

<p>
<table cellspacing="1" cellpadding="4" border="0" width="100%">
<tr bgcolor="<? echo "$trcolor"; ?>">
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
Function
</font></span></b>
</td>
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
Explanation
</font></span></b>
</td>
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
How to do it
</font></span></b>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<a href="http://www.sleepy.f2s.com">http://www.sleepy.f2s.com</a>
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
A link
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<font color="#ff0000">[URL]</font>http://www.sleepy.f2s.com<font
color="#ff0000">[/URL]</font>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/icons/icon11.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
An image
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<font color="#ff0000">[IMG]</font>http://www.yourhost.com/picture.jpg<font
color="#ff0000">[/IMG]</font>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<i>Email links</i>
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Make an email link
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<font color="#ff0000">[EMAIL]</font>you@yourdomain.com<font
color="#ff0000">[/EMAIL]</font>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<b>Bold Text</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Make text bold
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<font color="#ff0000">[B]</font>Bold text<font
color="#ff0000">[/B]</font>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<i>Italic text</i>
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Make text italic
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<font color="#ff0000">[I]</font>Italic text<font
color="#ff0000">[/I]</font>
</td>
</tr>

</table>
</p>

<?
$myhtml->end_html();
?>
