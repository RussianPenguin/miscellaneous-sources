<?php

require("global.php");

check_bb_status();

$time=time();

list($number,$forumname)=$funk->mul_vals("SELECT forumid,name FROM forums WHERE forumid='$forumid'");

if(!$forumname) {
funkdie("Error","No such forum, or there has been a database error.");
}

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > $forumname > New Topic","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > <a href=\"forums.php?id=$number\"><b>$forumname</b></a> > New Topic");

if(!$action) { ?>

<p>
<form action="newtopic.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Post a New Topic</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Name</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="name" value="<?php echo "$fbusername"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Pass</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass" value="<?php echo "$fbpassword"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Subject</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="50" name="subject">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Icon</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<?php
for($x=1;$x<=11;$x++) {
echo "<input type=\"radio\" name=\"iconid\" value=\"$x\">
<img src=\"images/icons/icon$x.gif\"> &nbsp; &nbsp;";
}

?>

<input type="radio" name="iconid" value="0" CHECKED> No icon
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Message</b> <font color="#ff0000">*</font>

<p>
<a href="faq.php" class="end" target="_blank">FAQ</a><br>
<a href="bbcode.php" class="end" target="_blank">BB Code</a><br>
<a href="smilies.php" class="end" target="_blank">Smilies</a><br>
</p>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<textarea rows="10" cols="50" name="msg" wrap="virtual"></textarea>
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="forumid" value="<? echo "$forumid"; ?>">
<input type="hidden" name="action" value="addtopic">
<input type="submit" value="Add Topic!">
</td>
</tr>
</table>
</form>
</p>

<?php

} else {

	if($name=='') {
$uid='0';
	} else {
list($uid,$rname,$rpass)=$funk->mul_vals("SELECT uid,name,pass_word FROM members WHERE
name='$name'");

if(!$rname) {funkdie("No such user","There is no such user- you may have entered your information incorrectly.");}
if($pass!=$rpass) {funkdie("Error","The password you entered was incorrect- please try again.");}

$posts=$funk->db_query("SELECT posts FROM members WHERE uid='$uid'");
$posts++;
$funk->ins_vals("UPDATE members SET posts='$posts' WHERE uid='$uid'");
	}

white_check($subject);
white_check($msg);

$subject=parse_msg($subject);
$msg=parse_msg($msg);
$msg=do_smilies($msg);
$msg=bbcodify($msg);

// this is very crap db accessing, there must be a more efficient way :)

$x=$funk->num_vals("SELECT threadid FROM list");
end($x);
$n=(current($x)+1);
$funk->ins_vals("INSERT INTO list VALUES('$forumid','$n','$subject','$iconid','0','0','$uid','$time','1')");

$q="INSERT INTO posts VALUES ('$n','$forumid','1','$subject','$iconid','$uid','$msg','$time')";

$funk->ins_vals($q);

$y=$funk->db_query("SELECT replies FROM forums WHERE forumid='$forumid'");
$y++;
$funk->ins_vals("UPDATE forums SET lastpost='$time', replies='$y' WHERE forumid='$forumid'");

?>

<meta http-equiv="refresh" content="3; url=<? echo "forums.php?id=$forumid"; ?>">

<p>
Your topic was added! <a href="forums.<? echo "$ext"; ?>?id=<? echo "$forumid"; ?>">Click
here</a> to go back to the forum listing, or you will be forwarded in 3
seconds.
</p>

<?php
}
$myhtml->end_html();
?>
