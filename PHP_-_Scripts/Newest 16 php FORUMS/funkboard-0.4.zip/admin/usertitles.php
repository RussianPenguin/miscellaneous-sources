<?php

require("global.php");

check_admin();
?>


<html><body>

<?
if($action=="addtitle") {

	if($c) {

if(!$title) { die("please complete the title field."); }

$title=addslashes($title);

// $x will be an array, and i'll add one to the last entry, to make sure the uid
// for the entry is unique.
$x=$funk->num_vals("SELECT uid FROM status");
end($x);
$n=(current($x)+1);

$funk->ins_vals("INSERT INTO status VALUES('$n','$title','$post','$edit','$admin')");

die("new status created.");

	} else {
?>

<p><b>Make a new User Title</b><hr></p>

<form action="usertitles.php" method="POST">

<p>
Name of the rank:<br>
<input size="30" name="title">
</p>

<p>
Can post? (set to no if you want a "banned"-type rank):
<input type="radio" name="post" value="1" CHECKED> yes
<input type="radio" name="post" value="0"> no
</p>

<p>
Can edit? (If user is not an admin, they only have rights on specific boards):
<input type="radio" name="edit" value="1"> yes
<input type="radio" name="edit" value="0" CHECKED> no
</p>

<p>
Is an admin? (be careful, this user has complete control on the board):
<input type="radio" name="admin" value="1"> yes
<input type="radio" name="admin" value="0" CHECKED> no
</p>

<p>
<input type="hidden" name="action" value="addtitle">
<input type="submit" name="c" value="add_title">
</p>

</form>

<?
	}

} elseif($action=="grantitle") {

	if($c) {

if(!$rankid || !$users) { die("please complete all the fields."); }

if($rankid=="admin") { $rankid="0"; }
$users=explode(",",$users);

///////////// CHECK FOR VALID USERS ///////////// 
while(list($ind,$val)=each($users)) {
$valid=$funk->db_query("SELECT name FROM members WHERE uid='$val'");
if(!$valid) { $notuser .= "<i>$val</i> is not a valid user.<br>"; }
}
if($notuser) { die($notuser); }
///////////// END CHECK /////////////

reset($users); // reset the internal pointer... thingy

while(list($i,$v)=each($users)) {
$funk->ins_vals("UPDATE members SET status='$rankid' WHERE uid='$v'");
}

die("titles granted.");

	} else {
?>

<p><b>Grant Custom Title</b><hr></p>

<p><b>Note</b>: the rank must be created already. Also, any user granted a
special title is exempt from the normal post-count based ranking.</p>

<form action="usertitles.php" method="POST">

<p>Grant:<br>

<?
$p=$funk->num_vals("SELECT uid FROM status WHERE uid>4");

// admin is special, but not >=5 like the others, also, php won't send zeros
$admintitle=$funk->db_query("SELECT title FROM status WHERE uid='0'");
echo "<input type=\"radio\" name=\"rankid\" value=\"admin\"> $admintitle";

while(list($i,$r)=each($p)) {

$rname=$funk->db_query("SELECT title FROM status WHERE uid='$r'");
$rname=stripslashes($rname);

echo "<input type=\"radio\" name=\"rankid\" value=\"$r\"> $rname";
}
?>

<br>
on (use <b>user numbers</b> -not- user names here, split multiple users with a
(",") comma, don't have a comma at the end eg. 2,4,5,):<br>
<input size="10" name="users">
</p>

<p>
<input type="hidden" name="action" value="grantitle">
<input type="submit" name="c" value="grant_title">
</p>


<?
	}

} elseif($action=="edititle") {
?>

<p><b>Edit User Title</b><hr></p>

<?
	if(!$id) {

echo "<ul>";

$a=$funk->num_vals("SELECT * FROM status WHERE uid>4");

while(list($i,$v) = each ($a) ) {
$name=$funk->db_query("SELECT title FROM status WHERE uid='$v'");
$name=stripslashes($name);
echo "<li><a href=\"usertitles.php?action=edititle&id=$v\">$name</a>";
}

echo "</ul>";

	} else {

		if($c) {

if(!$title) { die("please complete the title field."); }

$title=addslashes($title);
$funk->ins_vals("UPDATE status SET title='$title',post='$post',edit='$edit',admin='$admin' WHERE uid='$id'");
die("status edited.");


		} else {

list($title,$post,$edit,$admin)=$funk->mul_vals("SELECT title,post,edit,admin FROM status WHERE uid='$id'");
$title=stripslashes($title);
?>

<form action="usertitles.php" method="POST">

<p>
Name of the rank:<br>
<input size="30" name="title" value="<? echo $title; ?>">
</p>

<p>
Can post? (set to no if you want a "banned"-type rank):
<?
if($post==1) {
	$yes="CHECKED";	$no="";
} else {
	$yes=""; $no="CHECKED";
	}
?>
<input type="radio" name="post" value="1" <? echo "$yes"; ?>> yes
<input type="radio" name="post" value="0" <? echo "$no"; ?>> no
</p>

<p>
Can edit? (If user is not an admin, they only have rights on specific boards):
<?
if($edit==1) {
	$yes="CHECKED";	$no="";
} else {
	$yes=""; $no="CHECKED";
	}
?>
<input type="radio" name="edit" value="1" <? echo "$yes"; ?>> yes
<input type="radio" name="edit" value="0" <? echo "$no"; ?>> no
</p>

<p>
Is an admin? (be careful, this user has complete control on the board):
<?
if($admin==1) {
	$yes="CHECKED";	$no="";
} else {
	$yes=""; $no="CHECKED";
	}
?>
<input type="radio" name="admin" value="1" <? echo "$yes"; ?>> yes
<input type="radio" name="admin" value="0" <? echo "$no"; ?>> no
</p>

<p>
<input type="hidden" name="action" value="edititle">
<input type="hidden" name="id" value="<? echo $id; ?>">
<input type="submit" name="c" value="add_title">
</p>

</form>


<?
		}
	}
} elseif($action=="editbasic") {

	if($c) {

if(!$rank_mem || !$rank_sen || !$admr ||
!$modr || !$senr || !$memr || !$junr)
{ die("please complete all the fields."); }

// clean the titles
$admr=addslashes($admr);
$modr=addslashes($modr);
$senr=addslashes($senr);
$memr=addslashes($memr);
$junr=addslashes($junr);

// update the titles
$funk->ins_vals("UPDATE status SET title='$admr' WHERE uid = '0'");
$funk->ins_vals("UPDATE status SET title='$modr' WHERE uid = '1'");
$funk->ins_vals("UPDATE status SET title='$senr' WHERE uid = '2'");
$funk->ins_vals("UPDATE status SET title='$memr' WHERE uid = '3'");
$funk->ins_vals("UPDATE status SET title='$junr' WHERE uid = '4'");

// update the numbers needed to be promoted
$funk->ins_vals("UPDATE templates SET templ_value='$rank_mem' WHERE templ_name='rank_member'");
$funk->ins_vals("UPDATE templates SET templ_value='$rank_sen' WHERE templ_name='rank_senior'");

die("basic ranks edited.");

	} else {
// get the numbers needed to promote people, normally 10,30
$rank_mem=templates(rank_member);
$rank_sen=templates(rank_senior);

// get the titles
$admr=$funk->db_query("SELECT title FROM status WHERE uid = '0'");
$modr=$funk->db_query("SELECT title FROM status WHERE uid = '1'");
$senr=$funk->db_query("SELECT title FROM status WHERE uid = '2'");
$memr=$funk->db_query("SELECT title FROM status WHERE uid = '3'");
$junr=$funk->db_query("SELECT title FROM status WHERE uid = '4'");

// clean the titles
$admr=stripslashes($admr);
$modr=stripslashes($modr);
$senr=stripslashes($senr);
$memr=stripslashes($memr);
$junr=stripslashes($junr);
?>

<p><b>Edit the basic titles</b><hr></p>

<p>The properties of these basic ranks cannot be edited, but their titles
can be, eg. you can customise "Junior Member" to "Newbie" or something
like that if you like, or you can completely get rid of the whole ranking
system, and call everyone "Member".</p>

<form action="usertitles.php" method="POST">

<p>
Admin Title:<br>
<input size="30" name="admr" value="<? echo $admr; ?>">
</p>

<p>
Moderator Title:<br>
<input size="30" name="modr" value="<? echo $modr; ?>">
</p>

<p>
Senior Member Title:<br>
<input size="30" name="senr" value="<? echo $senr; ?>">
</p>

<p>
Member Title:<br>
<input size="30" name="memr" value="<? echo $memr; ?>">
</p>

<p>
Junior Member Title:<br>
<input size="30" name="junr" value="<? echo $junr; ?>">
</p>

<p>
Minimum Posts needed to become a Member (<? echo $memr; ?>):<br>
<input size="5" name="rank_mem" value="<? echo $rank_mem; ?>">
</p>

<p>
Minimum Posts needed to become a Senior Member (<? echo $senr; ?>):<br>
<input size="5" name="rank_sen" value="<? echo $rank_sen; ?>">
</p>

<p>
<input type="hidden" name="action" value="editbasic">
<input type="submit" name="c" value="edit_basic_titles">
</p>

</form>


<?
	}

} elseif($action=="deltitle") {

	if($del) {

if($del<5) {die("not a valid title to delete.");} // can't delete those base ranks

		if($sure) {

$funk->ins_vals("DELETE FROM status WHERE uid='$del'");
$funk->ins_vals("UPDATE members SET status='4' WHERE status='$del'");

die("title deleted.");

		} else {
$deltitle=$funk->db_query("SELECT title FROM status WHERE uid='$del'");
?>

<p><b>Delete a title</b><hr></p>

<form action="usertitles.php" method="POST">
<p>Are you sure you want to delete this title: <b><? echo $deltitle; ?></b>?
All users who had the rank will be returned to the normal ranking system
after you delete this. They must make a post first.</p>

<p>
<input type="hidden" name="action" value="deltitle">
<input type="hidden" name="del" value="<? echo $del; ?>">
<input type="submit" name="sure" value="delete_this_title">
</p>

</form>

<?
		}
	} else {
?>

<p><b>Delete a title</b><hr></p>

<?
echo "<ul>";

$a=$funk->num_vals("SELECT * FROM status WHERE uid > 4");

while( list($i,$v) = each ($a) ) {
$name=$funk->db_query("SELECT title FROM status WHERE uid='$v'");
$name=stripslashes($name);
echo "<li><a href=\"usertitles.php?action=deltitle&del=$v\">$name</a>";
}

echo "</ul>";

	}
}
?>
</body></html>
