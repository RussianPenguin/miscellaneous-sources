<?php

require("global.php");

check_admin();

?>

<html>
<body>

<?
if($action=="editst") {

	if(!$c) {

?>

<p><b>Edit Style Settings</b><hr></p>

<form action="style.php" method="POST">
<input type="hidden" name="action" value="editst">

<p>
TopHTML (The style settings (don't
edit too heavily unless you know what you're doing, you'll upset the
layout of the pages)):<br>
<textarea rows="8" cols="50" wrap="virtual" name="tophtml">
<? echo templates(tophtml); ?>
</textarea>
</p>

<p>
Body tags (Link, background and text colours):<br>
<textarea rows="3" cols="50" wrap="virtual" name="style">
<? echo templates(style); ?>
</textarea>
</p>

<p>
Alt1 (first alternating colour):<br>
<input size="30" name="alt1" value="<? echo templates(alt1); ?>">
</p>

<p>
Alt2 (second alternating colour):<br>
<input size="30" name="alt2" value="<? echo templates(alt2); ?>">
</p>


<p>
Table heading row color (Row on top of the list tables eg. the thread lists):<br>
<input size="30" name="trcolor" value="<? echo templates(trcolor); ?>">
</p>

<p>
Table heading text colour:<br>
<input size="30" name="trtext" value="<? echo templates(trtext); ?>">
</p>

<p>
Category Background Colour (Background for the categories on the main page):<br>
<input size="30" name="catbg" value="<? echo templates(catbg); ?>">
</p>


<p>
End HTML (A link back to your page, and a contact email):<br>
<textarea rows="6" cols="50" wrap="virtual" name="footer">
<? echo templates(footer); ?>
</textarea>
</p>


<p>
<input type="hidden" name="c" value="editst">
<input type="submit" name="do" value="edit_styles">
</p>


</form>

<?php

		} else {

// process the modify a forum form

if(!$tophtml || !$style || !$alt1 ||
!$alt2 || !$trcolor || !$trtext || !$catbg || !$footer) {
die("please complete all the fields.");
}

$tophtml=addslashes($tophtml);
$funk->ins_vals("UPDATE templates SET templ_value='$tophtml' WHERE templ_name='tophtml'");

$style=addslashes($style);
$funk->ins_vals("UPDATE templates SET templ_value='$style' WHERE templ_name='style'");

$alt1=addslashes($alt1);
$funk->ins_vals("UPDATE templates SET templ_value='$alt1' WHERE templ_name='alt1'");

$alt2=addslashes($alt2);
$funk->ins_vals("UPDATE templates SET templ_value='$alt2' WHERE templ_name='alt2'");

$trcolor=addslashes($trcolor);
$funk->ins_vals("UPDATE templates SET templ_value='$trcolor' WHERE templ_name='trcolor'");

$trtext=addslashes($trtext);
$funk->ins_vals("UPDATE templates SET templ_value='$trtext' WHERE templ_name='trtext'");

$catbg=addslashes($catbg);
$funk->ins_vals("UPDATE templates SET templ_value='$catbg' WHERE templ_name='catbg'");

$footer=addslashes($footer);
$funk->ins_vals("UPDATE templates SET templ_value='$footer' WHERE templ_name='footer'");

die("styles modified.");

		}
	} elseif($action=="dosett") {
		if(!$c) {
?>

<p><b>Edit Settings</b><hr></p>

<form action="style.php" method="POST">
<input type="hidden" name="action" value="dosett">

<p>
Board Title:<br>
<input size="30" name="boardname" value="<? echo templates(boardname); ?>">
</p>

<p>
Admin Password:<br>
<input size="30" name="adminpass" value="<? echo templates(adminpass); ?>">
</p>

<p>
Cookie Path (The cookies need a path, "/" should be fine):<br>
<input size="30" name="cookiepath" value="<? echo templates(cookiepath); ?>">
</p>

<p>
TimeZone (This is simply an aesthetic feature, the board does not calculate the
time):<br>
<input size="30" name="timezone" value="<? echo templates(timezone); ?>">
</p>

<p>
Is your BB viewable (you can turn it off if you like, so people can't view it)<br>
<?
$onf=templates(bbactive);
if($onf=="yes") {
echo "<input type=\"radio\" name=\"bbactive\" value=\"yes\" CHECKED>yes 
<input type=\"radio\" name=\"bbactive\" value=\"no\">no";
} else {
echo "<input type=\"radio\" name=\"bbactive\" value=\"yes\">yes 
<input type=\"radio\" name=\"bbactive\" value=\"no\" CHECKED>no";
}
?>
</p>

<p>
If the BB is off, you can set your own reason here, or leave this one.
You can leave this here even if your board is not off, it will be useful later.<br>
<input size="60" name="bbreason" value="<? echo templates(bbreason); ?>">
</p>

<p>
Reply page limit- how many replies to show on the "post reply" page:<br>
<input size="30" name="replypostlimit" value="<? echo templates(replypostlimit); ?>">
</p>

<p>
<input type="hidden" name="c" value="editse">
<input type="submit" name="do" value="edit_settings">
</p>

</form>


<?
		} else {

if(!$boardname || !$adminpass || !$cookiepath ||
!$timezone || !$bbactive || !$bbreason || !$replypostlimit) {
die("please complete all the fields.");
}

$boardname=addslashes($boardname);
$funk->ins_vals("UPDATE templates SET templ_value='$boardname' WHERE templ_name='boardname'");

$adminpass=addslashes($adminpass);
$funk->ins_vals("UPDATE templates SET templ_value='$adminpass' WHERE templ_name='adminpass'");

$cookiepath=addslashes($cookiepath);
$funk->ins_vals("UPDATE templates SET templ_value='$cookiepath' WHERE templ_name='cookiepath'");

$timezone=addslashes($timezone);
$funk->ins_vals("UPDATE templates SET templ_value='$timezone' WHERE templ_name='timezone'");

$bbactive=addslashes($bbactive);
$funk->ins_vals("UPDATE templates SET templ_value='$bbactive' WHERE templ_name='bbactive'");

$bbreason=addslashes($bbreason);
$funk->ins_vals("UPDATE templates SET templ_value='$bbreason' WHERE templ_name='bbreason'");

$replypostlimit=addslashes($replypostlimit);
$funk->ins_vals("UPDATE templates SET templ_value='$replypostlimit' WHERE templ_name='replypostlimit'");

die("settings modified.");

		}

	}
?>

</body></html>
