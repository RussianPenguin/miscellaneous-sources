<?php
chdir("../");
require("global.php");

function check_admin() {
global $fbadmin;
$pass=templates(adminpass);
$pass=crypt($pass,'.N');
	if($fbadmin==$pass) {
	return;
	} else {
	die("you are not a valid administrator.");
	}
}

?>
