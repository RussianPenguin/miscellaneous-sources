<?

require("global.php");

check_admin();

if($action=="templates") {

?>

<html>
<body>

<?php

if($field) {

	if($do) {

$thingy=addslashes($thingy);
$field=addslashes($field);

$funk->ins_vals("UPDATE templates SET templ_value='$thingy' WHERE templ_name='$field'");

die("Template updated.");

	} else {

// form processing.

$thingy=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='$field'");
$thingy=stripslashes($thingy);

?>

<form action="templates.php" method=POST>

<textarea rows="16" cols="56" name="thingy" wrap="virtual"><?php echo "$thingy";
?></textarea>
<p>
<input type="hidden" name="action" value="templates">
<input type="hidden" name="field" value="<?php echo "$field"; ?>">
<input type="submit" name="do" value="modify_template">
</form>

<?php
	}

} else {
?>

<p><b>Templates</b><hr></p>

<p>
Templates are very important. They hold the information for many different areas
of the board, for example the extension to use (.php or older .php3), the
colours, the template for the top of the page. These can be edited the customise
the board.
</p>

<ul>

<?php

$q=$funk->num_vals("SELECT * FROM templates");

while(list($i,$val) = each($q)) {

echo "<li><a href=\"templates.php?action=templates&field=$val\">$val</a>
";

}
	}
?>

</ul>
</body>
</html>

<?php

} elseif($action=='addtemplate') {

?>

<html><body>

<?php

	if($f) {

// form processing

if(!$templ_name || !$templ_value) {die("Please complete all fields, don't try to insert nothing into a database column.");}

$templ_name=stripslashes($templ_name);
$templ_value=stripslashes($templ_value);

$funk->ins_vals("INSERT INTO templates VALUES('$templ_name','$templ_value')");

die("Template added.");

	} else {

?>

<b>Create a Template</b><hr>
This will create a template in the template table, but it is of course up to you
to implement it wherever you intend in the board. For the templates name, avoid
using spaces, or strange characters- it just makes everything easier. :)
<p>
<form action="templates.php" method="POST">
Template name: <input size="30" name="templ_name">
<p>
<textarea rows="16" cols="56" name="templ_value" wrap="virtual"></textarea>
<p>
<input type="hidden" name="action" value="addtemplate">
<input type="submit" name="f" value="add_template">
</form>


<?php
	}
} // elseif
?>

</body></html>
