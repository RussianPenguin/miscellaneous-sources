<?php

/*
this is a very simple script and doesn't return any errors
itself, unless php or whatever sql does instead.
*/

require("global.php");

// table for categories
$a="
CREATE TABLE funkcats (
catid SMALLINT UNSIGNED NOT NULL,
catname VARCHAR(100) NOT NULL,
order_by SMALLINT UNSIGNED NOT NULL,
PRIMARY KEY(catid)
)";
$funk->ins_vals($a);

// table for forums
$a="
CREATE TABLE forums (
forumid SMALLINT UNSIGNED NOT NULL,
name VARCHAR(50) NOT NULL,
info MEDIUMBLOB NOT NULL,
order_by SMALLINT UNSIGNED NOT NULL,
replies SMALLINT UNSIGNED NOT NULL,
lastpost INT UNSIGNED NOT NULL,
moderators VARCHAR(20),
category VARCHAR(5) NOT NULL,
PRIMARY KEY(forumid)
)";
$funk->ins_vals($a);

// table for the forum list
$c="
CREATE TABLE list (
forumid SMALLINT UNSIGNED NOT NULL,
threadid SMALLINT UNSIGNED NOT NULL,
title VARCHAR(100) NOT NULL,
iconid SMALLINT UNSIGNED NOT NULL,
views SMALLINT UNSIGNED NOT NULL,
replies SMALLINT UNSIGNED NOT NULL,
lastposter VARCHAR(50) NOT NULL,
lastpost INT UNSIGNED NOT NULL,
status INT NOT NULL,
PRIMARY KEY(threadid)
)";
$funk->ins_vals($c);

// table for all posts
$e="
CREATE TABLE posts (
threadid SMALLINT UNSIGNED NOT NULL,
forumid SMALLINT UNSIGNED NOT NULL,
replyid SMALLINT UNSIGNED NOT NULL,
title VARCHAR(100) NOT NULL,
iconid SMALLINT UNSIGNED NOT NULL,
userid SMALLINT NOT NULL,
reply BLOB NOT NULL,
lastpost INT UNSIGNED NOT NULL
)";
$funk->ins_vals($e);

// table for members
$d="
CREATE TABLE members (
uid SMALLINT UNSIGNED NOT NULL,
name VARCHAR(100) NOT NULL,
pass_word VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL,
posts SMALLINT UNSIGNED NOT NULL,
status VARCHAR(50) NOT NULL,
www VARCHAR(100) NOT NULL,
icq VARCHAR(15) NOT NULL,
regdate VARCHAR(50) NOT NULL,
location VARCHAR(100) NOT NULL,
random VARCHAR(200) NOT NULL,
PRIMARY KEY(uid)
)";
$funk->ins_vals($d);

// table for statuses
$g="
CREATE TABLE status (
uid VARCHAR(100) NOT NULL,
title VARCHAR(100) NOT NULL,
post SMALLINT UNSIGNED NOT NULL,
edit SMALLINT UNSIGNED NOT NULL,
admin SMALLINT UNSIGNED NOT NULL
)";
$funk->ins_vals($g);

// insert the standard statuses (admin->junior)
$i="
INSERT INTO status VALUES(
'0',
'Admin',
'1',
'1',
'1'
)";
$funk->ins_vals($i);

$i="
INSERT INTO status VALUES(
'1',
'Moderator',
'1',
'1',
'0'
)";
$funk->ins_vals($i);

$i="
INSERT INTO status VALUES(
'2',
'Senior Member',
'1',
'0',
'0'
)";
$funk->ins_vals($i);

$i="
INSERT INTO status VALUES(
'3',
'Member',
'1',
'0',
'0'
)";
$funk->ins_vals($i);

$i="
INSERT INTO status VALUES(
'4',
'Junior Member',
'1',
'0',
'0'
)";
$funk->ins_vals($i);


// table for template stuff
$g="
CREATE TABLE templates (
templ_name VARCHAR(100) NOT NULL,
templ_value BLOB NOT NULL
)";
$funk->ins_vals($g);

$i="
INSERT INTO templates VALUES(
'style',
'<body bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#0077BB\" vlink=\"#0077BB\"
alink=\"#0077BB\">')";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'endhtml',
'</body></html>')";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'trcolor',
'\#00bbcc'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'trtext',
'\#FFFFFF'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'alt1',
'\#ddeeff'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'alt2',
'\#aaccff'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'boardname',
'Message Board'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'adminpass',
'funk'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'extension',
'php'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'cookiepath',
'/'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'timezone',
'GMT'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'bbactive',
'yes'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'bbreason',
'This board is temporarily closed for maintenance, please come back soon.'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'webmasteremail',
'you@yourdomain.com'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'replypostlimit',
'2'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'tophtml',
'<STYLE>
<!--
A,P,TD,TH {font-family: verdana, arial, helvetica; font-size: 10pt;}
.end,.ms {font-size: 7pt;}
A:HOVER {color:#00aaFF;}
-->
</STYLE>'
)";
$funk->ins_vals($i);



$i="
INSERT INTO templates VALUES(
'newtopic',
'[<a href=\"newtopic.\$ext?forumid=\$number\"><b>New Topic</b></a>]'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'newreply',
'[<a href=\"reply.\$ext?forumid=\$number&threadid=\$id\"><b>Post Reply</b></a>]'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'printthread',
'<a href=\"print.\$ext?threadid=\$id\">Printable Version</a>'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'catbg',
'#ccddff'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'rank_member',
'10'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'rank_senior',
'30'
)";
$funk->ins_vals($i);


$i="
INSERT INTO templates VALUES(
'footer',
'<p align=\"center\">
<b>
<a href=\"homepage.html\">My Homepage</a>
][
<a href=\"mailto:bort@oceanfree.net\">Contact Us</a>
</b>
</p>'
)";
$funk->ins_vals($i);

$i="
INSERT INTO templates VALUES(
'copyright',
'<p align=\"center\">
<span class=\"ms\"><font color=\"#888888\">
Powered by <a href=\"http://funkboard.sourceforge.net/\" class=\"end\">FunkBoard</a> v0.4
</font></span>
</p>'
)";
$funk->ins_vals($i);

$k="INSERT INTO forums VALUES(
'1',
'A Forum',
'The First Forum',
'1',
'0',
'0'
'None',
'1'
)";
$funk->ins_vals($k);

$k="INSERT INTO funkcats VALUES(
'1',
'The First Category',
'1'
)";
$funk->ins_vals($k);


die("Tables successfully created.");
?>
