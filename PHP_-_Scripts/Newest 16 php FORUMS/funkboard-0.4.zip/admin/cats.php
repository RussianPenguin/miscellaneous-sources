<?php

require("global.php");

check_admin();

if($action=="modcat") {

?>

<html>
<body>

<?php

	if($c) {

		if(!$do) {

list($catname)=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$c'");

?>

<html>
<body>
<p><b>Modify a Category</b><hr></p>

<form action="cats.php" method="POST">
<input type="hidden" name="action" value="modcat">
<input type="hidden" name="c" value="<?php echo "$c"; ?>">

<p>
Category Name (number <? echo "$c"; ?>):<br>
<input size="30" name="catname" value="<?php echo "$catname"; ?>">
</p>

<p>
<input type="hidden" name="catid" value="<? echo $c; ?>">
<input type="submit" name="do" value="modify_cat">
</p>

</form>
</body>
</html>

<?php

		} else {

// process the modify a forum form

if(!$catname) {
die("Please complete all the fields.");
}

$catname=addslashes($catname);

$funk->ins_vals("UPDATE funkcats SET catname='$catname' WHERE catid='$c'");

die("category edited.");

		}

	} else {

?>

<b>Choose one to modify</b><hr>

<ul>

<?php

$c=$funk->num_vals("SELECT * FROM funkcats ORDER BY order_by");

while(list($i,$v) = each($c)) {

$catname=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$v'");

echo "<li><a href=\"cats.php?action=modcat&c=$v\">$catname</a>";

}

	}

?>

</body></html>

<?php

} elseif($action=='addcat') {

if($c) {

if(!$catname || !$catord) {
die("Please complete all the fields.");
}

$catname=addslashes($catname);

$x=$funk->db_query("SELECT count(*) from funkcats");

$x++;

$funk->ins_vals("INSERT INTO funkcats VALUES('$x','$catname','$catord')");

die("Category added.");

} else {

?>

<html>
<body>
<p><b>Add a Category</b><hr></p>

<form action="cats.php" method="POST">
<input type="hidden" name="action" value="addcat">

<p>
Category Name:<br>
<input size="30" name="catname">
</p>

<p>
Category Order: (1,2 etc...)
<input size="3" name="catord">
</p>

<p>
<input type="submit" name="c" value="add_cat">
</p>

</form>
</body>
</html>

<?php
}


} elseif($action=="delcat") {

?>

<html>
<body>

<?php

if($c) {

if($do) {

$funk->ins_vals("DELETE FROM funkcats WHERE catid='$c'");

die("category successfully deleted.");

} else {

echo "<b>Confirm</b><hr>";
echo "Are you sure you want to delete this category: ";

$name=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$c'");

echo "<b>" . $name . "</b>? (This will <b>not</b> delete associated forums).";

?>

<form action="cats.php" method="POST">
<input type="hidden" name="action" value="delcat">
<input type="hidden" name="c" value="<?php echo "$c"; ?>">
<input type="submit" name="do" value="yes">
</form>

<?php
}

} else {

?>

<b>Choose one to delete</b><hr>

<ul>

<?php

$c=$funk->num_vals("SELECT * FROM funkcats ORDER BY order_by");

while(list($i,$v) = each($c)) {

$catname=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$v'");

echo "<li><a href=\"cats.php?action=delcat&c=$v\">$catname</a>";

}

}

?>

</body></html>

<?php

} elseif($action=="orderc") {

if(!$do) {

?>

<html><body>
<b>Order the Categories</b><hr>

<form action="cats.php" method="POST">

<?php
// display category order

$c=$funk->num_vals("SELECT * FROM funkcats ORDER BY order_by");

while(list($i,$v) = each($c)) {

list($catname,$order_by)=$funk->mul_vals("SELECT catname,order_by FROM funkcats WHERE catid='$v'");

echo "$catname <input size=2 name=order_by[$v] value=$order_by><br>";

}

?>
<input type="hidden" name="action" value="orderc">
<input type="submit" name="do" value="order_cats">
</form>
</body></html>

<?php

} else {

// process form

$c=$funk->num_vals("SELECT * FROM funkcats ORDER BY order_by");

while(list($i,$v) = each($c)) {

$funk->ins_vals("UPDATE funkcats SET order_by='$order_by[$v]' WHERE catid='$v'");

}

die("ordering complete.");

}
}
?>
