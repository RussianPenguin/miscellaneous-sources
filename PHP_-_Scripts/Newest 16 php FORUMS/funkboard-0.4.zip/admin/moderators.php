<?php

require("global.php");

check_admin();

if($action=="addmod") {

?>

<html>
<body>

<?php
	if(!$do) {

echo "<p><b>Assign Moderators</b><hr></p><br>
Moderators are assigned by their <b>user number</b> -not- their
user name. You can get their user number from viewing their profile, it will
be in the URL window. To assign multiple moderators to a forum, split
their numbers with a comma, eg. 1,4,23,12";
echo "<form action=\"moderators.php\" method=\"POST\">
<input type=\"hidden\" name=\"action\" value=\"addmod\">";

$count=$funk->num_vals("SELECT * FROM forums");

while(list($i,$num)=each($count)) {
list($fname,$fmod)=$funk->mul_vals("SELECT name,moderators FROM forums WHERE forumid='$num'");
echo "<input size=\"30\" name=\"forums[$num]\" value=\"$fmod\"> $fname<br>";
}

echo "<input type=\"submit\" name=\"do\" value=\"edit_moderators\">";

echo "</form>";

	} else {

while(list($i,$v)=each($forums)) {
$funk->ins_vals("UPDATE forums SET moderators='$v' WHERE forumid='$i'");
}

die("moderators set.");


	}
}
	
?>

</body></html>
