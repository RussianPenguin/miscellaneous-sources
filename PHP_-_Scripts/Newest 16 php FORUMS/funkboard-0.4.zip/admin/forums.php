<?php

require("global.php");

check_admin();

if($action=="modify") {

?>

<html>
<body>

<?php

	if($f) {

		if(!$do) {

list($name,$info,$category)=$funk->mul_vals("SELECT name,info,category FROM forums WHERE forumid='$f'");

?>

<html>
<body>
<p><b>Modify a Forum</b><hr></p>

<form action="forums.php" method="POST">
<input type="hidden" name="action" value="modify">
<input type="hidden" name="f" value="<?php echo "$f"; ?>">

<p>
Forum Name:<br>
<input size="30" name="forumname" value="<?php echo "$name"; ?>">
</p>

<p>
Description:<br>
<input size="50" name="forumdesc" value="<?php echo "$info"; ?>">
</p>

<p>
Category:<br>
<?
$cats=$funk->num_vals("SELECT * FROM funkcats");
while(list($i,$cat)=each($cats)) {
$name=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$cat'");
echo "<input type=\"radio\" name=\"catnum\" value=\"$cat\">$name ";
}
?>
</p>

<p>
<input type="submit" name="do" value="modify_forum">
</p>

</form>
</body>
</html>

<?php

		} else {

// process the modify a forum form

if(!$forumname || !$forumdesc) {
die("Please complete all the fields.");
}

$forumname=addslashes($forumname);
$forumdesc=addslashes($forumdesc);

$funk->ins_vals("UPDATE forums SET category='$catnum',name='$forumname', info='$forumdesc' WHERE forumid='$f'");

die("Forum edited.");

		}

	} else {

?>

<b>Choose one to modify</b><hr>

<ul>

<?php

$q=$funk->num_vals("SELECT * FROM forums ORDER BY order_by");

while(list($i,$v) = each($q)) {

$name=$funk->db_query("SELECT name FROM forums WHERE forumid='$v'");

echo "<li><a href=\"forums.php?action=modify&f=$v\">$name</a>";

}

echo "</ul>";

	}

?>

</body></html>

<?php

} elseif($action=='addforum') {

if($f) {

if(!$forumname || !$forumdesc || !$forumord) {
die("Please complete all the fields.");
}

$forumname=addslashes($forumname);
$forumdesc=addslashes($forumdesc);

$x=$funk->db_query("SELECT count(*) from forums");

$x++;

$funk->ins_vals("INSERT INTO forums
VALUES('$x','$forumname','$forumdesc','$forumord','0','0','None','$catno')");

die("Forum added.");

} else {

?>

<html>
<body>
<p><b>Add a Forum</b><hr></p>

<form action="forums.php" method="POST">
<input type="hidden" name="action" value="addforum">

<p>
Forum Name:<br>
<input size="30" name="forumname">
</p>

<p>
Description:<br>
<input size="50" name="forumdesc">
</p>

<p>
Forum Order: (1,2 etc...)
<input size="3" name="forumord">
</p>


<p>
Category:<br>
<?
$cats=$funk->num_vals("SELECT * FROM funkcats");
while(list($i,$cat)=each($cats)) {
$name=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$cat'");
echo "<input type=\"radio\" name=\"catno\" value=\"$cat\">$name ";
}
?>
</p>


<p>
<input type="submit" name="f" value="add_forum">
</p>

</form>
</body>
</html>

<?php
}


} elseif($action=="delete") {

?>

<html>
<body>

<?php

if($f) {

if($do) {

$funk->ins_vals("DELETE FROM forums WHERE forumid='$f'");

die("Forum successfully deleted.");

} else {

echo "<b>Confirm</b><hr>";
echo "Are you sure you want to delete this forum: ";

$name=$funk->db_query("SELECT name FROM forums WHERE forumid='$f'");

echo "<b>" . $name . "</b>?";

?>

<form action="forums.php" method="POST">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="f" value="<?php echo "$f"; ?>">
<input type="submit" name="do" value="yes">
</form>

<?php
}

} else {

?>

<b>Choose one to delete</b><hr>

<ul>

<?php

$q=$funk->num_vals("SELECT * FROM forums ORDER BY order_by");

while(list($i,$v) = each($q)) {

$name=$funk->db_query("SELECT name FROM forums WHERE forumid='$v'");

echo "<li><a href=\"forums.php?action=delete&f=$v\">$name</a>";

}

}

?>

</body></html>

<?php

} elseif($action=="orderf") {

if(!$do) {

?>

<html><body>
<b>Order the Forums</b><hr>

<form action="forums.php" method="POST">

<?php
// display forum order

$c=$funk->num_vals("SELECT * FROM forums ORDER BY order_by");

while(list($i,$f)=each($c)) {

list($name,$order)=$funk->mul_vals("SELECT name,order_by FROM forums WHERE forumid='$f'");

echo "$name <input size=2 name=order_by[$f] value=$order><br>";

}

?>
<input type="hidden" name="action" value="orderf">
<input type="submit" name="do" value="order_forums">
</form>
</body></html>

<?php

} else {

// process form

$c=$funk->num_vals("SELECT * FROM forums ORDER BY order_by");

while(list($i,$f)=each($c)) {

$funk->ins_vals("UPDATE forums SET order_by='$order_by[$f]' WHERE forumid='$f'");

}

die("Ordering complete.");

}
}

?>
