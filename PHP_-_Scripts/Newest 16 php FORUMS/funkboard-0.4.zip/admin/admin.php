<?php

require("global.php");

/*
require("../info.php");
require("../db/$dbtype.php");
$funk=new db_sql;
$pass=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='adminpass'");
*/

$pass=templates(adminpass);

$pass=crypt($pass,'.N');

if($fbadmin==$pass) {

$ext=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='extension'");

if(!$action) {

echo "
<html>
<head>
<STYLE type=text/css>
BODY {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
P {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
</STYLE>
<title>Funk Board Control Panel</title>
<frameset rows=\"30,*\">
<frame src=\"admin.$ext?action=head\" name=\"head\" scrolling=\"NO\">
<frameset cols=\"170,*\">
<frame src=\"admin.$ext?action=leftframe\" name=\"nav\" scrolling=\"AUTO\">
<frame src=\"admin.$ext?action=mainframe\" name=\"main\" scrolling=\"AUTO\">
</frameset>
</frameset>
</head>
</html>
";

} else {

if($action == 'head') {

echo "
<html>
<head>
<STYLE type=text/css>
BODY {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
P {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
</STYLE>
</head>
<body topmargin=2 bottomMargin=2>

<table border=0 width=\"80%\">
<tr>
<td valign=top nowrap>
<p><b>FunkBoard Control Panel (v0.4)</b></p>
</td>
<td valign=top nowrap>
<p><b><a href=\"../index.$ext\" target=\"_top\">Forums Home Page</a></b></p>
</td>
</tr>
</table>
</body>
</html>
";

} elseif($action == 'leftframe') {
?>

<html>
<head>
<STYLE type=text/css>
BODY {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
P {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
</STYLE><base target="main"></head>
<body>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Forums</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="forums.<?php echo "$ext"; ?>?action=addforum">Add</a><br>
<a href="forums.<?php echo "$ext"; ?>?action=modify">Modify</a><br>
<a href="forums.<?php echo "$ext"; ?>?action=delete">Delete</a><br>
<a href="forums.<?php echo "$ext"; ?>?action=orderf">Order</a></p></td>
</tr>
</table>
</td></tr></table>
<BR>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Categories</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="cats.<?php echo "$ext"; ?>?action=addcat">Add</a><br>
<a href="cats.<?php echo "$ext"; ?>?action=modcat">Modify</a><br>
<a href="cats.<?php echo "$ext"; ?>?action=delcat">Delete</a><br>
<a href="cats.<?php echo "$ext"; ?>?action=orderc">Order</a></p></td>
</tr>
</table>
</td></tr></table>
<BR>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Settings</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="style.<?php echo "$ext"; ?>?action=editst">Edit Styles</a><br>
<a href="style.<?php echo "$ext"; ?>?action=dosett">Global Settings</a><br>
</tr>
</table>
</td></tr></table>
<BR>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Moderators</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="moderators.<?php echo "$ext"; ?>?action=addmod">Add/Edit</a><br>
</tr>
</table>
</td></tr></table>
<BR>


<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>User Titles</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="usertitles.<?php echo "$ext"; ?>?action=editbasic">Basic Ranks</a><br>
<a href="usertitles.<?php echo "$ext"; ?>?action=addtitle">Make New</a><br>
<a href="usertitles.<?php echo "$ext"; ?>?action=grantitle">Grant Title</a><br>
<a href="usertitles.<?php echo "$ext"; ?>?action=edititle">Edit Titles</a><br>
<a href="usertitles.<?php echo "$ext"; ?>?action=deltitle">Delete Title</a>
</p></td>
</tr>
</table>
</td></tr></table>
<BR>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Templates</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="templates.<?php echo "$ext"; ?>?action=templates">Modify</a><br>
<a href="templates.<?php echo "$ext"; ?>?action=addtemplate">Add New</a><br>
</tr>
</table>
</td></tr></table>

<br>

<table width="100%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font color="#ffffff"><p><b>Log Out</b></p></td>
</tr>
<td bgcolor="#ffffff"><P>
<a href="admin.<?php echo "$ext"; ?>?action=logout" target="_top">Log Out</a><br>
</tr>
</table>
</td></tr></table>
</body>
</html>

<?php
}
elseif($action == 'mainframe') {
?>

<html>
<head>
<STYLE type=text/css>
BODY {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
P {
  font-family: arial;
  font-size: 10pt;
  font-variant: normal;
  font-style: normal;
}
</STYLE>
<title>Funk Board Control Panel</title>
</head>
<body>
<table width="85%" border=0 cellpadding=0 cellspacing=0 align="center"><tr><td bgcolor="#336699">
<table width="100%" border=0 cellpadding=3 cellspacing=2>
<tr>
<td align="right"><font size=3 face="Arial, Verdana" color="#ffffff"><b>Welcome to the Funk Board Control Panel</b></font></td>
</tr>
<tr>
<td bgcolor="#ffffff">

<p>
Welcome. To start your board, you need to edit the standard category and forum
that were added during the installation. Remember, forums have to have a
category, even if there is just one main category for all the forums.
Any other guidelines can be found through the links on the left.
</p>

<p><b>Links</b><br>
&nbsp;&nbsp;&nbsp;<a href="http://funkboard.sourceforge.net/" target="_blank">Funk Board Home Page</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.sleepy.f2s.com/fb/" target="_blank">Funk Board Support Forums</a><br>
</p>
<p>
&nbsp;&nbsp;&nbsp;<a href="http://www.php.net/" target="_blank">PHP Home Page</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.mysql.com/" target="_blank">MySQL Home Page</a><br>
</p>

<p><b>Developers and Contributors:</b><br>
&nbsp;&nbsp;&nbsp;<a href="mailto:bort@oceanfree.net">Paul Murphy</a>: <I>Founder and Developer.</i><br>
&nbsp;&nbsp;&nbsp;<a href="mailto:nickbrown@f2s.com">Nicholas Brown</a>:
<I>Admin HTML design, and stuff.</i></p>

</td>
</tr>
</table>
</td></tr></table>
</body>
</html>

<?php

} elseif($action=='logout') {
setcookie("fbadmin", "");

echo "
<head>
<meta http-equiv=\"refresh\" content=\"1; url=index.php\">
</head>
You're logged out. You're being forwarded back to the login page.
";

}
}

} else {
die("Not a valid administrator. You need to login with a cookie-enabled browser.");
}
?>
