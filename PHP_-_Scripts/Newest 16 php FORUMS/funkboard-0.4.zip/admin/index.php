<?php

require("global.php");

$ext=templates(extension);

if(!$action) {

echo "
<html>
<head>
</head>
<b>FunkBoard Admin Login</b>
<p>
<form method=\"POST\" action=\"index.$ext\">
<input type=\"password\" name=\"password\" size=\"30\">
<input type=\"submit\" name=\"action\" value=\"login\">
</form>
</html>
";

} else {

$thing=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='adminpass'");

if($password==$thing) {

	if(isset($fbadmin)) {
die("You are already logged in, please go to that window.");
	}

$password=crypt($password,'.N');

setcookie("fbadmin", $password);

echo "
<head>
<meta http-equiv=\"refresh\" content=\"1; url=admin.$ext\">
I am setting a cookie to ensure the security of the admin area. You will
be forwarded to the Control Panel in a sec.
";


} else {

die("Pass incorrect.");
}


}
?>
