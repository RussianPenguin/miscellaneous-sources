<?php

require("global.php");

check_bb_status();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$boardname=templates(boardname);

$myhtml->top_html("$boardname > Search","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Search");

if(!$action) {
?>

<p>
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<form action="search.<? echo "$ext"; ?>" method="POST">
<th colspan="2" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Search</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Search Word:
</td>
<td bgcolor="<? echo "$alt2"; ?>">
<input size="30" name="searchword">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Search in Forums:
</td>
<td bgcolor="<? echo "$alt2"; ?>">
<select name="id">
<option value="">Search All Forums
<?php
$x=$funk->num_vals("SELECT * FROM forums");

while(list($i,$value)=each($x)) {
$forumname=$funk->db_query("SELECT name FROM forums WHERE forumid='$value'");
echo "<option value=\"$value\">$forumname";
}
?>

</select>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Search method:
</td>
<td bgcolor="<? echo "$alt2"; ?>">
<select name="method">
<option value="posts">In posts
<option value="headings">In headings only
</select>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Submit Search Query
</td>
<td bgcolor="<? echo "$alt2"; ?>">
<input type="hidden" name="action" value="search">
<input type="submit" value="Search!">
</td>
</tr>
</form>
</table>
</p>

<?php
} else {

if(!$searchword) {funkdie("Enter a word","Please enter a search word.");}
white_check($searchword);

// formulate the sqluery
if($method=="posts") {
	$what="reply";
} elseif($method=="headings") {
	$what="title";
}
$q="SELECT threadid FROM posts WHERE $what LIKE '%$searchword%'";

if($id) {
$q.="&& forumid='$id'";
}

$threads=$funk->num_vals($q);
rsort($threads); // sort the array, newest first
?>

<p align="right">
<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr>
<td align="center" bgcolor="<? echo "$trcolor"; ?>" width="65%"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Thread</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Author</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Replies</font></span></b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Last Post</font></span></b></td>
</tr>

<?
while( list(,$v)=each($threads) ) {

list($title,$author,$replies,$time)=$funk->mul_vals("SELECT title,lastposter,replies,lastpost FROM list WHERE threadid='$v'");
list($name,$status)=user_stuff($author);
$time=date("d M Y @ H:i",$time);

echo "<tr>
<td bgcolor=\"$alt1\">
<a href=\"thread.php?id=$v\">$title</a>
</td>
<td bgcolor=\"$alt2\" align=\"center\">
$name
</td>
<td bgcolor=\"$alt1\" align=\"center\">
$replies
</td>
<td bgcolor=\"$alt2\" align=\"center\">
$time
</td>
</tr>";

}

?>

</table>

<?php
}

$myhtml->end_html();
?>
