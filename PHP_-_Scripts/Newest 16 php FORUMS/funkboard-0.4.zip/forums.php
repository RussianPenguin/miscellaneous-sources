<?php

if(ereg("cat",$id)) { Header("Location: index.php?skipcookie=1"); }

require("global.php");

check_bb_status();

$forumname=$funk->db_query("SELECT name FROM forums WHERE forumid='$id'");

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > $forumname","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > $forumname");

// if no name is returned, the forum can't exist anyway
if(!$forumname) {
funkdie("Forum not Found","No forum found. If you followed a valid link, please contact the administrator.");
}

?>

<p align="right">
<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr><td colspan="4">
<?
$threadsperpage=10;

// grab all the thread ids
$x = $funk->num_vals("SELECT threadid FROM list WHERE forumid='$id' ORDER by lastpost DESC");

// deal with pages
$p=sizeof($x);
$np=($p/$threadsperpage);
$np=ceil($np);

if($np>1) { // as long as there is more than 1 page
$pages="This forum has $np pages (";
for($y=1;$y<=$np;$y++) {
$pages.="<a href=\"forums.php?id=$id&page=$y\">$y</a> ";
}
$pages=chop($pages);
$pages.=")";
}
// print the pages stuff
echo $pages;
////////////////////
?>
</td><td colspan="3" align="right">
<?
$newtopic=templates(newtopic);
$newtopic=str_replace("\$ext","$ext",$newtopic);
$newtopic=str_replace("\$number","$id",$newtopic);
echo $newtopic;
?>
</td>
</tr>

<tr>
<td align="center" bgcolor="<? echo "$trcolor"; ?>" width="45%" colspan="3"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Thread</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Author</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Replies</font></span></b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Views</font></span></b></td>
<td bgcolor="<? echo "$trcolor"; ?>" align="center"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Last Reply</font></span></b></td>
</tr>

<?php
if(!$page) {$page='1';}
$offset=($page*$threadsperpage);
$start=($offset-$threadsperpage);

// first, get rid of threads too new (if multiple pages exist)
for($y=0;$y<$start;$y++) {
unset($x[$y]);
}

// get rid of threads too old
end($x);
$y=(sizeof($x)-1); // arrays start at 0...

while( sizeof($x)>$threadsperpage ) {
unset($x[$y]); $y--;
}

// reset the arrays pointer
reset($x);

// make the listing
while(list($i,$value)=each($x)) {

list($forumid,$threadid,$title,$iconid,$views,$replies,$lastposter,$lastpost,$thstatus)=$funk->mul_vals("SELECT * FROM list WHERE threadid='$value'");

if($thstatus=="0") {
	$image='closed';
} else {
	if($lastpost < $nbbvisit) {
	$image='folder';
	} else {
	$image='redfolder';
	}
}

if($iconid == '0') {
$iconhtml='&nbsp;';
} else {
$iconhtml= ('icon' . $iconid);
$iconhtml=('<img src="images/icons/' . $iconhtml . '.gif">');
}

$postdate=date("d M Y @ H:i",$lastpost);

if($lastposter==0) {
$lastposter="Anonymous";
} else {
$lastposter=$funk->db_query("SELECT name FROM members WHERE uid='$lastposter'");
}

$title=stripslashes($title);

echo "<tr>
<td align=\"center\" bgcolor=\"$alt1\" align=\"center\" width=\"8%\">
<img src=\"images/$image.gif\">
</td>
<td align=\"center\" bgcolor=\"$alt2\" align=\"center\" width=\"8%\">
$iconhtml
</td>
<td bgcolor=\"$alt1\">
<a href=\"thread.$ext?id=$threadid\">$title</a>
</td>
<td bgcolor=\"$alt2\" align=\"center\">
$lastposter
</td>
<td bgcolor=\"$alt1\" align=\"center\" width=\"8%\">
$replies
</td>
<td bgcolor=\"$alt2\" align=\"center\" width=\"8%\">
$views
</td>
<td bgcolor=\"$alt1\" align=\"center\">
$postdate
</td>
</tr>";
}

?>

<tr bgcolor="<? echo "$trcolor"; ?>">
<td colspan="7" align="right">
<font color="<? echo "$trtext"; ?>"><b>
<span class="ms">Times in <?php echo templates(timezone); ?></span>
</b></font>
</td>
</tr>
<tr>
<td colspan="4">
<? echo $newtopic; ?>
</td><td colspan="3" align="right">
<? echo $pages; ?>
</tr>
</table>
</p>

<table cellspacing="1" cellpadding="2" border="0" width="100%">
<tr>
<td><img src="images/redfolder.gif" align="right"></td>
<td><span class="ms"><b>New posts since your last visit</b></span></td>
</tr>
<tr>
<td><img src="images/folder.gif" align="right"></td>
<td><span class="ms"><b>No new posts since your last visit</b></span></td>
</tr>
</table>

<?php
echo forum_jump();

$myhtml->end_html();
?>
