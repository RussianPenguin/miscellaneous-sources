<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();


if(!$action) {

echo templates(tophtml);
echo templates(style);

$myhtml->top_html("$boardname > Reset Cookies","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Reset Cookies");

?>

<p>
<form action="prefs.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Enter User Info</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top" width="20%">
<b>Name</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="name" value="<? echo "$fbusername"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass" value="<? echo "$fbpassword"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="action" value="reset">
<input type="submit" value="Submit">
</td>
</tr>
</table>
</form>
</p>

<? } elseif($action=='reset') {

// cookies
setcookie("fbusername", $name, mktime(0,0,0,0,0,2020), $cookiepath);
setcookie("fbpassword", $pass, mktime(0,0,0,0,0,2020), $cookiepath);

$myhtml->top_html("$boardname > Reset Cookies","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Reset Cookies");

funkdie("Preferences","Username and password now stored in cookies.");

}

$myhtml->end_html();
?>
