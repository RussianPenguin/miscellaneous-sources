<?php

// server name, eg. localhost
$server = 'localhost';
// your database's name
$dbname = 'mydb';
// your username to access that database
$dbuser = 'username';
// your password to access that database
$dbpass = 'password';

// a contact email for when errors arise
$email = 'you@yourdomain.com';

// database engine- only support for mysql now. hope to have support for
// postgresql also
$dbtype='mysql';

?>
