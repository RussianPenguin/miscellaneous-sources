<?php
require("global.php");
check_bb_status();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > FAQ","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > FAQ");
?>

<hr>
<p><b>FAQ</b></p>

<ul>
<li><a href="#faq">What's a FAQ?</a>
<li><a href="#html">Can I use HTML?</a>
<li><a href="#cookies">Are cookies used on this board?</a>
<li><a href="#register">Can I/Do I have to register?</a>
<li><a href="#editposts">Can I edit my posts?</a>
<li><a href="#search">Can I search?</a>
<li><a href="#icons">What are the icon things?</a>
<li><a href="#nec">What fields do I need to fill out when I'm making a post?</a>
<li><a href="#smilies">What are/how do I use smilies?</a>
</ul>
<hr>
<p>
<a name="faq"><b>What's a FAQ?</b></a><br>
It's the "frequently asked questions." This is a list of annoying questions
everyone is tired of being helpful with, dealing with simple things like
smilies and bb code, and info about posting  and the board's functions. If
you're confused, just read through this and some things should be cleared up,
hopefully. :)

</p>

<p>
<a name="html"><b>Can I use HTML?</b></a><br>
Nope. HTML tags can include JavaScript and stuff which can do not nice
things. There is a simple code to replace HTML. <a href="bbcode.php">Find
it here</a>. This provides some of the functions of HTML, like links,
some text formatting and images.
</p>

<p>
<a name="cookies"><b>Are cookies used on this board?</b></a><br>
Yes, cookies remember when you last visited so new forums, threads
and posts will appear with a cool "new post" icon beside them if posts
are made since you last visited. :) If you register, your username and
password will also be stored in cookies.
</p>

<p>
<a name="register"><b>Can I/Do I have to register?</b></a><br>
No. You can post without registering, by leaving the username and password
fields blank. You can register if you like, though.
</p>

<p>
<a name="editposts"><b>Can I edit my posts?</b></a><br>
No. This isn't enabled yet. If you need something done quickly, you can
contact your administrator.
</p>

<p>
<a name="search"><b>Can I search?</b></a><br>
Yes, just click on the inventively labelled "search" button at the
top of every page in the board. Searching is straightforward: enter
a keyword, and it will search for occurences of it in messages or headings.
</p>

<p>
<a name="icons"><b>What are the icon things?</b></a><br>
They're just random things. You don't need to enter one. You can enter
a smiley or an icon to represent the message of your post in graphic form. ;)
They're pretty pointless, but cool all the same. :p
</p>

<p>
<a name="nec"><b>What fields do I need to fill out when I'm making a post?</b></a><br>
Your message are always required If you are posting anonymously, leave
the username/password fields blank. If you are making a new topic, you'll need
to enter a subject because something needs to appear on the forum thread
listing.
</p>

<p>
<a name="smilies"><b>What are/how do I use smilies?</b></a><br>
Smilies are internet-based facial expressions. :p They convert something
like <b>:)</b> into something like <img src="images/smilies/smile.gif">.
There is a table explaining how to use all the smilies <a
href="smilies.php">here</a>. Just type the "how to do it"
thingy into your message, and the board will convert it to a graphic smiley.
</p>

<?
$myhtml->end_html();
?>
