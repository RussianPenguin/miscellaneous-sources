<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

//////////////////////////
// get rid of cookies
if(isset($fbusername)) {
setcookie("fbusername", "", mktime(0,0,0,0,0,2020), $cookiepath);
$msg="Username cookie deleted. ";
} else {
$msg="No username cookie to delete. ";
}

if(isset($fbpassword)) {
setcookie("fbpassword", "", mktime(0,0,0,0,0,2020), $cookiepath);
$msg.="Password cookie deleted. ";
} else {
$msg.="No password cookie to delete. ";
}

$msg.="Cookies can be reset in &quot;preferences.&quot;";
// end cookie stuff
//////////////////////////

$myhtml->top_html("$boardname > Logout","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Logout");

funkdie("Cookies",$msg);
?>
