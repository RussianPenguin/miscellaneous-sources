<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$title=$funk->db_query("SELECT title FROM list WHERE threadid='$id'");

if($action=="thread") {

$myhtml->top_html("$boardname > Open/Close/Delete: $title","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Open/Close/Delete: <i>$title</i>");

	if($do) {

list($uid,$rname,$rpass,$status)=$funk->mul_vals("SELECT uid,name,pass_word,status FROM members WHERE name='$name'");

if(!$rname) {funkdie("No such user","There is no such user- you may have entered your information incorrectly.");}
if($pass!=$rpass) {funkdie("Error","The password you entered was incorrect- please try again.");}

$forumid=$funk->db_query("SELECT forumid FROM list WHERE threadid='$id'");

// get admin value for the status if it's not a standard one that has authority
$isadmin=$funk->db_query("SELECT admin FROM status WHERE uid='$status'");

if(!$threadfunc) { funkdie("Error","Please include a function to perform."); }

// admins -> do thread functions
if( $status=="0" ) {
	do_thread($threadfunc,$id);
}

// mods -> make sure they're mods of this forum first
elseif( mod_check($uid,$forumid)=="1" ) {
	do_thread($threadfunc,$id);
	}

// if it's none of those, we need to check for the special rank things.
// mar 14 2001: i've decided now, that only people with the "admin" option
// enabled with special ranks can do threads funcs. having only "edit"
// enabled will not allow them to perform these functions.

elseif( $isadmin=="1" ) {
	do_thread($threadfunc,$id);
} else {
	funkdie("Error","You don't have the authoritah to do that.");
}
?>

<p>
Topic function completed! <a href="forums.php?id=<? echo "$forumid"; ?>">Click
here</a> to go back to the updated forum listing.
</p>

<?
	} else {
?>

<p>
<table cellspacing="1" cellpadding="3" border="0" width="100%">
<th colspan="2" bgcolor="<?echo $trcolor;?>"><font color="<?echo $trtext;?>"
class="ms">Thread Functions</font></th>

<form action="moderate.php" method="POST">

<tr>
<td bgcolor="<?echo $alt1;?>" width="60%">
<p>Username:<br><input size="30" name="name" value="<?echo $fbusername;?>"></p>
<p>Password:<br><input type="password" size="30" name="pass" value="<?echo $fbpassword;?>"></p>
</td>
<td bgcolor="<?echo $alt1;?>" width="40%">
<p>
<input type="radio" name="threadfunc" value="open" CHECKED> Open this thread<br>
<input type="radio" name="threadfunc" value="close"> Close this thread<br>
<input type="radio" name="threadfunc" value="delete"> Delete this thread<br>
</p>
</td>
</tr>

<tr>
<td colspan="2" bgcolor="<?echo $alt2;?>">
<input type="hidden" name="action" value="thread">
<input type="hidden" name="id" value="<?echo $id;?>">
<input type="submit" name="do" value="Submit">
</td></tr>

</form>

</table>
</p>

<?
	}
} // action loop, add elseif() thingies to add new actions
?>


<?
$myhtml->end_html();
?>
