<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

if(!$action) {

echo templates(tophtml);
echo templates(style);

$myhtml->top_html("$boardname > Register","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Register");

?>

<p>
<form action="register.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Register!</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top" width="20%">
<b>Name</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="name">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Confirm Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="cpass">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>E-mail</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="fmail">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Homepage
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="www">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
ICQ
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="icq">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Location
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="location">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Hobbies/Interests
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="interebbies">
</td>
</tr>



<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="action" value="register">
<input type="submit" value="Register!">
</td>
</tr>
</table>
</form>
</p>

<?



} elseif($action=='register') {

white_check($name);
white_check($pass);
white_check($fmail);

if($pass!=$cpass) {funkdie("Passwords","Your password does not match.");}
if(!eregi("@",$fmail)) {funkdie("Not a valid email address","Your email address must contain an @ in it.");}

// formulate sqluery
$x=$funk->db_query("select count(*) from members");
$x++;

$q="INSERT INTO members VALUES('$x','$name','$pass','$fmail','0','4','$www','$icq',
'$time','$location','$interebbies')";

$funk->ins_vals($q);

mail("$fmail","$boardname Registration","Hi!\nWelcome to $boardname. Here is your information:\nUsername: $name\nPassword: $pass\nHave fun!");

// cookies
setcookie("fbusername", $name, mktime(0,0,0,0,0,2020), $cookiepath);
setcookie("fbpassword", $pass, mktime(0,0,0,0,0,2020), $cookiepath);

$myhtml->top_html("$boardname > Register","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Register");

funkdie("Thanks for registering!","Thanks for registering, your information
has been emailed to you.");

}

$myhtml->end_html();
?>
