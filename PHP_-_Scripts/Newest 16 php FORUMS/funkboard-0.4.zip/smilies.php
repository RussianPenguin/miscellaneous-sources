<?php

require("global.php");

check_bb_status();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > Smilies","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Smilies");
?>

<p>
<table cellspacing="1" cellpadding="4" border="0" width="100%">
<tr bgcolor="<? echo "$trcolor"; ?>">
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
Smiley
</font></span></b>
</td>
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
Represents
</font></span></b>
</td>
<td align="center">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">
How to do it
</font></span></b>
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/smile.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
A smile. :)
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
:)
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/wink.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
A wink...
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
;)
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/tongue.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Sticking out tongue
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
:p
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/frown.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
A frown...
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
:(
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/laugh.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Laughing
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
:D
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/mad.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Mad
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
:|
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
<img src="images/smilies/cool.gif">
</td>
<td bgcolor="<? echo "$alt2"; ?>" align="center">
Cool 
</td>
<td bgcolor="<? echo "$alt1"; ?>" align="center">
8)
</td>
</tr>
</table>
</p>

<?php
$myhtml->end_html();
?>
