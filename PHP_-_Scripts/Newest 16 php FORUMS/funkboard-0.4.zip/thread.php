<?php

require("global.php");

check_bb_status();

list($title,$forumid)=$funk->mul_vals("SELECT title,forumid from posts WHERE threadid='$id' && replyid='1'");
list($number,$forumname)=$funk->mul_vals("SELECT forumid,name FROM forums WHERE forumid='$forumid'");

// if the title wasn't returned, there can't be a thread so return an error
if(!$title) {
funkdie("Thread not found","That thread could not be found.");
}

// VIEWS
$views=$funk->db_query("SELECT views FROM list WHERE threadid='$id'");
$views++;

$funk->ins_vals("UPDATE list SET views='$views' WHERE threadid='$id'");

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > $forumname > $title","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > <a href=\"forums.php?id=$number\"><b>$forumname</b></a> > $title");

?>

<p>

</p>

<p align="right">
<?
$printable=templates(printthread);
$printable=str_replace("\$ext","$ext",$printable);
$printable=str_replace("\$id","$id",$printable);
echo $printable;
?>
</p>

<p align="right">
<?
$newreply=templates(newreply);
$newreply=str_replace("\$ext","$ext",$newreply);
$newreply=str_replace("\$number","$number",$newreply);
$newreply=str_replace("\$id","$id",$newreply);

$status=$funk->db_query("SELECT status FROM list WHERE threadid='$id'");

// is it closed?
if($status=="0") {
$newreply=str_replace("Post Reply","Topic Closed",$newreply);
}

echo $newreply;
?>

<table cellspacing="1" cellpadding="3" border="0" width="100%">
<tr>
<td bgcolor="<? echo "$trcolor"; ?>" width="20%"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Author</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Message</font></span>
</b></td>
</tr>

<?php

$x=$funk->db_query("SELECT count(*) FROM posts WHERE threadid='$id'");

$alt=$alt1;

$y=1;

while($y<=$x) {

list($threadid,$forumid,$replyid,$title,$iconid,$name,$reply,$lastpost)=$funk->mul_vals("SELECT * FROM posts WHERE threadid='$id' && replyid='$y'");

list($rname,$status)=user_stuff($name);

if($lastpost < $nbbvisit) {
$posticon='posticon';
} else {
$posticon='newposticon';
}

if($iconid == '0') {
$iconhtml='';
} else {
$iconhtml= ('icon' . $iconid);
$iconhtml=('<img src="images/icons/' . $iconhtml . '.gif">');
}

$postdate=date("d M Y @ H:i",$lastpost);

$title=stripslashes($title);
$reply=stripslashes($reply);

echo "<tr>
<td bgcolor=\"$alt\" valign=\"top\">
<span class=\"s\"><b>$rname</b><br></span><span class=\"ms\">$status</span>
</td>
<td bgcolor=\"$alt\">
<p>
$iconhtml
<span class=\"ms\"><b>$title</b></span>
</p>
<span class=\"s\">$reply</span>
</td></tr>
<tr><td bgcolor=\"$alt\">
<img src=\"images/$posticon.gif\"> <span class=\"ms\">$postdate</span>
</td><td bgcolor=\"$alt\">";
if($name==0) {
echo "&nbsp;";
} else {
echo "
<a href=\"users.php?profile=$name\" target=\"_new\"><img src=\"images/profile.gif\" alt=\"View $rname's profile\" border=\"0\"></a>
&nbsp;
<a href=\"users.php?mail=$name\"><img src=\"images/email.gif\" border=\"0\" alt=\"Email $rname\"></a>
</td>
</tr>
";
}

if($alt==$alt1) {
$alt=$alt2;
} else {
$alt=$alt1;
}

$y++;

}
?>

<tr bgcolor="<? echo "$trcolor"; ?>">
<td colspan="2" align="right">
<font color="<? echo "$trtext"; ?>"><b>
<span class="ms">Times in <?php echo templates(timezone); ?></span>
</b></font>
</td>
</tr>
<tr><td>
<?
echo $newreply;
?>
</td><td align="right">
<font class="ms">Administrative Functions: </font><a class="ms" href="moderate.php?action=thread&id=<? echo $id; ?>">Open/Close/Delete Thread</a>
</td></tr>
</table>
</p>

<?php

echo forum_jump();

$myhtml->end_html();
?>
