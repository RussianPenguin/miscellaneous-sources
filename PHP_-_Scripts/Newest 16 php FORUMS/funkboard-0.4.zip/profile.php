<?php

require("global.php");

check_bb_status();

$time=time();

list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > Profile","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > Profile");

if(!$action) {

?>

<p>
<form action="profile.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Login</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top" width="20%">
<b>Name</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="name" value="<? echo "$fbusername"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass" value="<? echo "$fbpassword"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="action" value="edit">
<input type="submit" value="Login!">
</td>
</tr>
</table>
</form>
</p>

<? } elseif($action=='edit') {

list($rname,$rpass)=$funk->mul_vals("SELECT name,pass_word FROM members WHERE
name='$name'");

if(!$rname) {funkdie("No such user","There is no such user- you may have entered your information incorrectly.");}
if($pass!=$rpass) {funkdie("Error","The password you entered was incorrect- please try again.");}

list($uid,$fmail,$www,$icq,$location,$random)=$funk->mul_vals("SELECT uid,email,www,icq,location,random FROM members WHERE name='$name'");

?>

<p>
<form action="profile.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Profile</font></span></b>
</th>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top" width="20%">
<b>Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass" value="<?echo "$rpass";?>">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Confirm Password</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="cpass" value="<?echo "$rpass";?>">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>E-mail</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="fmail" value="<?echo "$fmail";?>">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Homepage
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="www" value="<?echo "$www";?>">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
ICQ
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="icq" value="<?echo "$icq";?>">
</td>
</tr>

<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Location
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="location" value="<?echo "$location";?>">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
Hobbies/Interests
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="interebbies" value="<?echo "$random";?>">
</td>
</tr>


<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="action" value="process">
<input type="hidden" name="uid" value="<?echo "$uid";?>">
<input type="submit" value="Edit Profile">
</td>
</tr>
</table>
</form>
</p>

<?

} elseif($action=='process') {

white_check($pass);
white_check($fmail);

if($pass!=$cpass) {funkdie("Passwords","Your password does not match.");}
if(!eregi("@",$fmail)) {funkdie("Not a valid email address","Your email address must contain an @ in it.");}

$q="UPDATE members SET pass_word='$pass',email='$fmail',www='$www',icq='$icq',location='$location',random='$interebbies' WHERE uid='$uid'";

$funk->ins_vals($q);

funkdie("Thanks for editing your profile!","Your profile info has been updated.");

}

$myhtml->end_html();
?>
