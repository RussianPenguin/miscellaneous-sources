<?php

require("global.php");

check_bb_status();

$time=time();

list($number,$forumname)=$funk->mul_vals("SELECT forumid,name FROM forums WHERE forumid='$forumid'");
list($title,$forum,$thread)=$funk->mul_vals("SELECT title,forumid,threadid FROM list WHERE threadid='$threadid'");
$limit=templates(replypostlimit);
list($boardname,$trcolor,$trtext,$alt1,$alt2,$ext)=special_get();

$myhtml->top_html("$boardname > $forumname > $title > Post Reply","<a href=\"index.php?skipcookie=1\"><b>$boardname</b></a> > <a href=\"forums.php?id=$number\"><b>$forumname</b></a> > <a href=\"thread.php?id=$thread\"><b>$title</b></a> > Post Reply");

if($forum!=$number) {
funkdie("Error","This reply is being posted to the wrong forum. Please stop messing around. :)");
}

if(!$action) {

$status=$funk->db_query("SELECT status FROM list WHERE threadid='$threadid'");
if($status=="0") { funkdie("Thread is closed","Sorry- this thread is closed, no replies are allowed."); }

?>

<p>
<form action="reply.<? echo "$ext"; ?>" method="POST">
<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="4" bgcolor="<? echo "$trcolor"; ?>">
<b><span class="ms"><font color="<? echo "$trtext"; ?>">Post a Reply</font></span></b>
</th>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Your Name</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="30" name="name" value="<?php echo "$fbusername"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Pass</b> <font color="#ff0000">*</font>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="password" size="30" name="pass" value="<?php echo "$fbpassword"; ?>">
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Subject</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input size="50" name="subject"> <span class="ms">(Optional)</span>
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Icon</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<?php
for($x=1;$x<=11;$x++) {
echo "<input type=\"radio\" name=\"iconid\" value=\"$x\">
<img src=\"images/icons/icon$x.gif\"> &nbsp; &nbsp;";
}
?>

<input type="radio" name="iconid" value="0" CHECKED> No icon
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Message</b> <font color="#ff0000">*</font>

<p>
<a href="faq.php" class="end" target="_blank">FAQ</a><br>
<a href="bbcode.php" class="end" target="_blank">BB Code</a><br>
<a href="smilies.php" class="end" target="_blank">Smilies</a><br>
</p>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<textarea rows="10" cols="50" name="msg" wrap="virtual"></textarea>
</td>
</tr>
<tr>
<td bgcolor="<? echo "$alt1"; ?>" valign="top">
<b>Submit</b>
</td>
<td bgcolor="<? echo "$alt2"; ?>" colspan="3">
<input type="hidden" name="forumid" value="<? echo "$forumid"; ?>">
<input type="hidden" name="threadid" value="<? echo "$threadid"; ?>">
<input type="hidden" name="action" value="addreply">
<input type="submit" value="Add Reply!">
</td>
</tr>
</table>
</form>
</p>
<p>

<table cellspacing="1" cellpadding="2" border="0" width="100%">
<th colspan="2">
<span class="ms">Last <? echo "$limit"; ?> Post(s): Latest First</span>
</th>
<tr>
<td bgcolor="<? echo "$trcolor"; ?>" width="20%"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Author</font></span>
</b></td>
<td bgcolor="<? echo "$trcolor"; ?>"><b>
<span class="ms"><font color="<? echo "$trtext"; ?>">Message</font></span>
</b></td>
</tr>

<?php
$x=$funk->db_query("SELECT count(*) FROM posts WHERE threadid='$threadid'");

$alt=$alt1;

$y=$x;

$l=($x-$limit);

while($y>$l) {

list($id,$forumid,$replyid,$title,$iconid,$name,$reply,$lastpost)=$funk->mul_vals("SELECT * FROM posts WHERE threadid='$threadid' && replyid='$y'");

if($lastpost < $nbbvisit) {
$posticon='posticon';
} else {
$posticon='newposticon';
}

if($iconid == '0') {
$iconhtml='';
} else {
$iconhtml= ('icon' . $iconid);
$iconhtml=('<img src="images/icons/' . $iconhtml . '.gif">');
}

$postdate=date("d M Y @ H:i",$lastpost);

if(isset($name) && isset($reply)) {
	if($name==0) {
	$name='Anonymous';
	} else {
	$name=$funk->db_query("SELECT name FROM members WHERE uid='$name'");
	}

$title=stripslashes($title);
$reply=stripslashes($reply);

echo "<tr>
<td bgcolor=\"$alt\" valign=\"top\">
<span class=\"s\"><b>$name</b></span>
<br>
<img src=\"images/$posticon.gif\"> <span class=\"ms\">$postdate</span><br>
</td>
<td bgcolor=\"$alt\" valign=\"top\">
$iconhtml
<span class=\"ms\"><b>$title</b></span>
<p>
<span class=\"s\">$reply</span>
</p>
</td>
</tr>";
}

if($alt==$alt1) {
$alt=$alt2;
} else {
$alt=$alt1;
}

$y--;

}
?>
</table>
</p>

<?php

} else {

	if($name=='') {
$name='0';
	} else {
list($uid,$rname,$rpass)=$funk->mul_vals("SELECT uid,name,pass_word FROM members WHERE
name='$name'");

if(!$rname) {funkdie("No such user","There is no such user- you may have entered your information incorrectly.");}
if($pass!=$rpass) {funkdie("Error","The password you entered was incorrect- please try again.");}

$posts=$funk->db_query("SELECT posts FROM members WHERE uid='$uid'");
$posts++;
$funk->ins_vals("UPDATE members SET posts='$posts' WHERE uid='$uid'");
status($uid);
	}

white_check($msg);

$msg=parse_msg($msg);
$msg=do_smilies($msg);
$msg=bbcodify($msg);

// add the post-y entry

// get the reply number
$x=$funk->db_query("SELECT count(replyid) FROM posts WHERE threadid='$threadid'");
$x++;

$funk->ins_vals("INSERT INTO posts VALUES('$threadid','$forumid','$x','$subject','$iconid','$uid','$msg','$time')");

// update the listy page
$wee=$funk->db_query("SELECT replies FROM list WHERE threadid='$threadid'");
$wee++;

$funk->ins_vals("UPDATE list SET replies='$wee', lastpost='$time' WHERE threadid='$threadid'");


// update the front page
$y=$funk->db_query("SELECT replies FROM forums WHERE forumid='$forumid'");
$y++;

$funk->ins_vals("UPDATE forums SET lastpost='$time', replies='$y' WHERE forumid='$forumid'");

?>

<meta http-equiv="refresh" content="3; url=<? echo "thread.php?id=$threadid"; ?>">

<p>
Your reply was added! <a href="thread.<? echo "$ext"; ?>?id=<? echo "$threadid"; ?>">Click
here</a> to go back to the thread, or you will be forwarded in 3 seconds.
</p>


<?php

}

$myhtml->end_html();
?>
