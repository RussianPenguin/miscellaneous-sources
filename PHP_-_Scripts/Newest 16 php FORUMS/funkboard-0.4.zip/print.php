<?php
require("global.php");

check_bb_status();

$title=$funk->db_query("SELECT title from posts WHERE threadid='$threadid' && replyid='1'");

// if the title wasn't returned, there can't be a thread so return an error
if(!$title) {
funkdie("Thread not found","That thread could not be found.");
}

$boardname=templates(boardname);

?>
<html><head><title><? echo "$boardname"; ?></title></head><body>

<?
$location="http://".getenv("SERVER_NAME").getenv("SCRIPT_NAME");
?>

<p>
<? echo "<b>$boardname</b> - $title";  ?>
<br>[<a href="thread.php?id=<? echo "$threadid"; ?>">Back</a>]<br>
<? echo "URL: $location?threadid=$threadid"; ?>
<hr>
</p>


<?php

$x=$funk->db_query("SELECT count(*) FROM posts WHERE threadid='$threadid'");

$y=1;

while($y<=$x) {

list($threadid,$forumid,$replyid,$title,$iconid,$name,$reply,$lastpost)=$funk->mul_vals("SELECT * FROM posts WHERE threadid='$threadid' && replyid='$y'");

$postdate=date("d M Y @ H:i",$lastpost);

if($iconid==0) {
$iconstuff='&nbsp';
} else {
$iconstuff="<img src=\"images/icons/icon$iconid.gif\">";
}

list($name,$status)=user_stuff($name);

$title=stripslashes($title);
$reply=stripslashes($reply);

echo "
<p>
$iconstuff
<b>$title</b><br>
Posted by $name on $postdate.<br>
<p>
$reply
</p></p>
<hr>
";

$y++;

}
?>

<p align="right"><b><font size="-1">
Times in <?php echo templates(timezone); ?>
</font></b></p>


<?php
$myhtml->end_html();
?>
