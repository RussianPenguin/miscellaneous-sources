<?php

require("info.php");
$time = time();

require("db/$dbtype.php");
$funk=new db_sql;

// assign these values to the stuff in the mysql library thingy
$funk->dbserver=$server;
$funk->name=$dbname;
$funk->user=$dbuser;
$funk->pass=$dbpass;
$funk->admin=$email;

require("html.php"); // the amazing html generator
$myhtml=new MyHTML;

/* CHANGE NEWLINES INTO HTML+ FILTER SPECIAL HTML CHARACTERS */
function parse_msg($thingy) {
$thingy=str_replace("<","&lt;",$thingy);
$thingy=str_replace("<","&gt;",$thingy);
$thingy=str_replace("\n","<br>",$thingy);
$thingy=addslashes($thingy);
return $thingy;
}

/* DO SMILIES- i don't think there's a need to make a table for them ;) */
function do_smilies($thingy) {
$thingy=str_replace(":)","<img src=\"images/smilies/smile.gif\">",$thingy);
$thingy=str_replace(":(","<img src=\"images/smilies/frown.gif\">",$thingy);
$thingy=str_replace("8)","<img src=\"images/smilies/cool.gif\">",$thingy);
$thingy=str_replace(":D","<img src=\"images/smilies/laugh.gif\">",$thingy);
$thingy=str_replace(":|","<img src=\"images/smilies/mad.gif\">",$thingy);
$thingy=str_replace(":p","<img src=\"images/smilies/tongue.gif\">",$thingy);
$thingy=str_replace(";)","<img src=\"images/smilies/wink.gif\">",$thingy);
return $thingy;
}

/* BB CODE- as above... */
function bbcodify($bbcode) {
$bbcode=eregi_replace("\\[url\\](http://)([^\\[]*)\\[/url\\]","<a href=\"http://\\2\" target=\"_blank\">\\2</a>",$bbcode);
$bbcode=eregi_replace("\\[email\\]([^\\[]*)\\[/email\\]","<a href=\"mailto:\\1\">\\1</a>",$bbcode);
$bbcode=eregi_replace("\\[img\\]([^\\[]*)\\[/img\\]","<img src=\"\\1\">\\1",$bbcode);
$bbcode=eregi_replace("\\[b\\]([^\\[]*)\\[/b\\]","<b>\\1</b>",$bbcode);
$bbcode=eregi_replace("\\[i\\]([^\\[]*)\\[/i\\]","<i>\\1</i>",$bbcode);
return $bbcode;
}

/* GET $value FROM THE TEMPLATES TABLE */
function templates($value) {
global $funk;
$value=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='$value'");
$value=stripslashes($value);
return $value;
}

/* A DIE SUBROUTINE (a funky one :p)- TAKE ERROR AND MSG FROM INPUT */
function funkdie($error,$msg) {
global $myhtml;
$trcolor=templates(trcolor);
$trtext=templates(trtext);
$alt1=templates(alt1);
$boardname=templates(boardname);
echo "<p><table cellspacing=\"1\" cellpadding=\"4\" border=\"0\" width=\"100%\">
<tr bgcolor=\"$trcolor\"><td><font color=\"$trtext\">
<span class=\"ms\"><b>$error</b></span>
</font></td></tr>
<tr bgcolor=\"$alt1\"><td>
$msg
</td></tr>
</table></p>
";
echo forum_jump();
$myhtml->end_html();
exit;
}

/* FORUM JUMP THINGY */
function forum_jump() {
global $funk;
$ext=templates(extension);
$jump = "
<p>
<table cellspacing=\"0\" border=\"0\" cellpadding=\"0\" width=\"100%\">
<tr><td align=\"right\">
<form action=\"forums.$ext\" method=\"GET\">
<p><b>Forum Jump:</b>
<select name=\"id\">
<option>Please Select One:
<option>--
";
$cats = $funk->num_vals("SELECT catid FROM funkcats ORDER BY order_by");
$catbg=templates(catbg);
while(list($ind,$cat)=each($cats)) {
$namecat=$funk->db_query("SELECT catname FROM funkcats WHERE catid='$cat'");
$jump .= "<option value=\"cat$cat\">$namecat";
$c = $funk->num_vals("SELECT forumid FROM forums WHERE category='$cat' ORDER BY order_by");
while(list($i,$value)=each($c)) {
$name=$funk->db_query("SELECT name FROM forums WHERE forumid='$value'");
$jump .= "<option value=\"$value\">&nbsp;&nbsp;&nbsp;$name";
	}
$jump .= "<option> --";
}
$jump .=
"</select>
<input type=\"submit\" value=\"Go\">
</form>
</td></tr></table>
</p>
";
return $jump;
}

/* COOKIE TIMES- for the cool little new message icons :) */
function time_cookies() {
global $time;
global $bbvisit;
global $nbbvisit;
$cookiepath=templates(cookiepath);
	if(isset($bbvisit)) {
	
// if they have visited before, update the cookies
setcookie("nbbvisit", $bbvisit, mktime(0,0,0,0,0,2020), $cookiepath);
setcookie("bbvisit", $time, mktime(0,0,0,0,0,2020), $cookiepath);
	} else {

// this is the never visited before eventuality
setcookie("nbbvisit", "0", mktime(0,0,0,0,0,2020), $cookiepath);
setcookie("bbvisit", $time, mktime(0,0,0,0,0,2020), $cookiepath);
	}
}

/* BULLETIN BOARD OFF- for maintenance or anything... */
function check_bb_status() {
$check=templates(bbactive);
	if($check=='yes') {
return;
	} else {
echo templates(tophtml);
$reason=templates(bbreason);
funkdie("Board closed","$reason");
	}
}

/* SPECIAL_GET- stuff needed by almost every script, text colours etc... */
function special_get() {
global $funk;
$boardname=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='boardname'");
$trcolor=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='trcolor'");
$trtext=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='trtext'");
$alt1=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='alt1'");
$alt2=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='alt2'");
$ext=$funk->db_query("SELECT templ_value FROM templates WHERE templ_name='extension'");
return array($boardname,$trcolor,$trtext,$alt1,$alt2,$ext);
}

/* WHITESPACE CHECK- see if someone has just entered whitespace as an entry */
function white_check($msg) {
// turn &nbsp;s into spaces to be fixed like normal spaces
$check=str_replace("&nbsp;"," ",$msg);
// cut out all spaces (in $check)
$check=str_replace(" ","",$check);

// if the message is nothing now, die
	if($check=="") {
echo templates(tophtml);
funkdie("Error","You need to complete the necessary fields.");
	}
}

/* GET USER STUFF */
function user_stuff($uid) {
global $funk;
	if($uid==0) {
return array("Anonymous","Unregistered");
	} else {
list($name,$status)=$funk->mul_vals("SELECT name,status FROM members WHERE uid='$uid'");
$status=$funk->db_query("SELECT title FROM status WHERE uid='$status'");
$status=stripslashes($status);
return array($name,$status);
	}
}

/* PROMOTE USERS, don't change special ranks, remember 4=junior etc... */
function status($uid) {
global $funk;

// set the posts needed to be promoted (auto-set to 10,30)
$member=templates(rank_member);
$senior=templates(rank_senior);

list($posts,$status)=$funk->mul_vals("SELECT posts,status FROM members WHERE uid='$uid'");
	if($status>4 || $status<=1) { // ignore special ranks, which begin at 5, and moderators(1) and admins(0)
	return;
	} else {
		if($posts>$member && $posts<$senior) {
			if($status==3) {
			return;
			} else {
			$funk->ins_vals("UPDATE members SET status='3' WHERE uid='$uid'");
			}
		} elseif($posts>$senior) {
			if($status==2) {
			return;
			} else {
			$funk->ins_vals("UPDATE members SET status='2' WHERE uid='$uid'");
			}
		}
	}
}

/* THREAD FUNCTION- the admin functions on threads */
function do_thread($function,$threadid) {
global $funk;
	if($function=="open") {
	$funk->ins_vals("UPDATE list SET status='1' WHERE threadid='$threadid'");
	} elseif($function=="close") {
	$funk->ins_vals("UPDATE list SET status='0' WHERE threadid='$threadid'");
	} elseif($function=="delete") {
	// uncount the deleted posts
	$gone=$funk->db_query("SELECT count(*) FROM posts WHERE threadid='$threadid'");
	$forumid=$funk->db_query("SELECT forumid FROM list WHERE threadid='$threadid'");
	$oldcount=$funk->db_query("SELECT replies FROM forums WHERE forumid='$forumid'");
	$x=($oldcount - $gone);
	$funk->ins_vals("UPDATE forums SET replies='$x' WHERE forumid='$forumid'");
	// delete everything
	$funk->ins_vals("DELETE FROM list WHERE threadid='$threadid'");
	$funk->ins_vals("DELETE FROM posts WHERE threadid='$threadid'");
	}
}

/* MODERATOR CHECK- check to see if user with $uid is a moderator of $forumid */
function mod_check($uid,$forumid) {
global $funk;
$mods=$funk->db_query("SELECT moderators FROM forums WHERE forumid='$forumid'");
$mods=explode(",",$mods);
	while( list($i,$v)=each($mods) ) {
		if($v==$uid) {
		return true;
		}
	}
}

?>
