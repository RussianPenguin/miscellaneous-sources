      </td>
    </tr>
    <tr> 
      <td height="5"> </td>
    </tr>
    <tr> 
      <td bgcolor="#CDD9FC" height="17"> 
<?include("../menubar_btm.php"); ?>
      </td>
    </tr>
    <tr> 
      <td height="1"></td>
    </tr>
    <tr> 
      <td> 
        <table width="100%" cellspacing="4">
          <tr> 
              
            <td> 
              <div align="center"><font size="2"><font color="#000066">Copyright 
                &copy; 2001</font><a href="mailto:datax@datax.com.ua">dataX</a> 
                </font> </div>
            </td>
            </tr>
          </table>
      </td>
    </tr>
  </table>
<? include("../counters.inc"); ?>
</div>
</BODY>
</HTML>
