#!/usr/local/bin/php
<?php

require("functions.php");
require("ini.php"); 
$languagefile = language();
require($languagefile);

$PHP_AUTH_USER="storm";
$PHP_AUTH_PW="";
if(!$PHP_AUTH_USER) {
    Header("WWW-authenticate: basic realm=\"BBBB Admin: Enter database username/password\"");
    Header("HTTP/1.0 401 Unauthorized");
    echo "<h1>HTTP/1.0 401 Unauthorized</h1>";
    exit;
}
else {
	if (!(@db_connect($PHP_AUTH_USER, $PHP_AUTH_PW))) {
		Header("HTTP/1.0 401 Unauthorized");
		echo "<h1>HTTP/1.0 401 Unauthorized</h1>";
		exit;
	} 
}

/*****   basic authentification against your mySQL username/password          ***/
/*****   (If you know how, you'd rather use .htaccess instead)                ***/
/*****   In this case, delete the lines above (up to +x+x+x+)                    ***/




/**** the admin stuff ****/

function adminquery() {
	
	global  $emailTable, $modify_message, $removeorphans, $delete_message, $delete_thread,
	       $name, $email, $topic, $body, $thread, $hostaddress, $date, $depth, $childof, $pos,
	       $IsOldPeriod, $unlock, $PHP_SELF;
	
	db_lock(TBL_FORUM);

	if($modify_message) {
		$name = ereg_replace("'", "&#039;", $name);
		$email = ereg_replace("'", "&#039;", $email);
		$topic = ereg_replace("'", "&#039;", $topic);
		$body = ereg_replace("'", "&#039;", $body);

		$query = dbq17(TBL_FORUM, $name, $email, $topic, $body, $thread, $hostaddress, $date, $depth, $childof, $pos, $modify_message);		
		db_query($query);
	}	
	elseif($delete_message) {
		 $query = dbq_sel(TBL_FORUM, $delete_message, "id");
		 $Result = db_query($query);
		 $pos = db_fetchcell($Result, 0, "pos");
		 
		 $query = dbq_del(TBL_FORUM, $delete_message, "id");
		 db_query($query);
		 
		 $query = dbq19(TBL_FORUM, $pos);
		 db_query($query);		 
	}
	elseif($delete_thread) {
		 $query = dbq_del(TBL_FORUM, $delete_thread, "thread");
		 db_query($query);
		 
		 $query = dbq18(TBL_FORUM, $delete_thread);
		 db_query($query); 
	}	
	elseif ($removeorphans) {
		$day = gmdate("d", (time()));
		$safe_purge_threshold = gmdate("Ym", (time() - 86400 * $IsOldPeriod * 2));
				
		$query = dbq_sela($emailTable);
		$Result = db_query($query);
		$nRows = db_countrows($Result);

		for($i = 0; $i < $nRows; $i++) {			
			$a = db_fetchrow($Result);
			$passwd = $a[passwd];
			$email = $a[email];
			$passwd_time = substr($passwd, 1, 6);
			
			if ($passwd_time < $safe_purge_threshold) {
				$query = dbq_del2($emailTable, "'$passwd'", "passwd", "'$email'", "email");
				db_query($query);
			}
		}				
	}
	elseif ($unlock){
		db_unlock(TBL_FORUM);
	}
}

?>

<!doctype html public "-//W3C//DTD HTML 3.2 Final//EN">
        
        <html>
        
        <head>
        
        <title>Bare Bones Bulletin Board ADMIN</title>
        
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
        
        <style type="text/css">
        <!--
	body {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt; margin-left :10px; margin-right : 10px; text-align : center}
	th   {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt; font-weight: bold}
	td   {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt;}
	form   {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt}
	A:link    {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt; text-decoration: none; color: black}
	A:visited {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt; text-decoration: none; color: black}
	A:hover   {  font-family: Arial, Helvetica, sans-serif; font-size: 10pt; text-decoration: underline; color: red}
	//-->
        </style>
        
        </head>
        
	<body bgcolor="white" text="black" link="black" vlink="black" alink="red">
   
        
        <center>

	<div style="font-weight:bold; font-size:160%">ADMIN - Handle with Care</div>
	<br><br>
        

<?php


adminquery();

if ($unlock) {
	echo "Tables unlocked. You can close the browser now.";
	exit;

}
elseif ($request) {

/************   begin read display **************/

	$s = readdisplay($request);

	echo "
		<table border=0 width=560>

			<tr>
				<th colspan=2 align=left>
					&nbsp;$s[topic]
				</th>
			</tr>

			<tr>
				<td align=left bgcolor=#cccccc>
					<a href=\"mailto:$s[email]\">&nbsp;$s[name]</a>&nbsp;($s[host])
				</td>

				<td align=right bgcolor=#cccccc>
					$TableFont$s[date]&nbsp;
				</td>

			</tr>

			<tr>
				<td colspan=2 align=left bgcolor=#dddddd>
					<br><br>
					$s[body]
					<br><br>
				</td>
			</tr>

		</table>

	<br><br><br>
	";



/************  begin post form display **************/


echo "
	<form action=\"$PHP_SELF\" method=\"POST\">
	
	<p>Edit here:
		<br><br><br>


		$FormName:<br>
		<input type=\"text\" name=\"name\" size=30 maxlength=50 value=\"$s[name]\"><br><br>

		$FormMail:<br>
		<input type=\"text\" name=\"email\" size=30 maxlength=100 value=\"$s[email]\"><br><br>

		$FormTopic:<br>
		<input type=\"text\" name=\"topic\" size=30 maxlength=50 value=\"$s[topic]\"><br><br>

		$FormBody:<br>
		<textarea name=\"body\" cols=50 rows=20 wrap=\"virtual\">$s[body]</textarea><br><br>
		
		*Thread:<br>
		<input type=\"text\" readonly name=\"thread\" size=10 maxlength=50 value=\"$s[thread]\" notab><br><br>
		
		*Depth:<br>
		<input type=\"text\" readonly name=\"depth\" size=10 maxlength=50 value=\"$s[depth]\" notab><br><br>
		
		*Position:<br>
		<input type=\"text\" readonly name=\"pos\" size=10 maxlength=50 value=\"$s[pos]\" notab><br><br>
		
		*Childof:<br>
		<input type=\"text\" readonly name=\"childof\" size=10 maxlength=50 value=\"$s[childof]\" notab><br><br>
		
		Host:<br>
		<input type=\"text\" name=\"hostaddress\" size=30 maxlength=50 value=\"$s[host]\"><br><br>
		
		*Date:<br>
		<input type=\"text\" readonly name=\"sdate\" size=20 maxlength=50 value=\"$s[date]\" notab><br><br>
		
		*ID:<br>
		<input type=\"text\" readonly name=\"modify_message\" size=10 maxlength=50 value=\"$s[id]\" notab><br><br>
		
		<input type=\"hidden\" name=\"date\" value=\"$s[datestamp]\">
		<input type=\"Submit\" name=\"submit\" value=\"Submit changes\" notab>
		</form>
		
		<br><br>
		Fields marked with an asterisk (*) cannot be changed.
		<br><br>
	";
}

	


echo "
		<table width=620>
		
		<tr>
			<th align=left>
				&nbsp;$HdThreadText
			</th>

			<th align=right>
				$HdFromText
			</th>

			<th align=right>
				$HdDateText&nbsp;
			</td>
			
			<th align=right colspan=2 bgcolor=red>
				
			<div style=\"color:red\">ADMIN</div>
			</th>

		</tr>
		";

/************   begin table display **************/

if ($find) {list($rowstoshow, $rowcontent, $DisplayFrontText, $FormHeading) = findresult($find);}
else {list($rowstoshow, $rowcontent, $DisplayFrontText, $FormHeading)  = showwholetable($last);}

for($i = 0; $i < $rowstoshow; $i++) {

	$r = db_fetchrow($rowcontent);
	$Pic = whichindent($r[depth]);
	$r = showtablerow($r);

	echo "		<tr>

			<td align=left>
				$Pic<a href=\"$PHP_SELF?request=$r[id]\">&nbsp;$r[topic]</a>
			</td>

			<td align=right valign=top>
				$r[em_pre]$r[name]&nbsp;$r[em_suf]
			</td>

			<td align=right valign=top>
				$NewMarker&nbsp;$r[date]&nbsp;
			</td>

			<td>
				<a href=\"$PHP_SELF?delete_message=$r[id]\">&nbsp;[Delete&nbsp;message]</a>
			</td>			

			<td>
				<a href=\"$PHP_SELF?delete_thread=$r[thread]\">&nbsp;[Delete&nbsp;thread]</a>
			</td>
			
		</tr>
	";
}


echo "
	
	</table>


	<br><br>
";

/************  begin remove orphans display  ************/


echo "
	<br><br><br>
		<form action=\"$PHP_SELF\" method=\"post\">
		Remove orpans in email table (see file 'issues.txt' for use)<br>
		<input type=\"hidden\" name=\"removeorphans\" value=\"1\">
		<input  type=\"submit\"  name=\"submit\" value=\"Remove orphans now\" notab>

		</form>
		<hr width=560>
		<br><br><br>
	
	
	</body>
	</html>
	";
	
	
/************  begin exit display  ************/


echo "
	<br><br><br>
		<form action=\"$PHP_SELF\" method=\"post\">
		You must exit Admin with this button to unlock the tables and resume normal operation !<br>
		<input type=\"hidden\" name=\"unlock\" value=\"1\">
		<input  type=\"submit\"  name=\"submit\" value=\"Exit\" notab>

		</form>
		<hr width=560>
		<br><br><br>
	
	
	</body>
	</html>
	";
	
?>
