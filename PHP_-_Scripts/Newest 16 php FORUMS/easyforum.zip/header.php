<HTML>
<HEAD>
<TITLE>dataX @ Forum</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<link rel="stylesheet" href="../datax.css" type="text/css">
</HEAD>

<BODY BGCOLOR="#FFFFFF">
<div align="Center">
  <table width="620" border="0" cellpadding="0" cellspacing="0" bordercolor="#7A98F6">
    <tr align="left" valign="top"> 
      <td> <img src="../datax-top.gif" width="619" height="38"></td>
    </tr>
    <tr> 
      <td height="1"></td>
    </tr>
    <tr bgcolor="#CDD9FC"> 
      <td bgcolor="#CDD9FC"> 
<? include("../menubar_btm.php"); ?>
      </td>
    </tr>
    <tr valign="top"> 
      <td height="5"></td>
    </tr>
    <tr valign="top"> 
      <td>
