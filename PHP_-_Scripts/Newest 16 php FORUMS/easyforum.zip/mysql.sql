
CREATE TABLE forum (
  id smallint(6) NOT NULL auto_increment,
  name varchar(40),
  email varchar(60),
  topic varchar(50),
  body blob,
  host varchar(80),
  thread smallint(6) NOT NULL,
  datestamp int(11) NOT NULL,
  depth smallint(2) NOT NULL,
  childof smallint(6) NOT NULL,
  pos smallint(6) NOT NULL,
  
  PRIMARY KEY (id),
  KEY thread (thread),
  KEY childof (childof),
  KEY pos (pos)
);
