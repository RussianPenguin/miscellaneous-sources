
=============================================================

This is BBBB-based forum< optimized to work with MySQL database.
Very easy installation procedure
Just modify constatnts in ini.php!!!
==============================================================

Supported databases: 

mySQL (stable)
