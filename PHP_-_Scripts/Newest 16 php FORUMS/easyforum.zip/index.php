#!/usr/local/bin/php

<?
require("functions.php");
require("ini.php");

$languagefile = language();
require($languagefile);  

require($HeaderFile);

/**********  insert posted article into DB **********/
echo "<center>";

if ($insert) {
 list($request, $DisplayFrontText, $NewThreadHeaderText) = insertpost($name, $email, $emailnotice, $topic, $body, $replytovalue, $thread);
 echo "  <br>
	 <div style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12pt; font-weight:bold\">
			$SubmitSuccesText
	 </div>
	 <br>";
}

if ($request) {
/************   begin read display **************/
 $s = readdisplay($request);
 list($rowstoshow, $rowcontent, $DisplayFrontText, $FormHeading)= showthread($s[thread]);
 $NavBar = navbar($s[pos], $s[thread], "read");
	echo "	<table border=0 width=\"90%\" cellspacing=\"2\">
			<tr>
			 <td align=left bgcolor ='#CDD9FC'>
			  <b><a href=\"mailto:$s[email]\">&nbsp;$s[name]</a>&nbsp;
			  /$TableFont$s[date]/
                          </b>
			 </td>
			</tr>
			<tr>
			 <td colspan=2 align=left valign=top bgcolor ='#CDD9FC'>
			  $s[body]
			 </td>
			</tr>";
}
else {
 list($rowstoshow, $rowcontent, $DisplayFrontText, $FormHeading)  = showwholetable($last);
 $s[thread]= 0; $s[id] = 0;
 $NavBar = navbar($last, 0, "index");

// draw threads 

echo "<table border=0 width=\"90%\">";

for ($i = 0; $i < $rowstoshow; $i++) {
 $r = db_fetchrow($rowcontent);
 $NewMarker = isitnew($r[datestamp]);
 $Pic = whichindent($r[depth]);
 $r = showtablerow($r);

 if (!isset($oldthread)) $oldthread=$r[thread];
 if ($oldthread!=$r[thread]) {$oldthread=$r[thread];echo "<tr><td height=4></td></tr>";}

 echo "		<tr>
			<td align=left>
	  		  $Pic$NewMarker<a href=\"$PHP_SELF?request=$r[id]\">&nbsp;$r[topic]</a>,
			  $r[em_pre]$r[name]$r[em_suf] - $r[date]
			</td>
		</tr>";
}
}
if ($rowstoshow==0) echo "<tr><td><center>Empty</center></td></tr>";
echo "</table><br>
      $NavBar<hr>";

/************  begin post form display **************/
empty($s[revalue]) && $s[revalue] = "";

echo "		<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: 11pt; font-weight:bold; color: #000066\">
			$FormHeading
		</div>
		<br>

		<form action=\"$PHP_SELF\" method=\"POST\">
		
		<table border=\"0\" cellspacing=\"2\" cellpadding=\"2\">
		  <tr>
		    <td width=\"120\"><font color=navy>$FormName:</font></td>
		    <td width=\"400\"> 
                     <input type=\"text\" name=\"name\" size=53 maxlength=50>
		    </td>
		  </tr>
		  <tr>
		    <td width=\"120\"><font color=navy>$FormMail:</font></td>
		    <td width=\"400\"> 
                     <input type=\"text\" name=\"email\" size=53 maxlength=50>
		    </td>
		  </tr>
		  <tr>
		    <td width=\"120\"><font color=navy>$FormTopic:</font></td>
		    <td width=\"400\"> 
                     <input type=\"text\" name=\"topic\" size=53 maxlength=50 value=\"$s[revalue]\">
		    </td>
		  </tr>
		  <tr>
		    <td width=\"120\" valign=\"top\"><font color=navy>$FormBody:</font></td>
		    <td width=\"400\"> 
                     <textarea name=\"body\" cols=40 rows=10 wrap=\"virtual\"></textarea>
		    </td>
		  </tr>
		  <tr>
		    <td colspan=\"2\">
		     <center>
 			<input type=\"Submit\" name=\"submit\"  alt=\"$FormHeading\" border=0 notab>
			<input type=\"hidden\" name=\"replytovalue\" value=\"$s[id]\">
			<input type=\"hidden\" name=\"thread\" value=\"$s[thread]\">
			<input type=\"hidden\" name=\"insert\" value=\"true\">
                     </center>
		    </td>
		  </tr>
		</table>
	        </form>
 	<br>
	</center>";

require ($FooterFile);
?>






