<?php

/*
 edit database, password and user variables to reflect your settings
 read bbbb-mysql.sql for table setup instuctions
 -------------------------------------------------------
*/

	                        
/*****  database variables  *******/

 define ("DB_SERVER",""); 		# Server Name
 define ("DB_USER","storm");   		# User Name
 define ("DB_NAME","test");    		# database name
 define ("TBL_FORUM","forum");           # table name for data

 $pass="" ;   

 for ($i=0;$i<strlen($pass);$i++) $pass[$i]=$pass[$i] ^ '*'; #decrypt password

 define ("DB_PASS", $pass);


/* leave these two as they are... */
require("mysql.php");

$connection = db_connect(DB_USER, DB_PASS);

/*
 everything below this line already has working default values
 but you probably want to look at least into the formatting variables
 --------------------------------------------------------------
*/



/*****  formatting variables  ******/	

#$ThreadColor1 = "#dddddd";
#$ThreadColor2 = "#cccccc";
$ThreadColor1 = "";
$ThreadColor2 = "";

$IsNewMarker = "<img src=\"new.gif\" border=0 width=12 height=12>";
	
$HeaderFile = "header.php";  /* this file is prepended to the BBS */
$FooterFile = "footer.php";  /* this file is appended to the BBS */

$AllowHTML = 0;
/*
'<b>,</b>,<i>,</i>,<a href=",">,<a href = "," >,</a>,<u>,</u>,<hr>,<center>,</center>,<strong>,</strong>,<em>,</em>,<ul>,</ul>,<ol>,</ol>,<li>,</li>';
 Allow these HTML tags to be displayed. All others are rendered useless. */

/* Extend with care! Set $AllowHTML = 0; to disable all HTML display. */

$DisplayRowsAtOnce = 40; 
/* For larger boards. If not all messages are to be displayed at once */
/* choose the number to be displayed on one page. If all messages are */
/* to be displayed simultaniously, set $DisplayRowsAtOnce = 0; */
	

/*****  localization ******/		

$DetectLanguage = 1;  /* Query the user's browser for language preference. */
                      /* Set 0 to disable. */
$AvailableLanguages = "en";  /* The language files to chose from. */
$DefaultLanguage = "en";  /* Choose one from above */
$OffsetGMT = 2;		 /* Timezone of your target audience. */
                         /* e.g. 2 for Helsinki and Tel Aviv, 9 for Tokyo, */
                         /* -5 for New York, -8 for L.A. */


/*********  misc. variables *********/

$IsNewPeriod = 7;	/* Number of days messages are adorned with the NEW-Icon. */
                        /* Set 0 to disable. */
$IsOldPeriod = 90;  /* Number of days after which inactive threads are */
                    /* deleted. Set to 0 keep threads infinitely. */
                    /* Note: Messages are only deleted, after ALL messages */
                    /* in the thread are older than $IsOldPeriod. */
$IsTooBig = 1000;  /* Posted messages are chopped after so many characters. */
                   /* This should prevent people from posting lengthy */
                   /* garbage. 4000 is approximately one printed A4 page. */
                   /* Set to 0 to allow any length (max. 65535 anyway) */	
 
$AllowNukeing = 1;   /* users can delete their own messages */
                     /* 1 = allow, 0 = disallow */                        
                     
$NoEmailSpam = 0;  /* you may alter this value to 1 to prevent email harvesters */
                   /* that scan web pages for email adresses from gathering */
                   /* valid adresses. The backside of doing this is that */
                   /* users that want to email in resonse to messages have to */
                   /* manually remove the ".REMOVEME!" part of the email */
                   /* address displayed in their mail client. */
/*---------- end -------------*/     
?>