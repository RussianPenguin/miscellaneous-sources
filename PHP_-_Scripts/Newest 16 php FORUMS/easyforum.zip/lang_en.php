<?php

/*****   bbbb localization file: English   *****/

$TimestringFormat = "d.m.Y";


$ReplyHeaderText = "Reply to this message";
$NewThreadHeaderText = "Start a new thread";

$FormName = "Name";
$FormMail = "Email";
$FormTopic = "Topic";
$FormBody = "Message";
$SubmitSuccesText = "Your message was successfully posted";

$DisplayFrontText1 = "All threads";
$DisplayFrontText0 = "All messages in this thread";
$DisplayFrontText2 = "Query Result";

$NukeMessage = "Delete this message";
$NukeSubscription ="Revoke your email subsciption";

$PrevThread = "previous thread";
$NextThread = "next thread";
$PrevMessage = "previous message";
$NextMessage = "next message";
$UpIndex = "index";
$OlderMessages = "older messages";
$NewerMessages = "newer messages";

$HdThreadText = "Topic";
$HdFromText = "Posted by";
$HdDateText = "Date";
$Anonymous = "Nemo";
$NoTopic = "No Topic provided";

?>
