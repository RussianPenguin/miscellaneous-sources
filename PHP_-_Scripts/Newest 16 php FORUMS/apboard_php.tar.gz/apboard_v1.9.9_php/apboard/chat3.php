<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate ("D, d M Y H:i:s") . " GMT");
header ("Cache-control: no-cache, must-revalidate, no-store");
header ("Pragma: no-cache");
header("Refresh: 30; URL=$php_path/chat3.php");
$CFG_user_chat_nick_delete = 5 * 60;
?>
<HTML>
<HEAD><TITLE>APBoard-Chat</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<META content="MSHTML 5.00.2314.1000" name=GENERATOR>
<STYLE TYPE="TEXT/CSS">
<? echo $cfg[css]; ?>
</STYLE>
<basefont="<? echo $font; ?>">
</HEAD>

<?
echo "<BODY BGCOLOR=\"$bgcol\" text=\"$fontcolor\" link=\"$links\" alink=\"$active\" vlink=\"$visited\">";
?>
<b>User:</b><br><br>
<?
	$threshold = time() - $CFG_user_chat_nick_delete;
	$nickname = mysql_query("SELECT DISTINCT nickname FROM apb".$n."_chat WHERE zeit > '$threshold'");
	while ($nickname1 = mysql_fetch_row($nickname)) {
		if ($nickname1[0]=="" || $nickname1[0]==" ") {
			echo "< Gast ><br>";
		} else {
			echo "<b>".$nickname1[0]."</b><br>";
		}
	}
?>
</BODY>
</HTML>