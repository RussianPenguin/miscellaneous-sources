<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
/*
ACHTUNG:
Bei Servern, die nur PHP4 unterst&uuml;tzen und somit nur Dateien mit der Endung *.php erkennen,
kann die backend.php ganz einfach umbenannt werden!



Die Features:
-------------

	Parameter:



		what=xxx  -->  user|threads|news  -->  Anzahl der User-Online, die letzten Threads oder News-Anzeige
			   Beispiel : <script src=http://www.deinedomain.de/apboard/backend.php?what=threads></script>

		nr=n	  	-->  1|2|3|...|x 	-->  Anzahl der anzuzeigenden Threads (ohne diesen Parameter, default = 10)
			   Beispiel : <script src=http://www.deinedomain.de/apboard/backend.php?what=threads&nr=10></script>

		pt=n	  	-->  1|2|3	     	-->  Anzeige vor den Threads (   1="<li>"   /   2="- "   /   3="# "  ) (ohne Angabe, defalt = nichts)
			   Beispiel : <script src=http://www.deinedomain.de/apboard/backend.php?what=threads&nr=10&pt=2></script>

		dat=1	  	--> Nur 1 m&ouml;glich, wenn angegeben, dann Anzeige des Datums hinter den Threads (ohne Angabe, default = 0)
			   Beispiel : <script src=http://www.deinedomain.de/apboard/backend.php?what=threads&nr=10&pt=2&dat=1></script>

		len=nn	--> 1|2|3|...|x   -->  L&auml;nge der anzuzeigenden Threads (N&uuml;tzlich, weil sonst Zeilenumbr&uuml;che) (ohne ANgabe, default = 35)
			   Beispiel : <script src=http://www.deinedomain.de/apboard/backend.php?what=threads&nr=10&pt=2&dat=1&len=30></script>


	Beispiel f&uuml;r Anzeige der Anzahl der User, welche gerade online sind:

		Es sind gerade <b><script src=http://www.deinedomain.de/apboard/backend.php?what=user></script></b> User online!

	Beispiel f&uuml;r Anzeige der 30 neuesten Threads, mit "<li>" davor, ohne Datums-Angabe:

		<script src=http://www.deinedomain.de/apboard/backend.php?what=threads&nr=30&pt=1></script>
*/
require "_language.inc";
$board_closed = 0;
require "__config.inc";
$timeout					= "3";
$zeit						= time();
$loeschzeit				= $zeit-($timeout*60);
$result3 = @mysql_query("DELETE FROM apb".$n."_useronline WHERE zeit<'$loeschzeit'");

function RemoveNL($text) {
	$text = str_replace("\n \r", "", $text);
	$text = str_replace("\n\r", "", $text);
	$text = str_replace("\n", "", $text);
	$text = str_replace("\r", "", $text);
	$text = str_replace("\c", "", $text);
	$text = str_replace("\l", "", $text);
	return $text;
}

if (!isset($what)) {
	$what = "threads";
}

if ($what == "user"):
	$result = @mysql_query("SELECT DISTINCT nickname FROM apb".$n."_useronline WHERE nickname != ''");
	$anzahl_reg_user = @mysql_num_rows($result);
	$result1 = @mysql_query("SELECT DISTINCT ip FROM apb".$n."_useronline WHERE nickname = ''");
	$anzahl_guests = @mysql_num_rows($result1);
	$anzahl_user = $anzahl_reg_user + $anzahl_guests;
	echo "document.write('$anzahl_user');";


elseif ($what == "threads"):
	if (!isset($nr)) { $nr = "10"; }
   if (!isset($pt)) { $pt = "0"; }
   if (!isset($dat)) { $dat = "0"; }
   if (!isset($len)) { $len = "35"; }
   $ilen = $len + 1;
   if ($pt == "0") { $p = ""; }
   if ($pt == "1") { $p = "<li> "; }
   if ($pt == "2") { $p = "- "; }
   if ($pt == "3") { $p = "# "; }
	$thread_last = GetLastThreads($nr);
	while ($thread_t = mysql_fetch_array($thread_last)) {
    	$threadid = $thread_t["threadid"];
    	$threadname_full = $thread_t["threadname"];
    	$threadname_full = RemoveCrop($threadname_full);
		if (strlen($threadname_full) < $len) { $threadname = $threadname_full; } else { $threadname = substr($threadname_full,0,$ilen)." ..."; }
		$boardparentid = $thread_t["boardparentid"];
		$threadlastreply = $thread_t["timelastreply"];
		if ($dat == "1") { $date = " - ".HackDate($threadlastreply); }
		echo "document.write('$p<a href=\"$php_path/thread.php?id=$threadid&BoardID=$boardparentid\" target=\"_blank\">$threadname</a>$date<br>');";
	}


elseif ($what == "news"):
	if (!isset($id)) { $id = "1"; }
	if (!isset($nr)) { $nr = "10"; }
	if (!isset($com)) { $com = "1"; }
	if (!isset($dat)) { $dat = "1"; }
	$thread_last = GetNewsThreads($nr, $id);
	while ($thread_t = mysql_fetch_array($thread_last)) {
    	$threadid = $thread_t["threadid"];
    	$topic = $thread_t["threadname"];
		$boardparentid = $thread_t["boardparentid"];

		$thread_result = mysql_query("SELECT * FROM apb".$n."_posts WHERE threadparentid='$threadid' ORDER BY postid ASC LIMIT 0,1");
		$thread_text = mysql_fetch_array($thread_result);
		$text = $thread_text["message"];
		$date = $thread_text["posttime"];
		$user = $thread_text["authorname"];
		if ($dat == "1") { $datum = HackDate($date); }
		$text1 = RemoveCrap($text);
		$text2 = RemoveNL($text1);

		echo "document.write('<TABLE bgcolor=\"#000000\" align=\"center\" border=\"0\" cellpadding=\"6\" cellspacing=\"1\" width=\"95%\">');";
		echo "document.write('  <TR bgcolor=\"#00315C\">');";
		echo "document.write('    <TD COLSPAN=\"2\"><FONT FACE=\"Tahoma, Verdana, Arial, Helvetica, sans-serif\">&nbsp;&nbsp;&nbsp;<font size=\"2\"><b>$topic</b></font><br>');";
		echo "document.write('      &nbsp;&nbsp;&nbsp;<font size=\"1\">$datum&nbsp;&nbsp;von <A HREF=\"$php_path/user.php?username=yes&id=$user\" target=\"_blank\">$user</A></font></font>');";
		echo "document.write('    </TD>');";
		echo "document.write('  </TR>');";
		echo "document.write('</table>');";
		echo "document.write('<TABLE bgcolor=\"#000000\" align=\"center\" border=\"0\" cellpadding=\"6\" cellspacing=\"1\" width=\"95%\">');";
		echo "document.write('  <TR bgcolor=\"#00427C\">');";
		echo "document.write('    <TD VALIGN=\"top\">');";
		echo "document.write('      <p><FONT FACE=\"Tahoma, Verdana, Arial, Helvetica, sans-serif\" SIZE=\"2\">$text2</font></p>');";
		echo "document.write('    </TD>');";
		echo "document.write('  </TR>');";
//		echo "document.write('  <TR>');";
//		echo "document.write('    <TD VALIGN=\"bottom\">');";
//		echo "document.write('      <div align=\"right\"><font size=\"1\">[ <a href=$php_path/thread.php?id=$threadid&BoardID=$boardparentid>KOMMENTARE</a> ]</font></div>');";
//		echo "document.write('    </TD>');";
//		echo "document.write('  </TR>');";
		echo "document.write('</table>');";
		echo "document.write('<br>');";

	}

elseif ($what == "who"):
	$reg_user = mysql_query("SELECT DISTINCT nickname FROM apb".$n."_useronline WHERE nickname != ''");
	$anzahl_reg_user = mysql_num_rows($reg_user);
	$anzahl_guests = mysql_query("SELECT DISTINCT ip FROM apb".$n."_useronline WHERE nickname = ''");
	$anzahl_guests = mysql_num_rows($anzahl_guests);
	while ($nickname = mysql_fetch_row($reg_user)) {
		echo "document.write('<b><A HREF=\"$php_path/user.php?username=yes&id=$nickname[0]&BoardID=$BoardID\" target=\"_blank\">$nickname[0]</a></b><br>');";
	}
	if ($anzahl_guests == 1) {
		echo "document.write('1 Gast<br>');";
	} else if ($anzahl_guests > 1) {
		echo "document.write('$anzahl_guests G&auml;ste<br>');";
	}


endif;
?>