<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "./_language.inc";
function apb_error($error_msg)
{
echo "<HTML><BODY BGCOLOR=\"#ffffff\" TEXT=\"#ff0000\">
<TABLE BGCOLOR=\"#CCCCCC\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">
<TR BGCOLOR=\"#999999\">
	 <TD>
		<div align=\"center\"><B><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"4\" color=\"#FF0000\">*** APBoard-Install ***</font></B></div>
	 </TD>
</TR>
<TR>
<TD>
<FONT FACE=\"Verdana, Arial, Helvetica, sans-serif\" SIZE=3>".$install_meldet_fehler."<BR><BR>
<b><CENTER><FONT FACE=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#000000\" SIZE=2>$error_msg</font></CENTER></b><BR>
<BR>".$install_back."</FONT></TD></TR></TABLE>";
exit;
}
//
//
//
//
// #######################   Eingabe-Formular	############################
//
if (!isset ($install)):
?>
<HTML><HEAD><TITLE>APBoard - Another PHP Board</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<META content="MSHTML 5.00.2314.1000" name=GENERATOR>
<STYLE TYPE="TEXT/CSS">
a:link{color:#0044C2;text-decoration: none}
a:visited{color:#0044C2;text-decoration: none}
a:active{color:#F8C100;text-decoration: none}
a:hover{color:#F8C100;text-decoration: underline}
BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:#000000;}
.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}</STYLE><basefont="Verdana, Arial, Helvetica, sans-serif">
</HEAD>
<BODY BGCOLOR="#FBFBFB" text="#000000" link="#0044C2" alink="#F8C100" vlink="#0044C2">
<div align="center">
  <p><font face="Verdana" size="5" color="#333333">APBoard <? echo $versions_nummer; ?></font></p>
  <p><b><font face="Verdana" size="3" color="#333333">Automatisches Setup v1.0<br>
	 <br>
	 </font></b><font face="Verdana" size="3" color="#333333"><font size="2" color="#FF0000">Attention:
	 to translate this setup and the whole board, <br>
	 rename the file </font></font><font face="Verdana" size="3" color="#333333"><font size="2" color="#FF0000">&quot;<b><i>_language_???.inc</i></b>&quot;
	 to &quot;<b><i>_language.inc</i></b>&quot;.<br>
	 <font size="1" color="#333333">The &quot;???&quot; stands for the country-code
	 <br>
	 (i.e.: eng = english, fra = france...)</font></font></font><font size="1" color="#333333"><b><font face="Verdana"><br>
	 <br>
	 </font></b></font><font size="1"><b><font face="Verdana" color="#333333">
	 </font></b></font></p>
  <table width="400" border="0" cellspacing="0" cellpadding="0">
	 <tr>
		<td>
		  <p><b><font face="Verdana" size="2" color="#FF0000"><? echo $install_attention; ?><br>
			 <? echo $install_attention_text; ?></p>
		  </td>
	 </tr>
  </table>
  <form action="!_install_!.php" method="post">
	 <table width="95%" border="0" cellspacing="0" cellpadding="0" bgcolor="#CCCCCC">
		<tr>
		  <td width="4%" height="20">&nbsp;</td>
		  <td width="46%" height="20">&nbsp;</td>
		  <td width="47%" height="20">&nbsp;</td>
		  <td width="3%" height="20">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_name_admin; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="Admin_user" size="25" maxlength="20">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_pw_admin; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="password" name="Admin_pw" size="25" maxlength="20">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_pw2_admin; ?></font><b><font face="Verdana" size="2"> </font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="password" name="Admin_pw2" size="25" maxlength="20">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_email_admin; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="Forum_Admin_eMail" size="35" maxlength="100">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_url_apboard; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="location" size="40" maxlength="150" value="http://www.yourdomain.de/apboard">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_nummer_apboard; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="n" size="5" maxlength="10" value="1">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_mysql_server; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="MySQL_Server" size="35" maxlength="100">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_mysql_database; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="MySQL_Database" size="35" maxlength="100">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_mysql_user; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="text" name="MySQL_User" size="35" maxlength="100">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%">&nbsp;</td>
		  <td width="46%">
			 <div align="right"><font face="Verdana" size="1"><? echo $install_mysql_pw; ?></font><b><font face="Verdana" size="2">
				</font></b>&nbsp;&nbsp;&nbsp;</div>
		  </td>
		  <td width="47%">
			 <div align="left">
				<input type="password" name="MySQL_Password" size="25" maxlength="20">
			 </div>
		  </td>
		  <td width="3%">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%" height="20">&nbsp;</td>
		  <td width="46%" height="20">&nbsp;</td>
		  <td width="47%" height="20">&nbsp;</td>
		  <td width="3%" height="20">&nbsp;</td>
		</tr>
		<tr>
		  <td width="4%" height="19">&nbsp;</td>
		  <td width="93%" height="19" colspan="2">
			 <div align="center">
				<input type="hidden" name="install" value="1">
				<input type="submit" name="Submit" value="<? echo $install_start; ?>">
				&nbsp;&nbsp;&nbsp;
				<input type="reset" name="Submit2" value="<? echo $install_reset; ?>">
			 </div>
		  </td>
		  <td width="3%" height="19">&nbsp;</td>
		</tr>
	 </table>
</form>
  <p>&nbsp;</p>
</div>
<?
//
//
//
//
// #######################   Code zur Installation des Boardes   ############################
//
elseif ($install == "1"):
		  if ($Admin_pw==$Admin_pw2)
		  {

		  if (!$Admin_user || !$Admin_pw || !$Admin_pw2 || !$Forum_Admin_eMail || !$location || !$n || !$MySQL_Server || !$MySQL_Database || !$MySQL_User)
		  {
				apb_error($install_pflichtfeld);
				exit;
		  }
		  $inhalt = "<?\n\$mysqlhost = \"".$MySQL_Server."\";\n\$mysqldb = \"".$MySQL_Database."\";\n\$mysqluser = \"".$MySQL_User."\";\n\$mysqlpassword = \"".$MySQL_Password."\";\n\$adminemail = \"".$Forum_Admin_eMail."\";\n\$location = \"".$location."\";\n\$n = \"".$n."\";\n?>";
		  $now = time();
		  //
		  // ##########	Connect-Versuch und Auffangen einiger Fehler 	############
		  //
		  if (!@mysql_connect($MySQL_Server, $MySQL_User, $MySQL_Password))
				{ apb_error($install_connect_error); }
		  if (!@mysql_select_db($MySQL_Database))
				{ apb_error($install_database_error); }
		  //
		  // ##########	Listen vorhandener Tabellen und l&ouml;schen der betreffenden Tabellen 	############
		  //
		  $result = mysql_list_tables ($MySQL_Database);
		  $i = 0;
		  while ($i < mysql_num_rows ($result))
		  {
				$tb_names[$i] = mysql_tablename ($result, $i);
				if ($tb_names[$i] == "apb".$n."_board_news") { mysql_query("DROP TABLE apb".$n."_board_news;");  }
				if ($tb_names[$i] == "apb".$n."_boards") { mysql_query("DROP TABLE apb".$n."_boards;");  }
				if ($tb_names[$i] == "apb".$n."_config") { mysql_query("DROP TABLE apb".$n."_config;");  }
				if ($tb_names[$i] == "apb".$n."_posts") { mysql_query("DROP TABLE apb".$n."_posts;");  }
				if ($tb_names[$i] == "apb".$n."_statistik") { mysql_query("DROP TABLE apb".$n."_statistik;");  }
				if ($tb_names[$i] == "apb".$n."_threads") { mysql_query("DROP TABLE apb".$n."_threads;");  }
				if ($tb_names[$i] == "apb".$n."_user_table") { mysql_query("DROP TABLE apb".$n."_user_table;");  }
				if ($tb_names[$i] == "apb".$n."_useronline") { mysql_query("DROP TABLE apb".$n."_useronline;");  }
				if ($tb_names[$i] == "apb".$n."_chat") { mysql_query("DROP TABLE apb".$n."_chat;");  }
				$i++;
		  }
		  //
		  // ##########	Erzeugen der neuen Tabellen, mit Inhalt	 ############
		  //
		  $table_query1 = mysql_query("CREATE TABLE apb".$n."_board_news ( id int(11) DEFAULT '0' NOT NULL auto_increment, date int(11) DEFAULT '0' NOT NULL, topic varchar(100) NOT NULL, text text NOT NULL, PRIMARY KEY (id))");
		  $table_query2 = mysql_query("CREATE TABLE apb".$n."_boards ( boardid int(11) DEFAULT '0' NOT NULL auto_increment, boardname varchar(70) NOT NULL, boardpassword varchar(25) binary DEFAULT 'NONE' NOT NULL, boardmods varchar(70) binary NOT NULL, totalposts int(11) DEFAULT '0' NOT NULL, lastmodified int(11) DEFAULT '0' NOT NULL, descriptiontext text NOT NULL, boardgfx varchar(150) DEFAULT 'main.gif' NOT NULL, boardcss varchar(150) DEFAULT 'main.css' NOT NULL, category varchar(30) DEFAULT 'Keine Kategorie' NOT NULL, font varchar(100) NOT NULL, fontcolor varchar(7) NOT NULL, fontcolorsec varchar(7) NOT NULL, bgcolor varchar(7) NOT NULL, tablebg varchar(7) NOT NULL, tablea varchar(7) NOT NULL, tableb varchar(7) NOT NULL, tablec varchar(7) NOT NULL, imageurl varchar(150) NOT NULL, linkcolor varchar(7) NOT NULL, visited varchar(7) NOT NULL, active varchar(7) NOT NULL, hover varchar(7) NOT NULL, hgpicture varchar(200) NOT NULL, bgfixed int(1) DEFAULT '0' NOT NULL, sortit int(3) DEFAULT '1' NOT NULL, totalthreads int(11) DEFAULT '0' NOT NULL, PRIMARY KEY (boardid))");
		  $table_query3 = mysql_query("CREATE TABLE apb".$n."_config ( confid int(11) DEFAULT '0' NOT NULL auto_increment, php_path varchar(200) NOT NULL, master_board_name varchar(50) NOT NULL, font varchar(100) NOT NULL, fontcolor varchar(7) NOT NULL, fontcolorsec varchar(7) NOT NULL, bgcolor varchar(7) NOT NULL, tablebg varchar(7) NOT NULL, tablea varchar(7) NOT NULL, tableb varchar(7) NOT NULL, tablec varchar(7) NOT NULL, imageurl varchar(150) NOT NULL, linkcolor varchar(7) NOT NULL, visited varchar(7) NOT NULL, active varchar(7) NOT NULL, hover varchar(7) NOT NULL, icq_thread int(1) DEFAULT '0' NOT NULL, pic_thread int(1) DEFAULT '0' NOT NULL, linkleiste int(1) DEFAULT '0' NOT NULL, link1 varchar(100) NOT NULL, link11 varchar(100) NOT NULL, link2 varchar(100) NOT NULL, link22 varchar(100) NOT NULL, link3 varchar(100) NOT NULL, link33 varchar(100) NOT NULL, link4 varchar(100) NOT NULL, link44 varchar(100) NOT NULL, link5 varchar(100) NOT NULL, link55 varchar(100) NOT NULL, link6 varchar(100) NOT NULL, link66 varchar(100) NOT NULL, link7 varchar(100) NOT NULL, link77 varchar(100) NOT NULL, link8 varchar(100) NOT NULL, link88 varchar(100) NOT NULL, link9 varchar(100) NOT NULL, link99 varchar(100) NOT NULL, chat int(1) DEFAULT '0' NOT NULL, hgpicture varchar(200) NOT NULL, bgfixed int(1) DEFAULT '0' NOT NULL, adminmail int(1) DEFAULT '0' NOT NULL, installdate int(11) DEFAULT '0' NOT NULL, PRIMARY KEY (confid))");
		  $table_query4 = mysql_query("CREATE TABLE apb".$n."_posts ( threadparentid int(11) DEFAULT '0' NOT NULL, postid int(11) DEFAULT '0' NOT NULL auto_increment, authorname varchar(30) NOT NULL, authorrank varchar(60) NOT NULL, posttime int(11) DEFAULT '0' NOT NULL, message text NOT NULL, email text NOT NULL, disable_smilies int(1) DEFAULT '0' NOT NULL, post_ip VARCHAR (240), PRIMARY KEY (postid))");
		  $table_query5 = mysql_query("CREATE TABLE apb".$n."_statistik ( statid int(11) DEFAULT '0' NOT NULL auto_increment, time int(11) DEFAULT '0' NOT NULL, ip varchar(16) DEFAULT '0' NOT NULL, file varchar(30) NOT NULL, browser varchar(100) NOT NULL, name varchar(100) NOT NULL, PRIMARY KEY (statid))");
		  $table_query6 = mysql_query("CREATE TABLE apb".$n."_threads ( boardparentid int(11) DEFAULT '0' NOT NULL, threadid int(11) DEFAULT '0' NOT NULL auto_increment, threadname varchar(70) binary NOT NULL, author varchar(30) NOT NULL, replies int(11) DEFAULT '0' NOT NULL, timelastreply int(11) DEFAULT '0' NOT NULL, flags int(11) DEFAULT '0' NOT NULL, email text NOT NULL, topicicon varchar(200) NOT NULL, views int(11) DEFAULT '0' NOT NULL, PRIMARY KEY (threadid))");
		  $table_query7 = mysql_query("CREATE TABLE apb".$n."_user_table ( userid int(11) DEFAULT '0' NOT NULL auto_increment, username varchar(30) NOT NULL, userpassword varchar(25) binary NOT NULL, useremail varchar(70) binary NOT NULL, userposts int(11) DEFAULT '0' NOT NULL, status varchar(25) NOT NULL, statusextra varchar(25), regdate int(11) DEFAULT '0' NOT NULL, signatur text NOT NULL, infotext text NOT NULL, usericq varchar(10) DEFAULT '[N/A]' NOT NULL, userhp varchar(100) DEFAULT '[N/A]' NOT NULL, userage varchar(6) DEFAULT '[N/A]' NOT NULL, userpic varchar(100) NOT NULL, interests varchar(200) NOT NULL, show_email_global int(1) DEFAULT '0' NOT NULL, users_may_email INT (1) DEFAULT '1' NOT NULL, mods_may_email INT (1) DEFAULT '1' NOT NULL, PRIMARY KEY (userid))");
		  $table_query8 = mysql_query("CREATE TABLE apb".$n."_useronline ( zeit int(11) DEFAULT '0' NOT NULL, ip varchar(15) DEFAULT '0' NOT NULL, file varchar(20) NOT NULL, nickname varchar(20) NOT NULL)");
		  $table_query9 = mysql_query("CREATE TABLE apb".$n."_chat ( id int(11) DEFAULT '0' NOT NULL auto_increment, zeit int(11) DEFAULT '0' NOT NULL, nickname varchar(20) NOT NULL, text text NOT NULL, PRIMARY KEY (id))");
		  $table_query10 = mysql_query("INSERT INTO apb".$n."_user_table VALUES ( '1', '$Admin_user', '$Admin_pw', '$Forum_Admin_eMail', '0', 'ADMIN', '', '$now', '', 'Admin', '', '', '', '', '', '0', '', '')");
		  $table_query11 = mysql_query("INSERT INTO apb".$n."_config VALUES ( '1', '$location', 'APBoard $versions_nummer', 'Verdana, Arial, Helvetica, sans-serif', '#000000', '#4A0053', '#FBFBFB', '#003D71', '#F0F0F0', '#E9E9E9', '#DADADA', '$location/themes/board.gif', '#0044C2', '#0044C2', '#F8C100', '#F8C100', '1', '0', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '0', '0', '$now')");
		  $table_query12 = mysql_query("INSERT INTO apb".$n."_board_news VALUES ( '1', '$now', 'APBoard $versions_nummer erfolgreich installiert!', 'Hallo,<br>soeben habe ich dieses neue Board erfolgreich installiert!<br><br>Gruss...')");
		  $table_query13 = mysql_query("INSERT INTO apb".$n."_boards VALUES ( '1', '$install_general_board', '', '', '0', '$now', '$install_general_description', '$location/themes/board.gif', '', '$install_general_category', 'Verdana, Arial, Helvetica, sans-serif', '#000000', '#4A0053', '#FBFBFB', '#003D71', '#F0F0F0', '#E9E9E9', '#DADADA', '', '#0044C2', '#0044C2', '#F8C100', '#F8C100', '', '0', '1', '0')");
		  //
		  // ##########	Erzeugen der Datei _data.inc.php und Speichern der Daten	 ############
		  //
		  $wf = fopen ("_data.inc.php", "w+");
		  fwrite ($wf,$inhalt);
		  $copied = ftell($wf);
		  fclose ($wf);
		  if (!$copied)
		  {
			 $copied = "0 (ERROR)";
		  }
		  //
		  // ##########	Kopieren der Datei _data.inc.php nach .../admin/_data.inc.php	 ############
		  //
		  copy("_data.inc.php", "admin/_data.inc.php");
		  //
		  // ##########	Melden, dass die Installation erfolgreich war	 ############
		  //
		  echo "<center><font face=verdana size=4><b>".$install_erfolg1."</b><br></font></center><br><font size=2><blockquote>".$install_erfolg2."<br><br><a href=".$location.">".$location."</a><br><br>
		  <font size=\"3\" color=\"#FF0000\"><b>".$install_erfolg3."</b></font>
		  </blockquote>
		  </font>";
		  } else {
				apb_error($passwort_unterschiedlich);
		  }
endif;
?>
</body>
</html>