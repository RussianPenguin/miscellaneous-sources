<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
require "_iconmap.inc";
require "_ubbcodescript.inc";

$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$thread_info = GetThreadInfo($replyto);
$thread_info = mysql_fetch_array($thread_info);
$board_info = GetBoardInfo($thread_info[boardparentid]);
$board_info = mysql_fetch_array($board_info);
if (!$board_info) {
	echo mysql_error();
	apb_error($board_existiert_nicht,FALSE);
}
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/main.php?cat=$board_info[category]\">$board_info[category]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$php_path/board.php?id=$board_info[boardid]&BoardID=$BoardID\">$board_info[boardname]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$php_path/thread.php?id=$thread_info[threadid]&BoardID=$BoardID\">$thread_info[threadname]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$antwort_erstellen";
require "_header.inc";
require "getimagesize.php";
define("USER_PIC_MAX_WIDTH", $userpicwidth) ;
define("USER_PIC_MAX_HEIGHT", $userpicheight) ;

if ($thread_info[flags]=="1") {
	apb_error($error_thread_closed,FALSE);
}

if (!$logged) {
	apb_error($nur_reg_benutzer1."<A HREF=\"$php_path/register.php?BoardID=$BoardID\">".$nur_reg_benutzer2."</A>".$nur_reg_benutzer3."<A HREF=\"$php_path/login.php?BoardID=$BoardID\">".$nur_reg_benutzer2."</A>".$nur_reg_benutzer4,FALSE);
}
if ($postit) {
	if (!$replyto) {
		apb_error($kein_thema_angegeben,FALSE);
	}
	if (!$message) {
		apb_error($nix_geschrieben,FALSE);
	}
	UserAuth($UID,$UPASS,TRUE);
	$last_reply = time();
	$username = mysql_query("SELECT username,statusextra,userposts,signatur,useremail FROM apb".$n."_user_table WHERE userid='$UID';");
	$username = mysql_fetch_array($username);
	$author = $username[username];
	$extra = $username[statusextra];
	$rank = GetRank($username[userposts]);
	$signatur = $username[signatur];
	$useremail= $username[useremail];
	
	$lastuserpost = mysql_query ("SELECT * FROM apb".$n."_posts WHERE authorname = '$author' ORDER BY posttime DESC LIMIT 0,1");
	$lastuserpost = mysql_fetch_array($lastuserpost);
	$lastuserpost = $lastuserpost["posttime"];

	if ($min_post_inverval > 0 && ($lastuserpost > (time() - $min_post_inverval))) {
		apb_error($post_intervall_zu_klein, FALSE);
	}
	
	$pages = ceil(($thread_info[replies]+2) / $posts_per_page);
	$start_string = ( $pages > 1) ? "&start=".((($pages - 1) * $posts_per_page) + 1) : "";
	
	if ($signature=="1" && strlen($signatur) > 2) {
		$message = $message.$signatur_trennstrich.$signatur;
	} else {
		//$message = $message;
	}
	if ($do_disable_smilies != "1") {
		$do_disable_smilies = "0";
	}
	
	$message = apb_wordwrap($message);
	$message1 = RemovePostCrap($message);
	if ($email=="1") {
		if (!$useremail) {
			mysql_query("INSERT INTO apb".$n."_posts VALUES( '$replyto', '', '$author', '$rank', '$last_reply', '$message1', '', '$do_disable_smilies', , '$REMOTE_ADDR');");
			mysql_query("UPDATE apb".$n."_threads SET replies=replies+1,timelastreply='$last_reply' WHERE threadid='$replyto'");
			mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,lastmodified='$last_reply' WHERE boardid='$board_info[boardid]'");
			mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
			echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
			echo "<TR BGCOLOR=\"$tableA\"><TD>";
			print_mb ( $keine_email_in_profil, $font, "2" );
			echo "</TD></TR>";
			echo "<TR BGCOLOR=\"$tableC\"><TD>";
			print_mb ( $antwort_eingefuegt, $font, "2" );
			echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
			print_mb ( RemoveCrap($message1, $do_disable_smilies), $font, "2" );
			echo "<BR><BR></TD></TR>";
			echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
			print_mb ( "[ - <A HREF=\"$php_path/thread.php?id=$replyto&BoardID=$BoardID$start_string\">".$zurueck_zum_thema."</A> - ]", $font, "2" );
			echo "</CENTER></TD></TR></TABLE>";

			if ($thread_info[email]) {
				mail($thread_info[email], $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			}

			if ($adminmail == "1") {
				mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			}

			include "_footer.inc";
			exit;
		} else {
			if (!$thread_info[email]) {
				$thread_info[email] = $useremail;
			} else {
				if (!is_int(strpos($thread_info[email], $useremail))) {
					$thread_info[email] .= ",$useremail";
				}
			}
			mysql_query("INSERT INTO apb".$n."_posts VALUES( '$replyto', '', '$author', '$rank', '$last_reply', '$message1', '', '$do_disable_smilies', '$REMOTE_ADDR');");
			mysql_query("UPDATE apb".$n."_threads SET replies=replies+1,timelastreply='$last_reply',email='$thread_info[email]' WHERE threadid='$replyto'");
			mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,lastmodified='$last_reply' WHERE boardid='$board_info[boardid]'");
			mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
			mail($thread_info[email], $betreff_email, $message_email1.$master_board_name.$message_email3.$author.$message_email4.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
			echo "<TR BGCOLOR=\"$tableA\"><TD>";
			print_mb ( $email_hinzugefuegt, $font, "2" );
			echo "</TD></TR>";
			echo "<TR BGCOLOR=\"$tableC\"><TD>";
			print_mb ( $antwort_eingefuegt, $font, "2" );
			echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
			print_mb ( RemoveCrap($message1, $do_disable_smilies), $font, "2" );
			echo "<BR><BR></TD></TR>";
			echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
			print_mb ( "[ - <A HREF=\"$php_path/thread.php?id=$replyto&BoardID=$BoardID$start_string\">".$zurueck_zum_thema."</A> - ]", $font, "2" );
			echo "</CENTER></TD></TR></TABLE>";
			if ($adminmail == "1") {
				mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			}
			include "_footer.inc";
			exit;
		}
	} else {
		mysql_query("INSERT INTO apb".$n."_posts VALUES( '$replyto', '', '$author', '$rank', '$last_reply', '$message1', '', '$do_disable_smilies', '$REMOTE_ADDR');");
		mysql_query("UPDATE apb".$n."_threads SET replies=replies+1,timelastreply='$last_reply' WHERE threadid='$replyto'");
		mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,lastmodified='$last_reply' WHERE boardid='$board_info[boardid]'");
		mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
		echo "<TR BGCOLOR=\"$tableC\"><TD>";
		print_mb ( $antwort_eingefuegt, $font, "2" );
		echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
		print_mb ( RemoveCrap($message1, $do_disable_smilies), $font, "2" );
		echo "<BR><BR></TD></TR>";
		echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
		print_mb ( "[ - <A HREF=\"$php_path/thread.php?id=$replyto&BoardID=$BoardID$start_string\">".$zurueck_zum_thema."</A> - ]", $font, "2" );
		echo "</CENTER></TD></TR></TABLE>";
		if ($thread_info[email]) {
			mail($thread_info[email], $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
		}
		if ($adminmail == "1") {
			mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$replyto."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
		}
		include "_footer.inc";
		exit;
	}

}

	add_ubbcodescript("message");

	echo "<FORM NAME=\"MESSAGEFORM\" ACTION=\"$php_path/reply.php\" METHOD=\"POST\">";
	echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">";
	echo "<TR><TD BGCOLOR=\"$tableC\"><CENTER>";
	print_mb ($antwort_erstellen, $font, "4" );
	print_mb ($im_forum . $board_info[boardname], $font, "2" );
	echo "</CENTER></TD></TR><TR><TD BGCOLOR=\"$tableA\">";
	print_mb ($aktuelles_thema . $thread_info[threadname], $font, "2");

?>

<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER" CLASS="normaltext">
<?

if ($quote) {

	$quotemessage = mysql_query("SELECT message, authorname FROM apb".$n."_posts WHERE postid=$quote");
	echo mysql_error();
	$quotemessage = mysql_fetch_array($quotemessage);
	echo mysql_error();

	$thismessage = mysql_query("SELECT postid,authorname,authorrank,posttime,message,disable_smilies FROM apb".$n."_posts WHERE postid='$quote'");
	$thismessage = mysql_fetch_array($thismessage);

} else {
	$thismessage = GetPosts($thread_info[threadid], "");
	$thismessage = mysql_fetch_array($thismessage);
}

$user_info = GetUserInfo($thismessage[authorname]);
$user_info = mysql_fetch_array($user_info);


if ($thiscolor == $tableA) {
	$thiscolor = $tableB;
} else {
	$thiscolor = $tableA;
}
echo "<TR BGCOLOR=\"$thiscolor\"><TD WIDTH=\"20%\" VALIGN=\"top\">";
print_mb ( HackDate($thismessage[posttime]) . "<BR><BR>" , $font , "1");
if ($icq_thread=="1") {
	if ($user_info[usericq]=="" || $user_info[usericq]==" " || $user_info[usericq]=="[N/A]") {
		echo "";
	} else {
		echo "<a href=\"http://wwp.icq.com/scripts/search.dll?to=".$user_info[usericq]."\" target=\"_blank\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=".$user_info[usericq]."&img=5\" width=\"15\" height=\"15\" border=\"0\" alt=\"".$contact_hinzufuegen."\"></a>&nbsp;";
	}
} else {
	echo "";
}

print_mb ( "<A HREF=\"$php_path/user.php?username=yes&id=$thismessage[authorname]&BoardID=$BoardID\">$thismessage[authorname]</A><BR>" , $font , "2");
echo "<FONT COLOR=\"$fontcolorsec]\">";
print_mb ( "Posts: ".$user_info[userposts] , $font , "1");

if ($user_info[status]=="NORMAL") {
	print_mb ( "<br>$rank".GetRank($user_info[userposts]), $font , "1");
} else {
	if ($user_info[status]=="ADMIN") {
		$status="[Administrator]";
		print_mb ( "<br>".$status , $font , "1");
	} else {
		$status="[Moderator]";
		print_mb ( "<br>".$status , $font , "1");
	}
}

if (!$user_info[statusextra]) {
	echo " ";
} else {
	print_mb ( "<br><b>$extra".$user_info[statusextra]."</b>" , $font , "1");
}

/*   ACHTUNG FEHLER: Was sollte hier urspr&uuml;nglich rein??
					( $thismessage[5] gibt es nicht!!! )
			
if ($thismessage[5]) {
	print_mb ( "<BR>" . $thismessage[5], $font , "1");
}

*/

	echo "</FONT>";
	if ($pic_thread=="1") {
		if ($user_info[userpic]=="" || $user_info[userpic]==" " || $user_info[userpic]=="[N/A]") {
			echo "<br>";
		} else {
			$image = GetURLImageSize($user_info[userpic]);
			if ($image[0] > USER_PIC_MAX_WIDTH) {
				$width=$image[0];
				$image[0] = USER_PIC_MAX_WIDTH;
				$image[1] = floor(($image[0]*$image[1])/$width);
			}
			if ($image[1] > USER_PIC_MAX_HEIGHT) {
				$old=$image[1];
				$image[1] = USER_PIC_MAX_HEIGHT;
				$image[0] = floor($image[0]*$image[1]/$old);
			}
			print "<br>";
			if ($user_info[userhp] == "" || $user_info[userhp] == " " || $user_info[userhp] == "[N/A]") {
				$upic = "0";
			} else {
				$upic = "1";
			}
			if ($upic == "1") {
				print "<a href=\"".$user_info[userhp]."\" target=_blank>";
			}
			print "<IMG HEIGHT=\"$image[1]\" WIDTH=\"$image[0]\" SRC=\"".$user_info[userpic]."\" BORDER=0>";
			if ($upic == "1") {
				print "</a>";
			}
			print "<br>\n";
//
		}
	} else {
		echo "";
	}
	echo "</TD><TD WIDTH=\"80%\" VALIGN=\"top\"><br>";
	$message = RemoveCrap($thismessage[message], $thismessage[disable_smilies]);
	print_mb ( $message . "<BR>", $font, "2" );

?>
		</TD>
	</TR>
</TABLE>

			<INPUT TYPE="hidden" NAME="postit" VALUE="TRUE">
			<INPUT TYPE="hidden" NAME="replyto" VALUE="<? echo $replyto; ?>">
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN="2">
			<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="6">
				<TR BGCOLOR="<? echo $tableB; ?>">
					<TD NOWRAP>
						<? print_mb ($formatierung_hinweis, $font, "1"); ?><BR><BR><BR>
						<? print_mb ("<b>Klick'n'paste</b>", $font, "1"); ?><BR>
						<? print_mb ($iconauswahl, $font, "1"); ?><BR>
						<? add_iconmap("message"); ?>
					</td>
					<TD WIDTH="100%">
						<a name="textfeld">
						<TEXTAREA NAME="message" WRAP="VIRTUAL" COLS="70" ROWS="20"><?
							if ($quotemessage) {
								echo "\n[quote]\n[i]Original von $quotemessage[authorname]:[/i]\n$quotemessage[message]\n[/quote]\n\n\n";
							}
						?></TEXTAREA>
						</a>
					</TD>
				</TR>
			</TABLE>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
			<div align="center">
				<? include "_ubbcode.inc"; ?>
			</div>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
			<div align="center">
				<input type="checkbox" name="signature" value="1" checked>
				&nbsp;&nbsp;<? print_mb ($sig_anhaengen, $font, "2"); ?>
			</div>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
			<div align="center">
				<input type="checkbox" name="do_disable_smilies" value="1">
				&nbsp;&nbsp;<? print_mb ($post_disable_smilies, $font, "2"); ?>
			</div>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
			<div align="center">
				<input type="checkbox" name="email" value="1">
				&nbsp;&nbsp;<? print_mb ($email_not, $font, "2"); ?>
			</div>
		</TD>
	</TR>
	<TR ALIGN="CENTER">
		<TD BGCOLOR="<? echo $tableC; ?>" COLSPAN="2">
			<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
			<INPUT TYPE="submit" CLASS="button" NAME="reply_topic" VALUE="<? echo $antwort_posten; ?>">
		</TD>
	</TR>
</TABLE>
</FORM>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc"; 
?>