<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
require "_iconmap.inc";
require "_ubbcodescript.inc";

$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)){
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;edit Post";
require "_header.inc";
$result = mysql_query("SELECT userid,username,userpassword,status FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
$userdat = mysql_fetch_array($result);
echo mysql_error();
if ($userdat[userpassword] != $UPASS) {
	apb_error("ERROR #08: Invalid password in cookie!",TRUE);
}
if (!isset($postid)) {
	$postid = $edit_postid;
}
$post_info = GetPostInfo($postid);
$post_info = mysql_fetch_array($post_info);
$threadparentid = $post_info[threadparentid];
$postid = $post_info[postid];
$authorname = $post_info[authorname];
$authorrank = $post_info[authorrank];
$posttime = $post_info[posttime];
$message = $post_info[message];
$email = $post_info[email];
$disable_smilies = $post_info[disable_smilies];
$thread_info = GetThreadInfo($threadparentid);
$thread_info = mysql_fetch_array($thread_info);
$board_info = GetBoardInfo($thread_info[boardparentid]);
$board_info = mysql_fetch_array($board_info);
$boardparentid = $board_info[boardid];
// <--------------------------------------- edit POST ------------------------------------------>
if ($action == "editpost") {
	if ($userdat[username] == $authorname || $username == $authorname || $userdat[status] == "ADMIN") {
		if (!$postit) {

			add_ubbcodescript("new_message");

			echo "<FORM NAME=\"MESSAGEFORM\" ACTION=\"$php_path/edit.php\" METHOD=\"POST\">";
			echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">";
			echo "	<TR><TD BGCOLOR=\"$tableC\"><CENTER>";
			print_mb ($beitrag_editieren, $font, "4" );
			print_mb ($im_forum . $board_info[boardname], $font, "2" );
			echo "	</CENTER></TD></TR><TR><TD BGCOLOR=\"$tableA\">";
			print_mb ($aktuelles_thema . $thread_info[threadname], $font, "2");

?>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN="2">
			<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="6">
				<TR BGCOLOR="<? echo $tableB; ?>">
					<TD NOWRAP>
						<? print_mb ($formatierung_hinweis, $font, "1"); ?><BR><BR><BR>
						<? print_mb ("<b>Klick'n'paste</b>", $font, "1"); ?><BR>
						<? print_mb ($iconauswahl, $font, "1"); ?><BR>
						<? add_iconmap("new_message"); ?>
					</TD>
					<TD WIDTH="100%">
						<a name="textfeld">
						<TEXTAREA NAME="newmessage" WRAP="VIRTUAL" COLS="70" ROWS="20"><? echo $message; ?></TEXTAREA>
						</a>
					</TD>
				</TR>
			</TABLE>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
			<div align="center">
				<? include "_ubbcode.inc"; ?>
			</div>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
			<div align="center">
				<input type="checkbox" name="do_disable_smilies" value="1"<?
					if ($disable_smilies) {
						echo " checked";
					}
				?>>
				&nbsp;&nbsp;<? print_mb ($post_disable_smilies, $font, "2"); ?>
			</div>
		</TD>
	</TR>
	<TR ALIGN="CENTER">
		<TD BGCOLOR="<? echo $tableC; ?>" COLSPAN="2">
			<INPUT TYPE="hidden" NAME="edit_postid" VALUE="<? echo $postid; ?>">
			<INPUT TYPE="hidden" NAME="postit" VALUE="1">
			<INPUT TYPE="hidden" NAME="$username" VALUE="$userdat[username]">
			<INPUT TYPE="hidden" NAME="action" VALUE="editpost">
			<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
			<INPUT TYPE="submit" NAME="submit" VALUE="<? echo $save_choose; ?>">
		</TD>
	</TR>
</TABLE>
</FORM>

<?
		} else {
			if ($do_disable_smilies != "1") {
				$do_disable_smilies = "0";
			}
			
			$akt_post = GetPostInfo($edit_postid);
			$akt_post = mysql_fetch_array($akt_post);
			$akt_post_ip = $akt_post[post_ip];
			
			if (!is_int(strpos($akt_post_ip, $REMOTE_ADDR))) {
				$akt_post_ip .= ",$REMOTE_ADDR";
			}
			$now = time();
			$new_message1 = $new_message.$message_editiert1.$userdat[username].$message_editiert2.HackDate2($now).$message_editiert3;
			$new_message1 = apb_wordwrap($new_message1);
			$new_message1 = RemovePostCrap($new_message1);
			mysql_query("UPDATE apb".$n."_posts SET message='$new_message1', disable_smilies='$do_disable_smilies', post_ip='$akt_post_ip' WHERE postid='$edit_postid'");
			echo mysql_error();
			question_box($post_edited, "[ <A HREF=\"Javascript:history.back(1)\">$zurueck</A> | <A HREF=\"$php_path/thread.php?id=$threadparentid&BoardID=$boardparentid\">$zurueck_zum_thema</A> ]");
		}

	} else {
		$mod = explode (", ", $board_info[boardmods]);
		if ($userdat[status]=="MOD" && apb_in_array($userdat[username], $mod)) {
			
			if (!$postit) {

				add_ubbcodescript("new_message");

				echo "<FORM NAME=\"MESSAGEFORM\" ACTION=\"$php_path/edit.php\" METHOD=\"POST\">";
				echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">";
				echo "<TR><TD BGCOLOR=\"$tableC\"><CENTER>";
				print_mb ($beitrag_editieren, $font, "4" );
				print_mb ($im_forum . $board_info[boardname], $font, "2" );
				echo "</CENTER></TD></TR><TR><TD BGCOLOR=\"$tableA\">";
				print_mb ($aktuelles_thema . $thread_info[threadname], $font, "2");

?>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN="2">
			<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="6">
				<TR BGCOLOR="<? echo $tableB; ?>">
					<TD NOWRAP>
						<? print_mb ($formatierung_hinweis, $font, "1"); ?><BR><BR><BR>
						<? print_mb ("<b>Klick'n'paste</b>", $font, "1"); ?><BR>
						<? print_mb ($iconauswahl, $font, "1"); ?><BR>
						<? add_iconmap("new_message"); ?>
					</TD>
					<TD WIDTH="100%">
						<a name="textfeld">
						<TEXTAREA NAME="new_message" WRAP="VIRTUAL" COLS="70" ROWS="20"><? echo $message; ?></TEXTAREA>
						</a>
					</TD>
				</TR>
			</TABLE>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
			<div align="center">
				<? include "_ubbcode.inc"; ?>
			</div>
		</TD>
	</TR>
	<TR>
		<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
			<div align="center">
				<input type="checkbox" name="do_disable_smilies" value="1"<?
					if ($disable_smilies) {
						echo " checked";
					}
				?>>
				&nbsp;&nbsp;<? print_mb ($post_disable_smilies, $font, "2"); ?>
			</div>
		</TD>
	</TR>
	<TR ALIGN="CENTER">
		<TD BGCOLOR="<? echo $tableC; ?>" COLSPAN="2">
			<INPUT TYPE="hidden" NAME="edit_postid" VALUE="<? echo $postid; ?>">
			<INPUT TYPE="hidden" NAME="postit" VALUE="1">
			<INPUT TYPE="hidden" NAME="$username" VALUE="$userdat[username]">
			<INPUT TYPE="hidden" NAME="action" VALUE="editpost">
			<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
			<INPUT TYPE="submit" NAME="submit" VALUE="<? echo $save_choose; ?>">
		</TD>
	</TR>
</TABLE>
</FORM>

<?

			} else {
				if ($do_disable_smilies != "1") {
					$do_disable_smilies = "0";
				}
				
				$akt_post = GetPostInfo($edit_postid);
				$akt_post = mysql_fetch_array($akt_post);
				$akt_post_ip = $akt_post[post_ip];
				
				if (!is_int(strpos($akt_post_ip, $REMOTE_ADDR))) {
					$akt_post_ip .= ",$REMOTE_ADDR";
				}
			
				$now = time();
				$new_message1 = $new_message.$message_editiert1.$userdat[username].$message_editiert2.HackDate2($now).$message_editiert3;
				$new_message1 = apb_wordwrap($new_message1);
				$new_message1 = RemovePostCrap($new_message1);
				mysql_query("UPDATE apb".$n."_posts SET message='$new_message1', disable_smilies='$do_disable_smilies', post_ip='$akt_post_ip' WHERE postid='$edit_postid'");
				echo mysql_error();
				question_box($post_edited, "[ <A HREF=\"Javascript:history.back(1)\">$zurueck</A> | <A HREF=\"$php_path/thread.php?id=$threadparentid&BoardID=$boardparentid\">$zurueck_zum_thema</A> ]");
			}
		} else {
			apb_error($auth_edit,FALSE);
		}
	}
}

$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>