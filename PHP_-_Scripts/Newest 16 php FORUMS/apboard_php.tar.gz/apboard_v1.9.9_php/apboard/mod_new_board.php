<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/mod1.php\"><b>".$mod_center."</b></a>";
require "_header.inc";

$usedefaultstyle = 1;

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD><font face="<? echo $font; ?>" size=3><b><? echo $mod_center; ?></b></font></TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $mod_board_design; ?></font></td>
					<td width="2%">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%" height="18">&nbsp;</td>
					<td width="96%" height="18" colspan="2" rowspan="13">
<?

$auth = UserAuth($UserInformation[uid],$UserInformation[upass]);
if ($auth=="4") {
	$user_query = mysql_query("SELECT username FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
	while ($user_profile = mysql_fetch_row($user_query)) {
		$username = $user_profile[0];
	}

?>
						<table width="100%" border="0" cellspacing="1" cellpadding="4">
							<tr>
								<td width="96%" height="18">
									<div align="center">
									<font face="<? echo $font; ?>" size=2>
<?

	if (!isset($action)) {

?>
		<table width="98%" border="0" cellspacing="1" cellpadding="4">
			<tr BGCOLOR="<? echo $tableB; ?>">
				<td width="49%" height="18">
					<div align="left">
					<font face="<? echo $font; ?>" size=2><br>
					 <? echo $mod_welche_kat; ?>
					</font>
					</div>
				</td>
				<td width="49%" height="18">
					<div align="left">
					<font face="<? echo $font; ?>" size=2><br>
					<form action="mod_new_board.php" method="post">
					<select name="category1">
					<option selected><? echo $mod_bitte_waehlen; ?></option>
<?
		$resultkategorie1 = mysql_query("SELECT DISTINCT(category) FROM apb".$n."_boards WHERE boardmods LIKE '$username' OR boardmods LIKE '$username,%' OR boardmods LIKE '%, $username' OR boardmods LIKE '%, $username,%'");
		while($thiscategory = mysql_fetch_row($resultkategorie1)) {
			$cat = $thiscategory[0];
			echo "<option>".$cat."</option>";
		}
?>
					</select>&nbsp;&nbsp;&nbsp;
					<input type="hidden" name="action" value="1">
					<input type="submit" name="Submit" value="<? echo $mod_waehlen; ?>">
					</form>
					</font>
					</div>
				</td>
			</tr>
		</table>
<?

	} elseif ($action=="1") {
		if ($category1 == $mod_bitte_waehlen) {
			print_mb ("<B>".$mod_keine_kat_gewaehlt."</B><BR><BR>", $font, "3");
			echo "\n 					</td>\n";
			echo "				 </tr>\n";
			echo "			</table>\n";
			echo "	  </td>\n</tr>\n</table>\n";
			echo "</td>\n</tr>\n</table>\n";
			include "_footer.inc";
			exit;
		}
		
		$resultkategorie1 = mysql_query("SELECT category FROM apb".$n."_boards WHERE category = '$category1' AND (boardmods LIKE '$username' OR boardmods LIKE '$username,%' OR boardmods LIKE '%, $username' OR boardmods LIKE '%, $username,%')");
		if ($thiscategory = mysql_fetch_row($resultkategorie1)) {
			//
		} else {
			message_box ("Guter Versuch! :-)");
			exit;
		}
		
	

?>
		<form method=post ACTION=<? echo "$php_path/mod_new_board.php"; ?>>
			<table width="100%" border="0" cellspacing="1" cellpadding="4">
				<tr>
					<td width="48%" height="18">
						<div align="right"></div>
					</td>
					<td width="48%" height="18">
						<div align="left"></div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_name; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<input type="text" name="boardname1" size="40" maxlength="40">
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $board_passw; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
						<input type="text" name="boardpassword1" size="40" maxlength="40">
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_mod; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<input type="text" name="boardmods1" size="40" maxlength="40">
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_posts_bisher; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left"> <font face="<? echo $font; ?>" size=2>0</font>
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_letzter_post; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left"> <font face="<? echo $font; ?>" size=2>--</font>
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_describtion; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<input type="text" name="descriptiontext1" size="50" maxlength="100">
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_bild; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<input type="text" name="boardgfx1" size="40" maxlength="150"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$imageurl\"";
							 ?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_stylesheet; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<textarea name="boardcss1" cols="40" rows="6"></textarea>
						</div>
					</td>
				</tr>
				<tr>
					<td width="48%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
					</td>
					<td width="48%">
						<div align="left">
							<font face="<? echo $font; ?>" size=2><? echo $category1; ?></font>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hintergrundbild; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							<? echo $mod_hintergrundbild_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="hgpicture1" size="40" maxlength="200"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$hgpicture\"";
							 ?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_fixed; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							<? echo $mod_hg_fixed_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<? if ($usedefaultstyle=="1") {
									if ($bgfixed=="1")
										$bgfix1add = " checked";
									else
										$bgfix1add = "";
								} else {
									$bgfix1add = "";
								}
							 ?>
							<input type="checkbox" name="bgfixed1" value="1"<? echo $bgfix1add; ?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_gen_schriftart; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="font1" size="20" maxlength="20"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$font\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_prim_schriftfarbe; ?>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="fontcolor1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$fontcolor\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_sek_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
						<? echo $mod_sek_schriftfarbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="fontcolorsec1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$fontcolorsec\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_farbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
						<? echo $mod_hg_farbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="bgcol1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$bgcol\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_gen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
						<? echo $mod_hg_tab_gen_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="tablebg1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$tablebg\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_a; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="tableA1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$tableA\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_b; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="tableB1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$tableB\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_c; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="tableC1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$tableC\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_links; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
						<input type="text" name="links1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$links\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_visited; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
							<input type="text" name="visited1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$visited\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_active; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
						<input type="text" name="active1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$active\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td width="56%">
						<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_hover; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
					</td>
					<td width="44%">
						<div align="left">
						<input type="text" name="hover1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$hover\"";
								?>>
						</div>
					</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td width="48%">&nbsp;</td>
				</tr>
				<tr>
					<td colspan="2">
						<div align="center">
							<input type="hidden" name="totalposts" value="0">
							<input type="hidden" name="kat" value="<? echo $category1; ?>">
							<input type="hidden" name="action" value="2">
							<input type="submit" name="Submit" value="<? echo $mod_speichern; ?>">
						</div>
					</td>
				</tr>
			</table>
		</form>
<?
	} elseif ($action=="2") {
		if (!isset($boardname1)) {
			apb_error($kein_boardname, FALSE);
			include "_footer.inc";
			exit;
		}
		$resultkategorie1 = mysql_query("SELECT category FROM apb".$n."_boards WHERE category = '$kat' AND (boardmods LIKE '$username' OR boardmods LIKE '$username,%' OR boardmods LIKE '%, $username' OR boardmods LIKE '%, $username,%')");
		if ($thiscategory = mysql_fetch_row($resultkategorie1)) {
			//
		} else {
			message_box ("Guter Versuch! :-)");
			exit;
		}
		$lastmodified = time();
		mysql_query("INSERT INTO apb".$n."_boards VALUES('','$boardname1','$boardpassword1','$boardmods1','$totalposts','$lastmodified','$descriptiontext1','$boardgfx1','$boardcss1','$kat','$font1','$fontcolor1','$fontcolorsec1','$bgcol1','$tablebg1','$tableA1','$tableB1','$tableC1','$imageurl1','$links1','$visited1','$active1','$hover1','$hgpicture1','$bgfixed1')");
		echo mysql_error();
		echo "<br><br><br><center><font size=5 face=verdana><b>".$mod_gespeichert."</b></font></center><br><br><br>";
	}
?>
									</font>
									</div>
								</td>
							</tr>
						</table>
<?

} else {
	apb_error($mod_kein_mod,FALSE);
}

?>
					</td>
					<td width="2%" height="18">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%">&nbsp;</td>
					<td width="2%">&nbsp;</td>
				</tr>
			</table>
		</TD>
	</TR>
</TABLE>
<?

require "_footer.inc";

?>