<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";

$colwidths = array( "50", "*", "60", "50", "100", "135");

$ustring = CookieAuth($UserInformation);
$threads = GetThreads($id,$start);


// Seiten-String f&uuml;r Thread-&Uuml;bersicht
$thisboard = mysql_query("SELECT COUNT(*) FROM apb".$n."_threads WHERE boardparentid = '$id' AND flags != 2");
echo mysql_error();
$thisboard = mysql_fetch_row($thisboard);
$thisboard = $thisboard[0];
if ($thisboard == "0") {
	$thisboard = 1;
}
$ostr = " ";
$thread_pages = ceil($thisboard / $threads_per_page);
$thispage = ceil($start / $threads_per_page);
if ($thispage == "0") {
	$thispage = 1;
}
$thread_pages_string = $seiten." ";
for ($l=1 ; $l <= $thread_pages; $l++) {
	if ($l == $thispage) {
		$thread_pages_string .= "-$l-$ostr";
	} else {
		$thread_pages_string .= "<A HREF=\"$php_path/board.php?id=$id&start=";
		$thread_pages_string .= ($l - 1) * $threads_per_page + 1;
		$thread_pages_string .= "&BoardID=$BoardID\">$l</A>$ostr";
	}
}


$board_info = GetBoardInfo($id);
$board_info = mysql_fetch_array($board_info);
if (!$board_info) {
	apb_error($board_existiert_nicht,FALSE);
}
$BoardID = $id;
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style))
{
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}


if (isset($Cookie_Board_PW[$id]) && !$passwort) {
	if ($Cookie_Board_PW[$id] != $board_info[boardpassword]) setcookie("Cookie_Board_PW[$id]", "", time() - 60000);
}

if ($passwort && ($board_pw == $board_info[boardpassword])) {
	setcookie("Cookie_Board_PW[$id]", "$board_pw", time() + $time_BoardPW_store_cookie);
}

if (time() - ($treshold_last_activity) > $last_activity[$id]) {
	if ($last_activity[$id] != $last_visit[$id]) {
		setcookie("last_visit[$id]", "".$last_activity[$id]."", time() + (60*60*24*365));
	}
	setcookie("last_activity[$id]", time(), time() + (60*60*24*365));
}


$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/main.php?cat=$board_info[category]\">";
$hstring.= "$board_info[category]</A><BR>&nbsp;&nbsp;&nbsp;&nbsp;$board_info[boardname]";
require "_header.inc";


if (!$passwort && !$Cookie_Board_PW[$id]) {
	if (!$board_info[boardpassword])
	{
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\">";
		echo "  <TR BGCOLOR=\"$tableC\">";
		echo "    <TD COLSPAN=\"6\"><FONT SIZE=2 FACE=\"$font\">";
		echo "      <DIV ALIGN=\"LEFT\"><B>&nbsp;$board_info[boardname]</B><BR>";
		echo "         <FONT SIZE=1>&nbsp;&nbsp;$board_info[descriptiontext]</FONT><BR><BR>";
		echo "       </DIV>";
		echo "          <TABLE WIDTH=\"100%\"><TR>";
		echo "             <TD WIDTH=\"50%\"><FONT SIZE=2 FACE=\"$font\">$thread_pages_string</FONT></TD>";
		echo "             <TD WIDTH=\"50%\" ALIGN=\"RIGHT\"><FONT SIZE=2 FACE=\"$font\"><b>[ - <A HREF=\"$php_path/topic.php?insertinto=$id&BoardID=$BoardID\">".$neues_thema."</A> - ]</b></FONT></TD>";
		echo "          </TR></TABLE>";
		echo "         </font>";
		echo "    </TD>";
		echo "  </TR>";
?>
	<TR BGCOLOR="<? echo $tableA; ?>">
		<TD WIDTH="<? echo $colwidths[0]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $status_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[1]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $topic_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[2]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $author_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[3]; ?>"><CENTER><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $antworten_ueberschrift; ?></FONT></CENTER></TD>
		<TD WIDTH="<? echo $colwidths[4]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $letzter_poster; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[5]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $letzter_beitrag; ?></FONT></TD>
	</TR>
<?

	while ($thisthread = mysql_fetch_array($threads))
	{
		$pages = ceil(($thisthread[replies]+1) / $posts_per_page);
		if ($pages > 1) {
			$pages_string = "<BR><FONT SIZE=\"1\" face=\"$font\">".$seiten." ";
			for ($l=1 ; $l <= $pages; $l++) {
				$pages_string .= "<A HREF=\"$php_path/thread.php?id=$thisthread[threadid]&start=";
				$pages_string .= ($l - 1) * $posts_per_page + 1;
				$pages_string .= "&BoardID=$BoardID\">$l</A>$ostr";
			}
			$pages_string .= "</FONT>";
		} else {
			$pages_string = "";
		}

		$topic = RemoveCrop($thisthread[threadname]);
		if (!$thisthread[topicicon]) {
			$topicicon = "$php_path/themes/icons/text.gif";
		} else {
			$topicicon = $thisthread[topicicon];
		}
		
		if ($thisthread[replies] > "14") {
			if ($last_visit[$id] < $thisthread[timelastreply]) {
				$topicfolder = "$php_path/themes/icons/brennenrot.gif";
			} else {
				$topicfolder = "$php_path/themes/icons/brennen.gif";
			}
		} else {
			if ($last_visit[$id] < $thisthread[timelastreply]) {
				$topicfolder = "$php_path/themes/icons/roterordner.gif";
			} else {
				$topicfolder = "$php_path/themes/icons/ordner.gif";
			}
		}

		if ($thisthread[flags]!="2") {

			echo "<TR BGCOLOR=\"$tableB\">";
			if ($thisthread[flags]=="1") {
				echo "<TD><CENTER><img src=\"$topicfolder\"> <img src=\"$php_path/themes/closed.gif\"></CENTER></TD>";
			} else {
				echo "<TD><CENTER><img src=\"$topicfolder\"> <img src=\"$topicicon\"></CENTER></TD>";
			}
			$result = mysql_query("SELECT * FROM apb".$n."_posts WHERE threadparentid='$thisthread[threadid]' ORDER BY posttime DESC;");
			$result = mysql_fetch_array($result);
			$reply_von = $result[authorname];
			echo "<TD><A HREF=\"$php_path/thread.php?id=$thisthread[threadid]&BoardID=$BoardID\"><font size=2 face=\"$font\">$topic</font></A>&nbsp;&nbsp;&nbsp;$pages_string</TD>";
			echo "<TD><A HREF=\"$php_path/user.php?username=yes&id=$thisthread[author]&BoardID=$BoardID\"><font size=1 face=\"$font\">$thisthread[author]</font></a></TD>";
			echo "<TD><CENTER><font size=1 face=\"$font\">$thisthread[replies]</font></CENTER></TD>";
			if ($thisthread[replies]=="" || $thisthread[replies]==" " || $thisthread[replies]=="0") {
				$reply_von = "&nbsp;";
			} else {
				$reply_von = "<A HREF=\"$php_path/user.php?username=yes&id=$reply_von&BoardID=$BoardID\"><font size=1 face=\"$font\">".$reply_von."</font></a>";
			}
			echo "<TD>$reply_von</TD>\n";
			echo "<TD><font size=1 face=\"$font\">". HackDate($thisthread[timelastreply]) ."</font></TD></TR>\n";

		}
	}

	/*
	<TR BGCOLOR="<? echo $tableA; ?>">
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
	</TR>
	*/
?>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN="6">
			<FONT SIZE=2 FACE=\"$font\"><? echo $thread_pages_string; ?></FONT>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="6" HEIGHT="40">
			<CENTER><FONT SIZE=2 FACE="<? echo $font; ?>">
				<b>[ - <A HREF="<? echo "$php_path/topic.php?insertinto=$id&BoardID=$BoardID"; ?>"><? echo $neues_thema; ?></A> - ]</b>
			</FONT></CENTER>
		</TD>
	</TR>
</TABLE>
<?
} else {
	echo "<TABLE BGCOLOR=\"$tablebg\" ALIGN=\"CENTER\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\">
	<FORM ACTION=\"$php_path/board.php\" method=post>
	<TR BGCOLOR=\"$tableC\">
		<TD COLSPAN=\"2\"><FONT FACE=\"$font\" SIZE=5><B>$board_passw</B></FONT><BR>
			<FONT FACE=\"$font\" SIZE=2>$board_needs_pw</FONT>
		</TD>
	</TR>
	<TR BGCOLOR=\"$tableA\">
		<TD WIDTH=\"50%\"><FONT FACE=\"$font\" SIZE=2><B>$board_passw</B></FONT><BR>
			<FONT FACE=\"$font\" SIZE=1>$type_pw</FONT>
		</TD>
		<TD WIDTH=\"50%\">
			<INPUT CLASS=\"button\" TYPE=\"password\" NAME=\"board_pw\" MAXLENGTH=\"30\" SIZE=\"25\">
		</TD>
	</TR>
	<TR BGCOLOR=\"$tableB\">
		<TD COLSPAN=\"2\">
			<INPUT TYPE=\"hidden\" NAME=\"passwort\" VALUE=\"1\">
			<INPUT TYPE=\"hidden\" NAME=\"id\" VALUE=\"$id\">";			
	if ($start > 1) {
		echo "			<INPUT TYPE=\"hidden\" NAME=\"start\" VALUE=\"$start\">";
	}
	echo "			<CENTER><INPUT CLASS=\"button\" TYPE=\"submit\" NAME=\"Submit\" VALUE=\"Login\"></CENTER>
		</TD>
	</TR>
	</FORM>
</TABLE>";
}

//Passwort-Block
} else {
	if ($board_pw==$board_info[boardpassword] || $Cookie_Board_PW[$id]==$board_info[boardpassword]) {
		if (!isset($board_pw)) {
			$board_pw = $Cookie_Board_PW[$id];
		}
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\">";
		echo "  <TR BGCOLOR=\"$tableC\">";
		echo "    <TD COLSPAN=\"6\"><FONT SIZE=2 FACE=\"$font\">";
		echo "      <DIV ALIGN=\"LEFT\"><B>&nbsp;$board_info[boardname]</B><BR>";
		echo "         <FONT SIZE=1>&nbsp;&nbsp;$board_info[descriptiontext]</FONT><BR><BR>";
		echo "       </DIV>";
		echo "          <TABLE WIDTH=\"100%\"><TR>";
		echo "             <TD WIDTH=\"50%\"><FONT SIZE=2 FACE=\"$font\">$thread_pages_string</FONT></TD>";
		echo "             <TD WIDTH=\"50%\" ALIGN=\"RIGHT\"><FONT SIZE=2 FACE=\"$font\"><b>[ - <A HREF=\"$php_path/topic.php?insertinto=$id&BoardID=$BoardID\">".$neues_thema."</A> - ]</b></FONT></TD>";
		echo "          </TR></TABLE>";
		echo "         </font>";
		echo "    </TD>";
		echo "  </TR>";

?>
	<TR BGCOLOR="<? echo $tableA; ?>">
		<TD WIDTH="<? echo $colwidths[0]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $status_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[1]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $topic_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[2]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $author_ueberschrift; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[3]; ?>"><CENTER><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $antworten_ueberschrift; ?></FONT></CENTER></TD>
		<TD WIDTH="<? echo $colwidths[4]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $letzter_poster; ?></FONT></TD>
		<TD WIDTH="<? echo $colwidths[5]; ?>"><FONT FACE="<? echo $font; ?>" SIZE="1"><? echo $letzter_beitrag; ?></FONT></TD>
	</TR>
<?

	while($thisthread = mysql_fetch_array($threads))
	{
		$pages = ceil(($thisthread[replies]+1) / $posts_per_page);
		if ($pages > 1) {
			$pages_string = "<BR><FONT SIZE=\"1\" face=\"$font\">".$seiten." ";
			for ($l=1 ; $l <= $pages; $l++) {
				$pages_string .= "<A HREF=\"$php_path/thread.php?id=$thisthread[threadid]&start=";
				$pages_string .= ($l - 1) * $posts_per_page + 1;
				$pages_string .= "&BoardID=$BoardID\">$l</A>$ostr";
			}
			$pages_string .= "</FONT>";
		} else {
			$pages_string = "";
		}

		$topic = RemoveCrop($thisthread[threadname]);
		if (!$thisthread[topicicon]) {
			$topicicon = "$php_path/themes/icons/text.gif";
		} else {
			$topicicon = $thisthread[topicicon];
		}
		
		if ($thisthread[replies] > "14") {
			if ($last_visit[$id] < $thisthread[timelastreply]) {
				$topicfolder = "$php_path/themes/icons/brennenrot.gif";
			} else {
				$topicfolder = "$php_path/themes/icons/brennen.gif";
			}
		} else {
			if ($last_visit[$id] < $thisthread[timelastreply]) {
				$topicfolder = "$php_path/themes/icons/roterordner.gif";
			} else {
				$topicfolder = "$php_path/themes/icons/ordner.gif";
			}
		}

		if ($thisthread[flags]!="2") {
			echo "<TR BGCOLOR=\"$tableB\">";
			if ($thisthread[flags]=="1") {
				echo "<TD><CENTER><img src=\"$topicfolder\"> <img src=\"$php_path/themes/closed.gif\"></CENTER></TD>";
			} else {
				echo "<TD><CENTER><img src=\"$topicfolder\"> <img src=\"$topicicon\"></CENTER></TD>";
			}
			$result = mysql_query("SELECT * FROM apb".$n."_posts WHERE threadparentid='$thisthread[threadid]' ORDER BY posttime DESC;");
			$result = mysql_fetch_array($result);
			$reply_von = $result[authorname];
			echo "<TD><A HREF=\"$php_path/thread.php?id=$thisthread[threadid]&passwort=1&board_pw=$board_pw&BoardID=$BoardID\"><font size=2 face=\"$font\">$topic</font></A>&nbsp;&nbsp;&nbsp;$pages_string</TD>";
			echo "<TD><A HREF=\"$php_path/user.php?username=yes&id=$thisthread[author]&BoardID=$BoardID\"><font size=1 face=\"$font\">$thisthread[author]</font></a></TD>";
			echo "<TD><CENTER><font size=1 face=\"$font\">$thisthread[replies]</font></CENTER></TD>";
			if ($thisthread[replies]=="" || $thisthread[replies]==" " || $thisthread[replies]=="0") {
				$reply_von = "&nbsp;";
			}
			echo "<TD><A HREF=\"$php_path/user.php?username=yes&id=$reply_von&BoardID=$BoardID\"><font size=1 face=\"$font\">".$reply_von."</font></a></TD>\n";
			echo "<TD><font size=1 face=\"$font\">". HackDate($thisthread[timelastreply]) ."</font></TD></TR>\n";
		}
	}

	/*
	<TR BGCOLOR="<? echo $tableA; ?>">
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
		<TD><FONT SIZE="1">&nbsp;</FONT></TD>
	</TR>
	*/
	
?>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN="6">
			<FONT SIZE=2 FACE=\"$font\"><? echo $thread_pages_string; ?></FONT>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="6" HEIGHT="40">
			<CENTER><FONT SIZE=2 FACE="<? echo $font; ?>">
				<b>[ - <A HREF="<? echo "$php_path/topic.php?insertinto=$id&BoardID=$BoardID"; ?>"><? echo $neues_thema; ?></A> - ]</b>
			</FONT></CENTER>
		</TD>
	</TR>
</TABLE>
<?

	} else {
		apb_error ($pw_not_correct, $font, 1);
	}
}
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>