<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/mod1.php\"><b>".$mod_center."</b></a>";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD><font face="<? echo $font; ?>" size=3><b><? echo $mod_center; ?></b></font></TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $mod_board_design; ?></font></td>
					<td width="2%">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%" height="18">&nbsp;</td>
					<td width="96%" height="18" colspan="2" rowspan="13">
<?
$auth = UserAuth($UserInformation[uid],$UserInformation[upass]);
if ($auth=="4")
{
	$user_query = mysql_query("SELECT username FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
	while ($user_profile = mysql_fetch_row($user_query)) {
		$username = $user_profile[0];
	}

?>
						<table width="100%" border="0" cellspacing="1" cellpadding="4">
  							<tr>
	 							<td width="96%" height="18">
		  							<div align="center">
		  							<font face="<? echo $font; ?>" size=2>
<?
	if (!isset($action)) {
?>
										<table width="98%" border="0" cellspacing="1" cellpadding="4">
											<tr BGCOLOR="<? echo $tableB; ?>">
												<td width="49%" height="18">
													<div align="left">
													<font face="<? echo $font; ?>" size=2><br>
													<? echo $mod_board_waehlen; ?>
													</font>
													</div>
												</td>
												<td width="49%" height="18">
													<div align="left">
													<font face="<? echo $font; ?>" size=2><br>
													<form action="mod_board_design.php" method="post">
													<select name="board">
														<option selected><? echo $mod_bitte_waehlen; ?></option>
<?

		$resultkategorie1 = mysql_query("SELECT boardid,boardname,category FROM apb".$n."_boards WHERE boardmods LIKE '%$username%' ORDER BY category, boardname");
		while($thisboard = mysql_fetch_array($resultkategorie1)) {
			if ($thisboard[category] != $old_cat) {
				$cat_str = "---- $thisboard[category] -------------------------------------------------------------";
				$cat_str = substr($cat_str, 0, 55);
				echo "<option value=\"\"> $cat_str </option>";
			}
			echo "<option value=\"$thisboard[boardid]\">".$thisboard[boardname]."</option>";
			$old_cat = $thisboard[category];
		}

?>
													</select>&nbsp;&nbsp;&nbsp;
													<input type="hidden" name="action" value="1">
													<input type="submit" name="Submit" value="<? echo $mod_waehlen; ?>">
													</form>
													</font>
													</div>
												</td>
											</tr>
										</table>
<?

	} elseif ($action=="1") {
		if (!$board || $board == $mod_bitte_waehlen) {
			print_mb ("<B>".$mod_kein_board_gewaehlt."</B><BR><BR>", $font, "3");
			echo "\n 					</td>\n";
			echo "				 </tr>\n";
			echo "			</table>\n";
			echo "	  </td>\n</tr>\n</table>\n";
			echo "</td>\n</tr>\n</table>\n";
			include "_footer.inc";
			exit;
		}
		$resultboards = mysql_query("SELECT * FROM apb".$n."_boards WHERE boardid='$board'");
		echo mysql_error();
		while($thisline = mysql_fetch_array($resultboards)) {
			$boardid5 = $thisline[boardid];
			$boardname5 = $thisline[boardname];
			$boardpassword5 = $thisline[boardpassword];
			$boardmods5 = $thisline[boardmods];
			$totalposts5 = $thisline[totalposts];
			$lastmodified5 = $thisline[lastmodified];
			$descriptiontext5 = $thisline[descriptiontext];
			$boardgfx5 = $thisline[boardgfx];
			$boardcss5 = $thisline[boardcss];
			$category5 = $thisline[category];
			$font5 = $thisline[font];
			$fontcolor5 = $thisline[fontcolor];
			$fontcolorsec5 = $thisline[fontcolorsec];
			$bgcol5 = $thisline[bgcolor];
			$tablebg5 = $thisline[tablebg];
			$tableA5 = $thisline[tablea];
			$tableB5 = $thisline[tableb];
			$tableC5 = $thisline[tablec];
			$imageurl5 = $thisline[imageurl];
			$links5 = $thisline[linkcolor];
			$visited5 = $thisline[visited];
			$active5 = $thisline[active];
			$hover5 = $thisline[hover];
			$hgpicture5 = $thisline[hgpicture];
			$bgfixed5 = $thisline[bgfixed];
		}

?>
									<form method=post ACTION=<? echo "$php_path/mod_board_design.php"; ?>>
									<table width="100%" border="0" cellspacing="1" cellpadding="4">
										<tr>
											<td width="48%" height="18">
												<div align="right"></div>
											</td>
											<td width="48%" height="18">
												<div align="left"></div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_name; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="text" name="boardname1" value="<? echo $boardname5; ?>" size="40" maxlength="40">
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $board_passw; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="text" name="boardpassword1" value="<? echo $boardpassword5; ?>" size="40" maxlength="40">
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_mod; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="text" name="boardmods1" value="<? echo $boardmods5; ?>" size="40" maxlength="40" readonly>
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_posts_bisher; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left"> <font face="<? echo $font; ?>" size=2><? echo $totalposts5; ?></font></div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_letzter_post; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left"> <font face="<? echo $font; ?>" size=2><? echo HackDate($lastmodified5); ?></font>
											</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_describtion; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="text" name="descriptiontext1" value="<? echo $descriptiontext5; ?>" size="50" maxlength="100">
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_bild; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="text" name="boardgfx1" value="<? echo $boardgfx5; ?>" size="40" maxlength="150">
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_stylesheet; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<textarea name="boardcss1" cols="40" rows="6"><? echo $boardcss5; ?></textarea>
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
											</td>
											<td width="48%">
												<div align="left">
												<font face="<? echo $font; ?>" size=2><? echo $category5; ?></font>
												</div>
											</td>
										</tr>
										<tr>
											<td width="48%">
												<div align="right"><font face="<? echo $font; ?>" color=red size=1><b><? echo $mod_board_loeschen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="48%">
												<div align="left">
												<input type="checkbox" name="delete" value="1">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hintergrundbild; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
												<? echo $mod_hintergrundbild_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="hgpicture1" value="<? echo $hgpicture5; ?>" size="40" maxlength="200">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_fixed; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
												<? echo $mod_hg_fixed_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
											</td>
											<td width="44%">
												<div align="left"> <?
											if ($bgfixed5=="1") {
												$bgfixed2 = " checked";
											} else {
												$bgfixed2 = "";
											}
												?>
												<input type="checkbox" name="bgfixed1" value="1"<? echo $bgfixed2; ?>>
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_gen_schriftart; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="font1" value="<? echo $font5; ?>" size="20" maxlength="20">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_prim_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="fontcolor1" value="<? echo $fontcolor5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_sek_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
												<? echo $mod_sek_schriftfarbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="fontcolorsec1" value="<? echo $fontcolorsec5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_farbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
												<? echo $mod_hg_farbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="bgcol1" value="<? echo $bgcol5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_gen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
												<? echo $mod_hg_tab_gen_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="tablebg1" value="<? echo $tablebg5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_a; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="tableA1" value="<? echo $tableA5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_b; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="tableB1" value="<? echo $tableB5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_c; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="tableC1" value="<? echo $tableC5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_links; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="links1" value="<? echo $links5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_visited; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="visited1" value="<? echo $visited5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_active; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="active1" value="<? echo $active5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td width="56%">
												<div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_hover; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
											</td>
											<td width="44%">
												<div align="left">
												<input type="text" name="hover1" value="<? echo $hover5; ?>" size="9" maxlength="7">
												</div>
											</td>
										</tr>
										<tr>
											<td>&nbsp;</td>
											<td width="48%">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">
												<div align="center">
												<input type="hidden" name="action" value="2">
												<input type="hidden" name="boardid" value="<? echo $boardid5; ?>">
												<input type="submit" name="Submit" value="<? echo $mod_speichern; ?>">
												</div>
											</td>
										</tr>
									</table>
									</form>
<?
	} elseif ($action=="2") {
		if ($delete=="1") {
			mysql_query("DELETE FROM apb".$n."_boards WHERE boardid='$boardid'");
		} else {
			mysql_query("UPDATE apb".$n."_boards SET boardname='$boardname1', boardpassword='$boardpassword1', descriptiontext='$descriptiontext1', boardgfx='$boardgfx1', boardcss='$boardcss1', font='$font1', fontcolor='$fontcolor1', fontcolorsec='$fontcolorsec1', bgcolor='$bgcol1', tablebg='$tablebg1', tablea='$tableA1', tableb='$tableB1', tablec='$tableC1', imageurl='$imageurl1', linkcolor='$links1', visited='$visited1', active='$active1', hover='$hover1', hgpicture='$hgpicture1', bgfixed='$bgfixed1' WHERE boardid='$boardid'");
		}
		echo mysql_error();
		echo "<br><br><br><center><font size=5 face=verdana><b>".$mod_gespeichert."</b></font></center><br><br><br>";
	}
?>
									</font>
									</div>
								</td>
							</tr>
						</table>
<?
} else {
	apb_error($mod_kein_mod,FALSE);
}
?>
					</td>
					<td width="2%" height="18">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%">&nbsp;</td>
					<td width="2%">&nbsp;</td>
				</tr>
			</table>
		</TD>
	</TR>
</TABLE>
<?

require "_footer.inc";

?>