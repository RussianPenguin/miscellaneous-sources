<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$welcome";
if (!isset($cat)) {
	$user_category = $UserInformation[category];
	if (!isset($user_category)) {
		$boards = GetBoards();
		require "_header.inc";

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><? echo $status_ueberschrift; ?></font></TD>
		<TD WIDTH="45%"><font face="<? echo $font; ?>" size=1>Board</font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $threads_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $beitraege_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="20%"><font face="<? echo $font; ?>" size=1><? echo $letzter_beitrag; ?></font></TD>
		<TD WIDTH="10%"><font face="<? echo $font; ?>" size=1><? echo $moderiert_von; ?></font></TD>
	</TR>
<?
		while ($thisrow = mysql_fetch_array($boards)) {
			if ($thisrow[category] != $lastcategory) {
				echo " <TR BGCOLOR=\"$tableB\"><TD COLSPAN=6";
				if ($category_bgpicture != "") echo " background=\"$category_bgpicture\"";
				echo "><Font Size=2 Face=\"$font\"><b>$thisrow[category]</b></Font></TD></TR>";
			}
			$lastcategory = $thisrow[category];
			
			if ($last_visit[$thisrow[boardid]] < ($thisrow[totalposts] == "0" ? 0 : $thisrow[lastmodified])) {
				$new_posts_string = "<IMG SRC=\"$url_bulb_on\">";
			} else {
				$new_posts_string = "<IMG SRC=\"$url_bulb_off\">";
			}

					
			echo "	<TR BGCOLOR=\"$tableA\">\n    <TD VALIGN=\"CENTER\" ALIGN=\"CENTER\">$new_posts_string</TD>\n";
			echo "		<TD><A HREF=\"$php_path/board.php?id=$thisrow[boardid]&BoardID=$BoardID\"><b><FONT Face=\"$font\" SIZE=2>$thisrow[boardname]</Font></b></A><BR>";
			echo "			<FONT Face=\"$font\" SIZE=1>$thisrow[descriptiontext]</FONT>";
			echo "		</TD>\n";
			echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalthreads]</FONT></CENTER></TD>\n";
			echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalposts]</Font></CENTER></TD>\n";
			echo "		<TD><FONT Size=2 Face=\"$font\">".($thisrow[totalposts] == "0" ? $kein_beitrag : HackDate($thisrow[lastmodified]))."</Font></TD>\n";
			echo "		<TD>\n";
			
			$mod = explode (", ", $thisrow[boardmods]);
			$first_br = "";
			while (list($key, $val) = each($mod)) {
				if ($val != "" && $val != " " && $val != "  ") {
					echo"$first_br<A HREF=\"$php_path/user.php?username=yes&id=$val&BoardID=$BoardID\"><FONT Size=2 Face=\"$font\">$val</Font></A>\n";
				}
				$first_br = "<br>";
			}
			
			echo "		</TD>\n";
			echo "	</TR>\n";
			
		}
?>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN=6 ALIGN="RIGHT">
		<FONT SIZE="-1" FACE="<? echo $font; ?>">
		<FORM ACTION="useraction.php" METHOD=POST>
			<INPUT TYPE="HIDDEN" NAME="action" VALUE="set_boards_visited">
			<INPUT TYPE="IMAGE" SRC="./themes/button1.gif" VALUE="Boards als gelesen markieren">
		</FORM>
		</FONT>
		</TD>
	</TR>
</TABLE>
<?
	} elseif (isset($user_category)) {
		$boards_cat = GetBoards_cat($user_category);
		require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><? echo $status_ueberschrift; ?></font></TD>
		<TD WIDTH="45%"><font face="<? echo $font; ?>" size=1>Board</font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $threads_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $beitraege_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="20%"><font face="<? echo $font; ?>" size=1><? echo $letzter_beitrag; ?></font></TD>
		<TD WIDTH="10%"><font face="<? echo $font; ?>" size=1><? echo $moderiert_von; ?></font></TD>
	</TR>
<?
		while ($thisrow = mysql_fetch_array($boards_cat)) {
			if ($thisrow[category] != $lastcategory) {
				echo " <TR BGCOLOR=\"$tableB\"><TD COLSPAN=6";
				if ($category_bgpicture != "") echo " BACKGROUND=\"$category_bgpicture\"";
				echo "><Font Size=2 Face=\"$font\"><b>$thisrow[category]</b></Font></TD></TR>";
			}
			$lastcategory = $thisrow[category];
			
			if ($last_visit[$thisrow[boardid]] < ($thisrow[totalposts] == "0" ? 0 : $thisrow[lastmodified])) {
				$new_posts_string = "<IMG SRC=\"$url_bulb_on\">";
			} else {
				$new_posts_string = "<IMG SRC=\"$url_bulb_off\">";
			}
			
			echo "	<TR BGCOLOR=\"$tableA\">\n    <TD VALIGN=\"CENTER\" ALIGN=\"CENTER\">$new_posts_string</TD>\n";
			echo "		<TD><A HREF=\"$php_path/board.php?id=$thisrow[boardid]&BoardID=$BoardID\"><b><FONT Face=\"$font\" SIZE=2>$thisrow[boardname]</Font></b></A><BR>";
			echo "			<FONT Face=\"$font\" SIZE=1>$thisrow[descriptiontext]</FONT>\n";
			echo "		</TD>\n";
			echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalthreads]</FONT></CENTER></TD>\n";
			echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalposts]</Font></CENTER></TD>\n";
			echo "		<TD><FONT Size=2 Face=\"$font\">".($thisrow[totalposts] == "0" ? $kein_beitrag : HackDate($thisrow[lastmodified]))."</Font></TD>\n";
			echo "		<TD>\n";
			
			$mod = explode (", ", $thisrow[boardmods]);
			$first_br = "";
			while (list($key, $val) = each($mod)) {
				if ($val != "" && $val != " " && $val != "  ") {
					echo"$first_br<A HREF=\"$php_path/user.php?username=yes&id=$val&BoardID=$BoardID\"><FONT Size=2 Face=\"$font\">$val</Font></A>\n";
				}
				$first_br = "<br>";
			}
			
			echo "		</TD>\n";
			echo "	</TR>\n";
			
		}
?>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN=6 ALIGN="RIGHT">
		<FONT SIZE="-1" FACE="<? echo $font; ?>">
		<FORM ACTION="useraction.php" METHOD=POST>
			<INPUT TYPE="HIDDEN" NAME="action" VALUE="set_boards_visited">
			<INPUT TYPE="IMAGE" SRC="./themes/button1.gif" VALUE="Boards als gelesen markieren">
		</FORM>
		</FONT>
		</TD>
	</TR>
</TABLE>
<?

	}

} elseif (isset($cat)) {
	$cat1 = rawurldecode($cat);
	$boards_cat1 = GetBoards_cat($cat1);
	require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><? echo $status_ueberschrift; ?></font></TD>
		<TD WIDTH="45%"><font face="<? echo $font; ?>" size=1>Board</font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $threads_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="5%"><font face="<? echo $font; ?>" size=1><CENTER><? echo $beitraege_ueberschrift; ?></CENTER></font></TD>
		<TD WIDTH="20%"><font face="<? echo $font; ?>" size=1><? echo $letzter_beitrag; ?></font></TD>
		<TD WIDTH="10%"><font face="<? echo $font; ?>" size=1><? echo $moderiert_von; ?></font></TD>
	</TR>
<?
	while ($thisrow = mysql_fetch_array($boards_cat1)) {
		if ($thisrow[category] != $lastcategory) {
			echo " <TR BGCOLOR=\"$tableB\"><TD COLSPAN=6";
			if ($category_bgpicture != "") echo " BACKGROUND=\"$category_bgpicture\"";
			echo "><Font Size=2 Face=\"$font\"><b>$thisrow[category]</b></Font></TD></TR>";
		}
		$lastcategory = $thisrow[category];
		
		if ($last_visit[$thisrow[boardid]] < ($thisrow[totalposts] == "0" ? 0 : $thisrow[lastmodified])) {
			$new_posts_string = "<IMG SRC=\"$url_bulb_on\">";
		} else {
			$new_posts_string = "<IMG SRC=\"$url_bulb_off\">";
		}
		
		echo "	<TR BGCOLOR=\"$tableA\">\n    <TD VALIGN=\"CENTER\" ALIGN=\"CENTER\">$new_posts_string</TD>\n";
		echo "		<TD><A HREF=\"$php_path/board.php?id=$thisrow[boardid]&BoardID=$BoardID\"><b><FONT Face=\"$font\" SIZE=2>$thisrow[boardname]</Font></b></A><BR>";
		echo "			<FONT Face=\"$font\" SIZE=1>$thisrow[descriptiontext]</FONT>\n";
		echo "		</TD>\n";
		echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalthreads]</FONT></CENTER></TD>\n";
		echo "		<TD><CENTER><FONT Size=2 Face=\"$font\">$thisrow[totalposts]</FONT></CENTER></TD>\n";
		echo "		<TD><FONT Size=2 Face=\"$font\">".($thisrow[totalposts] == "0" ? $kein_beitrag : HackDate($thisrow[lastmodified]))."</Font></TD>\n";
		echo "		<TD>\n";
			
		$mod = explode (", ", $thisrow[boardmods]);
		$first_br = "";
		while (list($key, $val) = each($mod)) {
			if ($val != "" && $val != " " && $val != "  ") {
				echo"$first_br<A HREF=\"$php_path/user.php?username=yes&id=$val&BoardID=$BoardID\"><FONT Size=2 Face=\"$font\">$val</Font></A>\n";
			}
			$first_br = "<br>";
		}
		
		echo "		</TD>\n";
		echo "	</TR>\n";
			
	}
?>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
		<TD>&nbsp;</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD COLSPAN=6 ALIGN="RIGHT">
		<FONT SIZE="-1" FACE="<? echo $font; ?>">
		<FORM ACTION="useraction.php" METHOD=POST>
			<INPUT TYPE="HIDDEN" NAME="action" VALUE="set_boards_visited">
			<INPUT TYPE="IMAGE" SRC="./themes/button1.gif" VALUE="Boards als gelesen markieren">
		</FORM>
		</FONT>
		</TD>
	</TR>
</TABLE>
<?

}

$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>