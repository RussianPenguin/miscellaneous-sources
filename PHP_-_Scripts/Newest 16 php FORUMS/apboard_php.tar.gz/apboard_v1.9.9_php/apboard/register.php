<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$registrieren";
require "_header.inc";
if ($reg) {
	if (!$username || !$password || !$password2 || !$email) {
		apb_error($pflichtfeld_reg,FALSE);
	}
	if (strcmp($password,$password2)) {
				apb_error($passwort_unterschiedlich,FALSE);
	}
	if (!CheckChars($password)) {
		echo $password;
		apb_error($pw_unzulaessige_zeichen,FALSE);
	}
	if (!CheckChars($username)) {
		apb_error($benutzername_unzulaessig,FALSE);
	}
	if (strlen($password)<5) {
		apb_error($mind_5_zeichen,FALSE);
	}
	if (strlen($username)>30) {
		apb_error($benutzername_zu_lang,FALSE);
	}
	if (strlen($password)>25) {
		apb_error($max_25_zeichen,FALSE);
	}
	if (strlen($email)>70) {
		apb_error($email_zu_lang,FALSE);
	}
	if (strlen($signatur)>250) {
		apb_error($sig_zu_lang,FALSE);
	}
	$result = mysql_query("SELECT * FROM apb".$n."_user_table WHERE username='$username';");
	echo mysql_error();
	if (mysql_fetch_row($result)) {
		echo mysql_error();
		apb_error($benutzername_existiert_schon,FALSE);
	}
	$result = mysql_query("SELECT count(*) FROM apb".$n."_user_table;");
	echo mysql_error();
	$newuserid = mysql_fetch_row($result);
	$newuserid[0]++;
	$regdate = time();
	mysql_query("INSERT INTO apb".$n."_user_table VALUES('','$username','$password','$email','0','NORMAL','','$regdate','','','','','','','','','1','1');");
	echo mysql_error();
	echo "<TABLE BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" WIDTH=\"95%\" ALIGN=\"CENTER\" BGCOLOR=\"$tablebg\"><TR BGCOLOR=\"$tableC\"><TD><BR>";
	print_mb ($erfolgreich_registriert,$font,"2");
	echo "</TD></TR></TABLE>";
	echo mysql_error();
	include "_footer.inc";
	exit;
}

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<FORM ACTION="<? echo "$php_path/register.php"; ?>" METHOD="POST">
		<TR BGCOLOR="<? echo $tableC; ?>">
			<TD COLSPAN="2">
				<?	print_mb ($registrieren,$font,"6");
					print_mb ($registrieren_info,$font,"2"); ?>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ( $benutzername_profil, $font, "2");
					print_mb ( $benutzername_reg_info, $font, "1"); ?>
			</TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="username" MAXLENGTH="30">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%" VALIGN="TOP">
				<?	print_mb ( $passwort_profil, $font, "2");
					print_mb ( $passwort_profil_info, $font, "1"); ?>
			</TD>
			<TD>
				<INPUT CLASS="button" TYPE="PASSWORD" NAME="password" MAXLENGTH="26">
				<BR>
				<INPUT CLASS="button" TYPE="PASSWORD" NAME="password2" MAXLENGTH="26">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($email_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="email" MAXLENGTH="70">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD COLSPAN="2">
				<? print_mb($cookie_info_reg1,$font,"2");
					print_mb($cookie_info_reg2,$font,"2");
					print_mb($cookie_info_reg3,$font,"1"); ?>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableB; ?>">
			<TD COLSPAN="2">
				<CENTER>
				<INPUT TYPE="hidden" NAME="reg" VALUE="1">
				<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
				<INPUT CLASS="button" TYPE="reset" NAME="reset" VALUE="<? echo $reg_felder_loeschen; ?>">
				<INPUT CLASS="button" TYPE="submit" NAME="Submit" VALUE="<? echo $reg_felder_submit; ?>">
				</CENTER>
			</TD>
		</TR>
	</FORM>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>