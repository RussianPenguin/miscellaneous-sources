<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$hilfe";
require "_header.inc";

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="2">
			<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
				<TR BGCOLOR="<? echo $tableC; ?>">
					<TD COLSPAN="2">
						<FONT FACE="<? echo $font; ?>" SIZE=4>
						<center>
						<b><? echo $master_board_name; ?> - <? echo $hilfe; ?></b>
						</center>
						</font>
					</TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD colspan="2">
						<p><FONT FACE="<? echo $font; ?>" SIZE=2><? echo $apboard_code; ?></font></p>
					</TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%">
						<div align="center"><FONT FACE="<? echo $font; ?>" SIZE=2> <b>&nbsp;<? echo $code_ueberschrift; ?></b></font></div>
					</TD>
					<TD WIDTH="36%">
						<div align="center"><FONT FACE="<? echo $font; ?>" SIZE=2> <b>&nbsp;<? echo $ergebnis_ueberschrift; ?></b></font></div>
					</TD>
				</TR>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[url=http://www.apboard.de]APBoard-Homepage[/url]</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<a href="http://www.apboard.de">APBoard-Homepage</a></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						http://www.apboard.de</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<a href="http://www.apboard.de">http://www.apboard.de</a></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						www.apboard.de</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<a href="http://www.apboard.de">http://www.apboard.de</a></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[email]dma147@arcormail.de[/email]</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<a href="mailto:dma147@arcormail.de">dma147@arcormail.de</a></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[img]http://url_to_picture.de/bild.gif[/img]</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<? echo $help_picture; ?></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[url]http://URL_zu_page[img]http://url_to_picture.de/bild.gif[/img][/url]</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<? echo $help_picture_link; ?></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						&lt;htmltag&gt;Text&lt;/htmltag&gt;</font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<? echo $help_html; ?></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[center]Text[/center]</font></td>
					<td width="36%"><font FACE="<? echo $font; ?>" size="2">
						<center>
						Text
						</center>
						</font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[i]<? echo $help_kursiv; ?>[/i]</font></td>
					<td width="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<i><? echo $help_kursiv; ?></i></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[b]<? echo $help_fett; ?>[/b]</font></td>
					<td width="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<b><? echo $help_fett; ?></b></font></td>
				</tr>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[f1]<? echo $help_klein; ?>[/f1]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font size="1"><? echo $help_klein; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[f2]<? echo $help_normal; ?>[/f2]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<? echo $help_normal; ?></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%" height="29"><font FACE="<? echo $font; ?>" size="2">
						&nbsp; [f3]<? echo $help_etwas_goesser; ?>[/f3] </font></TD>
					<TD WIDTH="36%" height="29"><font FACE="<? echo $font; ?>" size="2">
						&nbsp; <font size="3"><? echo $help_etwas_groesser; ?></font> </font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[f4]<? echo $help_grosser; ?>[/f4]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font size="4"><? echo $help_grosser; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[f5]<? echo $help_riesiger; ?>[/f5]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font size="5"><? echo $help_riesiger; ?></font></font></TD>
				</TR>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[code]<? echo $help_phpcode; ?>[/code]</font></td>
					<td width="36%">
						<font face="<? echo $font; ?>" size="2"> <font face="Arial, Helvetica, sans-serif" size="1">&nbsp;
						Code: </font></font>
						<hr>
						<font face="<? echo $font; ?>" size="2"><font face="arial" size="1"><? echo $help_phpcode; ?></font></font>
						<hr>
					</td>
				</tr>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[verdana]<? echo $font_verdana.$help_font; ?>[/verdana]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<? echo $font_verdana.$help_font; ?></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[arial]<? echo $font_arial.$help_font; ?>[/arial]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font face="Arial"><? echo $font_arial.$help_font; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[courier]<? echo $font_courier.$help_font; ?>[/courier]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font face="Courier"><? echo $font_courier.$help_font; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[comic]<? echo $font_comic.$help_font; ?>[/comic]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font face="Comic Sans MS"><? echo $font_comic.$help_font; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[red]<? echo $font_rot.$help_font1; ?>[/red]</font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#FF0000"><? echo $font_rot.$help_font1; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[blue]<? echo $font_blau.$help_font1; ?>[/blue] </font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#0000FF"><? echo $font_blau.$help_font1; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[green]<? echo $font_gruen.$help_font1; ?>[/green] </font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#00FF00"><? echo $font_gruen.$help_font1; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[yellow]<? echo $font_gelb.$help_font1; ?>[/yellow] </font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#FFFF00"><? echo $font_gelb.$help_font1; ?></font></font></TD>
				</TR>
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD WIDTH="64%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						[white]<? echo $font_weiss.$help_font1; ?>[/white] </font></TD>
					<TD WIDTH="36%"><font FACE="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#FFFFFF"><? echo $font_weiss.$help_font1; ?></font></font></TD>
				</TR>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						[black]<? echo $font_schwarz.$help_font1; ?>[/black] </font></td>
					<td width="36%"><font face="<? echo $font; ?>" size="2"> &nbsp;
						<font color="#000000"><? echo $font_schwarz.$help_font1; ?></font></font></td>
				</tr>
				<tr bgcolor="<? echo $tableA; ?>">
					<td width="64%">
						<font face="<? echo $font; ?>" size="2">&nbsp;
						<? echo $font_points; ?>
						</font>
					</td>
					<td width="36%">
						<li><font font="font" face="<? echo $font; ?>" size="2">&nbsp;<? echo $font_point1; ?><br>
						</font>
						<li><font font="font" face="<? echo $font; ?>" size="2">&nbsp;<? echo $font_point2; ?><br>
						</font>
						<li><font font="font" face="<? echo $font; ?>" size="2">&nbsp;<? echo $font_point3; ?></font>
					</td>
				</tr>
			</TABLE>
			<br>
		</TD>
	</TR>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";
?>