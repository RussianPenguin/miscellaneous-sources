<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
$hilfe_cookie = $HTTP_COOKIE_VARS["APBoardHilfe"];
require "_language.inc";
require "__config.inc";
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;User online";
require "_header.inc";

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="2">
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<FONT FACE="<? echo $font; ?>" SIZE=4>
			<center>
			<b><? echo $master_board_name; ?> - User online</b>
			</center>
			</font>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableA; ?>">
		<TD>
			<p><FONT FACE="<? echo $font; ?>" SIZE=2><b><? echo $online_user_online; ?></b></font></p>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableA; ?>">
		<td>
			<TABLE BGCOLOR="<? echo $tableA; ?>" WIDTH="100%" BORDER="0" CELLSPACING="5" CELLPADDING="3" ALIGN="left">
				<TR BGCOLOR="<? echo $tableA; ?>">
					<TD width="120" height="69">
						<p align="center"><FONT FACE="<? echo $font; ?>" SIZE=2>
<?

$nickname = mysql_query("SELECT DISTINCT nickname FROM apb".$n."_useronline");
while ($nickname1 = mysql_fetch_row($nickname)) {
	if ($nickname1[0]=="" || $nickname1[0]==" ") {
		echo "< Gast ><br>";
	} else {
		echo "<b>".$nickname1[0]."</b><br>";
	}
}

?>
						</font></p>
						<p>&nbsp; </p>
					</TD>
					<TD width="498" height="69"><font face="<? echo $font; ?>" size=2>
<?
if ($chatact=="0") {
	echo "<blockquote><center>".$online_chat_nicht_aktiviert1.$adminemail.$online_chat_nicht_aktiviert2."</center></blockquote>";
} else {

?>
						<script language="JavaScript">
							window.open('<? echo $php_path; ?>/chat.html','APBoard_Chat_Fenster','left=30,top=100,width=780,height=500,resizable=yes,menubar=no,toolbar=no,location=no,directories=no,scrollbars=no,status=no');
						</script>
<?

}

?>
						</font>
					</TD>
				</TR>
			</TABLE>
		</td>
	</TR>
</TABLE>
		</TD>
	</TR>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>