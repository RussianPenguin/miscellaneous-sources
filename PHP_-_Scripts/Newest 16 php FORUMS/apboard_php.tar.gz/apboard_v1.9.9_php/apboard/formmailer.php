<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;FormMailer";
require "_header.inc";

if (!isset($UserInformation)) { apb_error("Nur registrierte Mitglieder d&uuml;rfen an andere Mitglieder eMails schicken",FALSE); }
if (!isset($toid)) {	apb_error("Keine Zielperson angegeben",FALSE); }

$user_result = GetUsereMail($toid);
$thisuser = mysql_fetch_array($user_result);

if ($allow_form_mailer != "1") {
	apb_error("Sorry der Formmailer wurde vom Administator dieses Boards deaktiviert.", FALSE);
}

if ($thisuser[users_may_email]) {
	echo "<BR>tutnix<BR>";
} elseif ($modlog || $adminlog) {
	if ($thisuser[mods_may_email] != "1") {
		apb_error("Dieser User m&ouml;chte keine eMails von Admins/Moderatoren empfangen.", FALSE);
	}
} else {
	apb_error("Dieser User m&ouml;chte keine eMails von anderen Usern empfangen.", FALSE);
}	

if (!isset($send)):
?>
<TABLE BGCOLOR="#003D71" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="#DADADA">
    <TD><font face="Verdana, Arial, Helvetica, sans-serif" size=3><b>FormMailer</b></font></TD>
  </TR>
  <TR BGCOLOR="#DADADA">
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="2%">&nbsp;</td>
          <td colspan="2"><font face="Verdana, Arial, Helvetica, sans-serif" size=2>eMail an <b><? echo $thisuser["username"]; ?></b></font></td>
          <td width="2%">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%" height="18">&nbsp;</td>
          <td width="96%" height="18" colspan="2" rowspan="13">
            <form action="<? echo $PHP_SELF; ?>" method="POST">
              <div align="center">To:&nbsp;&nbsp;&nbsp;<? echo $thisuser["username"]; ?><br>
                <br>
                Topic<br>
                <input type="text" name="mailtopic" size="40" maxlength="60">
                <br>
                <br>
                Text<br>
                <textarea name="mailtext" cols="72" rows="12" wrap=physical></textarea>
                <br>
                <br>
                <input type="hidden" name="toid" value="<? echo $toid; ?>">
                <input type="hidden" name="send" value="preview">
                <input type="submit" name="submit" value="Preview">
                &nbsp;
                <input type="reset" name="reset" value="reset">
                <br>
              </div>
            </form>
          </td>
          <td width="2%" height="18">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%">&nbsp;</td>
          <td width="2%">&nbsp;</td>
        </tr>
      </table>
    </TD>
  </TR>
</TABLE>
<?
elseif($send == "preview"):
$mailtext_preview = nl2br($mailtext);
?>
<TABLE BGCOLOR="#003D71" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="#DADADA">
    <TD><font face="Verdana, Arial, Helvetica, sans-serif" size=3><b>FormMailer</b></font></TD>
  </TR>
  <TR BGCOLOR="#DADADA">
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="2%">&nbsp;</td>
          <td colspan="2"><font face="Verdana, Arial, Helvetica, sans-serif" size=2>eMail
            an <b><? echo $thisuser["username"]; ?></b></font></td>
          <td width="2%">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%" height="18">&nbsp;</td>
          <td width="96%" height="18" colspan="2" rowspan="13">
            <form action="<? echo $PHP_SELF; ?>" method="POST">
              <div align="center">
                <table width="450" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td>
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td>
                            <div align="center">To:&nbsp;&nbsp;<b>&nbsp;<? echo $thisuser["username"]; ?></b></div>
                          </td>
                        </tr>
                      </table>
                      <div align="center"><br>
                        <br>
                        Topic<br>
                        <table width="100%" border="1" cellspacing="0" cellpadding="0">
                          <tr>
                            <td><font size="1"><? echo $mailtopic; ?></font></td>
                          </tr>
                        </table>
                        <br>
                        Text<br>
                        <table width="100%" border="1" cellspacing="0" cellpadding="0">
                          <tr>
                            <td><font size="1"><? echo $mailtext_preview; ?></font></td>
                          </tr>
                        </table>
                      </div>
                    </td>
                  </tr>
                </table>
                <br>
                <input type="hidden" name="mailtopic" value="<? echo $mailtopic; ?>">
                <input type="hidden" name="mailtext" value="<? echo $mailtext; ?>">
                <input type="hidden" name="toid" value="<? echo $toid; ?>">
                <input type="hidden" name="send" value="sendnow">
                <input type="submit" name="submit" value="Send it now!">
                &nbsp;
                <a href="javascript:history.go(-1)">Zur&uuml;ck</a>
                <br>
              </div>
            </form>
          </td>
          <td width="2%" height="18">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%">&nbsp;</td>
          <td width="2%">&nbsp;</td>
        </tr>
      </table>
    </TD>
  </TR>
</TABLE>
<?
elseif($send == "sendnow"):
	$myid = $UserInformation[uid];
	$my_result = GetUsereMail($myid);
	$me = mysql_fetch_array($my_result);
	$mename = $me["username"];
	$meemail= $me["useremail"];

	$mailtext .= "\n\n\n[ Dieses Mail wurde im Forum \"$master_board_name\"\n($php_path/) verschickt.\n";
	$mailtext .= "Falls Du keine weiteren Emails von Usern und/oder Moderatoren erhalten m&ouml;chtest,\ndann kannst Du das in Deinem Profil einstellen. ]";
	$name		= 	$thisuser["username"];
	$email	= 	$thisuser["useremail"];
	mail("$name <$email>", $mailtopic, $mailtext, "From: $mename <$meemail>\nReply-To: $meemail\nReturn-Path: $meemail\nX-Mailer: PHP\nContent-type: $mime");
?>
<TABLE BGCOLOR="#003D71" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="#DADADA">
    <TD><font face="Verdana, Arial, Helvetica, sans-serif" size=3><b>FormMailer</b></font></TD>
  </TR>
  <TR BGCOLOR="#DADADA">
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="2%">&nbsp;</td>
          <td colspan="2"><font face="Verdana, Arial, Helvetica, sans-serif" size=2>eMail an <b><? echo $thisuser["username"]; ?></b></font></td>
          <td width="2%">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%" height="18">&nbsp;</td>
          <td width="96%" height="18" colspan="2" rowspan="13">
            <div align="center"><font size="2"><b><br>
              Die eMail an <? echo $thisuser["username"]; ?>, wurde erfolgreich
              abgeschickt!<br>
              <br>
              <br>
              [ - <a href="<? echo $php_path; ?>/">Index</a> - ]<br>
              </b></font></div>
          </td>
          <td width="2%" height="18">&nbsp;</td>
        </tr>
        <tr>
          <td width="2%">&nbsp;</td>
          <td width="2%">&nbsp;</td>
        </tr>
      </table>
    </TD>
  </TR>
</TABLE>
<?
endif;
require "_footer.inc";
?>