<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$ustring = CookieAuth($UserInformation);
echo mysql_error();
      $hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>$admin_administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$admin_general";
require "_header.inc";
if (!isset($newspost)): 
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
    <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
    <TD> <form method=post ACTION=<? echo "$php_path/admin/news.php"; ?>> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%">&nbsp;</td>
          <td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_news_posten; ?></font></td>
          <td width="2%">&nbsp;</td>
        </tr>
        <tr> 
          <td width="2%" height="18">&nbsp;</td>
          <td width="96%" height="18" colspan="2" rowspan="13"> 
            <table width="100%" border="0" cellspacing="1" cellpadding="4">
              <tr> 
                <td width="48%" height="18"> 
                  <div align="right"></div>
                </td>
                <td width="48%" height="18"> 
                  <div align="left"></div>
                </td>
              </tr>
              <tr> 
                <td width="96%" colspan="2"> 
                  <div align="center"><font face="<? echo $font; ?>" size="2"><b><? echo $admin_news_ueberschrift; ?></b></font><font face="<? echo $font; ?>" size=1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    </font> 
                    <input type="text" name="topic" size="60" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="96%" colspan="2"> 
                  <div align="center"><font face="<? echo $font; ?>" size="2"><b><? echo $admin_news_test; ?><br>
                    <textarea name="text" cols="60" rows="10"></textarea>
                    </b></font></div>
                </td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td width="48%">&nbsp;</td>
              </tr>
              <tr> 
                <td colspan="2"> 
                  <div align="center"> 
                    <input type="hidden" name="newspost" value="1">
                    <input type="submit" name="Submit" value="<? echo $admin_news_posten; ?>">
                  </div>
                </td>
              </tr>
            </table>
          </td>
          <td width="2%" height="18" rowspan="13">&nbsp;</td>
        </tr>
        <tr> 
          <td width="2%" rowspan="12">&nbsp;</td>
        </tr>
      </table>
</form>
    </TD>
  </TR>
</TABLE><? 
elseif ($newspost == 1):
$posttime = time();
$text = RemoveCrap($text);
mysql_db_query($mysqldb, "INSERT INTO apb".$n."_board_news VALUES('','$posttime','$topic','$text')");
echo mysql_error();
echo "<br><br><br><center><font size=5 face=verdana><b>News gespeichert !</b></font></center><br><br><br>";
endif; 
require "_footer.inc";
?>