<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)																								#
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin  												#
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de																							#
// # Homepage: http://apboard.halflife-editing.de 																						#
// ####################################################################################################
// # Leave this header in every file !!!  																				#
// #  																																#
// ####################################################################################################
//
// 
//
//
// 	This program is free software; you can redistribute it and/or modify
// 	it under the terms of the GNU General Public License as published by
// 	the Free Software Foundation; either version 2 of the License, or
// 	(at your option) any later version.
//
// 	This program is distributed in the hope that it will be useful,
// 	but WITHOUT ANY WARRANTY; without even the implied warranty of
// 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// 	GNU General Public License for more details.
//
// 	You should have received a copy of the GNU General Public License
// 	along with this program; if not, write to the Free Software
// 	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$ustring = CookieAuth($UserInformation);
echo mysql_error();
	 $hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>$admin_administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$members_conf";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
	 <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
	 <TD>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
	 <tr> 
		<td width="2%">&nbsp;</td>
		<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $members_conf; ?></font></td>
		<td width="2%">&nbsp;</td>
	 </tr>
	 <tr> 
		<td width="2%" height="18">&nbsp;</td>
		<td colspan="2">
<TABLE width="100%">
  <TR>
	 <TD> &nbsp; </TD>
	 <TD> &nbsp; </TD>
	 <TD> &nbsp; </TD>
  </TR>
  <TR>
	 <TD> &nbsp; </TD>
	 <TD>
<?
if (!isset($adminaction)):
?>
			  <div align="right">
				 <font face="<? echo $font; ?>" size=2>
							<form action="members.php" method="post">
							<? echo $members_alle_auflisten; ?>&nbsp;&nbsp;&nbsp;&nbsp;
							<INPUT TYPE="radio" NAME="adminaction" VALUE=1 checked>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							<? echo $members_suchen; ?>&nbsp;&nbsp;&nbsp;&nbsp;
							<INPUT TYPE="radio" NAME="adminaction" VALUE=2>&nbsp;&nbsp;&nbsp;
							Funktioniert noch nicht ganz<br><br>
							<center><INPUT TYPE="submit" NAME="submit" VALUE="<? echo $members_und_los; ?>"></center>
							</form>
				 </font>
			  </div>
<?
elseif($adminaction=="1"):
					 if (!isset($id)): 
									  $result=mysql_query("SELECT userid,username,useremail,userposts,regdate FROM apb".$n."_user_table ORDER BY regdate DESC");
									  echo "<form action=\"members.php\" method=\"post\"><TABLE width=\"100%\">
											 <TR BGCOLOR=\"".$tableA."\">
											 <TD><b>w&auml;hlen</b></TD>
											 <TD width=\"15%\">".$benutzername_profil."</TD>
											 <TD>".$email_profil."</TD>
											 <TD>".$members_posts."</TD>
											 <TD width=\"45%\">".$members_reg_am."</TD>
											 </TR>";
										while ($result1=mysql_fetch_row($result))
										{
												echo"<TR BGCOLOR=\"".$tableB."\">
												<TD><INPUT TYPE=\"radio\" NAME=\"id\" VALUE=\"".$result1[0]."\"></TD>
												<TD width=\"15%\">".$result1[1]."</TD>
												<TD><a href=\"mailto:".$result1[2]."\">".$result1[2]."</a></TD>
												<TD>".$result1[3]."</TD>
												<TD width=\"45%\">".HackDate($result1[4])." </TD>
												</TR>";
										  }
										  echo"</TABLE><br><center><br><INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"1\"><INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_bearbeiten."\"></center></form><br>";
					 elseif(isset($id)):
										  if(!isset($profil_update)):
														  $result = mysql_query ( "SELECT * FROM apb".$n."_user_table WHERE userid='$id';" );
																						 echo mysql_error();
																						  while ( $user_profile = mysql_fetch_row ( $result ) ) 
																							{
																	  echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">
																		 <FORM ACTION=\"members.php\" METHOD=\"POST\">
																			 <TR BGCOLOR=\"$tableC\"> 
																			<TD COLSPAN=\"2\">
																			  </TD>
																				  </TR>
																			  <TR BGCOLOR=\"$tableA\"> 
																				 <TD WIDTH=\"50%\">";
																			print_mb ($benutzername_profil, $font, "2");
																						 echo "</TD>
																					<TD> 
																			 <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"username\" VALUE=\"$user_profile[1]\"  MAXLENGTH=\"30\">
																					 </TD>
																				 </TR>
																				  <TR BGCOLOR=\"$tableA\"> 
																					 <TD WIDTH=\"50%\" VALIGN=\"TOP\">";
																			  print_mb ($passwort_profil, $font, "2");
																			  echo "</TD>
																					  <TD> 
																						<INPUT CLASS=\"button\" TYPE=\"PASSWORD\" NAME=\"password\" VALUE=\"$user_profile[2]\" MAXLENGTH=\"26\">
																						 <BR>
																						<INPUT CLASS=\"button\" TYPE=\"PASSWORD\" NAME=\"password2\" VALUE=\"$user_profile[2]\" MAXLENGTH=\"26\">
																					 </TD>
																				  </TR>
																					<TR BGCOLOR=\"$tableA\"> 
																					 <TD WIDTH=\"50%\">";
																					 print_mb($members_status,$font,"2");
																					 echo "</TD>
																					 <TD> 
																						<INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"status\" VALUE=\"$user_profile[5]\" MAXLENGTH=\"25\" size=\"20\">
																						&nbsp;&nbsp;&nbsp;<font face=\"$font\" size=\"2\">ADMIN, MOD oder NORMAL</font>
																				</TD></tr>
																					 <TR BGCOLOR=\"$tableA\"> 
																					 <TD WIDTH=\"50%\">";
																					 print_mb($members_extra_status,$font,"2");
																					 echo "</TD>
																					 <TD> 
																						<INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"extrastatus\" VALUE=\"$user_profile[6]\" MAXLENGTH=\"25\" size=\"20\">
																						&nbsp;&nbsp;&nbsp;<font face=\"$font\" size=\"2\">Wird unter Rang angezeigt</font>
																				</TD></tr>
																					 <TR BGCOLOR=\"$tableA\"> 
																					 <TD WIDTH=\"50%\">";
																					 print_mb($alter_profil,$font,"2");
																					 echo "</TD>
																					 <TD> 
																						<INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"userage\" VALUE=\"$user_profile[12]\" MAXLENGTH=\"2\" size=\"3\">
																				</TD>
																			  </TR>
																			 <TR BGCOLOR=\"$tableA\"> 
																							<TD WIDTH=\"50%\">";
																						  print_mb($icq_profil,$font,"2");
																							echo "</TD>
																						  <TD> 
																							 <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"usericq\" VALUE=\"$user_profile[10]\" MAXLENGTH=\"8\" size=\"9\">
																						  </TD>
																							 </TR>
																								<TR BGCOLOR=\"$tableA\"> 
																								 <TD WIDTH=\"50%\">";
																									print_mb($email_profil,$font,"2");
																									echo "</TD>
																									 <TD> 
																									  <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"email\" VALUE=\"$user_profile[3]\" MAXLENGTH=\"70\" size=\"50\">
																								  </TD>
																								 </TR>
																								  <TR BGCOLOR=\"$tableA\"> 
																									 <TD WIDTH=\"50%\">";
																									  print_mb($homepage_profil,$font,"2");
																									  echo "</TD>
																										<TD> 
																									  <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"userhp\" VALUE=\"$user_profile[11]\" MAXLENGTH=\"100\" size=\"50\">
																								  </TD>
																											  </TR>
																						  <TR BGCOLOR=\"$tableA\"> 
																							 <TD WIDTH=\"50%\">";
																							 print_mb($userpicture_profil,$font,"2");
																							  echo "</TD>
																							  <TD> 
																								 <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"userpic\" VALUE=\"$user_profile[13]\" MAXLENGTH=\"100\" size=\"50\">
																							  </TD>
																							</TR>
																							 <TR BGCOLOR=\"$tableA\"> 
																								 <TD WIDTH=\"50%\">";
																								 print_mb($interessen_profil,$font,"2");
																								  echo "</TD>
																								  <TD> 
																								  <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"interests\" VALUE=\"$user_profile[14]\" MAXLENGTH=\"100\" size=\"50\">
																							  </TD>
																							 </TR>
																							 <TR BGCOLOR=\"$tableA\"> 
																								<TD WIDTH=\"50%\">";
																						  print_mb ($infotext_profil, $font, "2");
																						  echo "</TD>
																								 <TD> 
																									<TEXTAREA NAME=\"infotext\" cols=\"35\" rows=\"8\">$user_profile[9]</TEXTAREA>
																								  </TD>
																								</TR>
																								<TR BGCOLOR=\"$tableA\"> 
																									 <TD WIDTH=\"50%\">";
																							  print_mb ( $signatur_profil, $font, "2");
																								echo "</TD>
																												 <TD>
																								<TEXTAREA NAME=\"signatur\" cols=\"35\" rows=\"8\">$user_profile[8]</TEXTAREA>
																							  </TD>
																							</TR>
																							<TR BGCOLOR=\"$tableA\"> 
																								<TD COLSPAN=\"2\">
																								&nbsp;</TD>
																							  </TR>
																							  <TR BGCOLOR=\"$tableB\"> 
																								 <TD COLSPAN=\"2\"> 
																									<CENTER>
																									  <input type=\"hidden\" name=\"adminaction\" value=\"1\">
																									  <input type=\"hidden\" name=\"id\" value=\"$id\">
																									  <input type=\"hidden\" name=\"profil_update\" value=\"1\">
																										 <INPUT CLASS=\"button\" TYPE=\"reset\" NAME=\"reset\" VALUE=\"$felder_loeschen\">
																										 <INPUT CLASS=\"button\" TYPE=\"submit\" NAME=\"Submit\" VALUE=\"$profil_updaten\">
																										 </CENTER>
																											</TD>
																									  </TR>
																											</FORM>
																											<TR BGCOLOR=\"$tableB\"> 
																											  <TD COLSPAN=\"2\">
																											  <form action=\"m_delete.php\" method=\"post\">
																														  <CENTER>
																																 <input type=\"hidden\" name=\"del\" value=\"1\">
																																 <input type=\"hidden\" name=\"id\" value=\"$id\">
																																 <INPUT CLASS=\"button\" TYPE=\"submit\" NAME=\"Submit\" VALUE=\"".$members_delete."\">
																														  </CENTER>
																											  </form>
																												</TD>
																											  </TR>
																										  </TABLE>";
																												  }
													elseif($profil_update=="1"):
																																					if (!$password || !$password2 || !$email)
																																					{
																																										apb_error($pflichtfeld,FALSE);
																																					}
																																					if (strcmp($password,$password2))
																																					{
																																										 apb_error($passwort_unterschiedlich,FALSE);
																																					}
																																					if (!CheckChars($password))
																																					{
																																									  echo $password;
																																										apb_error($pw_unzulaessige_zeichen,FALSE);
																																					}
																																					if (strlen($password)<5)
																																					{
																																								  apb_error($mind_5_zeichen,FALSE);
																																					}
																																					if (strlen($password)>25)
																																					{
																																								 apb_error($max_25_zeichen,FALSE);
																																					}
																																					if (strlen($email)>70)
																																					{
																																							  apb_error($email_zu_lang,FALSE);
																																					}
																																					if (strlen($signatur)>250)
																																					{
																																								apb_error($sig_zu_lang,FALSE);
																																					}
																																				  $update_query = mysql_query ( "UPDATE apb".$n."_user_table SET useremail='$email',userpassword='$password',status='$status', statusextra='$extrastatus', signatur='$signatur',infotext='$infotext',usericq='$usericq',userhp='$userhp',userage='$userage',userpic='$userpic',interests='$interests' WHERE userid='$id';");
																																		?><div align="center">
																																		  <font face="<? echo $font; ?>" size=2>
																																					 <? echo $members_aenderung_uebernommen; ?>
																																			 </font>
																																			</div><?
													endif;
								  endif;
?>
<?
elseif($adminaction=="2"):
		 if(!isset($search)):
										echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">
														 <FORM ACTION=\"members.php\" METHOD=\"POST\">
														 <TR BGCOLOR=\"$tableC\"> 
																	 <TD COLSPAN=\"2\">
																	 </TD>
														 </TR>
														 <TR BGCOLOR=\"$tableA\"> 
																	 <TD WIDTH=\"40%\">";
																				  print_mb ($members_usernamen_suchen, $font, "2");
																	 echo "</TD>
																	 <TD> 
																				  <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"search_name\"  MAXLENGTH=\"30\" size=\"20\">
																				  <INPUT TYPE=\"hidden\" NAME=\"search\" VALUE=\"name\">
																				  <INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"2\">
																				  <INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_suchen_button."\">
																	 </TD>
														 </TR>
														 <FORM ACTION=\"members.php\" METHOD=\"POST\">
														 <TR BGCOLOR=\"$tableC\"> 
																	 <TD COLSPAN=\"2\">
																	 </TD>
														 </TR>
														 <TR BGCOLOR=\"$tableA\"> 
																	 <TD WIDTH=\"40%\">";
																				  print_mb ($members_mit_posts_auflisten, $font, "2");
																	 echo "</TD>
																	 <TD> 
																				  <INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"search_posts\"  MAXLENGTH=\"30\" size=\"20\">
																				  <INPUT TYPE=\"hidden\" NAME=\"search\" VALUE=\"posts\">
																				  <INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"2\">
																				  <INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_suchen_button."\">
																	 </TD>
														 </TR>
														 </FORM>
														 <FORM ACTION=\"members.php\" METHOD=\"POST\">
														 <TR BGCOLOR=\"$tableC\"> 
																	 <TD COLSPAN=\"2\">
																	 </TD>
														 </TR>
														 <TR BGCOLOR=\"$tableA\"> 
																	 <TD WIDTH=\"40%\">";
																				  print_mb ($members_mods_auflisten, $font, "2");
																echo "</TD>
																	 <TD> 
																				  <INPUT TYPE=\"hidden\" NAME=\"search\" VALUE=\"mods\">
																				  <INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"2\">
																				  <INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_suchen_button."\">
																	 </TD>
														 </TR>
														 </FORM>
														 <FORM ACTION=\"members.php\" METHOD=\"POST\">
														 <TR BGCOLOR=\"$tableC\"> 
																	 <TD COLSPAN=\"2\">
																	 </TD>
														 </TR>
														 <TR BGCOLOR=\"$tableA\"> 
																	 <TD WIDTH=\"40%\">";
																				  print_mb ("<b>Alle Administratoren auflisten</b>", $font, "2");
																	 echo "</TD>
																	 <TD> 
																				  <INPUT TYPE=\"hidden\" NAME=\"search\" VALUE=\"admin\">
																				  <INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"2\">
																				  <INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_suchen_button."\">
																	 </TD>
														 </TR>
														 </FORM>
														 <FORM ACTION=\"members.php\" METHOD=\"POST\">
														 <TR BGCOLOR=\"$tableC\"> 
																	 <TD COLSPAN=\"2\">
																	 </TD>
														 </TR>
														 <TR BGCOLOR=\"$tableA\"> 
																	 <TD WIDTH=\"40%\">";
																				  print_mb ($members_user_top10, $font, "2");
																	 echo "</TD>
																	 <TD> 
																				  <INPUT TYPE=\"hidden\" NAME=\"search\" VALUE=\"top10\">
																				  <INPUT TYPE=\"hidden\" NAME=\"adminaction\" VALUE=\"2\">
																				  <INPUT TYPE=\"submit\" NAME=\"submit\" VALUE=\"".$members_suchen_button."\">
																	 </TD>
														 </TR>
														 </FORM>
													  </TABLE>";
		 elseif($search == "name"):
					 if($search_name == "" || $search_name == " ") {
										  echo "<font face=\"$font\" size=2><center><b>ERROR (#14): ".$members_error1."</b><br>".$members_error2."<br><br>[ - <a href=\"javascript:history.go(-1)\">".$members_error3."</a> - ]</center></font>";
					 } else {
										  $result=mysql_query("SELECT * FROM apb".$n."_user_table WHERE username LIKE '%$search_name%';");
										  while($result=mysql_fetch_row($result)) {
																echo $result[0]."<BR>";
																echo $result[1]."<BR>";
																echo $result[2]."<BR>";
																echo $result[3]."<BR>";
																echo $result[4]."<BR>";
																echo $result[5]."<BR>";
																echo $result[6]."<BR>";
																echo $result[7]."<BR>";
																echo $result[8]."<BR>";
																echo $result[9]."<BR>";
																echo $result[10]."<BR>";
																echo $result[11]."<BR>";
																echo $result[12]."<BR>";
																echo $result[13]."<BR>";
																echo $result[14]."<BR>";
										  }
					 }
		 elseif($search == "posts"):
					 if($search_posts == "" || $search_posts == " ") {
										  echo "<font face=\"$font\" size=2><center><b>ERROR (#14): ".$members_error1."</b><br>".$members_error2."<br><br>[ - <a href=\"javascript:history.go(-1)\">".$members_error3."</a> - ]</center></font>";
					 } else {
										  $result=@mysql_query("SELECT * FROM apb".$n."_user_table WHERE userposts > '$search_posts';");
										  while($result=@mysql_fetch_row($result)) {
																echo $result[0]."<BR>";
																echo $result[1]."<BR>";
																echo $result[2]."<BR>";
																echo $result[3]."<BR>";
																echo $result[4]."<BR>";
																echo $result[5]."<BR>";
																echo $result[6]."<BR>";
																echo $result[7]."<BR>";
																echo $result[8]."<BR>";
																echo $result[9]."<BR>";
																echo $result[10]."<BR>";
																echo $result[11]."<BR>";
																echo $result[12]."<BR>";
																echo $result[13]."<BR>";
																echo $result[14]."<BR>";
										  }
					 }
		 elseif($search == "mods"):
					 if($search_name == "" || $search_name == " ") {
										  echo "<font face=\"$font\" size=2><center><b>ERROR (#14): ".$members_error1."</b><br>".$members_error2."<br><br>[ - <a href=\"javascript:history.go(-1)\">".$members_error3."</a> - ]</center></font>";
					 } else {
										  $result=mysql_query("SELECT * FROM apb".$n."_user_table WHERE username LIKE '%$search_name%';");
										  while($result=mysql_fetch_row($result)) {
																echo $result[1];
										  }
					 }
		 elseif($search == "admin"):
					 if($search_name == "" || $search_name == " ") {
										  echo "<font face=\"$font\" size=2><center><b>ERROR (#14): ".$members_error1."</b><br>".$members_error2."<br><br>[ - <a href=\"javascript:history.go(-1)\">".$members_error3."</a> - ]</center></font>";
					 } else {
										  $result=mysql_query("SELECT * FROM apb".$n."_user_table WHERE username LIKE '%$search_name%';");
										  while($result=mysql_fetch_row($result)) {
																echo $result[1];
										  }
					 }
		 elseif($search == "top10"):
					 if($search_name == "" || $search_name == " ") {
										  echo "<font face=\"$font\" size=2><center><b>ERROR (#14): ".$members_error1."</b><br>".$members_error2."<br><br>[ - <a href=\"javascript:history.go(-1)\">".$members_error3."</a> - ]</center></font>";
					 } else {
										  $result=mysql_query("SELECT * FROM apb".$n."_user_table WHERE username LIKE '%$search_name%';");
										  while($result=mysql_fetch_row($result)) {
																echo $result[1];
										  }
					 }
		 endif;
endif; 
?>
	 </TD>
	 <TD> &nbsp; </TD>
  </TR>
  <TR>
	 <TD> &nbsp; </TD>
	 <TD> &nbsp; </TD>
	 <TD> &nbsp; </TD>
  </TR>
</TABLE>
		</td>
		<td width="2%" height="18">&nbsp;</td>
	 </tr>
	 <tr>
		<td width="2%">&nbsp;</td>
		<td colspan="2">&nbsp;</td>
		<td width="2%">&nbsp;</td>
	 </tr>
  </table>
		  </TD>
  </TR>
</TABLE>
<? require "_footer.inc"; ?>