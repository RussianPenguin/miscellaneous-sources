<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>Administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$admin_boards_configuation";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
    <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="2%">&nbsp;</td>
      <td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_boards_configuation; ?></font></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%" height="18">&nbsp;</td>
      <td colspan="2">
<TABLE width="100%">
  <TR>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
  </TR>
  <TR>
    <TD> &nbsp; </TD>
    <TD>
     <font face="<? echo $font; ?>" size=2>
       <center>
         <b><? echo $admin_design_reset; ?></b><br><br>
         [ - <a href="index.php"><? echo $admin_zurueck_admin; ?></a> - ]
    </TD>
    <TD> &nbsp; </TD>
  </TR>
  <TR>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
  </TR>
</TABLE>
      </td>
      <td width="2%" height="18">&nbsp;</td>
    </tr>
    <tr>
      <td width="2%">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
  </table>
    </TD>
  </TR>
</TABLE>
<?
$result0 = mysql_query("SELECT * FROM apb".$n."_config");
while($thisline0 = mysql_fetch_array($result0))
{
        $font0 = $thisline0[font];
        $fontcolor0 = $thisline0[fontcolor];
        $fontcolorsec0 = $thisline0[fontcolorsec];
        $bgcol0 = $thisline0[bgcolor];
        $tablebg0 = $thisline0[tablebg];
        $tableA0 = $thisline0[tablea];
        $tableB0 = $thisline0[tableb];
        $tableC0 = $thisline0[tablec];
        $boardgfx0 = $thisline0[imageurl];
        $links0 = $thisline0[linkcolor];
        $visited0 = $thisline0[visited];
        $active0 = $thisline0[active];
        $hover0 = $thisline0[hover];
        $hgpicture0 = $thisline0[hgpicture];
        $bgfixed0 = $thisline0[bgfixed];
}
$table_query0 = mysql_query("UPDATE apb".$n."_boards SET boardgfx='$boardgfx0', font='$font0', fontcolor='$fontcolor0', fontcolorsec='$fontcolorsec0', bgcolor='$bgcol0', tablebg='$tablebg0', tablea='$tableA0', tableb='$tableB0', tablec='$tableC0', linkcolor='$links0', visited='$visited0', active='$active0', hover='$hover0', hgpicture='$hgpicture0', bgfixed='$bgfixed0'");
require "_footer.inc";
?>