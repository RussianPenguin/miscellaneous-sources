<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$ustring = CookieAuth($UserInformation);
echo mysql_error();
    $hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>$admin_administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$members_conf";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
    <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="2%">&nbsp;</td>
      <td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $members_conf; ?></font></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%" height="18">&nbsp;</td>
      <td colspan="2">
<TABLE width="100%">
  <TR>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
  </TR>
  <TR>
    <TD> &nbsp; </TD>
    <TD>
<?
if (!isset($del) || !isset($id)):
?>
                <font face="<? echo $font; ?>" size=2>
                <center>
                <b>ERROR (#14): <? echo $members_error1; ?></b><br><? echo $members_error2; ?><br><br>
                [ - <a href="javascript:history.go(-1)"><? echo $members_error3; ?></a> - ]
<?    
elseif($del=="1"):
                $result = mysql_query ("DELETE FROM apb".$n."_user_table WHERE userid='$id';");
?>
                <font face="<? echo $font; ?>" size=2>
                <center>
                <b><? echo $members_erfolgr; ?></b><br><br>
                [ - <a href="index.php"><? echo $members_back_admin; ?></a> - ]
<?    
endif; 
?>
    </TD>
    <TD> &nbsp; </TD>
  </TR>
  <TR>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
    <TD> &nbsp; </TD>
  </TR>
</TABLE>
      </td>
      <td width="2%" height="18">&nbsp;</td>
    </tr>
    <tr>
      <td width="2%">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
  </table>
        </TD>
  </TR>
</TABLE>
<? require "_footer.inc"; ?>