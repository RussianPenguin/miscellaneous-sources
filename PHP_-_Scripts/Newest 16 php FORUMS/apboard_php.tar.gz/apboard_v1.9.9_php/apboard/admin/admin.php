<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";

$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>Administration</b></a>";
require "_header.inc";
$result = mysql_query("SELECT userid,username,userpassword,status FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
$userdat = mysql_fetch_row($result);
      echo mysql_error();
if ($userdat[2] != $UPASS) { apb_error("ERROR #08: Invalid password in cookie!",FALSE); }

if ($userdat[3] != "ADMIN" && $userdat[3] != "MOD")
{
      apb_error("Admins/Moderators only!",FALSE);
}
if (!$action) { apb_error("No action selected!",FALSE); }
      $last_reply = time();
// <--------------------------------------- DELETE POST ------------------------------------------>
if ($action == "deletepost") {
      if (!$postid) { apb_error("ERROR #09: Invalid post ID",FALSE); }
      if (!$tparentid) { apb_error("no topic selected!",FALSE); }
  if (!$bparentid) { apb_error("No board selected!",FALSE); }
echo mysql_error();
      mysql_query("DELETE FROM apb".$n."_posts WHERE postid='$postid'");
      mysql_query("UPDATE apb".$n."_threads SET replies=replies-1,timelastreply='$last_reply' WHERE threadid='$tparentid'");
      mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts-1,lastmodified='$last_reply' WHERE boardid='$bparentid'");
      echo mysql_error();
      }
// <--------------------------------------- DELETE THREAD ------------------------------------------>
if ($action == "delete_thread") {
if (!$id) { apb_error("ERROR #10: Invalid Thread ID",FALSE); }
if (!$bparentid) { apb_error("No board selected!",FALSE); }
echo mysql_error();
      $last_reply = time();
$result = mysql_query("SELECT COUNT(*) FROM apb".$n."_posts WHERE threadparentid='$id'");
mysql_query("UPDATE apb".$n."_threads SET flags=2 WHERE threadid='$id'");
$minuszahl = mysql_fetch_row($result);
$minus = $minuszahl[0];
mysql_query("DELETE FROM apb".$n."_posts WHERE threadparentid='$id'");
mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts-'$minus',lastmodified='$last_reply' WHERE boardid='$bparentid'");
echo mysql_error();
      }
// <--------------------------------------- CLOSE THREAD ------------------------------------------>
if ($action == "close_thread") {
      if (!$id) { apb_error("ERROR #10: Invalid Thread ID",FALSE); }
      if (!$bparentid) { apb_error("No board selected!",FALSE); }
  echo mysql_error();
  $timelast = time();
      mysql_query("UPDATE apb".$n."_threads SET timelastreply='$timelast', flags=1 WHERE threadid='$id'");
      echo mysql_error();
      }
// <--------------------------------------- OPEN THREAD ------------------------------------------>
if ($action == "open_thread") {
      if (!$id) { apb_error("ERROR #10: Invalid Thread ID",FALSE); }
      if (!$bparentid) { apb_error("No board selected!",FALSE); }
  echo mysql_error();
  $timelast = time();
      mysql_query("UPDATE apb".$n."_threads SET timelastreply='$timelast', flags=0 WHERE threadid='$id'");
      echo mysql_error();
      }
require "_footer.inc";
?>