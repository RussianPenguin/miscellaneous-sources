<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$ustring = CookieAuth($UserInformation);
echo mysql_error();
                $hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>$admin_administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$admin_linkliste_conf";

require "_header.inc";
if (!isset($adminaction)): 
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
    <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
    <TD> <form method=post ACTION=<? echo "$php_path/admin/linkleiste.php"; ?>> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="2%">&nbsp;</td>
      <td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_linkliste_conf; ?></font></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%" height="18">&nbsp;</td>
      <td width="96%" height="18" colspan="2" rowspan="13">
            <table width="100%" border="0" cellspacing="1" cellpadding="4">
              <tr> 
                <td width="48%" height="18"> 
                  <div align="right"></div>
                </td>
                <td width="48%" height="18"> 
                  <div align="left"></div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linliste_anzeige; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                    </font></div>
                </td>
                <td width="48%"> 
                  <div align="left">
                        <?
                        if ($linkleiste=="1") {
                                     $linkleiste2 = " checked";
                        } else {
                                     $linkleiste2 = "";
                        }
                        ?>
                   <input type="checkbox" name="linkleiste1" value="1"<? echo $linkleiste2; ?>>
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 1. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link1_1" value="<? echo $link1; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 1. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link11_1" value="<? echo $link11; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 2. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link2_1" value="<? echo $link2; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 2. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link22_1" value="<? echo $link22; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 3. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link3_1" value="<? echo $link3; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 3. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link33_1" value="<? echo $link33; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 4. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link4_1" value="<? echo $link4; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 4. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link44_1" value="<? echo $link44; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 5. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link5_1" value="<? echo $link5; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 5. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link55_1" value="<? echo $link55; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 6. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link6_1" value="<? echo $link6; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> des 6. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link66_1" value="<? echo $link66; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 7. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link7_1" value="<? echo $link7; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> des 7. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link77_1" value="<? echo $link77; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 8. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link8_1" value="<? echo $link8; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> des 8. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link88_1" value="<? echo $link88; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_url_des; ?> 9. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link9_1" value="<? echo $link9; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td width="48%"> 
                  <div align="right"><font face="<? echo $font; ?>" size=1><? echo $linkliste_name_des; ?> 9. <? echo $linkliste_link; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
                </td>
                <td width="48%"> 
                  <div align="left"> 
                    <input type="text" name="link99_1" value="<? echo $link99; ?>" size="40" maxlength="100">
                  </div>
                </td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
                <td width="48%">&nbsp;</td>
              </tr>
              <tr> 
                <td colspan="2">
                  <div align="center">
                    <input type="hidden" name="adminaction" value="1">
                    <input type="submit" name="Submit" value="<? echo $mod_speichern; ?>">
                  </div>
                </td>
              </tr>
            </table>
      </td>
      <td width="2%" height="18">&nbsp;</td>
    </tr>

    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
  </table>
</form>
                                </TD>
  </TR>
</TABLE>
<? 
elseif ($adminaction == 1):
echo mysql_error();
mysql_db_query($mysqldb, "UPDATE apb".$n."_config SET linkleiste='$linkleiste1', link1='$link1_1', link11='$link11_1', link2='$link2_1', link22='$link22_1', link3='$link3_1', link33='$link33_1', link4='$link4_1', link44='$link44_1', link5='$link5_1', link55='$link55_1', link6='$link6_1', link66='$link66_1', link7='$link7_1', link77='$link77_1', link8='$link8_1', link88='$link88_1', link9='$link9_1', link99='$link99_1' WHERE confid='1'");
echo mysql_error();
echo "<br><br><br><center><font size=5 face=verdana><b>".$mod_gespeichert."</b></font></center><br><br><br>";
?>

<? endif; ?>

<? require "_footer.inc"; ?>