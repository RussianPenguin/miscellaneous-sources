<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin                                      #
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de                                                                     #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
// 
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc"; 
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>$admin_administration</b></a>";

require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
    <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>"> 
    <TD>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="2%">&nbsp;</td>
      <td colspan="2"><font face="<? echo $font; ?>" size=2>Administrations-Men&uuml;</font></td>
      <td width="2%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%" height="18">&nbsp;</td>
      <td width="96%" height="18" colspan="2" rowspan="13"><br>
              <table width="100%" border="0" cellspacing="1" cellpadding="6">
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=news.php><? echo $admin_index_news_posten; ?></a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;<? echo $admin_index_news_info; ?></font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=general.php><? echo $admin_general; ?></a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;<? echo $admin_general_info; ?></font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=linkleiste.php><? echo $admin_linkliste_conf; ?></a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;<? echo $admin_linkliste_info; ?></font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=boards.php><? echo $admin_boards_configuation; ?></a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;<? echo $admin_boards_conf_info; ?></font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=threads.php>Threads-Configuration</a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;Hier k&ouml;nnen Threads und/oder Posts bearbeitet werden (Noch nicht implementiert!)</font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
                <tr>
                  <td width="35%"><b><font face="<? echo $font; ?>" size=2><a href=members.php><? echo $admin_members_conf; ?></a></font></b></td>
                  <td width="65%"><font face="<? echo $font; ?>" size=1>&nbsp;<? echo $admin_members_conf_info; ?></font></td>
                </tr>
                <tr>
                  <td width="35%">&nbsp;</td>
                  <td width="65%">&nbsp;</td>
                </tr>
              </table>
            </td>
      <td width="2%" height="18">&nbsp;</td>
    </tr>
    <tr> 
      <td width="2%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
    </tr>
  </table>
        </TD>
  </TR>
</TABLE>
<? require "_footer.inc"; ?>