<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)																								#
// ####################################################################################################
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) Berlin  												#
// # Based on a very early version of MagicBoard v.1.5 � 2000 by Darth Paul, modified with permission #
// # Contact: dma147@arcormail.de																							#
// # Homepage: http://apboard.halflife-editing.de 																						#
// ####################################################################################################
// # Leave this header in every file !!!  																				#
// #  																																#
// ####################################################################################################
//
//
//
//
// 	This program is free software; you can redistribute it and/or modify
// 	it under the terms of the GNU General Public License as published by
// 	the Free Software Foundation; either version 2 of the License, or
// 	(at your option) any later version.
//
// 	This program is distributed in the hope that it will be useful,
// 	but WITHOUT ANY WARRANTY; without even the implied warranty of
// 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// 	GNU General Public License for more details.
//
// 	You should have received a copy of the GNU General Public License
// 	along with this program; if not, write to the Free Software
// 	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/admin/index.php\"><b>Administration</b></a><BR>&nbsp;&nbsp;&nbsp;&nbsp;$admin_boards_configuation";
require "_header.inc";

$usedefaultstyle = "1";

if (!isset($boardaction)):
		  $resultboards = mysql_query("SELECT boardid, boardname, category FROM apb".$n."_boards ORDER BY category, boardname");
		  $resultkategorie = mysql_query("SELECT category FROM apb".$n."_boards");
		  echo mysql_error();
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
	 <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
	 </TR>
	 <TR BGCOLOR="<? echo $tableC; ?>">
	 <TD>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
		  <td width="2%">&nbsp;</td>
		  <td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_boards_configuation; ?></font></td>
		  <td width="2%">&nbsp;</td>
		</tr>
	 <tr>
		<td width="2%" height="18">&nbsp;</td>
		<td width="96%" height="18" colspan="2" rowspan="13">
				<table width="100%" border="0" cellspacing="1" cellpadding="4">
				  <td colspan="2">
					 <div align="center">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
							 <td width="2%">&nbsp;</td>
							 <td width="48%">
								<div align="right"><font face="<? echo $font; ?>" size=1><? echo $admin_board_modifizieren; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
							 </td>
							 <td width="48%">
								<div align="left">
								  <form method=post ACTION=<? echo "$php_path/admin/boards.php"; ?>>
									 <select name="board">
										<?
									 while ($thisboard = mysql_fetch_array($resultboards))
									 {
										  if ($thisboard[category] != $old_cat) {
				                       $cat_str = "---- $thisboard[category] -------------------------------------------------------------";
				                       $cat_str = substr($cat_str, 0, 55);
				                       echo "<option value=\"\"> $cat_str </option>";
			}
										  echo "<option value=\"$thisboard[boardid]\">".$thisboard[boardname]."</option>";
										  $old_cat = $thisboard[category];
									 }
								?>
									 </select>
									 <font face="<? echo $font; ?>" size=1> &nbsp;&nbsp;</font>
									 <input type="hidden" name="boardaction" value="1">
									 <input type="hidden" name="boardname" value=$board>
									 <input type="submit" name="Submit" value="<? echo $admin_choose_board; ?>">
								  </form>
								</div>
							 </td>
							 <td width="2%">&nbsp;</td>
						  </tr>
						</table>
						</div>
						<center>
						  <form method=post ACTION=<? echo "$php_path/admin/boards.php"; ?>>
						  <input type="hidden" name="boardaction" value="2">
						  <input type="submit" name="Submit" value="<? echo $admin_new_board; ?>">
						</form><br>
						  <font face="<? echo $font; ?>" size=1><b><? echo $admin_reset_design1; ?><a href="ch_design.php"><font color="#FF0000"><? echo $admin_reset_design2; ?></font></a></b></font>
						</center>
				</table>
		</td>
		<td width="2%" height="18">&nbsp;</td>
	 </tr>
  </table>
					 </TD>
  </TR>
</TABLE>
<? elseif ($boardaction == 1):
		
		if (!$board) {
			message_box ("<B>".$admin_kein_board_gewaehlt."</B><BR><BR>");
			include "_footer.inc";
			exit;
		}
		
		  $resultboards = mysql_query("SELECT * FROM apb".$n."_boards WHERE boardid='$board'");
		  $resultkategorie = mysql_query("SELECT category FROM apb".$n."_boards WHERE boardid='$board'");
		  $resultkategorieneu = mysql_query("SELECT DISTINCT category FROM apb".$n."_boards");
		  echo mysql_error();
while($thisline = mysql_fetch_array($resultboards))
{
		  $boardid = $thisline[boardid];
		  $boardname = $thisline[boardname];
		  $boardpassword = $thisline[boardpassword];
		  $boardmods = $thisline[boardmods];
		  $totalposts = $thisline[totalposts];
		  $lastmodified = $thisline[lastmodified];
		  $descriptiontext = $thisline[descriptiontext];
		  $boardgfx = $thisline[boardgfx];
		  $boardcss = $thisline[boardcss];
		  $category = $thisline[category];
		  $font5 = $thisline[font];
		  $fontcolor5 = $thisline[fontcolor];
		  $fontcolorsec5 = $thisline[fontcolorsec];
		  $bgcol5 = $thisline[bgcolor];
		  $tablebg5 = $thisline[tablebg];
		  $tableA5 = $thisline[tablea];
		  $tableB5 = $thisline[tableb];
		  $tableC5 = $thisline[tablec];
		  $imageurl5 = $thisline[imageurl];
		  $links5 = $thisline[linkcolor];
		  $visited5 = $thisline[visited];
		  $active5 = $thisline[active];
		  $hover5 = $thisline[hover];
		  $hgpicture5 = $thisline[hgpicture];
		  $bgfixed5 = $thisline[bgfixed];
		  $sortit5 = $thisline[sortit];
		  $totalthreads5 = $thisline[totalthreads];
}
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
  <TR BGCOLOR="<? echo $tableC; ?>">
	 <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
  </TR>
  <TR BGCOLOR="<? echo $tableC; ?>">
	 <TD> <form method=post ACTION=<? echo "$php_path/admin/boards.php"; ?>>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
	 <tr>
		<td width="2%">&nbsp;</td>
		<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_boards_configuation; ?></font></td>
		<td width="2%">&nbsp;</td>
	 </tr>
	 <tr>
		<td width="2%" height="18">&nbsp;</td>
		<td width="96%" height="18" colspan="2" rowspan="13">
				  <table width="100%" border="0" cellspacing="1" cellpadding="4">
					 <tr>
						<td width="48%" height="18">
						  <div align="right"></div>
						</td>
						<td width="48%" height="18">
						  <div align="left"></div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_name; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardname" value="<? echo $boardname; ?>" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $board_passw; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardpassword" value="<? echo $boardpassword; ?>" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_mod; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardmods" value="<? echo $boardmods; ?>" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_posts_bisher; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left"> <font face="<? echo $font; ?>" size=2><? echo $totalposts; ?></font>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_letzter_post; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left"> <font face="<? echo $font; ?>" size=2><? echo HackDate($lastmodified); ?></font>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_describtion; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="descriptiontext" value="<? echo $descriptiontext; ?>" size="50" maxlength="100">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_bild; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardgfx" value="<? echo $boardgfx; ?>" size="40" maxlength="150">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_stylesheet; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <textarea name="boardcss" cols="40" rows="6"><? echo $boardcss; ?></textarea>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <select name="kategorie">
<?
		  while ($thiskategorie = mysql_fetch_array($resultkategorie))
		  {
		  $kategorie = $thiskategorie[category];
		  echo "<option selected>".$kategorie."</option>";
		  }
		  ?>
		  <option>-------------------</option>
		  <?
		  while ($thiskategorieneu = mysql_fetch_array($resultkategorieneu))
		  {
		  $kategorieneu = $thiskategorieneu[category];
		  if ($cat_old=="" || $cat_old==" " || $cat_old=="0")
				 { echo "<option>".$kategorieneu."</option>"; }
		  else
				 { if ($kategorieneu!=$cat_old) { echo "<option>".$kategorieneu."</option>"; } }
		  $cat_old = $kategorieneu;
		  }
?>
							 </select>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $admin_new_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="kat_neu" size="20" maxlength="25">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" color=red size=1><b><? echo $admin_board_loeschen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="checkbox" name="delete" value="1">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hintergrundbild; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hintergrundbild_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="hgpicture1" value="<? echo $hgpicture5; ?>" size="40" maxlength="200">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_fixed; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hg_fixed_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
						</td>
						<td width="44%">
						  <div align="left"> <?
																		if ($bgfixed5=="1") {
																			$bgfixed2 = " checked";
																		} else {
																			$bgfixed2 = "";
																		}
																		?>
							 <input type="checkbox" name="bgfixed1" value="1"<? echo $bgfixed2; ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_gen_schriftart; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="font1" value="<? echo $font5; ?>" size="20" maxlength="100">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_prim_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="fontcolor1" value="<? echo $fontcolor5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_sek_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_sek_schriftfarbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="fontcolorsec1" value="<? echo $fontcolorsec5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_farbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $admin_hg_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="bgcol1" value="<? echo $bgcol5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_gen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hg_tab_gen_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tablebg1" value="<? echo $tablebg5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_a; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableA1" value="<? echo $tableA5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_b; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableB1" value="<? echo $tableB5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_c; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableC1" value="<? echo $tableC5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_links; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="links1" value="<? echo $links5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_visited; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="visited1" value="<? echo $visited5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_active; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="active1" value="<? echo $active5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_hover; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="hover1" value="<? echo $hover5; ?>" size="9" maxlength="7">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td>&nbsp;</td>
						<td width="48%">&nbsp;</td>
					 </tr>
					 <tr>
						<td colspan="2">
						  <div align="center">
							 <input type="hidden" name="lastmodified" value="<? echo $lastmodified; ?>">
							 <input type="hidden" name="boardaction" value="5">
							 <input type="hidden" name="sortit" value="<? echo $sortit5; ?>">
							 <input type="hidden" name="totalthreads" value="<? echo $totalthreads5; ?>">
							 <input type="hidden" name="boardid" value=<? echo $boardid; ?>>
							 <input type="submit" name="Submit" value="<? echo $mod_speichern; ?>">
						  </div>
						</td>
					 </tr>
				  </table>
		</td>
		<td width="2%" height="18">&nbsp;</td>
	 </tr>
  </table>
</form>
</TD>
  </TR>
</TABLE>
<? elseif ($boardaction == 2):
		  $resultkategorieneu = mysql_query("SELECT DISTINCT category FROM apb".$n."_boards");
		  echo mysql_error();
			?>
		 <TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
			<TR BGCOLOR="<? echo $tableC; ?>">
			  <TD><font face="<? echo $font; ?>" size=3><b><? echo $admin_administration; ?></b></font></TD>
			</TR>
			<TR BGCOLOR="<? echo $tableC; ?>">
			  <TD> <form method=post ACTION=<? echo "$php_path/admin/boards.php"; ?>>
				 <table width="100%" border="0" cellspacing="0" cellpadding="0">
			  <tr>
		<td width="2%">&nbsp;</td>
		<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $admin_boards_configuation; ?></font></td>
		<td width="2%">&nbsp;</td>
	 </tr>
	 <tr>
		<td width="2%" height="18">&nbsp;</td>
		<td width="96%" height="18" colspan="2" rowspan="13">
				  <table width="100%" border="0" cellspacing="1" cellpadding="4">
					 <tr>
						<td width="48%" height="18">&nbsp;</td>
						<td width="48%" height="18">&nbsp;</td>
					 </tr>
					 <tr>
						<td colspan="2" height="18"><font face="<? echo $font; ?>" size=2><? echo $admin_design_new_forum_info; ?></font></td>
					 </tr>
					 <tr>
						<td width="48%" height="18">
						  <div align="right"></div>
						</td>
						<td width="48%" height="18">
						  <div align="left"></div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_name; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardname2" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $board_passw; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardpassword2" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_mod; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardmods2" size="40" maxlength="40">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_describtion; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="descriptiontext2" size="50" maxlength="100">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_board_bild; ?>d&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="boardgfx2" size="40" maxlength="150"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$imageurl\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_stylesheet; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <textarea name="boardcss2" cols="40" rows="6"><? echo $boardcss; ?></textarea>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <select name="kategorie2">
								<option selected><? echo $admin_kat_waehlen; ?></option>
								<?
		  while ($thiskategorieneu = mysql_fetch_array($resultkategorieneu))
		  {
		  $kategorieneu = $thiskategorieneu[category];
		  if ($cat_old=="" || $cat_old==" " || $cat_old=="0")
				 { echo "<option>".$kategorieneu."</option>"; }
		  else
				 { if ($kategorieneu!=$cat_old) { echo "<option>".$kategorieneu."</option>"; } }
		  $cat_old = $kategorieneu;
		  }
?>
							 </select>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="48%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $admin_new_kategorie; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div>
						</td>
						<td width="48%">
						  <div align="left">
							 <input type="text" name="kat_neu2" size="20" maxlength="25">
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hintergrundbild; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hintergrundbild_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="hgpicture1" size="40" maxlength="200"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$hgpicture\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_fixed; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hg_fixed_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
						</td>
						<td width="44%">
						  <div align="left">
						  <? if ($usedefaultstyle=="1") {
							 	   if ($bgfixed=="1")
							 			$bgfix1add = " checked";
							 	   else
							 	 		$bgfix1add = "";
							 	 } else {
							 	 		$bgfix1add = "";
							 	 }
							 ?>
							 <input type="checkbox" name="bgfixed1" value="1"<? echo $bgfix1add; ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_gen_schriftart; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="font1" size="20" maxlength="100"<?
								if ($usedefaultstyle=="1")
									 echo " value=\"$font\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_prim_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="fontcolor1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									 echo " value=\"$fontcolor\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_sek_schriftfarbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_sek_schriftfarbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="fontcolorsec1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
									echo " value=\"$fontcolorsec\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_farbe; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hg_farbe_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							 </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="bgcol1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$bgcol\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_gen; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
							 <? echo $mod_hg_tab_gen_info; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tablebg1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$tablebg\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_a; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableA1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$tableA\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_b; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableB1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$tableB\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_hg_tab_c; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="tableC1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$tableC\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_links; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="links1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$links\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_visited; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="visited1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$visited\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_active; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="active1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$active\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td width="56%">
						  <div align="right"><font face="<? echo $font; ?>" size=1><b><? echo $mod_farbe_hover; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font></div>
						</td>
						<td width="44%">
						  <div align="left">
							 <input type="text" name="hover1" size="9" maxlength="7"<?
								if ($usedefaultstyle=="1")
								  echo " value=\"$hover\"";
							 ?>>
						  </div>
						</td>
					 </tr>
					 <tr>
						<td>&nbsp;</td>
						<td width="48%">&nbsp;</td>
					 </tr>
					 <tr>
						<td colspan="2">
						  <div align="center">
							 <input type="hidden" name="boardaction" value="6">
							 <input type="submit" name="Submit" value="<? echo $mod_speichern; ?>">
						  </div>
						</td>
					 </tr>
				  </table>
		</td>
		<td width="2%" height="18">&nbsp;</td>
	 </tr>
  </table>
</form>
</TD>
  </TR>
</TABLE>
<? elseif ($boardaction == 5):
	if ($delete=="1") {
		mysql_query("DELETE FROM apb".$n."_boards WHERE boardid='$boardid'");
	} else {
	 	$lastmodified3=$lastmodified;
	 	if (!$kat_neu) {
		 	$kat = $kategorie;
	 	} else {
		 	$kat = $kat_neu;
	 	}
		$resultboards = mysql_query("SELECT totalposts FROM apb".$n."_boards WHERE boardid='$boardid'");
		$totalposts1 = mysql_fetch_array($resultboards);
		$totalposts2 = $totalposts1[totalposts];
		mysql_query("UPDATE apb".$n."_boards SET boardname='$boardname', boardpassword='$boardpassword', boardmods='$boardmods', totalposts='$totalposts2', lastmodified='$lastmodified3', descriptiontext='$descriptiontext', boardgfx='$boardgfx', boardcss='$boardcss', category='$kat', font='$font1', fontcolor='$fontcolor1', fontcolorsec='$fontcolorsec1', bgcolor='$bgcol1', tablebg='$tablebg1', tablea='$tableA1', tableb='$tableB1', tablec='$tableC1', imageurl='$imageurl1', linkcolor='$links1', visited='$visited1', active='$active1', hover='$hover1', hgpicture='$hgpicture1', bgfixed='$bgfixed1', sortit='$sortit' WHERE boardid='$boardid'");
	}
	echo mysql_error();
	message_box("<br><br><center><font size=4 face=\"$face\"><b>".$mod_gespeichert."</b></font></center><br><br>", "Board-Configuration");
?>
<? elseif ($boardaction == 6):
	if ($boardname2=="" || $boardname2==" " || $boardname2=="  ") {
		apb_error($kein_boardname, FALSE);
		exit;
	}
	$lastmodified2 = time();
	if (!$kat_neu2) {
		$kat2 = $kategorie2;
	} else {
		$kat2 = $kat_neu2;
	}
	$result1 = mysql_query("SELECT boardid FROM apb".$n."_boards");
	$board_anzahl = mysql_num_rows($result1);
	$sortit = $board_anzahl+1;
	mysql_query("INSERT INTO apb".$n."_boards VALUES( '', '$boardname2', '$boardpassword2', '$boardmods2', '0', '$lastmodified2', '$descriptiontext2', '$boardgfx2', '$boardcss2', '$kat2', '$font1', '$fontcolor1', '$fontcolorsec1', '$bgcol1', '$tablebg1', '$tableA1', '$tableB1', '$tableC1', '$imageurl1', '$links1', '$visited1', '$active1', '$hover1', '$hgpicture1', '$bgfixed1', '$sortit', '0')");
	echo mysql_error();
	message_box("<br><br><center><font size=4 face=\"$font\"><b>".$mod_gespeichert."</b></font></center><br><br>", "Board-Configuration");
?>
<? endif; ?>
<? require "_footer.inc"; ?>