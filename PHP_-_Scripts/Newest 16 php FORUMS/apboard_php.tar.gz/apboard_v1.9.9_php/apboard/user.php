<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
    $boardgfx = $boardstyle[boardgfx];
    $font = $boardstyle[font];
    $fontcolor = $boardstyle[fontcolor];
    $fontcolorsec = $boardstyle[fontcolorsec];
    $bgcol = $boardstyle[bgcolor];
    $tablebg = $boardstyle[tablebg];
    $tableA = $boardstyle[tablea];
    $tableB = $boardstyle[tableb];
    $tableC = $boardstyle[tablec];
    $imageurl = $boardstyle[imageurl];
    $links = $boardstyle[linkcolor];
    $visited = $boardstyle[visited];
    $active = $boardstyle[active];
    $hover = $boardstyle[hover];
    $hgpicture = $boardstyle[hgpicture];
    $bgfixed = $boardstyle[bgfixed];
    $cfg[css] = "a:link{color:".$links.";text-decoration: none}
    a:visited{color:".$visited.";text-decoration: none}
    a:active{color:".$active.";text-decoration: none}
    a:hover{color:".$hover.";text-decoration: underline}
    BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
    .button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$user_info_user";
require "_header.inc";
require "getimagesize.php";

define("USER_PIC_MAX_WIDTH", $userpicwidth) ;
define("USER_PIC_MAX_HEIGHT", $userpicheight) ;

if ($id == "") {
    apb_error($kein_benutzer_angegeben,FALSE);
}
if ($username == "yes") {
    $type = "username";
} else {
    $type = "userid";
}
$userdata = mysql_query("SELECT userid, username,useremail,userposts,status,regdate,infotext,signatur,usericq,userhp,userage,userpic,interests,show_email_global,users_may_email,mods_may_email FROM apb".$n."_user_table WHERE $type='$id';");
$thisuser = mysql_fetch_array($userdata);
echo mysql_error();

if (!$thisuser) {
    apb_error($benutzer_existiert_nicht_user,FALSE);
}
if ($thisuser[status] == "ADMIN") { $thisuser[status] = $administrator_user; }
if ($thisuser[status] == "MOD") { $thisuser[status] = $moderator_user; }
if ($thisuser[status] == "NORMAL") { $thisuser[status] = $mitglied_user; }
if ($thisuser[status] == "DELETED") { $thisuser[status] = $user_geloescht_user; }
if ($thisuser[status] == "BANNED") { $thisuser[status] = $user_banned_user; }

function tprint ($desc,$cont) {
    global $cfg;
    echo "  <TR BGCOLOR=\"$tableA\">
        <TD WIDTH=\"30%\"><FONT FACE=\"$font\" SIZE=2>$desc</FONT></TD>
        <TD WIDTH=\"70%\"><FONT FACE=\"$font\" SIZE=2>$cont</FONT></TD>
    </TR>";
}


echo "<TABLE BGCOLOR=\"$tableB\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\" ALIGN=\"CENTER\">";
echo "    <TR BGCOLOR=\"$tableC\">";
echo "        <TD COLSPAN=\"2\">";
echo "            <P>";
print_mb ("<B>Benutzerprofil</B><BR>", $font, "4");
print_mb ($thisuser[username] . "<BR>", $font, "6");
print_mb ("[ <A HREF=\"javascript:history.back(1)\">Zur&uuml;ck</A> ]", $font, "2");
echo "            </P>";
echo "        </TD>";
echo "    </TR>";

tprint ($benutzername_profil,$thisuser[username]);


if ($allow_form_mailer) {
	if ($thisuser[users_may_email]) {
		$email_profil_text = "<A HREF=\"$php_path/formmailer.php?toid=$thisuser[userid]\"><IMG SRC=\"$php_path/themes/icons/email_write.gif\" ALT=\"$ml_write_email...\" BORDER=0></A>&nbsp;&nbsp;";
	} else if ($modlog || $adminlog) {
		if ($thisuser[mods_may_email]) {
			$email_profil_text = "<A HREF=\"$php_path/formmailer.php?toid=$thisuser[userid]\"><IMG SRC=\"$php_path/themes/icons/email_write.gif\" ALT=\"$ml_write_email...\" BORDER=0></A>&nbsp;&nbsp;";
		}
	}
}

if ($thisuser[show_email_global] == "1") {
    if ($thisuser[useremail] == "") {
        $email_profil_text .= "[N/A]";
    } else {
        $email_profil_text .= "<A HREF=\"mailto:$thisuser[useremail]\">$thisuser[useremail]</A>";
    }
} else {
    $email_profil_text .= $ml_email_nicht_sichtbar;
}

tprint ($email_profil, $email_profil_text);


if ($thisuser[userhp] == "" || $thisuser[userhp] == "[N/A]") {
    tprint ($homepage_profil,"[N/A]");
} else {
    tprint ($homepage_profil,"<A HREF=\"$thisuser[userhp]\">$thisuser[userhp]</A>");
}

if ($thisuser[usericq] == "[N/A]" || $thisuser[usericq] == "") {
    tprint ($icq_profil,"[N/A]");
} else {
    tprint ($icq_profil,"<a href=\"http://wwp.icq.com/scripts/search.dll?to=$thisuser[usericq]\" target=\"_blank\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=$thisuser[usericq]&img=5\" width=\"20\" height=\"20\" border=\"0\" alt=\"$contact_hinzufuegen\"></a> $thisuser[usericq]");
}

if ($thisuser[userage] == "" || $thisuser[userage] == "[N/A]") {
    tprint ($alter_profil,"[N/A]");
} else {
    tprint ($alter_profil,$thisuser[userage]);
}

tprint ($registrier_datum,HackDate($thisuser[regdate]));
tprint ($beitraege_user,$thisuser[userposts]);
tprint ($status_ueberschrift,$thisuser[status]);
if ($thisuser[userpic]=="" || $thisuser[userpic]==" " || $thisuser[userpic]=="[N/A]") {
    tprint ($bild_user,"");
} else {
    $image = GetURLImageSize($thisuser[userpic]);
    if ($image[0] > USER_PIC_MAX_WIDTH) {
        $width=$image[0];
        $image[0] = USER_PIC_MAX_WIDTH;
        $image[1] = floor(($image[0]*$image[1])/$width);
    }
    if ($image[1] > USER_PIC_MAX_HEIGHT) {
        $old=$image[1];
        $image[1] = USER_PIC_MAX_HEIGHT;
        $image[0] = floor($image[0]*$image[1]/$old);
    }
    if ($thisuser[userhp] == "" || $thisuser[userhp] == " " || $thisuser[userhp] == "[N/A]") {
        $upic = "0";
    } else {
        $upic = "1";
    }
    if ($upic == "1") {
        $printpic .= "<a href=\"".$thisuser[userhp]."\" target=_blank>";
    }
    $printpic .= "<IMG HEIGHT=\"$image[1]\" WIDTH=\"$image[0]\" SRC=\"".$thisuser[userpic]."\" BORDER=0>";
    if ($upic == "1") {
        $printpic .= "</a>";
    }
    tprint ($bild_user,$printpic);
}
if ($thisuser[infotext] == "" || $thisuser[infotext] == "[N/A]") {
    tprint ($infotext_user," ");
} else {
    tprint ($infotext_user,$thisuser[infotext]);
}

if ($thisuser[interests] == "" || $thisuser[interests] == "[N/A]") {
    tprint ($interessen_user," ");
} else {
    tprint ($interessen_user,$thisuser[interests]);
}

?>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
    mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>