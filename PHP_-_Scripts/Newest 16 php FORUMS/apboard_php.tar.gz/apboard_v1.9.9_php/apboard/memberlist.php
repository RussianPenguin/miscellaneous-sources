<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
function ml_in_array($needle,$haystack) {
	for($i=0;$i<count($haystack) && $haystack[$i] !=$needle;$i++);
	return ($i!=count($haystack));
}
$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$memberliste";
require "_header.inc";
$members_per_page = 20;
if ($suche_benutzer && $such_typ) {
	$link_append = "&suche_benutzer=$suche_benutzer&such_typ=$such_typ";
	$where_append = " WHERE ";
	switch ($such_typ) {
		case $ml_search_name :
			$where_append .= "username LIKE '%$suche_benutzer%'";
			break;
		case $ml_search_email :
			$where_append .= "useremail LIKE '%$suche_benutzer%'";
			break;
		case $ml_search_hp :
			$where_append .= "userhp LIKE '%$suche_benutzer%'";
			break;
		case $ml_search_interessen :
			$where_append .= "interests LIKE '%$suche_benutzer%'";
			break;
		default :
			$where_append .= "(username LIKE '%$suche_benutzer%' OR useremail LIKE '%$suche_benutzer%' OR userhp LIKE '%$suche_benutzer%' OR interests LIKE '%$suche_benutzer%')";
			break;
	}
} else {
	$where_append = "";
	$link_append = "";
}
$anzahl_member = mysql_query ("SELECT COUNT(*) FROM apb".$n."_user_table".$where_append);
$anzahl_member = mysql_fetch_row($anzahl_member);
$anzahl_member = $anzahl_member[0];
$anzahl_seiten = ceil($anzahl_member / $members_per_page);
echo mysql_error();
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC ?>">
		<TD COLSPAN="7">
			<? print_mb ($memberliste, $font, "3"); ?>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC ?>">
		<TD COLSPAN="7">
<?
			echo "			<FORM ACTION=\"$php_path/memberlist.php\" METHOD=POST>
			<FONT face=\"$font\" SIZE=2>
			$ml_search_for <INPUT TYPE=TEXT NAME=\"suche_benutzer\" SIZE=20 MAXLENGTH=40> $ml_search_in
			<SELECT NAME=\"such_typ\">
				<OPTION SELECTED>$ml_search_all</OPTION>
				<OPTION>$ml_search_name</OPTION>
				<OPTION>$ml_search_email</OPTION>
				<OPTION>$ml_search_hp</OPTION>
				<OPTION>$ml_search_interessen</OPTION>
			</SELECT>
			<INPUT TYPE=\"SUBMIT\" VALUE=\"$ml_search_dosearch\">
			</FONT>
			</FORM>\n";
?>
		</TD>
	</TR>
<?
				if ($DESC != "1") {
					$gif_string = "<IMG SRC=\"$php_path/themes/icons/pfeil_runter.gif\" BORDER=0>&nbsp;";
				} else {
					$gif_string = "<IMG SRC=\"$php_path/themes/icons/pfeil_hoch.gif\" BORDER=0>&nbsp;";
				}
?>
	<TR BGCOLOR="<? echo $tableB ?>">
		<TD WIDTH="25%">
			<nobr>
<?
				if ((!$order || $order == "username") && $DESC != "1") {
					$order_string = "order=username&DESC=1";
				} else {
					$order_string = "order=username";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if (!$order || $order == "username") {
					echo $gif_string;
				}
				print_mb ($ml_name, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD WIDTH="5%">
			<nobr>
<?
				if ($order == "usericq" && $DESC != "1") {
					$order_string = "order=usericq&DESC=1";
				} else {
					$order_string = "order=usericq";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "usericq") {
					echo $gif_string;
				}
				print_mb ($ml_icq, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD WIDTH="5%">
			<nobr>
<?
				if ($order == "useremail" && $DESC != "1") {
					$order_string = "order=useremail&DESC=1";
				} else {
					$order_string = "order=useremail";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "useremail") {
					echo $gif_string;
				}
				print_mb ($ml_email, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD WIDTH="5%">
			<nobr>
<?
				if ($order == "userhp" && $DESC != "1") {
					$order_string = "order=userhp&DESC=1";
				} else {
					$order_string = "order=userhp";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "userhp") {
					echo $gif_string;
				}
				print_mb ($ml_homepage, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD>
			<nobr>
<?
				if ($order == "interests" && $DESC != "1") {
					$order_string = "order=interests&DESC=1";
				} else {
					$order_string = "order=interests";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "interests") {
					echo $gif_string;
				}
				print_mb ($ml_interests, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD WIDTH="5%">
			<nobr>
<?
				if ($order == "userposts" && $DESC != "1") {
					$order_string = "order=userposts&DESC=1";
				} else {
					$order_string = "order=userposts";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "userposts") {
					echo $gif_string;
				}
				print_mb ($ml_posts, $font, "1");
?>
			</A>
			</nobr>
		</TD>
		<TD WIDTH="25%">
			<nobr>
<?
				if ($order == "regdate" && $DESC != "1") {
					$order_string = "order=regdate&DESC=1";
				} else {
					$order_string = "order=regdate";
				}
				echo "			<a href=\"$php_path/memberlist.php?".$order_string.$link_append."\">";
				if ($order == "regdate") {
					echo $gif_string;
				}
				print_mb ($ml_registered, $font, "1");
?>
			</A>
			</nobr>
		</TD>
	</TR>
<?
$sql_query = "SELECT userid, username, usericq, useremail, userposts, regdate, userhp, interests, show_email_global, users_may_email, mods_may_email FROM apb".$n."_user_table";
$sql_query .= $where_append;
if ($order) {
	$tmp_array = array ("username", "usericq", "useremail", "userposts", "regdate", "interests", "userhp");
	if (ml_in_array($order, $tmp_array)) {
		$sql_query .= " ORDER BY $order";
	} else {
		$sql_query .= " ORDER BY username";
	}
} else {
	$sql_query .= " ORDER BY username";
}

if ($DESC == "1") {
	$sql_query .= " DESC";
}

if (!isset($show_page)) {
	$show_page = 1;
}
if ($show_page > $anzahl_seiten) {
	$show_page = $anzahl_seiten;
}
$start_at = ($show_page - 1) * $members_per_page;
$sql_query .= " LIMIT $start_at,$members_per_page";
//echo $sql_query;
$members = mysql_query ($sql_query);
echo mysql_error();
while ($this_member = mysql_fetch_array($members)) {

	$this_useremail = $this_member[useremail];
	if ($this_useremail == "" || $this_useremail == " " || $this_useremail == "[N/A]") {
		$this_useremail == "&nbsp;";
	} else {
		if ($this_member[show_email_global] == "1") {
			$this_useremail = "<A HREF=\"mailto:$this_member[useremail]\"><img src=".$php_path."/themes/icons/email.gif width=16 height=16 alt=\"eMail me...\" border=0></A>";
		} else {
			$this_useremail = "<img src=".$php_path."/themes/icons/email_na.gif width=20 height=20 alt=\"$ml_email_nicht_sichtbar...\" border=0>";
		}
	}
	
	if ($allow_form_mailer) {
		if ($this_member[users_may_email]) {
			$this_useremail .= "&nbsp;&nbsp;<A HREF=\"$php_path/formmailer.php?toid=$this_member[userid]\"><IMG SRC=\"$php_path/themes/icons/email_write.gif\" ALT=\"$ml_write_email...\" BORDER=0></A>";
		} else if ($modlog || $adminlog) {
			if ($this_member[mods_may_email]) {
				$this_useremail .= "&nbsp;&nbsp;<A HREF=\"$php_path/formmailer.php?toid=$this_member[userid]\"><IMG SRC=\"$php_path/themes/icons/email_write.gif\" ALT=\"$ml_write_email...\" BORDER=0></A>";
			}
		}
	}
	
	$this_usericq = $this_member[usericq];
	if ($this_usericq == "" || $this_usericq == " " || $this_usericq == "[N/A]") {
		$this_usericq = "&nbsp;";
	} else {
		$this_usericq = "<A HREF=\"http://wwp.icq.com/scripts/search.dll?to=".$this_member[usericq]."\" target=\"_blank\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=".$this_member[usericq]."&img=5\" width=\"15\" height=\"15\" border=\"0\" alt=\"".$contact_hinzufuegen."\"></a> ";
	}

	$this_userhp = $this_member[userhp];
	if ($this_userhp == "" || $this_userhp == "[N/A]") {
		$this_userhp = "&nbsp;";
	} else {
		$this_userhp = "<A HREF=\"$this_member[userhp]\" target=_blank><img src=".$php_path."/themes/icons/home.gif width=16 height=16 alt=\"Hier gehts zur Homepage\" border=0></A>";
	}
?>
	<TR BGCOLOR="<? echo $tableC ?>">
		<TD>
			<A HREF="<? echo "$php_path/user.php?username=yes&id=$this_member[username]"; ?>"><? print_mb ($this_member[username], $font, "1"); ?></A>
		</TD>
		<TD>
			<? print_mb ($this_usericq, $font, "1"); ?>
		</TD>
		<TD>
			<? print_mb ($this_useremail, $font, "1"); ?>
		</TD>
		<TD>
			<? print_mb ($this_userhp, $font, "1"); ?>
		</TD>
		<TD>
			<? print_mb ($this_member[interests], $font, "1"); ?>&nbsp;
		</TD>
		<TD>
			<? print_mb ($this_member[userposts], $font, "1"); ?>
		</TD>
		<TD>
			<? print_mb (Hackdate($this_member[regdate]), $font, "1"); ?>
		</TD>
	</TR>
<?
	echo mysql_error();
}
$page_string = "<FONT SIZE=\"-1\">$ml_pages";
$i = 1;
while ($i <= $anzahl_seiten) {
	if ($i == $show_page) {
		$page_string .= " $i ";
	} else {
		$page_string .= " <A HREF=\"$php_path/memberlist.php?show_page=$i";
		if ($suche_benutzer && $such_typ) {
			$page_string .= "&such_typ=$such_typ&suche_benutzer=$suche_benutzer";
		}
		if ($order) {
			$page_string .= "&order=$order";
			if ($DESC == "1") {
				$page_string .= "&DESC=1";
			}
		}
		$page_string .= "\">$i</A> ";
	}
	$i++;
}
$page_string .= "</FONT>";
?>
	<TR BGCOLOR="<? echo $tableB ?>">
		<TD COLSPAN="7">
			<? echo $page_string; ?>
		</TD>
	</TR>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";
?>