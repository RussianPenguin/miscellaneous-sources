<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$news_board_news";
require "_header.inc";
echo "
<table align=\"center\" bgcolor=\"$tablebg\" width=\"95%\" cellspacing=\"1\" border=\"0\" cellpadding=\"6\">
	<tr bgcolor=$tableC>
		<td colspan=\"2\">";

$result = mysql_query("SELECT * FROM apb".$n."_board_news ORDER BY date DESC LIMIT 10;");
print_mb("<b>".$news_board_news."</b>",$font,"4");
echo "<BR>";
print_mb($news_info,$font,"1");
echo "		</td>
	</tr>
	<tr valign=\"top\" bgcolor=\"$tableB\">
		<td width=\"50%\">";
while ( $thisnews = mysql_fetch_array ( $result ) ) {
	if ($id) {
		if ($thisnews[id] == $id) $displaynews = $thisnews;
	} else {
		if (!$displaynews) $displaynews = $thisnews;
	}
	$newsdate = HackDate ($thisnews[date]);
	print_mb ( $newsdate , $font , "1" );
	echo "<br>";
	print_mb ( "<A HREF=\"$php_path/news.php?id=$thisnews[id]&BoardID=$BoardID\">$thisnews[topic]</A>" , $font , "1" );
	echo "<br><br>";
};
echo "		</td><td width=\"50%\">";
$tdate = HackDate ($displaynews[date]);
print_mb ( "$tdate" , $font , "1" );
echo "<br>";
print_mb ( "<b>$displaynews[topic]</b>" , $font , "2" );
echo "<br><br>";
print_mb ( $displaynews[text] , $font , "2" );
echo "		</td></tr>
	<tr bgcolor=$tableA>
		<td colspan=\"2\"><center>";
print_mb ("[ - <A HREF=\"javascript:history.back(1)\">".$zurueck."</A> - ]",$font,"2");
echo"</center></td>
	</tr>
</table>";
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>