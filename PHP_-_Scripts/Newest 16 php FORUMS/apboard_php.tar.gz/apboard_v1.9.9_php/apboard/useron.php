<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
$timeout						= "3";
$twidth						= "95%";
$bghl							= $tableA;
$bgfl							= $tableB;
$ffacehl						= $font;
$fsizehl						= "2";
$fcolorhl					= $fontcolor;
$ffacefl						= $font;
$fsizefl						= "1";
$fcolorfl					= $fontcolorsec;
$texthl						= $user_online;
$zeit							= time();
$loeschzeit					= $zeit-($timeout*60);
$ip							= getenv(REMOTE_ADDR);
$file							= $PHP_SELF;

$nickname = mysql_query("SELECT username FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]'");
$nickname1 = mysql_fetch_array($nickname);
$result = @mysql_query("INSERT INTO apb".$n."_useronline VALUES ('$zeit','$ip','$file','$nickname1[username]')");
$result = @mysql_query("DELETE FROM apb".$n."_useronline WHERE zeit<'$loeschzeit'");
$result = @mysql_query("SELECT DISTINCT nickname FROM apb".$n."_useronline WHERE nickname != ''");
$anzahl_reg_user = @mysql_num_rows($result);
$result = @mysql_query("SELECT DISTINCT ip FROM apb".$n."_useronline WHERE nickname = ''");
$anzahl_guests = @mysql_num_rows($result);
$anzahl_user = $anzahl_reg_user + $anzahl_guests;
echo "<a href=\"$php_path/online.php?BoardID=$BoardID\"><b>".$anzahl_user."</b> ".$texthl."</a>";

unset($file);

?>