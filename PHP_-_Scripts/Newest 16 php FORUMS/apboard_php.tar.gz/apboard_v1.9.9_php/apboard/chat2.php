<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
//$ustring = CookieAuth($UserInformation);
header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header ("Last-Modified: " . gmdate ("D, d M Y H:i:s") . " GMT");
header ("Cache-control: no-cache, must-revalidate, no-store");
header ("Pragma: no-cache");

?>
<HTML><HEAD><TITLE>APBoard-Chat</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<STYLE TYPE="TEXT/CSS">
<? echo $cfg[css]; ?>
</STYLE>
<basefont="<? echo $font; ?>">
</HEAD>
<?

$usern1 = mysql_query("SELECT username FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]'");
echo mysql_error();
if (!($userna = mysql_fetch_row($usern1))) {
	
	if ($chatusername) {
		if (strlen($chatusername) > 12) {
			$chatusername = substr($chatusername, 0, 12);
		}
		$usern1 = mysql_query("SELECT username FROM apb".$n."_user_table WHERE username='$chatusername'");
		echo mysql_error();
		if ($userna = mysql_fetch_row($usern1)) {
			$chatusername2 = "";
		} else {
			if (isset($chatusername)) {
				$chatusername2 = $chatusername . " (Gast)";
			}
		}
	}
	
} else {
	$chatusername2 = $userna[0];
}


		
echo mysql_error();


ereg(".*\">(.*)</A>$",$ustring,$user);
echo "<BODY BGCOLOR=\"$bgcol\" text=\"$fontcolor\" link=\"$links\" alink=\"$active\" vlink=\"$visited\">";
if (isset($chatdo)) {
	$zeit = time() + $zeitverschiebung;
	$timeaus = "30";
	$deletetime = $zeit - ($timeaus * 60);
	mysql_query("DELETE FROM apb".$n."_chat WHERE zeit<'$deletetime'");
	RemovePostCrap($chat);
	$chat = RemoveCrap($chat);
	mysql_query("INSERT INTO apb".$n."_chat VALUES( '', '$zeit', '$chatusername2', '$chat')");
	unset($chatdo);
}
if ($chatact=="0") {
	echo "<blockquote><center><b>Die Chat-Funktion ist zur Zeit nicht aktiviert.</b><br><br>Bitte wende Dich an den <a href=\"mailto:".$adminemail."?subject=APBoard - Chat activation\">Administrator</a>.</center></blockquote>";
} else {

/*  <input type="hidden" name="chatusername" value="<? echo $userna[0]; ?>">  */

?>
	<form action="<? echo $php_path; ?>/chat2.php" method="post" name="chatting">
		<input type="text" name="chat" size="60" maxlength="250">
		<input type="submit" name="submit" value="<? echo $chat_senden; ?>"><BR>
<?
	if (!$chatusername2) {
		echo "		Name (f. G&auml;ste): <input type=\"text\" name=\"chatusername\" size=\"12\" maxlength=\"12\">\n";
	} else {
		echo "		<input type=\"hidden\" name=\"chatusername\" value=\"$chatusername\">";
	}
?>
		<input type="hidden" name="chatdo" value="1">
	</form>
<?

}

?>

<script language="JavaScript">
document.chatting.chat.focus();
</script>

</BODY>
</HTML>