<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";

$ustring = CookieAuth($UserInformation);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<b>Administration</b>";
require "_header.inc";
$result = mysql_query("SELECT userid,username,userpassword,status FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
$userdat = mysql_fetch_array($result);
echo mysql_error();
if ($userdat[userpassword] != $UPASS) {
	apb_error("ERROR #08: Invalid password in cookie!",TRUE);
}

if ($userdat[status] != "ADMIN" && $userdat[status] != "MOD")
{
	apb_error("Admins/Moderators only!",FALSE);
}
if (!$action) {
	apb_error("No action selected!",FALSE);
}
$last_reply = time();
// <--------------------------------------- DELETE POST ------------------------------------------>
if ($action == "deletepost") {
	if (!$postid) {
		apb_error("ERROR #09: Invalid post ID",FALSE);
	}
	if (!$tparentid) {
		apb_error("No topic selected!",FALSE);
	}
	if (!$bparentid) {
		apb_error("No board selected!",FALSE);
	}
	echo mysql_error();

	$author_name = mysql_query("SELECT authorname FROM apb".$n."_posts WHERE postid='$postid'");
	$author_name = mysql_fetch_row($author_name);
	echo mysql_error();
	$author_name = $author_name[0];

	echo mysql_error();

	if (!isset($really_delete)) {
		$question = "$mod_really_delete_post1 $postid ($mod_really_delete_post2 $author_name) $mod_really_delete_post3";
		$message = "<FORM action=\"$php_path/mod_delete_post.php\" METHOD=POST>";
		$message .= "<INPUT TYPE=SUBMIT VALUE=\"$mod_really_delete_post4\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"action\" VALUE=\"deletepost\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"postid\" VALUE=\"$postid\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"tparentid\" VALUE=\"$tparentid\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"bparentid\" VALUE=\"$bparentid\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"really_delete\" VALUE=\"1\">";
		$message .= "</FORM>\n";
		question_box ($question, $message);
		include "_footer.inc";
		exit;
	}

	mysql_query("DELETE FROM apb".$n."_posts WHERE postid='$postid'");
	echo mysql_error();
	mysql_query("UPDATE apb".$n."_user_table SET userposts = userposts - 1 WHERE username = '$author_name'");
	echo mysql_error();

	$latest_post = GetLatestPost($tparentid);
	if ($latest_post = mysql_fetch_array($latest_post)) {
		$new_timelastreply = $latest_post[posttime];
		mysql_query ("UPDATE apb".$n."_threads SET timelastreply = '$new_timelastreply' WHERE threadid = '$tparentid'");
	}

	$reply_count = mysql_query("SELECT replies FROM apb".$n."_threads WHERE threadid='$tparentid'");
	while ($reply_count1 = mysql_fetch_row($reply_count)) {
		$reply_count2 = $reply_count1[0];
	}
	echo mysql_error();


	if ($reply_count2 < 1) {
		mysql_query("DELETE FROM apb".$n."_threads WHERE threadid='$tparentid'");
		echo mysql_error();

		$sql_query = "UPDATE apb".$n."_boards SET totalposts=totalposts-1, totalthreads=totalthreads-1";

		$last_thread = GetLatestThread($bparentid);
		if ($last_thread = mysql_fetch_array($last_thread)) {
			$last_thread = $last_thread[timelastreply];
			$sql_query .= ", lastmodified='$last_thread'";
		}
		$sql_query .= " WHERE boardid='$bparentid'";
		mysql_query($sql_query);
		echo mysql_error();

	} else {

		mysql_query("UPDATE apb".$n."_threads SET replies=replies-1 WHERE threadid='$tparentid'");
		echo mysql_error();

		$sql_query = "UPDATE apb".$n."_boards SET totalposts=totalposts-1";

		$last_thread = GetLatestThread($bparentid);
		if ($last_thread = mysql_fetch_array($last_thread)) {
			$last_thread = $last_thread[timelastreply];
			$sql_query .= ", lastmodified='$last_thread'";
		}
		$sql_query .= " WHERE boardid='$bparentid'";


		mysql_query($sql_query);
		echo mysql_error();
	}

	message_box($mod_post_deleted);
}


// <--------------------------------------- DELETE THREAD ------------------------------------------>
if ($action == "delete_thread") {
	if (!$id) {
		apb_error("ERROR #10: Invalid Thread ID",FALSE);
	}
	if (!$bparentid) {
		apb_error("No board selected!",FALSE);
	}

	$thread_name = mysql_query("SELECT threadname FROM apb".$n."_threads WHERE threadid='$id'");
	$thread_name = mysql_fetch_row($thread_name);
	echo mysql_error();
	$thread_name = $thread_name[0];

	if (!isset($really_delete)) {
		$question = "$mod_really_delete_thread1 $id (\"$thread_name\") $mod_really_delete_thread2";
		$message = "<FORM action=\"$php_path/mod_delete_post.php\" METHOD=POST>";
		$message .= "<INPUT TYPE=SUBMIT VALUE=\"$mod_really_delete_thread3\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"action\" VALUE=\"delete_thread\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"id\" VALUE=\"$id\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"bparentid\" VALUE=\"$bparentid\">";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"really_delete\" VALUE=\"1\">";
		$message .= "</FORM>\n";
		question_box ($question, $message);
		include "_footer.inc";
		exit;
	}

	echo mysql_error();

	$result = mysql_query("SELECT COUNT(*) FROM apb".$n."_posts WHERE threadparentid='$id'");
	mysql_query("DELETE FROM apb".$n."_threads WHERE threadid='$id'");
	$minuszahl = mysql_fetch_row($result);
	$minus = $minuszahl[0];
	$posts_per_author = mysql_query("SELECT authorname, COUNT(authorname) AS posts FROM apb".$n."_posts WHERE threadparentid='$id' GROUP BY authorname");
	echo mysql_error();
	mysql_query("DELETE FROM apb".$n."_posts WHERE threadparentid='$id'");
	echo mysql_error();
	
	while ($this_author = mysql_fetch_array($posts_per_author)) {
		mysql_query("UPDATE apb".$n."_user_table SET userposts = userposts - $this_author[posts] WHERE username = '$this_author[authorname]'");
		echo mysql_error();
	}
	
	$sql_query_boards = "UPDATE apb".$n."_boards SET totalposts=totalposts-'$minus',totalthreads=totalthreads-1";

	$last_thread = GetLatestThread($bparentid);
	if ($last_thread = mysql_fetch_array($last_thread)) {
		$last_thread = $last_thread[timelastreply];
		$sql_query_boards .= ", lastmodified='$last_thread'";
	}

	$sql_query_boards .= " WHERE boardid='$bparentid'";

	mysql_query($sql_query_boards);
	echo mysql_error();

	message_box($mod_thread_deleted);

}


// <--------------------------------------- MOVE THREAD ------------------------------------------>
if ($action == "move_thread") {
	if (!$id) {
		apb_error("ERROR #10: Invalid Thread ID",FALSE);
	}
	if (!$bparentid) {
		apb_error("No board selected!",FALSE);
	}
	if (!$newpboard) {
		
		$resultboards = mysql_query("SELECT boardid, boardname, category FROM apb".$n."_boards ORDER BY category, boardname");

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD><font face="<? echo $font; ?>" size=3><b>Moderation</b></font></TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $mod_move_thread1; ?></font></td>
					<td width="2%">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2">

						<table width="98%" border="0" cellspacing="1" cellpadding="4">
							<tr BGCOLOR="<? echo $tableB; ?>">
								<td width="49%" height="18">
									<div align="right">
									<font face="<? echo $font; ?>" size=2><? echo $move_thread_quest; ?>...</font>
									</div>
								</td>
								<td width="49%" height="18">
									<div align="left">
									<font face="<? echo $font; ?>" size=2><br>
				<form method=post ACTION="<? echo "$php_path/mod_delete_post.php"; ?>">
					<input type="hidden" name="action" value="<? echo $action; ?>">
					<input type="hidden" name="id" value="<? echo $id; ?>">
					<input type="hidden" name="bparentid" value="<? echo $bparentid; ?>">
					<select name="newpboard">
<?
					while ($thisboard = mysql_fetch_array($resultboards)) {
						if ($thisboard[category] != $old_cat) {
							$cat_str = "---- $thisboard[category] -------------------------------------------------------------";
							$cat_str = substr($cat_str, 0, 55);
							echo "<option value=\"\"> $cat_str </option>";
						}
						echo "<option value=\"$thisboard[boardid]\">".$thisboard[boardname]."</option>";
						$old_cat = $thisboard[category];
					}
?>
					</select>&nbsp;
					<input type="submit" name="Submit" value="<? echo $mod_move_thread2; ?>">
				</form>
									</font>
									</div>
								</td>
							</tr>
						</table>

					</td>
					<td width="2%">&nbsp;</td>
				</tr>
			</table>
		</TD>
	</TR>
</TABLE>

<?
	} else {

		echo mysql_error();
		
		if (!$newpboard) {
			apb_error("<B>".$mod_kein_board_gewaehlt."</B><BR><BR>", $font, "3");
		}
		
		$resultboardid = mysql_query("SELECT boardid FROM apb".$n."_boards WHERE boardid='$newpboard'");
		$newbparentid = mysql_fetch_array($resultboardid);
		$newbparentid = $newbparentid[0];
		
		echo mysql_error();
		$last_reply = time();

		$thread_posts = mysql_query("SELECT COUNT(*) FROM apb".$n."_posts WHERE threadparentid='$id'");
		$thread_posts = mysql_fetch_row($thread_posts);
		$thread_posts = $thread_posts[0];
		echo mysql_error();
		mysql_query("UPDATE apb".$n."_threads SET boardparentid=$newbparentid WHERE threadid='$id'");
		echo mysql_error();

		$sql_query_old_board = "UPDATE apb".$n."_boards SET totalposts=totalposts-$thread_posts,totalthreads=totalthreads-1";
		$sql_query_new_board = "UPDATE apb".$n."_boards SET totalposts=totalposts+$thread_posts,totalthreads=totalthreads+1";

		$last_thread_old_board = GetLatestThread($bparentid);
		if ($last_thread_old_board = mysql_fetch_array($last_thread_old_board)) {
			$last_thread_old_board = $last_thread_old_board[timelastreply];
			$sql_query_old_board .= ", lastmodified='$last_thread_old_board'";
		}

		echo mysql_error();

		$last_thread_new_board = GetLatestThread($newbparentid);
		if ($last_thread_new_board = mysql_fetch_array($last_thread_new_board)) {
			$last_thread_new_board = $last_thread_new_board[timelastreply];
			$sql_query_new_board .= ", lastmodified='$last_thread_new_board'";
		}

		echo mysql_error();

		$sql_query_old_board .= " WHERE boardid='$bparentid'";
		$sql_query_new_board .= " WHERE boardid='$newbparentid'";


		mysql_query($sql_query_old_board);
		echo mysql_error();
		mysql_query($sql_query_new_board);
		echo mysql_error();

?>

<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD><font face="<? echo $font; ?>" size=3><b>Moderation</b></font></TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $mod_move_thread1; ?></font></td>
					<td width="2%">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2">
						<? echo mysql_error(); ?>
						<br><br><center><font size=5 face=verdana><b><? echo $mod_move_thread_success; ?></b></font></center><br><br>
					</td>
					<td width="2%">&nbsp;</td>
				</tr>
			</table>
		</TD>
	</TR>
</TABLE>

<?

	}
}


// <--------------------------------------- CLOSE THREAD ------------------------------------------>
if ($action == "close_thread") {
	if (!$id) { apb_error("ERROR #10: Invalid Thread ID",FALSE); }
	if (!$bparentid) { apb_error("No board selected!",FALSE); }
	echo mysql_error();
	$timelast = time();
	mysql_query("UPDATE apb".$n."_threads SET flags=1 WHERE threadid='$id'");
	echo mysql_error();
	message_box ($mod_thread_closed);
}
// <--------------------------------------- OPEN THREAD ------------------------------------------>
if ($action == "open_thread") {
	if (!$id) { apb_error("ERROR #10: Invalid Thread ID",FALSE); }
	if (!$bparentid) { apb_error("No board selected!",FALSE); }
	echo mysql_error();
	$timelast = time();
	mysql_query("UPDATE apb".$n."_threads SET flags=0 WHERE threadid='$id'");
	echo mysql_error();
	message_box ($mod_thread_opened);
}


// <--------------------------------------- GET IP ------------------------------------------>
if ($action == "get_ip") {
	if (!$postid) {
		apb_error("ERROR #10: Invalid Post ID",FALSE);
	}
	$post = GetPostInfo($postid);
	$post = mysql_fetch_array($post);
	$post_pthread_id = $post[threadparentid];

	$parentthread = GetThreadInfo($post_pthread_id);
	$parentthread = mysql_fetch_array($parentthread);
	$parentthread = $parentthread[boardparentid];

	$parentboard = GetBoardInfo($parentthread);
	$parentboard = mysql_fetch_array($parentboard);
	$parentmods = explode (", ", $parentboard[boardmods]);
	
	if ($userdat[status] != "ADMIN" && !(apb_in_array($userdat[username], $parentmods))) {
		apb_error("Only Moderators of this board or Admins!",FALSE);
	}
	
	$post_ips = $post[post_ip];
	$post_ips = explode(",", $post_ips);
	
	if (!$post_ips[0]) {
		$post_ips[0] = "konnte nicht ermittelt werden!";
	}
	
	$message = "Dieser Beitrag wurde mit folgender IP verfasst:<BR><BR>\n<B>$post_ips[0]</B>\n";
	
	if ($post_ips[1]) {
		$message .= "<BR><BR>Der Beitrag wurde au�erdem mit folgenden IPs editiert:<BR>\n";
		next ($post_ips);
		$pos = 0;
		while (list($key, $val) = each ($post_ips)) {
			if (!$val) {
				$val = "konnte nicht ermittelt werden!";
			}
			$pos++;
			$message .= "<BR>$pos. - <B>$val</B>\n";
			
		}
	}
	
	message_box($message);
	
}
require "_footer.inc";
?>