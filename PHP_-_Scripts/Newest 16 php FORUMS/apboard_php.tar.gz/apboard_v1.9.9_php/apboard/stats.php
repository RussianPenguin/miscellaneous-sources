<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$statistiken";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="4">
			<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
				<TR BGCOLOR="<? echo $tableC; ?>">
					<TD COLSPAN="4"><FONT FACE="<? echo $font; ?>" SIZE=4>
						<center>
						<b><? echo $master_board_name; ?> - <? echo $statistiken; ?></b>
						</center>
						</font>
					</TD>
				</TR>
				<TR BGCOLOR="<? echo $tableC; ?>">
					<TD COLSPAN="4">
						<center>
							<table width="100%" border="0" cellspacing="1" cellpadding="6" align="center">
								<tr>
									<td valign="top" width="60%">
<?
$max_laenge = "150";
$user_top = GetUserTop10();
$query = "SELECT userposts FROM apb".$n."_user_table ORDER BY userposts DESC LIMIT 0,10";
$result = mysql_query($query);
$totalposts = 0;
while(list($posts) = mysql_fetch_array($result)) {
	$totalposts = $totalposts + $posts;
}
if ($totalposts == 0) $totalposts = 1;
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">";
echo "<tr><td colspan=3><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>User Top 10</b></font></div></td></tr>";
echo "<tr><td colspan=3><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>&nbsp;</b></font></div></td></tr>";
$stati = 1;
while ($user_t = mysql_fetch_array($user_top)) {
	$userid = $user_t[userid];
	$username = $user_t[username];
	$userposts = $user_t[userposts];
	$user_post_percent = (int) ($userposts*$max_laenge/$totalposts);
	
	echo "<tr><td width=\"5%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n".$stati.".&nbsp;</font>\n</div></td>
	<td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n
	<A HREF=\"$php_path/user.php?username=yes&id=$username&BoardID=$BoardID\">".$username."</a>&nbsp;&nbsp;&nbsp;&nbsp;</font>\n
	</div></td><td width=\"65%\"><div align=left>\n
	<FONT FACE=\"".$font."\" SIZE=1>\n
	<img src=\"".$php_path."/themes/aqua.gif\" border=\"0\" height=\"6\" width=\"".$user_post_percent."\">\n
	&nbsp;&nbsp;&nbsp;&nbsp;".$userposts." Posts\n
	</font></div></td></tr>\n";
    $stati++;
}
?>
</table>
<br>
</td>
	<td valign="top" width="40%">
<?
	echo "<font face=\"$font\" size=\"1\">";
	echo "<center><FONT FACE=\"".$font."\" SIZE=2><b>User im Board Online</b></font></center><br>";

	$reg_user = mysql_query("SELECT DISTINCT nickname FROM apb".$n."_useronline WHERE nickname != ''");
	$anzahl_reg_user = mysql_num_rows($reg_user);

	$anzahl_guests = mysql_query("SELECT DISTINCT ip FROM apb".$n."_useronline WHERE nickname = ''");
	$anzahl_guests = mysql_num_rows($anzahl_guests);

	$anzahl_user = $anzahl_reg_user + $anzahl_guests;

	if ($anzahl_user == "1") {
		echo "Es ist zur Zeit ein Besucher online:<br><br>";
	} else {
		echo "Es sind zur Zeit ".$anzahl_user." Besucher online:<br><br>";
	}

	while ($nickname = mysql_fetch_row($reg_user)) {
		echo "<b><A HREF=\"$php_path/user.php?username=yes&id=$nickname[0]&BoardID=$BoardID\">".$nickname[0]."</a></b><br>";
	}

	if ($anzahl_guests == 1) {
		echo "1 Gast<br>";
	} else if ($anzahl_guests > 1) {
		echo "$anzahl_guests G&auml;ste<br>";
	}
?>

						</font>
					</td>
				</tr>
			</table><br>
			<table width="100%" border="0" cellspacing="1" cellpadding="6" align="center">
				<tr>
					<td valign="top" width="60%">
<?
$board_top = GetBoardsTop10();
$query1 = "SELECT totalposts FROM apb".$n."_boards ORDER BY totalposts DESC LIMIT 0,10";
$result1 = mysql_query($query1);
$totalboardposts = 0;
while(list($boardposts) = mysql_fetch_array($result1)) {
    $totalboardposts = $totalboardposts + $boardposts;
}
if ($totalboardposts == 0) $totalboardposts = 1;
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">";
echo "<tr><td colspan=3><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>Boards Top 10</b></font></div></td></tr>";
echo "<tr><td colspan=3><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>&nbsp;</b></font></div></td></tr>";
$stati1 = 1;
while ($board_t = mysql_fetch_array($board_top)) {
	$boardid = $board_t["boardid"];
	$boardname = $board_t["boardname"];
	$boardtotalposts = $board_t["totalposts"];
	$board_post_percent = (int) ($boardtotalposts*$max_laenge/$totalboardposts);
	echo "<tr><td width=\"5%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n".$stati1.".&nbsp;</font>\n</div></td>
	<td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n
	<A HREF=\"$php_path/board.php?id=$boardid&BoardID=$BoardID\">".$boardname."</a>&nbsp;&nbsp;&nbsp;&nbsp;</font>\n
	</div></td><td width=\"65%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n
	<img src=\"".$php_path."/themes/aqua.gif\" border=\"0\" height=\"6\" width=\"".$board_post_percent."\">\n
	&nbsp;&nbsp;&nbsp;&nbsp;".$boardtotalposts." Posts\n
	</font></div></td></tr>\n";
    $stati1++;
}
?>
</table>
<br>
</td>
	<td valign="top" width="40%">
<?
$thread_last = GetLastThreads(10);
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">";
echo "<tr><td colspan=4><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>Last Threads Top 10</b></font></div></td></tr>";
echo "<tr><td colspan=4><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>&nbsp;</b></font></div></td></tr>";
$stati2 = 1;
while ($thread_t = mysql_fetch_array($thread_last)) {
	$threadid = $thread_t["threadid"];
	$threadname = $thread_t["threadname"];
	$boardparentid = $thread_t["boardparentid"];
	$threadtopicicon = $thread_t["topicicon"];
	$threadlastreply = $thread_t["timelastreply"];
	
	$threadname = RemoveCrop($threadname);
	
	echo "	<tr><td width=\"5%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n";
		echo $stati2.".&nbsp;</font>\n</div></td>\n";
	echo "	<td width=\"5%\"><IMG SRC=\"$threadtopicicon\"> </td>\n
	<td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n<A HREF=\"$php_path/thread.php?id=$threadid&BoardID=$boardparentid\">".$threadname."</a>&nbsp;&nbsp;&nbsp;&nbsp;</font>\n
	</div></td><td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n
	&nbsp;&nbsp; <nobr>".Hackdate($threadlastreply)."</nobr>\n
	</font></div></td></tr>\n";
    $stati2++;
}
?>
							</table>
						</font>
					</td>
				</tr>
			</table><br>
			<table width="100%" border="0" cellspacing="1" cellpadding="6" align="center">
				<tr>
					<td valign="top" width="60%">
<?

$thread_top = GetThreadsTop10(10);
while ($thisrow = mysql_fetch_array($thread_top)) {
	$totalthreadposts += $thisrow[replies]+1;
}

$thread_top = GetThreadsTop10(10);


if ($totalthreadposts == 0) $totalthreadposts = 1;
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">";
echo "<tr><td colspan=5><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>Threads Top 10</b></font></div></td></tr>";
echo "<tr><td colspan=5><div align=center><FONT FACE=\"".$font."\" SIZE=2><b>&nbsp;</b></font></div></td></tr>";
$stati2 = 1;

while ($thread_t = mysql_fetch_array($thread_top)) {
	$threadid = $thread_t["threadid"];
	$threadname = $thread_t["threadname"];
	$boardparentid = $thread_t["boardparentid"];
	$threadtopicicon = $thread_t["topicicon"];
	$threadtotalposts = $thread_t["replies"] + 1;
	$thread_post_percent = (int) ($threadtotalposts*$max_laenge/$totalthreadposts);

	$threadname = RemoveCrop($threadname);
	
	echo "	<tr><td width=\"5%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n";
		echo $stati2.".&nbsp;</font>\n</div></td>\n";
	echo "	<td width=\"5%\"><IMG SRC=\"$threadtopicicon\"> </td>\n
	<td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n<A HREF=\"$php_path/thread.php?id=$threadid&BoardID=$boardparentid\">".$threadname."</a>&nbsp;&nbsp;&nbsp;&nbsp;</font>\n
	</div></td><td width=\"30%\"><div align=left>\n<FONT FACE=\"".$font."\" SIZE=1>\n
	<img src=\"".$php_path."/themes/aqua.gif\" border=\"0\" height=\"6\" width=\"".$thread_post_percent."\">\n
	&nbsp;&nbsp;&nbsp;&nbsp;".$threadtotalposts." Posts\n
	</font></div></td></tr>\n";
    $stati2++;
}
?>
</table>
<br>
</td>
	<td valign="top" width="40%">
<?
	echo "<font face=\"$font\" size=\"1\">";
	echo "<center><FONT FACE=\"".$font."\" SIZE=2><b>Diverse</b></font></center><br>";
    $memberresult = mysql_query ("SELECT username FROM apb".$n."_user_table ORDER BY regdate DESC LIMIT 0,1");
    $newestm = mysql_fetch_array ($memberresult);
    echo "Neuestes Mitglied:&nbsp;&nbsp;&nbsp;<b>".$newestm[0]."</b><br>";
	echo "Insgesamt registrierte Mitglieder:&nbsp;&nbsp;&nbsp;<b>".$user_gesamt."</b> (<a href=".$php_path."/memberlist.php>Liste</a>)<br>";
    $threads_result = mysql_query("SELECT COUNT(*) FROM apb".$n."_threads");
    $threads_gesamt = mysql_fetch_array($threads_result);
    $allthreads = $threads_gesamt[0];
    $posts_result = mysql_query("SELECT COUNT(*) FROM apb".$n."_posts");
    $posts_gesamt = mysql_fetch_array($posts_result);
    $allposts = $posts_gesamt[0];
    echo "Insgesamt bisherige Threads:&nbsp;&nbsp;&nbsp;<b>".$allthreads."</b><br>";
    echo "Insgesamt bisherige Posts:&nbsp;&nbsp;&nbsp;<b>".$allposts."</b><br>";
	$installdate_format = HackDate($installdate);
    $timediff = $now - $installdate;						// Sek. vom Zeitpunkt der Installation, bis heute
	$postperday = ($allposts) / ((($timediff / 60) / 60) / 24);
	$postperhour = ($allposts) / (($timediff / 60) / 60);
	$postperday = round($postperday);
	$postperhour = round($postperhour);
	echo "Postings/Tag:&nbsp;&nbsp;&nbsp;<b>".$postperday."</b>&nbsp;&nbsp;(seit ".$installdate_format.")<br>";
    echo "Postings/Std.:&nbsp;&nbsp;&nbsp;<b>".$postperhour."</b>&nbsp;&nbsp;(seit ".$installdate_format.")<br>";
	?>
						</font>
					</td>
				</tr>
			</table>
		</center>
		</TD>
	</TR>
</table>
     </TD>
    </TR>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time()+$zeitverschiebung);
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()+$zeitverschiebung."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>