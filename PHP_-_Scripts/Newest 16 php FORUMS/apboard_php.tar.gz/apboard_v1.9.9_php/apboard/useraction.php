<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";

$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;Boards als gelesen markieren";

if ($action == "set_boards_visited") {
	
	if ($set_boards == "yes") {
		
		if ($all_boards == "yes") {
			
			$boards = mysql_query("SELECT boardid FROM apb".$n."_boards");
			while ($thisboard = mysql_fetch_row($boards)) {
				$board_ids[] = $thisboard[0];
			}
			
			while(list($key, $val) = each($board_ids)) {
				setcookie("last_visit[$val]", time(), time() + (60*60*24*365));
				setcookie("last_activity[$val]", time(), time() + (60*60*24*365));
			}
			
			include "_header.inc";
			
			$message = "Die ausgew&auml;hlten Boards wurden als gelesen markiert.";
			
			message_box($message);
			include "_footer.inc";
			exit;
			
			
		} else {
			
			if (sizeof($board_ids) == 0) {
				include "_header.inc";
				apb_error("Keine Boards ausgew&auml;hlt", FALSE);
			}
			
			while(list($key, $val) = each($board_ids)) {
				if ($val == "") {
					continue;
				}
				setcookie("last_visit[$val]", time(), time() + (60*60*24*365));
				setcookie("last_activity[$val]", time(), time() + (60*60*24*365));
			}
			
			include "_header.inc";
			
			$message = "Die ausgew&auml;hlten Boards wurden als gelesen markiert.";
			
			message_box($message);
			include "_footer.inc";
			exit;
			
		}
	
	
	} else {
		
		$boards = mysql_query("SELECT boardid, boardname, category FROM apb".$n."_boards ORDER BY category, boardname");
		
		
		
		include "_header.inc";
		$question = "Welche Boards sollen als gelesen markiert werden?";
		$message = "<TABLE WIDTH=\"95%\" BORDER=0>\n<TR>\n<TD>";
		$message .= "<FONT SIZE=\"2\" FACE=\"$font\">\n";
		$message .= "<FORM ACTION=\"useraction.php\" METHOD=POST>\n";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"action\" VALUE=\"set_boards_visited\">\n";
		$message .= "<INPUT TYPE=HIDDEN NAME=\"set_boards\" VALUE=\"yes\">\n";
		$message .= "<INPUT TYPE=RADIO NAME=\"all_boards\" VALUE=\"yes\"> Alle Boards<BR><BR>\n";
		$message .= "<INPUT TYPE=RADIO NAME=\"all_boards\" VALUE=\"no\"> einzelne Boards:<BR><BR>\n";
		$message .= "<DIV ALIGN=\"CENTER\">\n";
		$message .= "<SELECT NAME=\"board_ids[]\" size=\"10\" multiple>\n";
		
		while ($thisboard = mysql_fetch_array($boards)) {
			if ($thisboard[category] != $old_cat) {
				
				$cat_str = "---- $thisboard[category] -------------------------------------------------------------";
				$cat_str = substr($cat_str, 0, 55);
				$message .= "<option value=\"\"> $cat_str </option>\n";
				
			}
			
			$message .= "<option value=\"$thisboard[boardid]\">".$thisboard[boardname]."</option>\n";
			$old_cat = $thisboard[category];
		}
		
		$message .= "</SELECT>\n<BR><BR>";
		$message .= "</DIV>\n";
		$message .= "<INPUT TYPE=SUBMIT VALUE=\"gew&auml;hlte Boards als gelesen markieren\">\n";
		$message .= "</FORM>\n";
		$message .= "</FONT>\n";
		$message .= "</TD>\n</TR>\n</TABLE>";
		
		
		
		question_box($question, $message, "Boards ausw&auml;hlen");
		include "_footer.inc";
		exit;
		
	}
	
	
}


?>