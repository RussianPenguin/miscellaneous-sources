<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$boards = GetBoards();
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;Choose";
$user_category = $UserInformation[category];
setcookie ("UserInformation[category]", "", time()-31536000);
require "_header.inc";

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD colspan="3"><font face="<? echo $font; ?>" size=5><? echo $choose; ?><br>
			<font size="2"><? echo $choose_info; ?></font>
			</font>
		</TD>
	</TR>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD colspan="3"><FONT face="<? echo $font; ?>" SIZE="2">&nbsp;</font></TD>
	</TR>
	<tr bgcolor="<? echo $tableB; ?>">
		<td width="5%"><font face="<? echo $font; ?>" size="2">&nbsp;</font></td>
		<td width="90%" bgcolor="<? echo $tableA; ?>">
			<font face="<? echo $font; ?>" size="2">
			<br><div align="center">
			<? echo $choosen_category; ?><br><font size="4"><? echo $no_choosen; ?></font><br>
			[ - <a href="<? echo $php_path; ?>/choose.php"><? echo $choose_new; ?></a> | <a href="<? echo $php_path; ?>/main.php"><? echo $zurueck_zum_board; ?></a> - ]<br>
			<br></div>
			</font>
		</td>
		<td width="5%"><font face="<? echo $font; ?>" size="2">&nbsp;</font></td>
	</tr>
	<TR BGCOLOR="<? echo $tableB; ?>">
		<TD colspan="3"><FONT face="<? echo $font; ?>" SIZE="2">&nbsp;</font></TD>
	</TR>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>