<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
header("Refresh: 5; URL=$php_path/chat1.php; TARGET=chatfenster");

?>
<HTML><HEAD><TITLE>APBoard-Chat</TITLE>
<META content="text/html; charset=iso-8859-1" http-equiv=Content-Type>
<META content="MSHTML 5.00.2314.1000" name=GENERATOR>
<STYLE TYPE="TEXT/CSS">
<? echo $cfg[css]; ?>
</STYLE>
</HEAD>
<?
echo "<BODY BGCOLOR=\"$bgcol\" text=\"$fontcolor\" link=\"$links\" alink=\"$active\" vlink=\"$visited\">";
?>
<FONT FACE="<? echo $font; ?>" SIZE=1><? echo $chatinfo1; ?>
<hr>
<?
$messages = mysql_query("SELECT * FROM apb".$n."_chat ORDER BY zeit DESC");
while ($messages1 = mysql_fetch_array($messages))
{
	$id = $messages1[id];
	$zeit = $messages1[zeit];
	$name = $messages1[nickname];
	$text = $messages1[text];
	$message = $text;
	//$message = RemoveCrap($text);

	if ($name == "" || $name == " " || $name == "  ") {
		$name = "< Gast >";
	} else {
		$name = $name;
	}
	echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td><font face=\"".$font."\" size=\"2\"><b>[".HackTime($zeit)."] ".$name.":</b>&nbsp;&nbsp;".$message."</font></td></tr></table>";
}
?>
</FONT>
</BODY>
</HTML>