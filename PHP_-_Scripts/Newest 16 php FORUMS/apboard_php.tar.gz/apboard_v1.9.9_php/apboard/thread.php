<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
echo mysql_error();
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$posts = GetPosts($id,$start);
$thread_info = GetThreadInfo($id);
$thread_info = mysql_fetch_array($thread_info);
if (!$thread_info) {
	apb_error($thema_existiert_nicht,FALSE);
}
$board_info = GetBoardInfo($thread_info[boardparentid]);
$board_info = mysql_fetch_array($board_info);
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/main.php?cat=$board_info[category]\">$board_info[category]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$php_path/board.php?id=$board_info[boardid]&BoardID=$BoardID\">$board_info[boardname]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$thread_info[threadname]";


if (isset($Cookie_Board_PW[$BoardID]) && !$passwort) {
	if ($Cookie_Board_PW[$BoardID] != $board_info[boardpassword]) setcookie("Cookie_Board_PW[$BoardID]", "", time() - 60000);
}

if ($passwort && ($board_pw==$board_info[boardpassword])) {
	setcookie("Cookie_Board_PW[$BoardID]", "$board_pw", time() + $time_BoardPW_store_cookie);
}


require "_header.inc";
require "getimagesize.php";

define("USER_PIC_MAX_WIDTH", $userpicwidth) ;
define("USER_PIC_MAX_HEIGHT", $userpicheight) ;

if (!$passwort && !$Cookie_Board_PW[$BoardID]) {
	if (!$board_info[boardpassword]) {
		$pages = ceil(($thread_info[replies]+1) / $posts_per_page);
		$thispage = ceil(($start+1) / $posts_per_page);
		if ($pages > 1) {
			$pages_string = "<FONT SIZE=2>".$seiten." [ ";
			for ($l=1 ; $l <= $pages; $l++) {
				if ($l == $pages) {
					$ostr = " ";
				} else {
					$ostr = " | ";
				}
				if ($l != $thispage) {
					$pages_string .= "<A HREF=\"$php_path/thread.php?id=$id&start=";
					$pages_string .= ($l - 1) * $posts_per_page + 1;
					$pages_string .= "&BoardID=$BoardID\">$l</A>$ostr";
				} else {
					$pages_string.= "<b>-$l-</b>$ostr";
				}
			}
			$pages_string .= "]</FONT>";
		} else {
			$pages_string = "&nbsp;";
		}
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER" CLASS="normaltext">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="2">
			<p>
<?
			$topic = RemoveCrop($thread_info[threadname]);
			if (!$thread_info[topicicon]) {
				$topicicon = "<img src=\"$php_path/themes/icons/text.gif\">";
			} else {
				$topicicon = "<img src=\"$thread_info[topicicon]\">";
			}
			print_mb ( "<P><B>".$mom_thema."</B> $topicicon $topic", $font , "2");
?>
			</P><P ALIGN="RIGHT">
<?
		if ($thread_info[flags]=="1") {
			print_mb ( $thread_geschlossen , $font , "2");
		} else {
			print_mb ( "[ - <A HREF=\"$php_path/reply.php?replyto=$id&BoardID=$BoardID\">".$auf_thread_antworten."</A> - ]" , $font , "2");
		}
?>
			</p>
		</TD>
	</TR>
</table>
<?

		$udat = mysql_query("SELECT username, status FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]'");
		$userdat = mysql_fetch_array($udat);
		$mod = explode (", ", $board_info[boardmods]);
		if ($userdat[status]=="MOD" AND apb_in_array($userdat[username], $mod)) {
			$modlog=TRUE;
		} else {
			$modlog=FALSE;
		}
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\" CLASS=\"normaltext\"><TR BGCOLOR=\"$tableC\"><TD ALIGN=\"CENTER\" COLSPAN=\"2\">";
		print_mb ($pages_string,$font,"1");
		echo "</TD></TR></table>";
		
		while ($thismessage = mysql_fetch_array($posts)) {
			$user_info = GetUserInfo($thismessage[authorname]);
			$user_info = mysql_fetch_array($user_info);
			if ($thiscolor == $tableA) { $thiscolor = $tableB; } else { $thiscolor = $tableA; }
			echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\" CLASS=\"normaltext\"><TR BGCOLOR=\"$thiscolor\"><TD WIDTH=\"20%\" VALIGN=\"top\">";
			print_mb ( HackDate($thismessage[posttime]) . "<BR><BR>" , $font , "1");
			if ($icq_thread=="1") {
				if ($user_info[usericq]=="" || $user_info[usericq]==" " || $user_info[usericq]=="[N/A]") {
					echo "";
				} else {
					echo "<a href=\"http://wwp.icq.com/scripts/search.dll?to=".$user_info[usericq]."\" target=\"_blank\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=".$user_info[usericq]."&img=5\" width=\"15\" height=\"15\" border=\"0\" alt=\"".$contact_hinzufuegen."\"></a>&nbsp;";
				}
			} else {
				echo "";
			}
			print_mb ( "<A HREF=\"$php_path/user.php?username=yes&id=$thismessage[authorname]&BoardID=$BoardID\">$thismessage[authorname]</A><BR>" , $font , "2");
			echo "<FONT COLOR=\"$fontcolorsec\">";
			print_mb ( "Posts: ".$user_info[userposts] , $font , "1");

			if ($user_info[status]=="NORMAL") {
				print_mb ( "<br>$rank".GetRank($user_info[userposts]), $font , "1");
			} else {
				if ($user_info[status]=="ADMIN") {
					$status="[Administrator]";
				} else {
					$status="[Moderator]";
				}
				print_mb ( "<br>".$status , $font , "1");
			}

			if (!$user_info[statusextra]) {
				echo " ";
			} else {
				print_mb ( "<br><b>$extra".$user_info[statusextra]."</b>" , $font , "1");
			}


			/*   ACHTUNG FEHLER: Was sollte hier urspr&uuml;nglich rein??
					( $thismessage[5] gibt es nicht!!! )
			
			if ($thismessage[5]) {
				print_mb ( "<BR>" . $thismessage[5], $font , "1");
			}
			
			*/
			
			echo "</FONT>";
			if ($pic_thread=="1") {
				if ($user_info[userpic]=="" || $user_info[userpic]==" " || $user_info[userpic]=="[N/A]") {
					echo "<br>";
				} else {
					$image = GetURLImageSize($user_info[userpic]);
					if ($image[0] > USER_PIC_MAX_WIDTH) {
						$width=$image[0];
						$image[0] = USER_PIC_MAX_WIDTH;
						$image[1] = floor(($image[0]*$image[1])/$width);
					}
					if ($image[1] > USER_PIC_MAX_HEIGHT) {
						$old=$image[1];
						$image[1] = USER_PIC_MAX_HEIGHT;
						$image[0] = floor($image[0]*$image[1]/$old);
					}
					print "<br>";
					if ($user_info[userhp] == "" || $user_info[userhp] == " " || $user_info[userhp] == "[N/A]") {
						$upic = "0";
					} else {
						$upic = "1";
					}
					if ($upic == "1") {
						print "<a href=\"".$user_info[userhp]."\" target=_blank>";
					}
					print "<IMG HEIGHT=\"$image[1]\" WIDTH=\"$image[0]\" SRC=\"".$user_info[userpic]."\" BORDER=0>";
					if ($upic == "1") {
						print "</a>";
					}
					print "<br>\n";
//
				}
			} else {
				// echo "";
			}
			echo "</TD><TD WIDTH=\"80%\" VALIGN=\"top\"><br>";
			$message = RemoveCrap($thismessage[message], $thismessage[disable_smilies]);
			print_mb ( $message . "<BR>", $font, "2" );
			if ($adminlog || $modlog) {
				echo "<P align=right><FONT FACE=$font SIZE=1>[ <a href=$php_path/reply.php?replyto=$id&BoardID=$BoardID&quote=$thismessage[postid]>$quote_answer</a> - <a href=$php_path/edit.php?action=editpost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]&BoardID=$BoardID>edit</a> - <a href=\"$php_path/mod_delete_post.php?action=get_ip&postid=$thismessage[postid]\">IP</a> - <a href=$php_path/mod_delete_post.php?action=deletepost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]>delete</a> ]</font></p></TD></TR></table>";
			} else {
				echo "<div align=right><FONT FACE=$font SIZE=1>[ <a href=$php_path/reply.php?replyto=$id&BoardID=$BoardID&quote=$thismessage[postid]>$quote_answer</a> - <a href=$php_path/edit.php?action=editpost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]&BoardID=$BoardID>edit</a> ]</font></div></TD></TR></table>";
			}
		}
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\" CLASS=\"normaltext\"><TR BGCOLOR=\"$tableC\"><TD ALIGN=\"CENTER\" COLSPAN=\"2\">";
		print_mb ($pages_string,$font,"1");
		echo "</TD></TR></table>";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER" CLASS="normaltext">
	<TR BGCOLOR="<? echo $tableC; ?>"HEIGHT="64">
		<TD COLSPAN="2">
			<DIV ALIGN="CENTER">
<?
		echo "<FONT FACE=\"$font\" SIZE=2><b>";
		echo "[ - <A HREF=\"$php_path/board.php?id=$thread_info[boardparentid]&BoardID=$BoardID\">".$zurueck."</A> ";
		if ($thread_info[flags]=="1") {
			echo "- <FONT FACE=$font SIZE=2 COLOR=red>$topic_closed</font> ";
		} else {
			echo "- <A HREF=\"$php_path/reply.php?replyto=$id&BoardID=$BoardID\">".$auf_thread_antworten."</A> ";
		}
		if ($adminlog || $modlog) {
			if ($thread_info[flags]=="1") {
				echo "- <A HREF=\"$php_path/mod_delete_post.php?action=open_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$open_thread."</A> ";
			} else {
				echo "- <A HREF=\"$php_path/mod_delete_post.php?action=close_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$close_thread."</A> ";
			}
			echo "- <A HREF=\"$php_path/mod_delete_post.php?action=delete_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$delete_thread."</A> ";
			echo "- <A HREF=\"$php_path/mod_delete_post.php?action=move_thread&id=$id&bparentid=$thread_info[0]\">".$move_thread."</A> - ]";
			
		} else {
			echo "- ]";
		}
		echo "</b></FONT>";


?>
			</DIV>
		</TD>
	</TR>
</TABLE>
<?
	} else {
		echo "<TABLE BGCOLOR=\"$tablebg\" ALIGN=\"CENTER\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\">
	<FORM ACTION=\"$php_path/thread.php\" method=post>
		<TR BGCOLOR=\"$tableC\">
			<TD COLSPAN=\"2\"><FONT FACE=\"$font\" SIZE=5><B>$board_passw</B></FONT><BR>
				<FONT FACE=\"$font\" SIZE=2>$board_needs_pw</FONT>
			</TD>
		</TR>
		<TR BGCOLOR=\"$tableA\">
			<TD WIDTH=\"50%\"><FONT FACE=\"$font\" SIZE=2><B>$board_passw</B></FONT><BR>
				<FONT FACE=\"$font\" SIZE=1>$type_pw</FONT>
			</TD>
			<TD WIDTH=\"50%\">
				<INPUT CLASS=\"button\" TYPE=\"password\" NAME=\"board_pw\" MAXLENGTH=\"30\" SIZE=\"25\">
			</TD>
		</TR>
		<TR BGCOLOR=\"$tableB\">
			<TD COLSPAN=\"2\">
				<INPUT TYPE=\"hidden\" NAME=\"passwort\" VALUE=\"1\">
				<INPUT TYPE=\"hidden\" NAME=\"id\" VALUE=\"$id\">
				<CENTER><INPUT CLASS=\"button\" TYPE=\"submit\" NAME=\"Submit\" VALUE=\"Login\"></CENTER>
			</TD>
		</TR>
	</FORM>
</TABLE>";

	}

// Passwort gesetzt!
} else {
	if ($board_pw==$board_info[boardpassword] || $Cookie_Board_PW[$BoardID]==$board_info[boardpassword]) {
		if (!isset($board_pw)) {
			$board_pw = $Cookie_Board_PW[$BoardID];
		}
		$pages = ceil(($thread_info[replies]+1) / $posts_per_page);
		$thispage = ceil(($start+1) / $posts_per_page);
		if ($pages > 1) {
			$pages_string = "<FONT SIZE=2>".$seiten." [ ";
			for ($l=1 ; $l <= $pages; $l++) {
				if ($l == $pages) {
					$ostr = " ";
				} else {
					$ostr = " | ";
				}
				if ($l != $thispage) {
					$pages_string .= "<A HREF=\"$php_path/thread.php?id=$id&start=";
					$pages_string .= ($l - 1) * $posts_per_page + 1;
					$pages_string .= "&BoardID=$BoardID&passwort=1&board_pw=$board_pw\">$l</A>$ostr";
				} else {
					$pages_string.= "<b>-$l-</b>$ostr";
				}
			}
			$pages_string .= "]</FONT>";
		} else {
			$pages_string = "&nbsp;";
		}
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER" CLASS="normaltext">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD COLSPAN="2">
			<p>
<?
			$topic = RemoveCrop($thread_info[threadname]);
			if (!$thread_info[topicicon]) {
				$topicicon = "<img src=\"$php_path/themes/icons/text.gif\">";
			} else {
				$topicicon = "<img src=\"$thread_info[topicicon]\">";
			}
			print_mb ( "<P><B>".$mom_thema."</B> $topicicon $topic", $font , "2");
?>
			</P><P ALIGN="RIGHT">
<?
		if ($thread_info[flags]=="1") {
			print_mb ( $thread_geschlossen , $font , "2");
		} else {
			print_mb ( "[ - <A HREF=\"$php_path/reply.php?replyto=$id&BoardID=$BoardID\">".$auf_thread_antworten."</A> - ]" , $font , "2");
		}
?>
			</p>
		</TD>
	</TR>
</TABLE>
<?
		$udat = mysql_query("SELECT username, status FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]'");
		$userdat = mysql_fetch_array($udat);
		$mod = explode (", ", $board_info[boardmods]);
		if ($userdat[status]=="MOD" AND apb_in_array($userdat[username], $mod)) {
			$modlog=TRUE;
		} else {
			$modlog=FALSE;
		}
		echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\" CLASS=\"normaltext\"><TR BGCOLOR=\"$tableC\"><TD ALIGN=\"CENTER\" COLSPAN=\"2\">";
		print_mb ($pages_string,$font,"1");
		echo "</TD></TR></table>";
		while ($thismessage = mysql_fetch_array($posts)) {
			$user_info = GetUserInfo($thismessage[authorname]);
			$user_info = mysql_fetch_array($user_info);
			if ($thiscolor == $tableA) { $thiscolor = $tableB; } else { $thiscolor = $tableA; }
			echo "<TABLE BGCOLOR=\"$tablebg\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"4\" ALIGN=\"CENTER\" CLASS=\"normaltext\"><TR BGCOLOR=\"$thiscolor\"><TD WIDTH=\"20%\" VALIGN=\"top\">";
			print_mb ( HackDate($thismessage[posttime]) . "<BR><BR>" , $font , "1");
			if ($icq_thread=="1") {
				if ($user_info[usericq]=="" || $user_info[usericq]==" " || $user_info[usericq]=="[N/A]") {
					echo "";
				} else {
					echo "<a href=\"http://wwp.icq.com/scripts/search.dll?to=".$user_info[usericq]."\" target=\"_blank\"><img src=\"http://wwp.icq.com/scripts/online.dll?icq=".$user_info[usericq]."&img=5\" width=\"15\" height=\"15\" border=\"0\" alt=\"".$contact_hinzufuegen."\"></a>&nbsp;";
				}
			} else {
				//echo "";
			}
			print_mb ( "<A HREF=\"$php_path/user.php?username=yes&id=$thismessage[authorname]&BoardID=$BoardID\">$thismessage[authorname]</A><BR>" , $font , "2");
			echo "<FONT COLOR=\"$fontcolorsec\">";
			print_mb ( "Posts: ".$user_info[userposts] , $font , "1");

			if ($user_info[status]=="NORMAL") {
				print_mb ( "<br>$rank".GetRank($user_info[userposts]) , $font , "1");
			} else {
				if ($user_info[status]=="ADMIN") {
					$status="[Administrator]";
				} else {
					$status="[Moderator]";
				}
				print_mb ( "<br>".$status , $font , "1");
			}

			if (!$user_info[statusextra]) {
				echo " ";
			} else {
				print_mb ( "<br><b>$extra".$user_info[statusextra]."</b>" , $font , "1");
			}

			/*   ACHTUNG FEHLER: Was sollte hier urspr&uuml;nglich rein??
					( $thismessage[5] gibt es nicht!!! )
					
					
			if ($thismessage[5]) {
				print_mb ( "<BR>" . $thismessage[5], $font , "1");
			}
			
			*/
			
			echo "</FONT>";
			if ($pic_thread=="1") {
				if ($user_info[userpic]=="" || $user_info[userpic]==" " || $user_info[userpic]=="[N/A]") {
					echo "<br>";
				} else {
					$image = GetURLImageSize($user_info[userpic]);
					if ($image[0] > USER_PIC_MAX_WIDTH) {
						$width=$image[0];
						$image[0] = USER_PIC_MAX_WIDTH;
						$image[1] = floor(($image[0]*$image[1])/$width);
					}
					if ($image[1] > USER_PIC_MAX_HEIGHT) {
						$old=$image[1];
						$image[1] = USER_PIC_MAX_HEIGHT;
						$image[0] = floor($image[0]*$image[1]/$old);
					}
					print "<br>";
					if ($user_info[userhp] == "" || $user_info[userhp] == " " || $user_info[userhp] == "[N/A]") {
						$upic = "0";
					} else {
						$upic = "1";
					}
					if ($upic == "1") {
						print "<a href=\"".$user_info[userhp]."\" target=_blank>";
					}
					print "<IMG HEIGHT=\"$image[1]\" WIDTH=\"$image[0]\" SRC=\"".$user_info[userpic]."\" BORDER=0>";
					if ($upic == "1") {
						print "</a>";
					}
					print "<br>\n";
//
				}
			} else {
				echo "";
			}
			echo "</TD><TD WIDTH=\"80%\" VALIGN=\"top\"><br>";
			$message = RemoveCrap($thismessage[message], $thismessage[disable_smilies]);
			print_mb ( $message . "<BR>", $font, "2" );
			if ($adminlog || $modlog) {
				echo "<P align=right><FONT FACE=$font SIZE=1>[ <a href=$php_path/reply.php?replyto=$id&BoardID=$BoardID&quote=$thismessage[postid]>$quote_answer</a> - <a href=$php_path/edit.php?action=editpost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]&BoardID=$BoardID>edit</a> - <a href=\"$php_path/mod_delete_post.php?action=get_ip&postid=$thismessage[postid]\">IP</a> - <a href=$php_path/mod_delete_post.php?action=deletepost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]>delete</a> ]</font></p></TD></TR>";
			} else {
				echo "<div align=right><FONT FACE=$font SIZE=1>[ <a href=$php_path/reply.php?replyto=$id&BoardID=$BoardID&quote=$thismessage[postid]>$quote_answer</a> - <a href=$php_path/edit.php?action=editpost&postid=$thismessage[postid]&tparentid=$id&bparentid=$thread_info[boardparentid]&BoardID=$BoardID>edit</a> ]</font></div></TD></TR>";
			}
		}
		echo "<TR BGCOLOR=\"$tableC\"><TD ALIGN=\"CENTER\" COLSPAN=\"2\">";
		print_mb ($pages_string,$font,"1");
		echo "</TD></TR></table>";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="4" ALIGN="CENTER" CLASS="normaltext">
	<TR BGCOLOR="<? echo $tableC; ?>"HEIGHT="64">
		<TD COLSPAN="2">
			<DIV ALIGN="CENTER">
<?
		echo "<FONT FACE=\"$font\" SIZE=2><b>";
		echo "[ - <A HREF=\"$php_path/board.php?id=$thread_info[boardparentid]&BoardID=$BoardID\">".$zurueck."</A> ";
		if ($thread_info[flags]=="1") {
			echo "- <FONT FACE=$font SIZE=2 COLOR=red>$topic_closed</font> ";
		} else {
			echo "- <A HREF=\"$php_path/reply.php?replyto=$id&BoardID=$BoardID\">".$auf_thread_antworten."</A> ";
		}
		if ($adminlog || $modlog) {
			if ($thread_info[flags]=="1") {
				echo "- <A HREF=\"$php_path/mod_delete_post.php?action=open_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$open_thread."</A> ";
			} else {
				echo "- <A HREF=\"$php_path/mod_delete_post.php?action=close_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$close_thread."</A> ";
			}
			echo "- <A HREF=\"$php_path/mod_delete_post.php?action=delete_thread&id=$id&bparentid=$thread_info[boardparentid]\">".$delete_thread."</A> ";
			echo "- <A HREF=\"$php_path/mod_delete_post.php?action=move_thread&id=$id&bparentid=$thread_info[0]\">".$move_thread."</A> - ]";
		
		} else {
			echo "- ]";
		}
		echo "</b></FONT>";


?>
			</DIV>
		</TD>
	</TR>
</TABLE>
<?
	} else {
		apb_error($pw_not_correct, $font, 1);
	}

}
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>