<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
require "_iconmap.inc";
require "_ubbcodescript.inc";

$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$board_info = GetBoardInfo($insertinto);
$board_info = mysql_fetch_array($board_info);
echo mysql_error();
if (!$board_info) {
	apb_error($board_existiert_nicht,FALSE);
}
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/main.php?cat=$board_info[category]\">$board_info[category]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;<A HREF=\"$php_path/board.php?id=$board_info[boardid]&BoardID=$BoardID\">$board_info[boardname]</A><BR>";
$hstring .= "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$neues_thema<BR>";
require "_header.inc";
if (!$logged) {
	apb_error($nur_reg_benutzer1."<A HREF=\"$php_path/register.php?BoardID=$BoardID\">".$nur_reg_benutzer2."</A>".$nur_reg_benutzer3."<A HREF=\"$php_path/login.php?BoardID=$BoardID\">".$nur_reg_benutzer2."</A>".$nur_reg_benutzer4,FALSE);
}
if ($postit) {
	if (!$insertinto) {
		apb_error($kein_board_angegeben,FALSE);
	}
	if (!$message || !$topic) {
		apb_error($alle_felder_ausfuellen,FALSE);
	}

	$tnumber = mysql_query("SELECT threadid FROM apb".$n."_threads ORDER BY threadid DESC");
	$tid = mysql_fetch_array($tnumber);
	$oldid = $tid["threadid"];

	$newid = $oldid + 1;

	$last_reply = time();
	$username = mysql_query("SELECT username,statusextra,userposts,signatur,useremail FROM apb".$n."_user_table WHERE userid='$UID';");
	$username = mysql_fetch_array($username);
	$author = $username[username];
	$extra = $username[statusextra];
	$rank = GetRank($username[userposts]);
	$signatur = $username[signatur];
	$useremail= $username[useremail];
	UserAuth($UID,$UPASS,TRUE);

	$lastuserpost = mysql_query ("SELECT * FROM apb".$n."_posts WHERE authorname = '$author' ORDER BY posttime DESC LIMIT 0,1");
	$lastuserpost = mysql_fetch_array($lastuserpost);
	$lastuserpost = $lastuserpost["posttime"];

	if ($min_post_inverval > 0 && ($lastuserpost > (time() - $min_post_inverval))) {
		apb_error($post_intervall_zu_klein, FALSE);
	}

	if (!isset($topicicon)) {
		$topicicon = $topicicon_array[$default_topic_icon];
	} else {		
		$topicicon = $topicicon_array[$topicicon];
	}
	
	if ($signature=="1" && strlen($signatur) > 2) {
		$message = $message.$signatur_trennstrich.$signatur;
	} else {
		//$message = $message;
	}
	
	if ($do_disable_smilies != "1") {
		$do_disable_smilies = "0";
	}
	
	$message = apb_wordwrap($message);
	$message = RemovePostCrap($message);
	$topic = RemovePostCrap($topic);
	if ($email=="1") {
		if (!$useremail) {
			mysql_query("INSERT INTO apb".$n."_threads VALUES( '$insertinto', '$newid', '$topic', '$author', '0', $last_reply, '', '', '$topicicon', '');");
			echo mysql_error();
			mysql_query("INSERT INTO apb".$n."_posts VALUES( '$newid', '', '$author', '$rank', '$last_reply', '$message', '', '$do_disable_smilies', '$REMOTE_ADDR');");
			echo mysql_error();
			mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,totalthreads=totalthreads+1,lastmodified='$last_reply' WHERE boardid='$insertinto'");
			echo mysql_error();
			mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
			echo mysql_error();
			echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
			echo "<TR BGCOLOR=\"$tableA\"><TD>";
			print_mb ( $keine_email_in_profil, $font, "2" );
			echo "</TD></TR>";
			echo "<TR BGCOLOR=\"$tableC\"><TD>";
			print_mb ($thema_eingefuegt, $font, "2" );
			echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
			print_mb ( RemoveCrap($message, $do_disable_smilies), $font, "2" );
			echo "<BR><BR></TD></TR>";
			echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
			print_mb ("<CENTER>[ <A HREF=\"$php_path/board.php?id=$insertinto&BoardID=$BoardID\">".$zurueck_zum_board."</A> | ".$beitrag_editieren." ]</CENTER>",$font,"2");
			echo "</CENTER></TD></TR></TABLE>";
			if ($adminmail == "1" && !$adminlog) {
				mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$topic_number."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			}
			include "_footer.inc";
			exit;
		} else {
			mysql_query("INSERT INTO apb".$n."_threads VALUES( '$insertinto', '$newid', '$topic', '$author', '0', $last_reply, '', '$useremail', '$topicicon', '');");
			echo mysql_error();
			mysql_query("INSERT INTO apb".$n."_posts VALUES( '$newid', '', '$author', '$rank', '$last_reply', '$message', '', '$do_disable_smilies', '$REMOTE_ADDR');");
			echo mysql_error();
			mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,totalthreads=totalthreads+1,lastmodified='$last_reply' WHERE boardid='$insertinto'");
			echo mysql_error();
			mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
			echo mysql_error();
			mail($useremail, $topic_betreff_email, $topic_message_email1.$master_board_name.$topic_message_email2.$php_path."/thread.php?id=".$topic_number."&BoardID=".$BoardID."\n".$topic_message_email3, "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
			echo "<TR BGCOLOR=\"$tableA\"><TD>";
			print_mb ( $email_hinzugefuegt, $font, "2" );
			echo "</TD></TR>";
			echo "<TR BGCOLOR=\"$tableC\"><TD>";
			print_mb ($thema_eingefuegt, $font, "2" );
			echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
			print_mb ( RemoveCrap($message, $do_disable_smilies), $font, "2" );
			echo "<BR><BR></TD></TR>";
			echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
			print_mb ("<CENTER>[ <A HREF=\"$php_path/board.php?id=$insertinto&BoardID=$BoardID\">".$zurueck_zum_board."</A> | ".$beitrag_editieren." ]</CENTER>",$font,"2");
			echo "</CENTER></TD></TR></TABLE>";
			if ($adminmail == "1" && !$adminlog) {
				mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$topic_number."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
			}
			include "_footer.inc";
			exit;
		}
	} else {
		mysql_query("INSERT INTO apb".$n."_threads VALUES( '$insertinto', '$newid', '$topic', '$author', '0', $last_reply, '', '', '$topicicon', '');");
		echo mysql_error();
		mysql_query("INSERT INTO apb".$n."_posts VALUES( '$newid', '', '$author', '$rank', '$last_reply', '$message', '', '$do_disable_smilies', '$REMOTE_ADDR');");
		echo mysql_error();
		mysql_query("UPDATE apb".$n."_boards SET totalposts=totalposts+1,totalthreads=totalthreads+1,lastmodified='$last_reply' WHERE boardid='$insertinto'");
		echo mysql_error();
		mysql_query("UPDATE apb".$n."_user_table SET userposts=userposts+1 WHERE userid='$UID'");
		echo mysql_error();
		echo "<TABLE BGCOLOR=\"$tablebg\" BORDER=0 CELLSPACING=1 CELLPADDING=6 ALIGN=CENTER>";
		echo "<TR BGCOLOR=\"$tableC\"><TD>";
		print_mb ($thema_eingefuegt, $font, "2" );
		echo "</TD></TR><TR BGCOLOR=\"$tableA\"><TD><BR>";
		print_mb ( RemoveCrap($message, $do_disable_smilies), $font, "2" );
		echo "<BR><BR></TD></TR>";
		echo "<TR BGCOLOR=\"$tableB\"><TD><CENTER>";
		print_mb ("<CENTER>[ <A HREF=\"$php_path/board.php?id=$insertinto&BoardID=$BoardID\">".$zurueck_zum_board."</A> | ".$beitrag_editieren." ]</CENTER>",$font,"2");
		echo "</CENTER></TD></TR></TABLE>";
		if ($adminmail == "1" && !$adminlog) {
			mail($adminemail, $betreff_email, $message_email1.$master_board_name.$message_email2.$php_path."/thread.php?id=".$topic_number."&BoardID=".$BoardID."\n", "From: ".$adminemail."\nReply-To: ".$adminemail."\nX-Mailer: PHP/" . phpversion());
		}
		include "_footer.inc";
		exit;
	}
}

add_ubbcodescript("message");

?>

<FORM NAME="MESSAGEFORM" ACTION="<? echo "$php_path/topic.php"; ?>" METHOD="POST">
	<TABLE BGCOLOR="<? echo $tablebg; ?>" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
		<TR>
			<TD BGCOLOR="<? echo $tableC; ?>" COLSPAN="2">
				<CENTER>
<?
				print_mb ($neues_thema."<BR>",$font,"4");
				print_mb ($im_forum_topic.$board_info[boardname],$font,"2");
?>
				</CENTER>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableA; ?>">
				<? print_mb ( $thema_topic,$font,"2"); ?>
			</TD>
			<TD BGCOLOR="<? echo $tableA; ?>">
				<CENTER>
					<INPUT TYPE="text" CLASS="button" NAME="topic" MAXLENGTH="70" SIZE="30">
				</CENTER>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableB; ?>">
				<? print_mb ( $topic_icon_desc,$font,"2"); ?>
			</TD>
			<TD BGCOLOR="<? echo $tableB; ?>">
				<div align="center">
<?
					while (list($key, $val) = each($topicicon_array)) {
						echo "<input type=\"radio\" name=\"topicicon\" value=\"$key\"";
						if ($default_topic_icon == $key) echo " checked";
						echo ">&nbsp;<IMG SRC=\"$php_path/$val\">&nbsp;&nbsp;\n";
						if ((($key + 1) % $newline_after_x_smilies) == 0 ) echo "<BR>\n";
					}
?>
				</div>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD COLSPAN="2">
				<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="100%" BORDER="0" CELLSPACING="0" CELLPADDING="6">
					<TR BGCOLOR="<? echo $tableA; ?>">
						<TD NOWRAP>
							<? print_mb ($formatierung_hinweis, $font, "1"); ?><BR><BR><BR>
							<? print_mb ("<b>Klick'n'paste</b>", $font, "1"); ?><BR>
							<? print_mb ($iconauswahl, $font, "1"); ?><BR>
							<? add_iconmap("message"); ?>
						</TD>
						<TD WIDTH="100%">
							<a name="textfeld">
							<TEXTAREA NAME="message" WRAP="VIRTUAL" COLS="70" ROWS="20"></TEXTAREA>
							</a>
						</TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
				<div align="center">
					<? include "_ubbcode.inc"; ?>
				</div>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
				<div align="center">
					<input type="checkbox" name="signature" value="1" checked>&nbsp;&nbsp;<? print_mb ($sig_anhaengen, $font, "2"); ?>
				</div>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableB; ?>" COLSPAN="2">
				<div align="center">
					<input type="checkbox" name="do_disable_smilies" value="1">&nbsp;&nbsp;<? print_mb ($post_disable_smilies, $font, "2"); ?>
				</div>
			</TD>
		</TR>
		<TR>
			<TD BGCOLOR="<? echo $tableA; ?>" COLSPAN="2">
				<div align="center"><input type="checkbox" name="email" value="1">&nbsp;&nbsp;<? print_mb ($email_not, $font, "2"); ?></div>
			</TD>
		</TR>
		<TR ALIGN="CENTER">
			<TD BGCOLOR="<? echo $tableC; ?>" COLSPAN="2">
				<INPUT TYPE="hidden" NAME="postit" VALUE="TRUE">
				<INPUT TYPE="hidden" NAME="insertinto" VALUE="<? echo $insertinto; ?>">
				<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
				<INPUT CLASS="button" TYPE="submit" NAME="new_topic" VALUE="<? echo $thread_posten; ?>">
			</TD>
		</TR>
	</TABLE>
</FORM>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>