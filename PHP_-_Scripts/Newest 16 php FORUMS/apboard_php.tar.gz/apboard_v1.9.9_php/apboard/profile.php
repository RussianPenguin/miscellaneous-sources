<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$dein_profil";
require "getimagesize.php";

if ($update) {
	if (!$password || !$password2 || !$email) {
		include "_header.inc";
		apb_error($pflichtfeld,FALSE);
	}
	if (strcmp($password,$password2)) {
		include "_header.inc";
		apb_error($passwort_unterschiedlich,FALSE);
	}
	if (!CheckChars($password)) {
		include "_header.inc";
		echo $password;
		apb_error($pw_unzulaessige_zeichen,FALSE);
	}
	if (strlen($password)<5) {
		include "_header.inc";
		apb_error($mind_5_zeichen,FALSE);
	}
	if (strlen($password)>25) {
		include "_header.inc";
		apb_error($max_25_zeichen,FALSE);
	}
	if (strlen($email)>70) {
		include "_header.inc";
		apb_error($email_zu_lang,FALSE);
	}
	if (strlen($signatur)>250) {
		include "_header.inc";
		apb_error($sig_zu_lang,FALSE);
	}
	if (apb_substr_count($signatur,"[img]") > $max_grafics_in_sig) {
		include "_header.inc";
		apb_error($zuviele_bilder_in_sig.$max_grafics_in_sig,FALSE);
	}
	if (strlen($userpic) > 0) {
		$image = GetURLImageSize($userpic);
		if (!$image[0]) {
			include "_header.inc";
			apb_error("Das angegebene User-Bild wurde nicht gefunden, oder es hat ein nicht bekanntes Format!", FALSE);
		}
		if ($image[0] > $userpicwidth || $image[1] > $userpicheight) {
			include "_header.inc";
			apb_error("Das angegebene User-Bild ist zu gro�!", FALSE);
		}
	}
	
	
	
	
	$old_password = mysql_query("SELECT userpassword FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
	echo mysql_error();
	$old_password = mysql_fetch_array($old_password);
	$old_password = $old_password[userpassword];
	if ($password != $old_password) {
		setcookie ("UserInformation[uid]", "$UserInformation[uid]", time()+31536000);
		setcookie ("UserInformation[upass]", "$password", time()+31536000);
	}
	
	include "_header.inc";
	
	if (strlen($userhp) != 0) {
		if (!(eregi("^(http|https|ftp):\/\/", $userhp))) {
			$userhp = "http://".$userhp;
		}
	}
	
	$signatur=RemovePostCrap($signatur);
	$infotext=RemovePostCrap($infotext);
	$interests=RemovePostCrap($interests);
	
	$update_query = mysql_query ( "UPDATE apb".$n."_user_table SET useremail='$email',userpassword='$password',signatur='$signatur',infotext='$infotext',usericq='$usericq',userhp='$userhp',userage='$userage',userpic='$userpic',interests='$interests',show_email_global='$show_email',users_may_email='$users_may_email',mods_may_email='$mods_may_email' WHERE userid='$UserInformation[uid]';");
	echo mysql_error();
	message_box($aenderung_uebernommen);
	include "_footer.inc";
	exit;

}

require "_header.inc";

$user_query = mysql_query("SELECT * FROM apb".$n."_user_table WHERE userid='$UserInformation[uid]';");
$user_profile = mysql_fetch_array($user_query);

?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<FORM ACTION="<? echo "$php_path/profile.php"; ?>" METHOD="POST">
		<TR BGCOLOR="<? echo $tableC; ?>">
			<TD COLSPAN="2">
<?
				print_mb ($profil_bearbeiten,$font,"6");
				print_mb ($profil_bearbeiten_info,$font,"2");
?>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<? print_mb ($benutzername_profil, $font, "2");
					print_mb ($benutzername_profil_info, $font, "1"); ?>
			</TD>
			<TD>
				<? print_mb ("$echo $user_profile[username]" , $font , "2" ); ?>
				<? //		  <INPUT CLASS="button" TYPE="text" NAME="username" VALUE=$user_profile[username];  MAXLENGTH="30">
				?>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%" VALIGN="TOP">
<?
			print_mb ($passwort_profil, $font, "2");
			print_mb ($passwort_profil_info, $font, "1");
?>
			</TD>
			<TD>
				<INPUT CLASS="button" TYPE="PASSWORD" NAME="password" VALUE="<? echo $user_profile[userpassword]; ?>" MAXLENGTH="26">
				<BR>
				<INPUT CLASS="button" TYPE="PASSWORD" NAME="password2" VALUE="<? echo $user_profile[userpassword]; ?>" MAXLENGTH="26">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($alter_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="userage" VALUE="<? echo $user_profile[userage]; ?>" MAXLENGTH="2" size="3">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($icq_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="usericq" VALUE="<? echo $user_profile[usericq]; ?>" MAXLENGTH="10" size="10">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($email_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="email" VALUE="<? echo $user_profile[useremail]; ?>" MAXLENGTH="70" size="50">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($homepage_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="userhp" VALUE="<? echo $user_profile[userhp]; ?>" MAXLENGTH="100" size="50">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($userpicture_profil,$font,"2" ) ; ?><BR>
				<? print_mb("max. Bildbreite: $userpicwidth<BR>",$font,"1" ) ; ?>
				<? print_mb("max. Bildh&ouml;he: $userpicheight",$font,"1" ) ; ?>
			</TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="userpic" VALUE="<? echo $user_profile[userpic]; ?>" MAXLENGTH="100" size="50">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%"><? print_mb($interessen_profil,$font,"2"); ?></TD>
			<TD>
				<INPUT CLASS="button" TYPE="text" NAME="interests" VALUE="<? echo $user_profile[interests]; ?>" MAXLENGTH="100" size="50">
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ($infotext_profil, $font, "2");
					print_mb ($infotext_profil_info, $font, "1"); ?>
			</TD>
			<TD>
				<TEXTAREA NAME="infotext" cols="35" rows="8"><? echo $user_profile[infotext]; ?></TEXTAREA>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ( $signatur_profil, $font, "2");
					print_mb ( $signatur_profil_info,$font, "1"); ?>
			</TD>
			<TD>
				<TEXTAREA NAME="signatur" cols="35" rows="8"><? echo $user_profile[signatur]; ?></TEXTAREA>
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ( $show_email_profil, $font, "2");
					print_mb ( $show_email_profil_info,$font, "1"); ?>
			</TD>
			<TD>
				<INPUT NAME="show_email" TYPE=CHECKBOX VALUE="1"<?
					echo (($user_profile[show_email_global]) ? " checked>" : ">");
					print_mb ( " ".$show_email_profil2, $font, "2");
				?> 
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ( $users_may_email_profil, $font, "2");
					print_mb ( $users_may_email_profil_info,$font, "1"); ?>
			</TD>
			<TD>
				<INPUT NAME="users_may_email" TYPE=CHECKBOX VALUE="1"<?
					echo (($user_profile[users_may_email]) ? " checked>" : ">");
					print_mb ( " ".$users_may_email_profil2, $font, "2");
				?> 
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD WIDTH="50%">
				<?	print_mb ( $mods_may_email_profil, $font, "2");
					print_mb ( $mods_may_email_profil_info,$font, "1"); ?>
			</TD>
			<TD>
				<INPUT NAME="mods_may_email" TYPE=CHECKBOX VALUE="1"<?
					echo (($user_profile[mods_may_email]) ? " checked>" : ">");
					print_mb ( " ".$mods_may_email_profil2, $font, "2");
				?> 
			</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableA; ?>">
			<TD COLSPAN="2">&nbsp;</TD>
		</TR>
		<TR BGCOLOR="<? echo $tableB; ?>">
			<TD COLSPAN="2">
				<CENTER>
					<INPUT TYPE="hidden" NAME="update" VALUE="TRUE">
					<INPUT TYPE="hidden" NAME="BoardID" VALUE="<? echo $BoardID; ?>">
					<INPUT CLASS="button" TYPE="reset" NAME="reset" VALUE="<? echo $felder_loeschen; ?>">
					<INPUT CLASS="button" TYPE="submit" NAME="Submit" VALUE="<? echo $profil_updaten; ?>">
				</CENTER>
			</TD>
		</TR>
	</FORM>
</TABLE>
<?
$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>