<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
$board_closed = 0;
require "__config.inc";
$board_style = GetStyle($BoardID);
while($boardstyle = mysql_fetch_array($board_style)) {
	$boardgfx = $boardstyle[boardgfx];
	$font = $boardstyle[font];
	$fontcolor = $boardstyle[fontcolor];
	$fontcolorsec = $boardstyle[fontcolorsec];
	$bgcol = $boardstyle[bgcolor];
	$tablebg = $boardstyle[tablebg];
	$tableA = $boardstyle[tablea];
	$tableB = $boardstyle[tableb];
	$tableC = $boardstyle[tablec];
	$imageurl = $boardstyle[imageurl];
	$links = $boardstyle[linkcolor];
	$visited = $boardstyle[visited];
	$active = $boardstyle[active];
	$hover = $boardstyle[hover];
	$hgpicture = $boardstyle[hgpicture];
	$bgfixed = $boardstyle[bgfixed];
	$cfg[css] = "a:link{color:".$links.";text-decoration: none}
	a:visited{color:".$visited.";text-decoration: none}
	a:active{color:".$active.";text-decoration: none}
	a:hover{color:".$hover.";text-decoration: underline}
	BODY{font-family:Verdana, Arial, Helvetica, sans-serif;font-size:10pt;color:".$fontcolor.";}
	.button{font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}";
}
if($dologin) {
	$result = mysql_query ("SELECT userid,userpassword FROM apb".$n."_user_table WHERE username='$username';");
	if (!$result) {
		$l_error = $benutzername_existiert_nicht;
	} else {
		$userdat = mysql_fetch_array($result);
		if (strcmp($userdat[userpassword],$userpass)) {
			$l_error = $pw_falsch;
		} else {
			setcookie ("UserInformation[uid]", "$userdat[userid]", time()+31536000);
			setcookie ("UserInformation[upass]", "$userdat[userpassword]", time()+31536000);
		}
	}
}

if ($delete) {
	setcookie ("UserInformation[uid]");
	setcookie ("UserInformation[upass]");
}
$hstring = "<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;$einloggen";

if (substr($refer_to, 0, strlen($php_path)) != $php_path) {
	$referer = "";
} else {
	if (!eregi("register.php", $refer_to)) {
		$referer = $refer_to;
	} else {
		$referer = "$php_path/main.php";
	}
}
require "_header.inc";
if ($delete) {
	message_box($cookies_entfernen);
	include "_footer.inc";
	exit;
}

if ($dologin) {
	if ($l_error) {
		apb_error($l_error,FALSE);
	} else {
		$message = $cookies_setzen;
		if ($refer_to != "") {
			$message .= "<BR><BR>Du wirst jetzt automatisch weitergeleitet zu:<BR><A HREF=\"$referer\">$referer</A><BR>";
		}
		
		message_box($message);
		include "_footer.inc";
		exit;
	}
}

$refer_to = getenv("HTTP_REFERER");

echo "<TABLE BGCOLOR=\"$tablebg\" ALIGN=\"CENTER\" WIDTH=\"95%\" BORDER=\"0\" CELLSPACING=\"1\" CELLPADDING=\"6\">
	<FORM ACTION=\"$php_path/login.php\" method=post>
	<TR BGCOLOR=\"$tableC\">
		<TD COLSPAN=\"2\"><FONT FACE=\"$font\" SIZE=5><B>".$einloggen."</B></FONT><BR>
			<FONT FACE=\"$font\" SIZE=2>".$info_text1."</FONT>
		</TD>
	</TR>
	<TR BGCOLOR=\"$tableA\">
		<TD WIDTH=\"50%\"><FONT FACE=\"$font\" SIZE=2><B>".$benutzername_eingabe."</B></FONT><BR>
			<FONT FACE=\"$font\" SIZE=1>".$benutzername_info."</FONT>
		</TD>
		<TD WIDTH=\"50%\">
			<INPUT CLASS=\"button\" TYPE=\"text\" NAME=\"username\" MAXLENGTH=\"30\" SIZE=\"25\">
		</TD>
	</TR>
	<TR BGCOLOR=\"$tableA\">
		<TD WIDTH=\"50%\"><FONT FACE=\"$font\" SIZE=2><B>".$passwort_eingabe."</B></FONT><BR>
			<FONT FACE=\"$[font\" SIZE=1>".$passwort_info."</FONT>
		</TD>
		<TD WIDTH=\"50%\">
			<INPUT CLASS=\"button\" TYPE=\"password\" NAME=\"userpass\" MAXLENGTH=\"25\" SIZE=\"25\">
			<INPUT TYPE=\"hidden\" NAME=\"dologin\" VALUE=\"TRUE\">
		</TD>
	</TR>
	<TR BGCOLOR=\"$tableB\">
		<TD COLSPAN=\"2\">
			<CENTER>
			<INPUT TYPE=\"hidden\" NAME=\"BoardID\" VALUE=\"$BoardID\">\n";
if (isset($refer_to)) {
	echo "			<INPUT TYPE=\"hidden\" NAME=\"refer_to\" VALUE=\"$refer_to\">\n";
}
echo "			<INPUT CLASS=\"button\" TYPE=\"submit\" NAME=\"Submit\" VALUE=\"Login\">
			<FONT FACE=\"$font\" SIZE=1>&nbsp;&nbsp;<b>".$cookies_info."</b></font>
			</CENTER>
		</TD>
	</TR>
	</FORM>
</TABLE>";

$oday = mysql_fetch_row(mysql_db_query ($mysqldb,"SELECT time FROM apb".$n."_statistik ORDER BY time DESC LIMIT 1"));
$oday = getdate($oday[0]);
$day = getdate(time());
if (!$oday) $oday[yday] = $day[yday];
if ($oday[yday] != $day[yday])
{
	mysql_db_query($mysqldb,"DELETE FROM apb".$n."_statistik");
}
mysql_db_query ($mysqldb,"INSERT INTO apb".$n."_statistik VALUES('','".time()."','$REMOTE_ADDR','$PHP_SELF','$HTTP_USER_AGENT','$REMOTE_HOST');");
require "userreg.php";
require "_footer.inc";

?>