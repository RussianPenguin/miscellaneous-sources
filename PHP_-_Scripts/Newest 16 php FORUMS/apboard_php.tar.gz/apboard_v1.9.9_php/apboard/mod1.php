<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_language.inc";
require "__config.inc";
$ustring = CookieAuth($UserInformation);
$hstring ="<B><A HREF=\"$php_path/main.php\">$master_board_name</A></B><BR>&nbsp;&nbsp;<A HREF=\"$php_path/mod1.php\"><b>".$mod_center."</b></a>";
require "_header.inc";
?>
<TABLE BGCOLOR="<? echo $tablebg; ?>" WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="6" ALIGN="CENTER">
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD><font face="<? echo $font; ?>" size=3><b><? echo $mod_center; ?></b></font></TD>
	</TR>
	<TR BGCOLOR="<? echo $tableC; ?>">
		<TD>
			<form method=post ACTION=<? echo "$php_path/mod1.php"; ?>>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="2%">&nbsp;</td>
					<td colspan="2"><font face="<? echo $font; ?>" size=2><? echo $mod_menue; ?></font></td>
					<td width="2%">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%" height="18">&nbsp;</td>
					<td width="96%" height="18" colspan="2" rowspan="13">
<?

$auth = UserAuth($UserInformation[uid],$UserInformation[upass]);
if ($auth=="4")
{
?>
						<table width="100%" border="0" cellspacing="1" cellpadding="4">
							<tr>
								<td width="96%" height="18">
									<div align="center">
									<font face="<? echo $font; ?>" size=2>
										<table width="98%" border="0" cellspacing="1" cellpadding="4">
											<tr BGCOLOR="<? echo $tableB; ?>">
												<td width="49%" height="18">
													<div align="left">
													<font face="<? echo $font; ?>" size=2><br>
													<? echo $menue_design; ?><br><br>
													<? echo $menue_new_board; ?><br><br>
													<? echo $menue_weiteres; ?><br><br>
													</font>
													</div>
												</td>
												<td width="49%" height="18">
													<div align="left">
													<font face="<? echo $font; ?>" size=2><br>
													<a href="<? echo "$php_path/mod_board_design.php"; ?>"><? echo $menue_design1; ?></a><br><br><br>
													<a href="<? echo "$php_path/mod_new_board.php"; ?>"><? echo $menue_new_board1; ?></a><br><br><br>
													<a href="<? echo "$php_path/mod1.php#"; ?>"><? echo $menue_weiteres1; ?></a><br><br>
													</font>
													</div>
												</td>
											</tr>
										</table>
									</font>
									</div>
								</td>
							</tr>
						</table>
<?
} else {
	apb_error($mod_kein_mod,FALSE);
}
?>
					</td>
					<td width="2%" height="18">&nbsp;</td>
				</tr>
				<tr>
					<td width="2%">&nbsp;</td>
					<td width="2%">&nbsp;</td>
				</tr>
			</table>
			</form>
		</TD>
	</TR>
</TABLE>
<?

require "_footer.inc";

?>