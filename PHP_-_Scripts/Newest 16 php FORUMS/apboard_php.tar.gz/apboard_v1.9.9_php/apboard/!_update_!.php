<?
// ####################################################################################################
// # APBoard (AnotherPHPBoard)                                                                        #
// ####################################################################################################
// #                                                                                                  #
// # Copyright � 2000 by Alexander Mieland (DMA147.ThW.N) and Lars Volkhardt (Snoopy)                 #
// # Contact: dma147@arcormail.de, 66Snoopy@gmx.de                                                    #
// # Homepage: http://apboard.halflife-editing.de                                                                   #
// #                                                                                                  #
// # Based on a very early version of DarthPauls MagicBoard, modified with permission                 #
// ####################################################################################################
// # Leave this header in every file !!!                                                              #
// #                                                                                                  #
// ####################################################################################################
//
//
//
//
//    This program is free software; you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation; either version 2 of the License, or
//    (at your option) any later version.
//
//    This program is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//
//
//
require "_data.inc.php";
$new_version = "1.9.9";
function lng_german() {
	global $title, $subtitle, $title_description, $update_success, $update_success2, $changes, $scipt_to_version, $quest_which_version,
			$go_on, $check, $check_akt_version, $check_new_version, $check_number, $quest_really_update, $warn_notice, $error_wrong_version, $update;
	$title = "Update der Datenbank des APBoards";
	$subtitle = "Willkommen beim automatischen Update der Datenbankstruktur des ABoards.";
	$title_description = "Mit Hilfe dieses Scripts werden alle &Auml;nderungen an der Datenbank vorgenommen,<BR>die f&uuml;r das Update auf die neueste Version n&ouml;tig sind.";
	$update_success = "Das Update wurde erfolgreich durchgef&uuml;hrt.";
	$update_success2 = "Falls die Dateien der neuen Version $new_version noch nicht auf den Server geladen wurden,<BR>sollte dies jetzt geschehen!!";
	$changes = "&Auml;nderungen f&uuml;r Version";
	$scipt_to_version = "Dieses Script aktualisiert die Datenbank auf die Version:";
	$quest_which_version = "Welche Version ist im Moment bei Ihnen installiert?";
	$go_on = "weiter...!";
	$check = "&Uuml;berpr&uuml;fen Sie nochmals die Korrektheit folgender Angaben:";
	$check_akt_version = "aktuelle Version: ";
	$check_new_version = "neue Version: ";
	$check_number = "Nummer dieses APBoards: ";
	$quest_really_update = "Update jetzt wirklich durchf&uuml;hren??";
	$warn_notice = "(ACHTUNG: bei falschen Angabe in der obigen Liste<BR>k&ouml;nnte der Inhalt der Datenbank besch&auml;digt werden!)";
	$error_wrong_version = "Fehler: falsche Angabe bei der alten Version:";
	$update = "Updaten!!";
}

switch ($use_language) {
	case "english":
		lng_english();
		break;
	case "german":
		lng_german();
		break;
	default:
		lng_german();
}

?>
<HTML>
<HEAD>
<TITLE><? echo $title; ?></TITLE>
</HEAD>
<BODY>
<DIV ALIGN="CENTER">
<FONT FACE="Verdana, Arial, Helvetica, sans-serif">
<TABLE BORDER="0" WIDTH="95%">
<TR>
<TD COLSPAN="3">
	<FONT FACE="Verdana, Arial, Helvetica, sans-serif" COLOR="RED" SIZE="5"><DIV ALIGN="CENTER">
	<BR><? echo $subtitle; ?></FONT><BR><BR>
	<FONT FACE="Verdana, Arial, Helvetica, sans-serif" SIZE="3">
	<? echo $title_description; ?></FONT></DIV>
</TD>
</TR>
<TR><TD COLSPAN="3"><BR><BR><HR><BR><BR></TD></TR>

<?
function update_erfolgreich() {
	global $update_success, $update_success2;
	echo "
	<TR>
		<TD ALIGN=\"CENTER\" COLSPAN=\"3\">
			<BR><BR><BR>
			<FONT SIZE=\"+1\">$update_success</FONT><BR><BR>
			$update_success2
		</TD>
	</TR>";
}

/* Update-Funktionen */

function update_198_199() {
	global $changes, $mysqlhost, $mysqluser, $mysqlpassword, $mysqldb, $n;

	// &Auml;nderungen etc...

	ECHO "<TR>\n<TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>$changes 1.9.9<BR></TD>\n</TR>";

	ECHO "<TR><TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>
	Hinzuf&uuml;gen der Spalten \"sortit\" und \"totalthreads\" in die Tabelle apb".$n."_boards<BR>
	Hinzuf&uuml;gen der Spalte \"views\" in die Tabelle apb".$n."_threads<BR>
	&Auml;ndern des Feldes \"text\" in Tabelle apb".$n."_chat<BR> in ein text-Feld<BR>
	Hinzuf&uuml;gen der Spalte \"disable_smilies\" und \"post_ip\" in die Tabelle apb".$n."_posts<BR>
	Hinzuf&uuml;gen der Spalte \"show_email_global\", \"users_may_email\" und \"mods_may_email\" in die Tabelle apb".$n."_user_table<BR>
	</TD></TR>";

	$handler = mysql_connect($mysqlhost,$mysqluser,$mysqlpassword);
	echo mysql_error();
	mysql_select_db($mysqldb, $handler);
	echo mysql_error();

	mysql_query("ALTER TABLE apb".$n."_threads ADD views INT(11) DEFAULT '0' NOT NULL");
	echo mysql_error();
	mysql_query("ALTER TABLE apb".$n."_boards ADD sortit INT(3) DEFAULT '1' NOT NULL, ADD totalthreads INT(11) DEFAULT '0' NOT NULL");
	echo mysql_error();
	mysql_query("ALTER TABLE apb".$n."_chat CHANGE text text TEXT NOT NULL");
	echo mysql_error();
	mysql_query("ALTER TABLE apb".$n."_posts ADD disable_smilies INT (1) DEFAULT '0' NOT NULL, ADD post_ip VARCHAR (240) NOT NULL");
	echo mysql_error();
	mysql_query("ALTER TABLE apb".$n."_user_table ADD show_email_global INT (1) DEFAULT '0' NOT NULL, ADD users_may_email INT (1) DEFAULT '1' NOT NULL, ADD mods_may_email INT (1) DEFAULT '1' NOT NULL");
	echo mysql_error();
	
	$board_result = mysql_query("SELECT boardid FROM apb".$n."_boards");
	while ($boardid_result = mysql_fetch_array($board_result)) {
		$board = $boardid_result["boardid"];
		$threads_result = mysql_query("SELECT threadid FROM apb".$n."_threads WHERE flags != '2' AND boardparentid='$board'");
		$anzahl_threads = mysql_num_rows($threads_result);
		$put_totalthreads = mysql_query("UPDATE apb".$n."_boards SET totalthreads='$anzahl_threads' WHERE boardid='$board'");
	}

	$result1 = mysql_query("SELECT boardid FROM apb".$n."_boards");
	$b = 1;
	while ($boardid = mysql_fetch_array($result1)) {
		$bid = $boardid["boardid"];
		mysql_query("UPDATE apb".$n."_boards SET sortit='$b' WHERE boardid='$bid'");
		echo mysql_error();
		$b++;
	}

	update_erfolgreich();
}

function update_197_198() {
	global $changes, $mysqlhost, $mysqluser, $mysqlpassword, $mysqldb, $n;

	// &Auml;nderungen etc...

	ECHO "<TR>\n<TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>$changes 1.9.8<BR></TD>\n</TR>";

	ECHO "<TR><TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>Hinzuf&uuml;gen der Spalte \"installdate\" in die Tabell apb".$n."_config<BR>
	</TD></TR>";

	$handler = mysql_connect($mysqlhost,$mysqluser,$mysqlpassword);
	echo mysql_error();
	mysql_select_db($mysqldb, $handler);
	echo mysql_error();

	$installdate1 = mysql_query("SELECT date FROM apb".$n."_board_news ORDER BY date LIMIT 0,1");
	$installdate1 = mysql_fetch_row($installdate1);
	$installdate1 = $installdate1[0];

	$installdate2 = mysql_query("SELECT regdate FROM apb".$n."_user_table ORDER BY regdate LIMIT 0,1");
	$installdate2 = mysql_fetch_row($installdate2);
	$installdate2 = $installdate2[0];

	if ($installdate1 < $installdate2) {
		$installdate = $installdate1;
	} else {
		$installdate = $installdate2;
	}

	//echo $installdate;


	mysql_query("ALTER TABLE apb".$n."_config ADD installdate INT(11) DEFAULT '0' NOT NULL");
	echo mysql_error();

	mysql_query("UPDATE apb".$n."_config SET installdate = '$installdate'");
	echo mysql_error();

	update_198_199();
}

function update_195_197() {
	global $changes, $mysqlhost, $mysqluser, $mysqlpassword, $mysqldb, $n;

	// &Auml;nderungen etc...

	ECHO "<TR>\n<TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>$changes 1.9.7<BR></TD>\n</TR>";

	ECHO "<TR><TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR>Hinzuf&uuml;gen der Spalte \"adminmail\" in die Tabell apb".$n."_config<BR>
	</TD></TR>";

	$handler = mysql_connect($mysqlhost,$mysqluser,$mysqlpassword);
	echo mysql_error();
	mysql_select_db($mysqldb, $handler);
	echo mysql_error();

	mysql_query("ALTER TABLE apb".$n."_config ADD adminmail INT (1) DEFAULT '0' not null AFTER bgfixed");
	echo mysql_error();

	update_197_198();
}

/* Haupt-Teil */

if (!$old_version) {

?>
	<TR>
	<TD WIDTH="60%" ALIGN="RIGHT">
	<? echo $scipt_to_version; ?>
	</TD>
	<TD WIDTH="5%">&nbsp;</TD>
	<TD WIDTH="35%">
	<B><? echo $new_version; ?></B>
	</TD>
	</TR>
	<TR>
	<TD COLSPAN="3"><BR><BR><BR></TD>
	</TR>
	<FORM ACTION="!_update_!.php" METHOD="POST">
	<TR>
	<TD ALIGN="RIGHT"><? echo $quest_which_version; ?></TD>
	<TD>&nbsp;</TD>
	<TD>
		<select name="old_version" size=1>
		<option>Version 1.9.5</option>
		<option>Version 1.9.7</option>
		<option checked>Version 1.9.8</option>
		</select>
	</TD>
	</TR>
	<TR>
	<TD COLSPAN="3"><BR><BR><BR></TD>
	</TR>
	<TR>
	<TD ALIGN="CENTER" COLSPAN="3"><INPUT TYPE="SUBMIT" VALUE="<? echo $go_on; ?>"></TD>
	</TR>
	<INPUT TYPE="HIDDEN" NAME="use_language" VALUE="<? echo $use_language; ?>">
	</FORM>
<?
} else {
	if (!$do_update) {
		echo "
		<TR>
			<TD ALIGN=\"CENTER\" COLSPAN=\"3\">";
		echo "$check <BR><BR>";
		echo "$check_akt_version$old_version<BR>";
		echo "$check_new_version$new_version<BR>";
		echo "$check_number $n<BR>";

		echo "
			</TD>
		</TR>";

		echo "
		<TR>
			<TD ALIGN=\"CENTER\" COLSPAN=\"3\">
			<BR><BR><BR><B>$quest_really_update</B><BR><BR>
			<FONT COLOR=\"RED\" SIZE=\"+1\"><B>$warn_notice</B></FONT>

			</TD>
		</TR>";
		echo "
		<TR>
			<TD ALIGN=\"CENTER\" COLSPAN=\"3\"><BR><BR><BR>
				<FORM ACTION=\"!_update_!.php\" METHOD=\"POST\">
				<INPUT TYPE=\"HIDDEN\" NAME=\"old_version\" VALUE=\"$old_version\">
				<INPUT TYPE=\"HIDDEN\" NAME=\"do_update\" VALUE=\"1\">
				<INPUT TYPE=\"SUBMIT\" VALUE=\"$update\">
				<INPUT TYPE=\"HIDDEN\" NAME=\"use_language\" VALUE=\"$use_language\">
				</FORM>
			</TD>
		</TR>";
	} else {
		switch ($old_version) {
		case "Version 1.9.5":
			update_195_197();
			break;
		case "Version 1.9.7":
			update_197_198();
			break;
		case "Version 1.9.8":
			update_198_199();
			break;
		default:

			echo "<TR ALIGN=\"CENTER\">\n<TD COLSPAN=\"3\"><BR><BR><BR>$error_wrong_version $old_version</TD></TR>";
		}
	}
}

?>
</TABLE>
</FONT>
</DIV>
</BODY>
</HTML>