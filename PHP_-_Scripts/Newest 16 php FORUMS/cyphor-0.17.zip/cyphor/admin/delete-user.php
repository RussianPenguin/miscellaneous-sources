<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");




    $db = new DB_Cyphor;
    $db->connect();

	if ($abort) {
		$confirm = 0;
		$id = 0;
	}

	if ($id && $confirm) {
		// Delete user
		$query = "DELETE FROM users WHERE id=$id";
		$db->query($query);
		admin_exit_page("User deleted.", "index.php", "Back to Administration");
		exit();
	} else if ($id) {
		// Get confirmation    	
    	$query = "SELECT * FROM users WHERE id=$id";
    	$db->query($query);
		$db->next_record();

        ?>
            <html>
            <head>
                <title>Confirm user deletion</title>
                <link rel="stylesheet" href="admin.css" type="text/css">
            </head>

            <body bgcolor="#FFFFFF" text="#000000">
				<span class=h>Do you really want to delete user "<? echo $db->f("nick"); ?>"</span><br><br>
				                
                <form action="<? echo $PHP_SELF ?>" method="POST">                	
                    <input type="hidden" name="id" value="<? echo $id ?>">
                    <input type="hidden" name="confirm" value="1">
                    <input type="submit" name="submit" value="Yes, go ahead."> <input type="submit" name="abort" value="No, never mind.">
                </form>
            </body>

            </html>
        <?
        exit();		    		
    }
?>
<html>
	<head>
		<META http-equiv="refresh" content="0; URL=index.php">
	</head>
	<body>
	</body>
</html>