<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");
	
	$db = new DB_Cyphor;
	$db->connect();

	if ($confirm) { # SELECTED USER, ACTION TAKEN
		if ($make_user)
			$group_id = 1;
		else if ($make_moderator)
			$group_id = 2;
		else if ($make_admin)
			$group_id = 3;
			
		$query = "UPDATE users SET group_id='$group_id' WHERE nick='$user'";
		$db->query($query);
		admin_exit_page("User promoted!", "index.php", "Back to Administration");
		exit();
	}

	if ($submit) { # SELECTED USER		
		$query = "SELECT u.nick AS nick, g.allow_admin AS allow_admin, g.allow_moderate AS allow_moderate
				  FROM users AS u, groups AS g
				  WHERE (u.nick='$user') AND (u.group_id=g.id)";
		$db->query($query);
		if (!$db->num_rows()) {
			admin_exit_page("User '$user' does not exist!", "promote-user.php", "Promote A User"); exit();
		}
		$db->next_record();
		if ($db->f("allow_admin"))
			$user_rights = "Admin";
		else if ($db->f("allow_moderate"))
			$user_rights = "Moderator";
		else
			$user_rights = "Normal User";
		?>
			<html>
			<head>
			    <title>Promote A User</title>
			    <link rel="stylesheet" href="admin.css" type="text/css">
			</head>
			
			<body>
			    <span class=h>User "<? echo $db->f("nick"); ?>" is <? echo $user_rights; ?>.</span><br>

			    <form action="<? $PHP_SELF ?>" method="POST">
			    	<input type="hidden" name="user" value="<? echo $db->f("nick"); ?>">
			    	<input type="hidden" name="confirm" value="1">
			    	<input type="submit" name="make_user" value="Make normal user">
					<input type="submit" name="make_moderator" value="Make Moderator">
					<input type="submit" name="make_admin" value="Make Admin">
			    </form>
			    
			    <br><br>
			    <span class=t><a href="index.php">Back to Administration</a></span>
			</body>
			
			</html>		
		<?
		exit();
	}
?>
<html>
<head>
    <title>Promote A User</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Promote A User</span><br>
    <form action="<? $PHP_SELF ?>" method="POST">
		<span class=t>Enter username: </span>
		<input type="text" name="user" maxlength="15" size="15"> <input type="submit" name="submit" value="Show User">
    </form>
    
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>