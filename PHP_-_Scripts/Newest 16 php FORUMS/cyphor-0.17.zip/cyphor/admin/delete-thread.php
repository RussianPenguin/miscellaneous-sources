<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    	
	# CHECKS IF YOU'RE AN ADMIN
	# include("check.php"); <-- only useful for admin-only checks
	include("check-moderator.php");
	
	$db = new DB_Cyphor;
	$db->connect();
	
	if ($abort) {
		$fid = 0;
		$id = 0;
	}	
	
	if ($fid) {
		$query = "SELECT db_table_name FROM forums WHERE id=$fid";
		$db->query($query);
		$db->next_record();
		$db_table_name = $db->f("db_table_name");
	}	
	
	# DELETE THE THREAD WITH thread_id = $id
	if ($fid && $id && $submit) {
		$query = "DELETE FROM $db_table_name WHERE thread_id=$id";
		$db->query($query);
		printf("<html><head><title>Delete A Thread</title><link rel=\"stylesheet\" href=\"admin.css\" type=\"text/css\"></head><body>");				
		printf("<span class=h>Thread deleted.</span>");
		printf("<br><br><span class=t><a href=\"index.php\">Back to Administration</a> � <a href=\"../index.php\">Forums Overview</a></span></body></html>");
		exit();
	}
		
	# USER HAS SELECT FORUM AND THREAD, PROMPT HIM TO DELETE
	if ($fid && $id) {
		$query = "SELECT * FROM $db_table_name WHERE ((thread_id=$id) AND (parent_id=0))";
		$db->query($query);
		$db->next_record();
		$title = htmlspecialchars(StripSlashes($db->f("title")));
		$date = $db->f("date");
		
		$query = "SELECT COUNT(id) AS child_count FROM $db_table_name WHERE thread_id='$id' GROUP BY thread_id";
		$db->query($query);
		$db->next_record();
		$child_count = $db->f("child_count") - 1;
		
		printf("<html><head><title>Delete A Thread</title><link rel=\"stylesheet\" href=\"admin.css\" type=\"text/css\"></head><body>");		

		printf("<span class=b>Do you really want to delete the thread \"%s\" (%s subitems)?<br><br>", $title, $child_count);

		?>
			<form action="<? echo $PHP_SELF ?>" method="POST">
				<input type="hidden" name="fid" value="<? echo $fid ?>">
				<input type="hidden" name="id" value="<? echo $id ?>">
				<input type="submit" name="submit" value="Yes, go ahead.">
				<input type="submit" name="abort" value="Nope, never mind.">
			</form>
		<?
		printf("<br><br><span class=t><a href=\"index.php\">Back to Administration</a></span></body></html>");		
		exit();
	}
	
	# USER HAS SELECTED A FORUM, SHOW HIM THE LIST OF THREADS
	if ($fid) {
		$query = "SELECT db_table_name FROM forums WHERE id=$fid";
		$db->query($query);
		$db->next_record();
		$db_table_name = $db->f("db_table_name");
		
		$query = "SELECT a.thread_id AS thread_id, a.title AS title, a.date AS date, b.nick AS nick
				  FROM $db_table_name AS a, users AS b
				  WHERE ((a.parent_id=0) AND (a.author_id=b.id)) ORDER BY a.date DESC";
		$db->query($query);
		
		printf("<html><head><title>Delete A Thread</title><link rel=\"stylesheet\" href=\"admin.css\" type=\"text/css\"></head><body>");
		printf("<span class=b>Select a thread:</span><br><br>");
		printf("<table border=1 cellspacing=0 cellpadding=3>");
		
		?>
			<tr>
				<td><span class=b>ID</span></td>
				<td><span class=b>Title</span></td>
				<td><span class=b>Author</span></td>
				<td><span class=b>Date</span></td>
			</tr>
		<?

		while ($db->next_record()) {
			printf("<tr><td><span class=t>%s</span></td>
			            <td><span class=t><a href=\"%s?fid=%s&id=%s\">%s</a></span></td>
			            <td><span class=t>%s</span></td>
			            <td><span class=t>%s</span></td></tr>",
			$db->f("thread_id"), $PHP_SELF, $fid, $db->f("thread_id"), htmlspecialchars(StripSlashes($db->f("title"))), htmlspecialchars(StripSlashes($db->f("nick"))), nice_date($db->f("date")));
		}
		
		printf("</table><br><br><span class=t><a href=\"index.php\">Back to Administration</a></span></body></html>");
		exit();		
	}
?>
<html>
<head>
    <title>Delete A Thread</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Delete A Thread</span><br><br>
    
    <span class=b>Select forum:</span><br>
    
    <table border=1 cellspacing=0 cellpadding=3>
        <tr>
        	<td><span class=b>ID</span></td>
        	<td><span class=b>Name</span></td>
        	<td><span class=b>Short description</span></td>
        	<td><span class=b>MySQL Table</span></td>
		</tr>
        <?
        	$query = "SELECT * FROM forums ORDER BY id ASC";
        	$db->query($query);
            while ($db->next_record()) {
                printf("<td><span class=t>%s</span></td>", $db->f("id"));
                printf("<td><span class=t><a href=\"%s?fid=%s\">%s</span></td>", $PHP_SELF, $db->f("id"), $db->f("name"));
                printf("<td><span class=t>%s</span></td>", $db->f("short_desc"));
                printf("<td><span class=t>%s</span></td></tr>", $db->f("db_table_name"));
            }
        ?>
    </table>

    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>