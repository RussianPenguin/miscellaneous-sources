<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");
	
	$db = new DB_Cyphor;
	$db->connect();
	
	$query = "SELECT * FROM users ORDER BY signup_date ASC";
	$db->query($query);	
?>
<html>
<head>
    <title>List Users</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>List Users</span><br><br>
    
    <span class=t>There are <? echo $db->num_rows(); ?> users in the database.</span><br><br>

	<table border=1 cellspacing=0 cellpadding=2>
	
	<tr>
		<td><span class=b>ID</span></td>
		<td><span class=b>Username</span></td>
		<td><span class=b>Real name</span></td>
		<td><span class=b>Email</span></td>
		<td><span class=b>Total posts</span></td>
		<td><span class=b>Last post</span></td>
		<td><span class=b>Signup date</span></td>
		<td><span class=b>Action</span></td>
	</tr>
	
	<?
		while ($db->next_record()) {
			printf("<tr><td><span class=t>%s</td>", $db->f("id"));
			printf("<td><span class=t>%s</td>", $db->f("nick"));
			printf("<td <span class=t>%s</td>", $db->f("real_name"));
			printf("<td <span class=t>%s</td>", $db->f("email"));
			printf("<td <span class=t>%s</td>", $db->f("total_posts"));
			$last_post = $db->f("last_post");
			if ($last_post) $last_post = nice_short_date($last_post);
			else $last_post = "N/A";
			printf("<td <span class=t>%s</td>", $last_post);
			printf("<td <span class=t>%s</td>", nice_short_date($db->f("signup_date")));
			printf("<td <span class=t><a href=\"delete-user.php?id=%s\">Delete User</a></span></td></tr>\n", $db->f("id"));
		}
	?>
		
	</table>
	    
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>