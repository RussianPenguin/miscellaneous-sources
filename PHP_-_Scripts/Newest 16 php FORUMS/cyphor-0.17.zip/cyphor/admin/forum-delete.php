<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");

    $db = new DB_Cyphor;
    $db->connect();

	if ($abort) {
		exit();
	}

	if ($fid) {		
        if ($confirm) {
            $query = "DELETE FROM forums WHERE id='$fid'";
            $db->query($query);
            $query = "DROP TABLE $tname";
            $db->query($query);
            admin_exit_page("Forum successfully deleted!", "index.php", "Back to Administration");
            exit();
        }

        $query = "SELECT * FROM forums WHERE id='$fid'";
        $db->query($query);
        if (!$db->num_rows()) {
            admin_exit_page("Could not find forum!", "javascript:history.back()", "Back");
            exit();
        }
        $db->next_record();
        $forum_name = $db->f("name");
        $db_table_name = $db->f("db_table_name");
        
        // Get number of messages in forum
        $query = "SELECT id FROM $db_table_name";
        $db->query($query);
        $num_msgs = $db->num_rows();

        ?>
            <html>
            <head>
                <title>Confirm forum deletion</title>
                <link rel="stylesheet" href="admin.css" type="text/css">
            </head>

            <body bgcolor="#FFFFFF" text="#000000">
				<span class=h>Do you really want to delete the forum "<? echo $forum_name ?>" (<? echo $num_msgs ?> messages)?</span><br>
				                
                <form action="<? echo $PHP_SELF ?>" method="POST">                	
                    <input type="hidden" name="fid" value="<? echo $fid ?>">
                    <input type="hidden" name="tname" value="<? echo $db_table_name ?>">
                    <input type="hidden" name="confirm" value="1">
                    <input type="submit" name="submit" value="Yes, go ahead."> | <input type="submit" name="abort" value="No, never mind.">
                </form>
            </body>

            </html>
        <?
        exit();
    }    
?>
<html>
<head>
    <title>Delete A Forum</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Delete A Forum</span><br><br>

    <table border=1 cellspacing=0 cellpadding=3>
        <tr>
        	<td><span class=b>ID</span></td>
        	<td><span class=b>Name</span></td>
        	<td><span class=b>Short description</span></td>
        	<td><span class=b>MySQL Table</span></td>
		</tr>
        <?
        	$query = "SELECT * FROM forums ORDER BY id ASC";
        	$db->query($query);
            while ($db->next_record()) {
                printf("<td><span class=t>%s</span></td>", $db->f("id"));
                printf("<td><span class=t><a href=\"%s?fid=%s\">%s</span></td>", $PHP_SELF, $db->f("id"), $db->f("name"));
                printf("<td><span class=t>%s</span></td>", $db->f("short_desc"));
                printf("<td><span class=t>%s</span></td></tr>", $db->f("db_table_name"));
            }
        ?>
    </table>
        
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>