<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");
    
	include("check.php");

    $db = new DB_Cyphor;
    $db->connect();

	if ($fid && $submit && $name) {
		$query = "UPDATE forums SET name='$name' WHERE id='$fid'";
		$db->query($query);
		
		$name = AddSlashes($name);

		$short_desc = AddSlashes($short_desc);
		
		$query = "UPDATE forums SET short_desc='$short_desc' WHERE id='$fid'";
		$db->query($query);
		
		admin_exit_page("Forum updated.", "index.php", "Back to Administration");
		exit();
	}

    if ($fid) {
		$query = "SELECT * FROM forums WHERE id=$fid";
		$db->query($query);
		$db->next_record();
		
		?>
			<html>
			<head><title>Edit A Forum</title><link rel="stylesheet" href="admin.css" type="text/css"></head>			
			<body>
			    <span class=h>Edit Forum "<? echo $db->f("name"); ?>"</span><br>
			    
			    <form action="<? echo $PHP_SELF ?>" method="POST">
			    <input type="hidden" name="fid" value="<? echo $fid ?>">
				
				<table border=1 cellspacing=0 cellpadding=3>
					<tr><td>
						<span class=t>
							Name:
						</span>
					</td><td>
						<input type="text" name="name" value="<? echo $db->f("name"); ?>">
					</td></tr>
					
					<tr><td>
						<span class=t>
							Description:
						</span>
					</td><td>
						<textarea cols="40" rows="3" name="short_desc" maxlength="255" wrap=virtual><? echo $db->f("short_desc"); ?></textarea>
					</td></tr>
					
				
					<tr><td colspan=2 align=center>
						<input type="submit" name="submit" value="Update">
					</td></tr>
				</table>			    
			    </form>
			    
			    <br><br>
			    <span class=t><a href="index.php">Back to Administration</a></span>
			</body>
			
			</html>		
		<?
		
		exit();
    }    
?>
<html>
<head>
    <title>Edit A Forum</title>
    <link rel="stylesheet" href="admin.css" type="text/css">
</head>

<body>
    <span class=h>Edit A Forum</span><br>
    
    <table border=1 cellspacing=0 cellpadding=3>
        <tr>
        	<td><span class=b>ID</span></td>
        	<td><span class=b>Name</span></td>
        	<td><span class=b>Short description</span></td>
        	<td><span class=b>MySQL Table</span></td>
		</tr>
        <?
        	$query = "SELECT * FROM forums ORDER BY id ASC";
        	$db->query($query);
            while ($db->next_record()) {
                printf("<td><span class=t>%s</span></td>", $db->f("id"));
                printf("<td><span class=t><a href=\"%s?fid=%s\">%s</span></td>", $PHP_SELF, $db->f("id"), $db->f("name"));
                printf("<td><span class=t>%s</span></td>", $db->f("short_desc"));
                printf("<td><span class=t>%s</span></td></tr>", $db->f("db_table_name"));
            }
        ?>
    </table>
    
    <br><br>
    <span class=t><a href="index.php">Back to Administration</a></span>
</body>

</html>