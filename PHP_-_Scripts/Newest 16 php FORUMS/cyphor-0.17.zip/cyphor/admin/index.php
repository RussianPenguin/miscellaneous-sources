<?
    include("../include/db_mysql.php");
    include("../include/settings.php");
    include("../include/global.php");
    include("admin.php");

    # Start PHP4 Session
    open_session();

	include("check.php");
?>
<html>
<head>
    <title><? echo $forum_title ?> | Administration</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
</head>

<body bgcolor="#FFFFFF" text="#000000">
    <span class=h><? echo $forum_title ?> | Administration</span><br>

    <hr size=1 noshade>

    <table width=100% border=0 cellspacing=0 cellpadding=2>

    <tr><td>
        <span class=h>General</span>
    </td></tr>
    
    <tr><td>
    	<span class=t>
            <a href="edit-field.php?field=terms_of_usage">Edit terms of usage</a> |
            <a href="edit-field.php?field=welcome_msg">Edit welcome message</a>
        </span>
    </td></tr>

    <tr><td>&nbsp;</td></tr>


    <tr><td>
        <span class=h>Forums</span>
    </td></tr>
    
    <tr><td>
    	<span class=t>
            <a href="forum-create.php">Create A New Forum</a> | <a href="forum-delete.php">Delete A Forum</a> | <a href="forum-edit.php">Edit A Forum</a>
        </span>
    </td></tr>

    <tr><td>&nbsp;</td></tr>

    <tr><td>
        <span class=h>Users</span>
    </td></tr>
    <tr><td>
        <span class=t>
        	<a href="promote-user.php">Promote User</a> | <a href="list-users.php">List/Delete Users</a>
        </span>
    </td></tr>
                
    </tr><tr><td>&nbsp;</td></tr>
    
    <tr><td>
        <span class=h>Threads</span>
    </td></tr>
    <tr><td>
        <span class=t>
        	<a href="delete-thread.php">Delete A Thread</a>
        </span>
    </td></tr>            

    </tr><tr><td>&nbsp;</td></tr>

    <tr><td>
        <span class=h>Maintenance</span>
    </td></tr>
    <tr><td>
    	<span class=t>
            <a href="delete-old-threads.php">Delete Old Threads</a>
        </span>
    </td></tr>

    </table>

	<br>
	<hr size=1 noshade>

    <span class=t><a href="../index.php">Forums Overview</a> | <a href="../index.php?logout=logout">Logout</a></span>
</body>
</html>

