<?php

/*
	german.php - German language file
	Created: January 22, 2001
	Author: Alex Suzuki, Cynox webdesign
	
	This is a language file. You can alter it to fit your language. For example if were to make a russian
	one, name it "russian.php" and put into the "lang" subdirectory along with the other language files.
	Then start editing the variables. Note that there are pieces of text that are actually format strings
	(those including a %s) somewhere in the text. Those %s have to be there, they are placeholders for
	information that is dynamically inserted at run-time. Mostly their content is self-explaining.
	
	If you have created a language file for a language that is not yet supported (in the official release),
	please email it to me (yes I will mention your name somewhere :). It will then be included in the next
	release.	
*/

/*
	Variables for index.php
*/

$t_overview_upper_right = "%s registrierte Benutzer | Aktivster Benutzer: %s (%s posts) | <b>%s Benutzer online</b>";
$t_welcome = "Willkommen";

$t_login = "Login";
$t_guest_access = "Gastzugriff erteilt. Sie m&uuml;ssen sich <a href=\"register.php\">registrieren</a> falls Sie auch Nachrichten schreiben wollen.";
$t_username = "Benutzer";
$t_password = "Passwort";
$t_logged_in = "Eingeloggt";
$t_reguser_welcome_phrase = "Willkommen, <b>%s</b>."; // %s = username
$t_reguser_rights = "Du hast <b>%s</b>-Rechte."; // %s = rights (admin, moderator, normal)

$t_search = "Suchen in Foren";
$t_find = "Suche:";
$t_infield = "in Feld:";
$t_search_subject = "Betreff";
$t_search_text = "Text";
$t_indiscussion = "in Forum:";


$t_forums = "Foren";
$t_forumname = "Name";
$t_new = "Neu";
$t_total = "Total";
$t_lastpost = "Letzte Nachricht";
$t_fdesc = "Beschreibung";


/*
	Variables for profile.php
*/

$t_update_confirmation = "Profil aktualisiert, Sie m&uuml;ssen sich neu einloggen um die &Auml;nderungen wirksam zu machen.";
$t_general_info = "Allgemeine Information f&uuml;r %s"; // %s = username
$t_real_name = "Richtiger Name";
$t_emailaddr = "Email";
$t_newpwd = "Neues Passwort";
$t_repeatpwd = "Wiederholen Sie das Passwort";

$t_preferences = "Forum Einstellungen";
$t_threadsperpage = "Threads pro Seite: ";
$t_signature = "Signatur: ";


/*
	Variables for show.php
*/

$t_foruminfo = "(%s Threads, %s Nachrichten total)";
$t_usersonline = "%s Benutzer online";

$t_post_new_topic = "Neue Nachricht verfassen";
$t_collapse_threads = "Kompaktansicht";
$t_expand_threads = "Baumansicht";

$t_previous_page = "Vorherige Seite";
$t_next_page = "N&auml;chste Seite";

$t_subject_field = "Betreff";
$t_author_field = "Autor";
$t_date_field = "Datum";

$t_one_reply = "(1 Antwort)";
$t_many_replies = "(%s Antworten)";
$t_delete_thread = "Thread l&ouml;schen";

$t_user_info = "Benutzerinfo";
$t_text = "Text";
$t_user_posts = "(%s Nachrichten total, Letzte Nachricht: %s)";
$t_replies_to_this_msg = "Antworten auf diese Nachricht";
$t_postinfo = ", geschrieben von <b>%s</b>, [%s], %s. <b>%s</b> mal gelesen.";
$t_reply_to_msg = "Auf diese Nachricht antworten";

/*
	Variables for register.php
*/

$t_terms_of_usage = "Nutzungsbedingungen";
$t_userinformation = "Benutzerinfo";
$t_reg_info = "Sobald Sie sich angemeldet haben, wird Ihnen das Passwort via Email zugestellt.";

$t_regmail_head = "Sie haben sich fuer ein Cyphor Forum angemeldet (%s). Dies ist ihre Bestaetigung."; // %s = forum name
$t_regmail_user = "Ihr Benutzername: ";
$t_regmail_pass = "Ihr Passwort: ";
$t_regmail_info = "Die URL des Forums: ";
$t_regmail_subject = "[Cyphor] Anmeldung erfolgreich!";
$t_reg_conf = "Anmeldung erfolgreich! Sie erhalten Ihr Best&auml;tigungsemail an folgende Adresse: %s"; // %s = email

/*
	Variables for search.php
*/

$t_search = "Suchen";
$t_results = "%s Ergebnisse f&uuml;r Forum \"%s\" gefunden.";
$t_found_nothing = "Keine Ergebnisse f&uuml;r Forum \"%s\" gefunden.";
$t_search_again = "Neue Suche";

/*
	Variables for send.php
*/

$t_message_posted = "Nachricht abgeschickt!";
$t_view_your_message = "Nachricht anschauen";
$t_mail_header = "%s hat auf Ihre Nachricht im Forum '%s' geantwortet."; // %s = nickname, forum name
$t_mail_link = "Dieser Link bringt Sie direkt zu seiner Nachricht";
$t_mail_subject = "[Cyphor] Antwort auf: %s"; // %s = subject of message

/*
	Variables for newmsg.php
*/

$t_new_msg_in_forum = "Neue Nachricht in Forum \"%s\""; // %s = forum name
$t_new_reply_in_forum = "Antwort auf \"%s\" im Forum \"%s\""; // %s = subject of parent msg | forum name
$t_post_rules = "Zeilenumbr&uuml;che werden ber&uuml;cksichtigt, Sie m&uuml;ssen Sie nicht durch &lt;BR&gt;-Tags forcieren! Jegliches HTML wird gefiltert. Links auf Internetadressen werden automatisch hervorgehoben.";
$t_msg_from_field = "Von: ";
$t_msg_subject_field = "Betreff: ";
$t_msg_text_field = "Text: ";
$t_email_notification = "Ich w&uuml;nsche eine Emailbenachrichtigung wenn auf diese Nachricht geantwortet wird.";
$t_attach_sig = "Meine Signatur soll dieser Nachricht angef&uuml;gt werden.";

/*
	Variables for lost_pwd.php
*/

$t_enter_email_address = "Benutzername und Passwort angeben";
$t_lostpwd_info = "Sie k&ouml;nnen sich ein neues Passwort erstellen lassen, indem Sie Cyphor ihren Benutzernamen und ihre Emailadresse geben. Cyphor wird dann f&uuml;r diesen Benutzer ein neues Passwort erstellen, und es ihm per Email zustellen.";
$t_pwd_sent = "Neues Passwort erstellt.";

/*
	Globals	
*/

$t_btnupdate = "Profil aktualisieren";
$t_btnsignup = "Anmelden";
$t_btnsearch = "Suchen";
$t_btnresetform = "Zur&uuml;cksetzen";
$t_btnpostmsg = "Nachricht abschicken";
$t_btnquote = "Originalnachricht zitieren";
$t_back_link = "Zur&uuml;ck";
$t_invalid_query = "Fehlerhafte Anforderung!";
$t_btnsubmit = "Senden";

/*
	Footer
*/

$t_forums_overview = "Foren &Uuml;bersicht";
$t_back_to_forum = "Zur&uuml;ck zum Forum";
$t_register = "Registrieren";
$t_edit_profile = "Profil editieren";
$t_logout = "Logout";
$t_administration = "Administration";
$t_btngo = "Wechseln";
$t_jump_to = "Forum wechseln...";
$t_lost_password = "Passwort vergessen?";


/*
	Error messages
*/

$terr_not_logged_in = "Nicht eingeloggt!";
$terr_no_admin_rights = "Benutzer hat keine Administrativrechte!";
$terr_no_forum = "Kein Forum angegeben!";
$terr_login_failed = "Login gescheitert!";
$terr_required_fields = "Sie haben nicht alle erforderlichen Felder angegeben!";
$terr_pwd_match = "Passw&ouml;rter stimmen nicht &uuml;berein!";

$terr_nick_alpha = "Benttzername muss alpha-numerisch sein!";
$terr_nick_len = "Benutzername muss mindestens 3 Zeichen lang sein!";
$terr_nick_reg = "Benutzername ist bereits registriert!";
$terr_dbl_email = "Jemand mit der gleichen Emailadresse hat sich bereits angemeldet!";


?>