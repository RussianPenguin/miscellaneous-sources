<?
    include("include/db_mysql.php");
    include("include/settings.php");
    include("include/global.php");

    /* Include the language file */
    $lang_file = "lang/" . $language . ".php";
    include($lang_file);

    open_session();

    if (!$login || !$pass) {
        exit_page_with_msg($terr_not_logged_in, "javascript:history.back()", $t_back_link); exit();
    }

    if (!login($login, $pass)) {
        exit_page_with_msg($terr_login_failed, "javascript:history.back()", $t_back_link); exit();
    }

    if ($submit) {
        if ((!($f_pwd)) || (!($f_pwd_check)) || (!($f_email)) || (!($f_threads_per_page))) {
            exit_page_with_msg($terr_required_fields, "javascript:history.back()", $t_back_link); exit();
        }

        if ($f_pwd != $f_pwd_check) {
            exit_page_with_msg($terr_pwd_match, "javascript:history.back()", $t_back_link); exit();
        }

        $db = new DB_Cyphor;
        $db->connect();
        $query = "SELECT id FROM users WHERE nick='$login'";
        $db->query($query);
        $db->next_record();
        $id = $db->f("id");


        $query = "UPDATE users SET email='$f_email' WHERE id='$id'";
        $db->query($query);
        if ($f_real_name) { $query = "UPDATE users SET real_name='$f_real_name' WHERE id='$id'"; }
        $db->query($query);
        $query = "UPDATE users SET password='" . crypt($f_pwd, $login) . "' WHERE id='$id'";
        $db->query($query);
        $query = "UPDATE user_settings SET threads_per_page='$f_threads_per_page' WHERE id=$id";
        $db->query($query);
        if ($f_signature) { $query = "UPDATE user_settings SET signature='$f_signature' WHERE id=$id"; }
        $db->query($query);
        
        session_destroy();
        
        exit_page_with_msg($t_update_confirmation, "index.php", $t_forums_overview);
        exit();
    }

    $db = new DB_Cyphor;
    $db->connect();
    $query = "SELECT * FROM users WHERE nick='$login'";
    $db->query($query);
    $db->next_record();

    $user_id = $db->f("id");
    $user_name = $db->f("nick");
    $user_password = $pass;
    $user_email = $db->f("email");
    $user_realname = $db->f("real_name");


    $query = "SELECT * FROM user_settings WHERE id=$user_id";
    $db->query($query);
    $db->next_record();
    $threads_per_page = $db->f("threads_per_page");
    $signature = $db->f("signature");
?>
<html>

<head>
    <title><? echo $forum_title ?> | <? echo $t_edit_profile ?></title>
    <link rel="stylesheet" type="text/css" href="cyphor.css">
</head>

<body>

<table border=0 cellspacing=0 cellpadding=1 width=100%>

<tr><td class=border>

	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=bigh><? echo $t_edit_profile ?></span></td></tr>
	</table>
	
</td></tr>

<tr><td class=border>

	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=h>
			<? printf($t_general_info, $user_name) ?>
		</span></td></tr>
		<tr><td class=standard>

			<form action="<? echo $PHP_SELF ?>" method="POST">

			<table border=0 cellspacing=0 cellpadding=2>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_real_name ?>: </span></td>
				    <td class=standard><input class=formbox type="text" name="f_real_name" size="20" maxlength="50" value="<? echo $user_realname ?>"></td>
				</tr>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_emailaddr ?>: </span></td>
				    <td class=standard><input class=formbox type="text" name="f_email" size="20" maxlength="100" value="<? echo $user_email ?>"></td>
				</tr>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_newpwd ?>: </span></td>
				    <td class=standard><input class=formbox type="password" name="f_pwd" size="20" maxlength="50" value="<? echo $user_password ?>"></td>
				</tr>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_repeatpwd ?>: </span></td>
				    <td class=standard><input class=formbox type="password" name="f_pwd_check" size="20" maxlength="50" value="<? echo $user_password ?>"></td>
				</tr>
			</table>
			
			<br><br>
			
		</td></tr>
	</table>
	
</td></tr>

<tr><td class=border>

	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=h><? echo $t_preferences ?></span></td></tr>
		<tr><td class=standard>	

			<table border=0 cellspacing=0 cellpadding=2>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_threadsperpage ?></span></td>
				    <td class=standard><input class=formbox type="text" name="f_threads_per_page" size="5" maxlength="5" value="<? echo $threads_per_page ?>"></td>
				</tr>
				<tr>
				    <td class=standard valign=top><span class=t><? echo $t_signature ?></span></td>
				    <td class=standard><textarea class=textarea name="f_signature" cols="40" rows="4" maxlength="255"><? echo $signature ?></textarea></td>
				</tr>
				<tr><td colspan=2 align=center>	
					<input class=button type="submit" name="submit" value="<? echo $t_btnupdate ?>">
					<input class=button type="reset" name="reset" value="<? echo $t_btnresetform ?>">
				</td></tr>
			</table>

			</form>

		<br><br>
			
		</td></tr>
	</table>

</td></tr>

<tr><td class=border>

<? 
	include("include/footer.php");
?>


</td></tr></table>



</body>

</html>
