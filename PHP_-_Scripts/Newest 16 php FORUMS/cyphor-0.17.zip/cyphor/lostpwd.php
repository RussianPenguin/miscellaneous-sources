<?
    include("include/db_mysql.php");
    include("include/settings.php");
    include("include/global.php");

    /* Include the language file */
    $lang_file = "lang/" . $language . ".php";
    include($lang_file);

    function mail_confirmation($email_addr, $user, $pwd) {
        global $forum_title;
        global $forum_url;
		global $admin_email;
		global $t_regmail_head;
		global $t_regmail_user;
		global $t_regmail_pass;
		global $t_regmail_info;
		global $t_regmail_subject;
		$add_headers = "From: $admin_email";

		$data = sprintf($t_regmail_head, $forum_title) . "\n\n";
		$data .= $t_regmail_user . $user . "\n";
		$data .= $t_regmail_pass . $pwd . "\n\n";
		$data .= $t_regmail_info . $forum_url;
        $subject = $t_regmail_subject;
        mail($email_addr, $subject, $data, $add_headers);
    }

    if ($submit) {
        $db = new DB_Cyphor;
        $db->connect();
        $query = "SELECT * FROM users WHERE (email='$email' AND nick='$nick') ";
        $db->query($query);
                
		if (!$db->num_rows()) {
			// no user found, don't tell user about it.
			exit_page_with_msg($t_pwd_sent, "index.php", $t_forums_overview);
			exit();
		}
		
		$db->next_record();
		$new_pwd = random_password();
		$new_pwd_crypt = crypt($new_pwd, $db->f("nick"));
		$query = "UPDATE users SET password='$new_pwd_crypt' WHERE id=" . $db->f("id");
		$db->query($query);
		
        mail_confirmation($email, $nick, $new_pwd);
		
		exit_page_with_msg($t_pwd_sent, "index.php", $t_forums_overview);
        exit();
    }
?>
<html>

<head>
    <title><? echo $forum_title ?> | <? echo $t_lost_password ?></title>
    <link rel="stylesheet" type="text/css" href="cyphor.css">
</head>

<body>

<table border=0 cellspacing=0 cellpadding=1 width=100%>

<tr><td class=border>
	
	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=bigh><? echo $t_lost_password ?></span></td></tr>
	</table>
	
</td></tr>

<tr><td class=border>
	
	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=h><? echo $t_enter_email_address ?></span></td></tr>
		<tr><td class=standard>
			<span class=t>
				<? echo $t_lostpwd_info ?>
			</span>
				<br><br>
				
				<form action="<? echo $PHP_SELF ?>" method="POST">
					<span class=t><? echo $t_emailaddr ?>:</span> <input class="formbox" type="text" name="email" size="20" maxlength="100">
					<span class=t><? echo $t_username ?>:</span> <input class=formbox type="text" name="nick" size="20" maxlength="15">
					<input class="button" type="submit" name="submit" value="<? echo $t_btnsubmit ?>">
				</form>
				
				<br><br>
			
		</td></tr>
	</table>
	
</td></tr>

<tr><td class=border>

<?
    include("include/footer.php");
?>

</td></tr></table>



</body>

</html>
