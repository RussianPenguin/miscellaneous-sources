<?
    include("include/db_mysql.php");
    include("include/settings.php");
    include("include/global.php");

    /* Include the language file */
    $lang_file = "lang/" . $language . ".php";
    include($lang_file);

    function mail_confirmation($email_addr, $user, $pwd) {
        global $forum_title;
        global $forum_url;
		global $admin_email;
		global $t_regmail_head;
		global $t_regmail_user;
		global $t_regmail_pass;
		global $t_regmail_info;
		global $t_regmail_subject;
		$add_headers = "From: $admin_email";

		$data = sprintf($t_regmail_head, $forum_title) . "\n\n";
		$data .= $t_regmail_user . $user . "\n";
		$data .= $t_regmail_pass . $pwd . "\n\n";
		$data .= $t_regmail_info . $forum_url;
        $subject = $t_regmail_subject;
        mail($email_addr, $subject, $data, $add_headers);
    }

    if ($submit) {
        if (!($f_nick) || !($f_email)) {
            exit_page_with_msg($terr_required_fields, "javascript:history.back()", $t_back_link);
            exit();
        }

        if(preg_match("/[^\w]/", $f_nick)) {
            exit_page_with_msg($terr_nick_alpha, "javascript:history.back()", $t_back_link);
            exit();
        }

        if (strlen($f_nick) < 3) {
            exit_page_with_msg($terr_nick_len, "javascript:history.back()", $t_back_link);
            exit();
        }

        $db = new DB_Cyphor;
        $db->connect();
        $query = "SELECT id FROM users WHERE nick='$f_nick'";
        $db->query($query);

        if ($db->num_rows()) {
            exit_page_with_msg($terr_nick_reg, "javascript:history.back()", $t_back_link);
            exit();
        }

        # Nickname is OK

        $query = "SELECT * FROM users WHERE email='$f_email'";
        $db->query($query);
        if ($db->num_rows() && $block_multiple_email) {
            exit_page_with_msg($terr_dbl_email, "javascript:history.back()", $t_back_link);
            exit();
        }

        # Email is OK

        $signup_date = time(); ## Get UNIX timestamp
        $password = random_password();
        $p = crypt($password, $f_nick);

        # Create new user row in DB, group_id defaults to 1
        $query = "INSERT INTO users (id, nick, real_name, email, password, signup_date, last_post, total_posts) VALUES('', '$f_nick', '$f_real_name', '$f_email', '$p', '$signup_date', '0', '0')";
        $db->query($query);
        # Get ID of that row
        $query = "SELECT id FROM users WHERE nick='$f_nick'";
        $db->query($query);
        $db->next_record();
        $id = $db->f("id");

        # Create new settings row in DB
        $query = "INSERT INTO user_settings (id, threads_per_page) VALUES('$id', '20')";
        $db->query($query);

        mail_confirmation($f_email, $f_nick, $password);
		
		exit_page_with_msg(sprintf($t_reg_conf, $f_email), "index.php", $t_login);
        exit();
    }
?>
<html>

<head>
    <title><? echo $forum_title ?> | <? echo $t_register ?></title>
    <link rel="stylesheet" type="text/css" href="cyphor.css">
</head>

<body>

<table border=0 cellspacing=0 cellpadding=1 width=100%>

<tr><td class=border>
	
	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=bigh><? echo $t_register ?></span></td></tr>
	</table>
	
</td></tr>

<tr><td class=border>
	
	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=h><? echo $t_terms_of_usage ?></span></td></tr>
		<tr><td class=standard>
			<span class=t>
			<!-- TERMS OF USAGE HERE -->
			<?
				$db = new DB_Cyphor;
				$db->connect();
				
				$query = "SELECT value FROM forum_settings WHERE field='terms_of_usage'";
				$db->query($query);
				$db->next_record();
				printf("%s", StripSlashes($db->f("value")));
			?>
			</span>
		</td></tr>
	</table>
	
</td></tr>


<tr><td class=border>
	<table border=0 cellspacing=0 cellpadding=2 width=100%>
		<tr><td class=title><span class=h><? echo $t_userinformation ?></span></td></tr>
		<tr><td class=standard>
			<span class=t>
				<? echo $t_reg_info ?>
			</span>

			<form action="<? echo $PHP_SELF ?>" method="POST">
			
			<table border=0 cellspacing=0 cellpadding=2>

				<tr>
				    <td class=standard><span class=b><? echo $t_username ?></span></td>
				    <td class=standard><input class=formbox type="text" name="f_nick" size="20" maxlength="15"></td>
				</tr>
				
				<tr>
				    <td class=standard><span class=t><? echo $t_real_name ?></span></td>
				    <td class=standard><input class=formbox type="text" name="f_real_name" size="20" maxlength="40"></td>
				</tr>
				
				<tr>
				    <td class=standard><span class=b><? echo $t_emailaddr ?></span></td>
				    <td class=standard><input class=formbox type="text" name="f_email" size="20" maxlength="100"></td>
				</tr>
				
				<tr><td colspan=2 align=center class=standard>
					<input class=button type="submit" name="submit" value="<? echo $t_btnsignup ?>">
					<input class=button type="reset" name="reset" value="<? echo $t_btnresetform ?>">
				</td></tr>			
			
			</table>

			</form>

			<br><br>
			
		</td></tr>
	</table>

</td></tr>

<tr><td class=border>

<?
    include("include/footer.php");
?>

</td></tr></table>



</body>

</html>
