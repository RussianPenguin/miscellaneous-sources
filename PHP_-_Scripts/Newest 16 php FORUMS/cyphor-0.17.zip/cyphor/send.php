<?
    // send.php         Nachrichten erstellen
    // Alex Suzuki, erstellt am 7. Oktober 2000
    //
    // erh�lt alle seine Parameter von newmsg.php

    include("include/db_mysql.php");
    include("include/settings.php");
    include("include/global.php");

    /* Include the language file */
    $lang_file = "lang/" . $language . ".php";
    include($lang_file);

    function mail_reply_confirmation($email_addr, $your_msg_title, $author_name, $forum_name, $forum_id, $msg_id, $msg_title, $msg_data) {
        global $forum_url;
        global $admin_email;
        global $t_mail_header;
        global $t_mail_subject;
        global $t_mail_link;
		$add_headers = "From: $admin_email"; // Add a From: header

		$data = sprintf($t_mail_header, $author_name, $forum_name);
        $data = $data . "\n" . $t_mail_link . "\n\n";
        $data = $data . StripSlashes($msg_title) . "\n";
        $data = $data . $forum_url . "/" . "show.php?fid=" . $forum_id . "&id=" . $msg_id . "\n\n";
        
        $subject = sprintf($t_mail_subject, $your_msg_title);
        mail($email_addr, $subject, $data, $add_headers);
    }

    open_session();

    $login_error_message = "";

    if ($submit) {
        $back_page = "newmsg.php?fid=$fid";
        if ($pid) { $back_page = $back_page . "&pid=$pid"; }
        $back_page = $back_page . "&f_title=" . urlencode($f_title) . "&f_data=" . urlencode($f_data);

        if (!$login || !$pass) {
            exit_page_with_msg($terr_not_logged_in, "javascript:history.back()", $t_back_link);
            exit();
        }

        if ((!$f_title) || (!$f_data)) {
            exit_page_with_msg($terr_required_fields, $back_page, $t_back_link);
            exit();
        }

        if (!$fid) {
            exit_page_with_msg($terr_no_forum, "javascript:history.back()", $t_back_link);
            exit();
        }

        if (!login($login, $pass)) {            
            exit_page_with_msg($terr_login_failed, $back_page, $t_back_link);
            exit();
        }

        $db = new DB_Cyphor;
        $db->connect();
        $query = "SELECT db_table_name FROM forums WHERE id=$fid";
        $db->query($query);
        $db->next_record();
        $db_table_name = $db->f("db_table_name");
        $query = "SELECT id FROM users WHERE nick='$login'";
        $db->query($query);
        $db->next_record();
        $author_id = $db->f("id");

        if ($pid) {
            // Nachricht ist ein Reply, parent_id setzen, thread_id �bernehmen
            $query = "SELECT title, thread_id, mail_reply, author_id FROM $db_table_name WHERE id=$pid";
            $db->query($query);
            $db->next_record();
            $thread_id = $db->f("thread_id");
            $parent_mail_reply = $db->f("mail_reply");
            $parent_author_id = $db->f("author_id");
            $parent_msg_title = $db->f("title");
        } else {
            // Allocate new Thread ID;			
			$query = "SELECT thread_id FROM $db_table_name GROUP BY thread_id ORDER BY thread_id DESC LIMIT 0,1";
            $db->query($query);
            $db->next_record();
            $thread_id = $db->f("thread_id") + 1;
        }

        $time_stamp = time();

        if ($f_mailreply) $f_mailreply = 1;
        else $f_mailreply = 0;

        if ($f_with_signature) {
            // Attach signature if it is wished
            $query = "SELECT signature FROM user_settings WHERE id=$author_id";
            $db->query($query);
            $db->next_record();
            $f_data = $f_data . "\n" . $db->f("signature");
        }

        $f_data = AddSlashes($f_data);
        $f_title = AddSlashes($f_title);
        $hostname = getShortHostname();

        $query = "INSERT INTO $db_table_name (id, parent_id, thread_id, author_id, date, title, data, mail_reply, hostname) VALUES('', '$pid', '$thread_id', '$author_id', '$time_stamp', '$f_title', '$f_data', '$f_mailreply', '$hostname')";
        $db->query($query);

        $query = "SELECT id FROM $db_table_name WHERE thread_id='$thread_id' AND date='$time_stamp' AND parent_id='$pid' AND author_id='$author_id' AND title='$f_title' AND data='$f_data' AND mail_reply='$f_mailreply'";
        $db->query($query);
        $db->next_record();
        $id = $db->f("id");

        if (($pid) && ($parent_mail_reply) && ($parent_author_id != $author_id)) {
            // Send mail confirmation, if wished
            $query = "SELECT email FROM users WHERE id=$parent_author_id";
            $db->query($query);
            $db->next_record();
            $parent_email = $db->f("email");
            $query = "SELECT name FROM forums WHERE id=$fid";
            $db->query($query);
            $db->next_record();
            $for_name = $db->f("name");
            mail_reply_confirmation($parent_email, StripSlashes($parent_msg_title), $login, $for_name, $fid, $id, StripSlashes($f_title), StripSlashes($f_data));
        }

        // Increment User's total posts
        $query = "UPDATE users SET total_posts=total_posts+1 WHERE id=$author_id";
        $db->query($query);
        $query = "UPDATE users SET last_post=" . time() . " WHERE id=$author_id";
        $db->query($query);

		$query = "SELECT id FROM $db_table_name WHERE ((date='$time_stamp') AND (author_id='$author_id'))";
		$db->query($query);
		$db->next_record();

        $exit_link_url = "show.php?fid=$fid&id=" . $db->f("id");
        exit_page_with_msg($t_message_posted, $exit_link_url, $t_view_your_message);
        exit();
    }
?>
