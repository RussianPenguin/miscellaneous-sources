<table border=0 cellspacing=0 cellpadding=2 width=100%>
	<tr><td class=controls width=50%>
	    <span class=b>
	    <?
	        print "<a class=controls href=\"index.php\">" . $t_forums_overview . "</a> | ";
	
	        if ((!$login) || (!$pass)) {
	        	print "<a class=controls href=\"index.php\">" . $t_login . "</a> | ";
	            print "<a class=controls href=\"register.php\">" . $t_register . "</a> | ";
	            print "<a class=controls href=\"lostpwd.php\">" . $t_lost_password . "</a> ";
	        } else {
	            print "<a class=controls href=\"profile.php\">" . $t_edit_profile . "</a> | ";
	            print "<a class=controls href=\"index.php?logout=logout\">" . $t_logout . "</a> ";
	        }
	
			if ($admin)
	        	print "| <a class=controls href=\"admin/index.php\">" . $t_administration . "</a>";
	    ?>
	  </span>
	</td><td class=controls align=right width=50%>
		<span class=s>
		<a class=controls href="http://www.cynox.ch/cyphor/">Cyphor</a>
		<?
			if ($cyphor_ver) {
				?> (Release: <? echo $cyphor_ver; ?>, PHP <? echo phpversion() ?>) <?
			}
		?>
		</span>		
	</td></tr>
</table>
