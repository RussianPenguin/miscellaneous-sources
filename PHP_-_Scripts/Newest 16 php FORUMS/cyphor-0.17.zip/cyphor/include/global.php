<?
	function HighlightURLs($msg_data) { 
		return ereg_replace('(h?[tf]tp://[-~a-zA-Z_0-9/.+;%&?|=:]+)([^-~a-zA-Z_0-9/.+%&?|=:]|$)', '<A HREF="\1" TARGET="_blank">\1</A>\2', $msg_data); 
	} 

	function random_password() {
		/* 
			Pronouncable random password, borrowed by Olivier Mueller,
			Omnis Internet Services, http://www.omnis.ch
		*/
	    srand(time());
	    $cons = "bcdfghjklmnpqrstvwxz"; 
	    $voy = "eaiou"; 
	    $chi = "123456789"; 
	    $spe = ".;,-.;,-";
	
	    $new_passwd = substr($cons, rand(0,(strlen($cons)-1)), 1) .
	    substr($voy, rand(0,(strlen($voy)-1)), 1) .
	    substr($cons, rand(0,(strlen($cons)-1)), 1) .
	    substr($voy, rand(0,(strlen($voy)-1)), 1) .
	    substr($spe, rand(0,(strlen($spe)-1)), 1) .
	    substr($chi, rand(0,(strlen($chi)-1)), 1) .
	    substr($chi, rand(0,(strlen($chi)-1)), 1) .
	    substr($cons, rand(0,(strlen($cons)-1)), 1);
		return $new_passwd;
	}

	function getShortHostname() {
		$HOSTNAME_FIELD_LENGTH = 30; // length for hostname in MySQL table
		if (getenv("REMOTE_HOST")) {			
			$host = getenv("REMOTE_HOST");
			$host = strstr($host, "."); // Get something like .freesurf.ch from dialup.freesurf.ch
			$host = substr($host, 1, 26); // Cut it off 
			$host = "---." . $host;
			return $host;
		} else {
			// Remote address is 15 chars max.
			return getenv("REMOTE_ADDR");
		}
	}

	function num_users_online() {
		$db = new DB_Cyphor;
		$db->connect();
		$time = time();
		$del_time = $time - (5*60); # 5 MINUTES
		$ip	= getenv(REMOTE_ADDR);
		
		# clean up old entries
		$query = "DELETE FROM useronline WHERE (time<'$del_time')";
		$db->query($query);
		
		# SELECT TREATS MULTIPLE IDENTICAL ROWS AS ONE
		$query = "SELECT DISTINCT ip FROM useronline";
		$db->query($query);
		return $db->num_rows();
	}	
	
	function self_count_page($time, $ip) {
		$db = new DB_Cyphor;
		$db->connect();
		$query = "INSERT INTO useronline VALUES('$time', '$ip')";
		$db->query($query);
	}

    function exit_page_with_msg($msg, $link_url, $link_title) {
        printf("<html><head><title>%s</title><link rel=\"stylesheet\" href=\"cyphor.css\" type=\"text/css\"></head>", $msg);
        printf("<body bgcolor=\"#FFFFFF\" text=\"#000000\"><span class=h>%s</span><br>", $msg);
        printf("<span class=t><a href=\"%s\">%s</a></span></body></html>", $link_url, $link_title);
    }

	function nice_short_date($time_stamp) {
		global $timezone_inc;
		return date("F d, Y - H:i", $time_stamp + $timezone_inc);
	}

    function nice_date($time_stamp) {
        global $timezone_inc;
        return date("D, d. M - H:i", $time_stamp + $timezone_inc);
    }

    function open_session() {
        session_start();
        session_register("pass");
        session_register("login");
        session_register("admin");
        session_register("moderator");
        
        session_register("collapse");
    }

	function is_admin($nick) {
		$db = new DB_Cyphor;
		$db->connect();
		$query = "SELECT g.allow_admin AS adm FROM users AS u, groups AS g WHERE (u.group_id=g.id) AND (u.nick='$nick')";
		$db->query($query);
		$db->next_record();
		return $db->f("adm");
	}
	
	function is_moderator($nick) {
		$db = new DB_Cyphor;
		$db->connect();
		$query = "SELECT g.allow_moderate AS mod FROM users AS u, groups AS g WHERE (u.group_id=g.id) AND (u.nick='$nick')";
		$db->query($query);
		$db->next_record();
		return $db->f("mod");
	}

	function login($login, $password) {
		global $admin;
		global $moderator;
		
		$db = new DB_Cyphor;
		$db->connect();
		$query = "SELECT password FROM users WHERE nick='$login'";
		$db->query($query);
		if (!$db->num_rows()) { # USER DOES NOT EXIST
			session_destroy();
			exit_page_with_msg("User does not exist!", "index.php", "Login");
			exit();
		} else { # USER EXISTS
			$db->next_record();
			if (!strcmp(crypt($password, $login), $db->f("password"))) { # LOGIN SUCCESSFUL
				$admin = is_admin($login);
				$moderator = is_moderator($login);
				return 1;
			} else {
				session_destroy();
				exit_page_with_msg("Wrong password!", "index.php", "Login");
				exit();
			}
		}
	}    

   
    function delete_old_threads($days, $forum) {
	    $db = new DB_Cyphor;
    	$db->connect();
    	$db2 = new DB_Cyphor;
    	$db2->connect();
    	$db3 = new DB_Cyphor;
    	$db3->connect();    	
    	$now = time();
    	$day = 60*60*24;    	
    	$expiry_date = $now - ($days * $day);

		if ($forum == "all") {
			# EXPIRE THREADS FROM ALL OF FORUMS
			$query = "SELECT db_table_name FROM forums";
			$db->query($query);
			
			$total_deleted = 0;
			
			while ($db->next_record()) {
				$table = $db->f("db_table_name");
				
				$query = "SELECT thread_id FROM $table WHERE (date < $expiry_date) AND (parent_id=0)";									
				$db2->query($query);
				$total_deleted = $total_deleted + $db2->num_rows();
				while ($db2->next_record()) {
					$del_query = "DELETE FROM $table WHERE thread_id=" . $db2->f("thread_id");
					$db3->query($del_query);
				}
			}
			
	    	return $total_deleted;
	    } else {
	    	# EXPIRE THREADS FROM forum_id = $forum
	    	$query = "SELECT db_table_name FROM forums WHERE id=$forum";
	    	$db->query($query);
	    	$db->next_record();
	    	$table = $db->f("db_table_name");

			$query = "SELECT thread_id FROM $table WHERE (date < $expiry_date) AND (parent_id=0)";									
			$db2->query($query);
			$total_deleted = $db2->num_rows();
			while ($db2->next_record()) {
				$del_query = "DELETE FROM $table WHERE thread_id=" . $db2->f("thread_id");
				$db3->query($del_query);
			}
	    	
	    	return $total_deleted;
    	}
    }

    function jump_control() {
        $db = new DB_Cyphor;
        $db->connect();
        ?>
			<form action="show.php" method="POST"><select class=formbox name="fid" size="1"><option value="">Jump to...<option value="">----------
			<?
				$query = "SELECT id, name FROM forums ORDER BY id ASC";
				$db->query($query);
				while ($db->next_record()) {
					print "<option value=" . $db->f("id") . ">" . $db->f("name") . "</option>";
				}
			?>
			</select> <input class=button type="submit" name="submit" value="GO"></form>
        <?
    }
    
    $cyphor_ver = "0.17";
?>