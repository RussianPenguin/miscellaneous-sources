<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
/*
Led Forums Install Script
*/

require('../config.inc.php');

if(trim($QUERY_STRING) != 'install') {
	?>
					<html>
					<head>
					<title>Ledscripts.com Forums - Beta 1</title>
					<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
					</head>

					<body bgcolor="#000033" text="#FFFFFF" link="#CCCCCC" vlink="#CCCCCC" alink="#999999">
							<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
					  <tr>
						<td width="50%"> 
						<a href="index.php"><img src="../images/logo.gif" border=0></a>			 </td>
						<td width="50%"> 

				  <table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr> 
					  <td> 
						<div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="3">LedForums 
						  Beta 1 Install Script</font></div>
					  </td>
					</tr>
				  </table>
						</td>
					  </tr>
				 <tr>
				<td><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="http://www.ledscripts.com">Ledscripts.com</a></font></td>
			  </tr>
					</table>
					<hr width="90%" size="1" noshade>
			 <table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
			  <tr>
				<td width="100%" align="right"> 
				  <div align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
					Welcome to the <b>LedForums </b>Install Script. Please fill a username/password for the administrator below.
					<br>
					<font size="1">Note: These forums are in beta stage. While they shouldn't 
					cause any problems with your system, we accept no responsibility for what 
					might happen</font></font></div>
				</td>
			  </tr>
			 </table>
			<table width="90%" border="0" cellspacing="0" cellpadding="0" align="center">
			  <tr>
				<td> 
				  <div align="center"> 
					<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
					  <form action="<?=$PHP_SELF?>?install" method=post>
					  Username:<br>
					  <input type=text name=username><br>
					  Password:<br>
					  <input type=text name=password><br>
					  <input type=submit value="Install!">
					  </form>
					  </font>
					</div>
				</td>
			  </tr>
			</table>
				<center>
						   <table width="90%" border="0" cellspacing="1" cellpadding="1">
							 <tr>
				  <td width="100%" align="right"> <font face="Verdana, Arial, Helvetica, sans-serif" size="2">Please 
					Delete the script (install.php) after you install the forums.</font></td>
				</tr>
						   </table>
					<hr width="90%" size="1" noshade>
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="1">Powered by <a href="http://www.ledscripts.com">Led-Forums</a><br>
			  Copyright <a href="mailto:ledjon@ledscripts.com">Jon Coulter</a>, 2000</font> 
			</center></body>
		  </html>
	<?
} else {

if(empty($username) || empty($password)) {
	lederror("You need to fill in the username and password fields.");
}

		mysql_query("CREATE TABLE $tables[flist] (
					   id int(11) DEFAULT '0' NOT NULL auto_increment,
					   name varchar(255) NOT NULL,
					   description text NOT NULL,
					   moderator_id int(11) DEFAULT '0' NOT NULL,
					   PRIMARY KEY (id)
					)") or lederror(mysql_error());


		# --------------------------------------------------------
		#
		# Table structure for table 'ledforums_icons'
		#

		mysql_query("CREATE TABLE $tables[icon] (
		   id int(11) DEFAULT '0' NOT NULL auto_increment,
		   url varchar(255) NOT NULL,
		   replace_text varchar(255) NOT NULL,
		   PRIMARY KEY (id)
		)") or lederror(mysql_error());


		# --------------------------------------------------------
		#
		# Table structure for table 'ledforums_posts'
		#

		mysql_query("CREATE TABLE $tables[posts] (
		   id int(11) DEFAULT '0' NOT NULL auto_increment,
		   parent_id int(11) DEFAULT '0' NOT NULL,
		   forum_id int(11) DEFAULT '0' NOT NULL,
		   poster_id int(11) DEFAULT '0' NOT NULL,
		   headline varchar(255) NOT NULL,
		   body longtext NOT NULL,
		   unixtime int(11) DEFAULT '0' NOT NULL,
		   icon_id int(11) DEFAULT '0' NOT NULL,
		   sig tinyint(4) DEFAULT '0' NOT NULL,
		   PRIMARY KEY (id)
		)") or lederror(mysql_error());


		# --------------------------------------------------------
		#
		# Table structure for table 'ledforums_style_settings'
		#

		mysql_query("CREATE TABLE $tables[style] (
		   id tinyint(4) DEFAULT '0' NOT NULL auto_increment,
		   background varchar(255) NOT NULL,
		   image_url varchar(255) NOT NULL,
		   background_image_url varchar(255) NOT NULL,
		   table_width varchar(255) NOT NULL,
		   table_top_background varchar(255) NOT NULL,
		   first_alt_colum_bg varchar(255) NOT NULL,
		   second_alt_colum_bg varchar(255) NOT NULL,
		   forum_name varchar(255) NOT NULL,
		   header longtext NOT NULL,
		   footer longtext NOT NULL,
		   copyright_text longtext NOT NULL,
		   text_color varchar(255) NOT NULL,
		   link_color varchar(255) NOT NULL,
		   vlink_color varchar(255) NOT NULL,
		   alink_color varchar(255) NOT NULL,
		   font varchar(255) NOT NULL,
		   PRIMARY KEY (id)
		)") or lederror(mysql_error());


		# --------------------------------------------------------
		#
		# Table structure for table 'ledforums_threads'
		#

		mysql_query("CREATE TABLE $tables[threads] (
		   id int(11) DEFAULT '0' NOT NULL auto_increment,
		   forum_id int(11) DEFAULT '0' NOT NULL,
		   post_id int(11) DEFAULT '0' NOT NULL,
		   update_time int(11) DEFAULT '0' NOT NULL,
		   closed tinyint(4) DEFAULT '0' NOT NULL,
		   mail tinyint(4) DEFAULT '0' NOT NULL,
		   PRIMARY KEY (id)
		)") or lederror(mysql_error());


		# --------------------------------------------------------
		#
		# Table structure for table 'ledforums_users'
		#

		mysql_query("CREATE TABLE $tables[user] (
		   id int(11) DEFAULT '0' NOT NULL auto_increment,
		   username varchar(255) NOT NULL,
		   password varchar(255) NOT NULL,
		   email varchar(255) NOT NULL,
		   homepage varchar(255) NOT NULL,
		   icq varchar(255) NOT NULL,
		   sig text NOT NULL,
		   uncrypt_pass varchar(255) DEFAULT '0' NOT NULL,
		   auth tinyint(4) DEFAULT '0' NOT NULL,
		   status int(11) DEFAULT '0' NOT NULL,
		   PRIMARY KEY (id)
		)") or lederror(mysql_error());


		mysql_query("INSERT INTO $tables[style] VALUES ( '1', '000033', 'images/logo.gif', '', '90%', '330000', '333333', '000000', 'You Forum Name', '', '', 'Copyright <a href=\"http://www.ledscripts.com\">Jon Coulter</a>', 'FFFFFF', 'CCCCCC', 'CCCCCC', '999999', 'Verdana, Arial, Helvetica, sans-serif')") or lederror(mysql_error());

		mysql_query("INSERT INTO $tables[icon] VALUES ( '1', 'images/smile.gif', ':)')") or lederror(mysql_error());
		
		mysql_query("INSERT INTO $tables[user] (username, password, uncrypt_pass, auth) VALUES ('$username', '".md5($password)."', '$password', '1')") or lederror(mysql_error());
											@fopen("http://www.ledscripts.com/ledforums/installed.php?url=http://".$HTTP_HOST.$PHP_SELF, "r");
		?>
			Congrats! Forums Installed! <a href="index.php">Login and start Administrating!</a><br>
			<b>Delete install.php right now!</b><br>
			</small>Note: Once you log in, you'll be taken to your forum's main page. You'll need to go to /admin/index.php manually to start working with the forums.</small>
		<?
}

?>