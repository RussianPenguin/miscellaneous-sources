<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
// Require
require('../config.inc.php');

	// Make sure they're logged in and admin
	if(!$HTTP_COOKIE_VARS['username'] || get_user_data($user_id,"auth") != 1) {
		?>
			<form action="../log.php?login" method=post>
			Username:<br><input type=text name=username><br>  
			Password:<br><input type=password name=password> <small><a href="../misc.php?a=password">Forget Your Password?</a></small><br>
			<input type=submit value="Login">
			</form>
		<?
		exit;
	}

if(isset($a)) {
	if(function_exists($a)) {
		$a();
	} else {
		start();
	}
} else {
	start();
}

// Start function
function start() {
	//Globals
	global $PHP_SELF, $tables;
	
	// print the menu
	menu();
	
	print "Please choose an option from the menu above.";
	
}

// Style Settings
function style() {
	global $PHP_SELF, $tables;
	
	$tbl_data = style_settings();
	
	menu();
	
	?>
		<form action="<?=$PHP_SELF?>?a=exec_style" method=POST>
			Background Color: <input type="text" name="background" value="<?=$tbl_data[background]?>"><br>
			Background Image: <input type="text" name="background_image_url" value="<?=$tbl_data[background_image_url]?>"><br>
			Logo URL: <input type="text" name="image_url" value="<?=$tbl_data[image_url]?>"><br>
			Table Width: <input type="text" name="table_width" value="<?=$tbl_data[table_width]?>"><br>
			Table Top BG Color: <input type="text" name="table_top_background" value="<?=$tbl_data[table_top_background]?>"><br>
			First Alt BG Color: <input type="text" name="first_alt_colum_bg" value="<?=$tbl_data[first_alt_colum_bg]?>"><br>
			Second Alt BG Color: <input type="text" name="second_alt_colum_bg" value="<?=$tbl_data[second_alt_colum_bg]?>"><br>
			Forum Name: <input type="text" name="forum_name" value="<?=$tbl_data[forum_name]?>"><br>
			Header:<br> <textarea name="header" cols=40 rows=5><?=$tbl_data[header]?></textarea><br>
			Footer:<br> <textarea name="footer" cols=40 rows=5><?=$tbl_data[footer]?></textarea><br>
			Copyright Text:<br> <textarea name="copyright_text" cols=40 rows=5><?=$tbl_data[copyright_text]?></textarea><br>
			Font Color: <input type="text" name="text_color" value="<?=$tbl_data[text_color]?>"><br>
			Link Color: <input type="text" name="link_color" value="<?=$tbl_data[link_color]?>"><br>
			VLink Color: <input type="text" name="vlink_color" value="<?=$tbl_data[vlink_color]?>"><br>
			ALink Color: <input type="text" name="alink_color" value="<?=$tbl_data[alink_color]?>"><br>
			Font Face: <input type="text" name="font" value="<?=$tbl_data[font]?>"><br>
			<input type=submit value="Modify Settings">
		</form>
	<?
}

// Exec Style settings
function exec_style() {
	global $tables;
	global $background, $image_url, $background_image_url, $table_width, $table_top_background, $first_alt_colum_bg;
	global $second_alt_colum_bg, $forum_name, $header, $footer, $copyright_text, $text_color, $link_color, $vlink_color, $alink_color, $font;
	
	mysql_query("UPDATE $tables[style] SET
					background = '$background', 
					image_url = '$image_url',
					background_image_url = '$background_image_url',
					table_width = '$table_width',
					table_top_background = '$table_top_background',
					first_alt_colum_bg = '$first_alt_colum_bg',
					second_alt_colum_bg = '$second_alt_colum_bg',
					forum_name = '$forum_name',
					header = '$header',
					footer = '$footer',
					copyright_text = '$copyright_text',
					text_color = '$text_color',
					link_color = '$link_color',
					vlink_color = '$vlink_color',
					alink_color = '$alink_color',
					font = '$font'
				 WHERE id = 1") or lederror(mysql_error());
	
	style();					
}

// Forums Menu
function forums() {
	global $tables, $fid, $PHP_SELF;
	
	menu();
	
	if(!$fid) {
		$query = mysql_query("SELECT * FROM $tables[flist] ORDER BY id") or lederror(mysql_error());
		
		echo "Existing Forums:\n";
		echo "<ul>";
		
		while($row = mysql_fetch_object($query)) {
			echo "<li><a href='$PHP_SELF?a=forums&fid=$row->id'>$row->name</a> [ Moderator: ".get_user_data($row->moderator_id, "username")." ]</li>\n";
			
			if(!empty($row->description)) {
				echo "<ul><li><b>Description:</b><br>$row->description</li></ul>\n";
			}
		}
		
		echo "</ul>";

			?>
				<form action="<?=$PHP_SELF?>?a=new_forum" method=post>
					<b>New Forum</b><br>
					Forum Name: <input type=text name=name size=30><br>
					Forum Description:<br>
						<textarea name=description cols=30 rows=7></textarea><br>
					Moderator:
					<select name="moderator_id">
			<?
			
			$query = mysql_query("SELECT * FROM $tables[user] ORDER BY username") or lederror(mysql_error());
			while($row = mysql_fetch_object($query)) {
				echo "<option value=\"$row->id\">$row->username</option>\n";
			}
			
			?>
					</select><br>
					<input type=submit value="Add New Forum">
					</form>
			<?
		
	} else {
		// View the stats for one forum
		$forum_row = mysql_fetch_object(mysql_query("SELECT * FROM $tables[flist] WHERE id = $fid"));

			?>
				<form action="<?=$PHP_SELF?>?a=mod_forum&fid=<?=$forum_row->id?>" method=post>
					<b><?=$forum_row->name?></b><br>
					Forum Name: <input type=text name=name size=30 value="<?=$forum_row->name?>"><br>
					Forum Description:<br>
						<textarea name=description cols=30 rows=7><?=$forum_row->description?></textarea><br>
					Moderator:
					<select name="moderator_id">
			<?
			
			$query = mysql_query("SELECT * FROM $tables[user] ORDER BY username") or lederror(mysql_error());
			while($row = mysql_fetch_object($query)) {
				if($forum_row->moderator_id == $row->id) {
					echo "<option value=\"$row->id\" selected>$row->username</option>\n";
				} else {
					echo "<option value=\"$row->id\">$row->username</option>\n";
				}
			}
			
			?>
					</select><br>
					<input type=checkbox name=delete value=1> Delete Forum?<br>
					<input type=submit value="Modify <?=$forum_row->name?>">
					</form>
			<?
	}
}

// Add New Forum
function new_forum() {
	global $tables, $name, $moderator_id, $description, $PHP_SELF;
	
	mysql_query("INSERT INTO $tables[flist] (name, description, moderator_id) VALUES ('$name', '$description', '$moderator_id')") or lederror(mysql_error());
	
	forums();
}

// Mod/Delete forums
function mod_forum() {
	global $tables, $name, $moderator_id, $description, $delete, $fid;
	
	if($delete == 1) {
		mysql_query("DELETE FROM $tables[flist] WHERE id = $fid") or lederror(mysql_error());
	} else {
		mysql_query("UPDATE $tables[flist] SET name = '$name', description = '$description', moderator_id = '$moderator_id' WHERE id = $fid") or lederror(mysql_error());
	}
	
	header("Location: $PHP_SELF?a=forums");
}

// Icons
function icons() {
	global $tables, $PHP_SELF;
	
	menu();
	
	$query = mysql_query("SELECT * FROM $tables[icon]") or lederror(mysql_error());
	
		?>
			<form action="<?=$PHP_SELF?>?a=exec_icons" method=post>
		<?
		
		while($row = mysql_fetch_object($query)) {
			echo "Text To Replace: <input type=text name=\"replace_text[$row->id]\" value=\"$row->replace_text\" size=5> | Image URL: <input type=text name=\"url[$row->id]\" value=\"$row->url\" size=40> | <input type=checkbox name='delete[$row->id]' value=1> Delete?<br>\n";
		}
		
		?>
			<b>New Icon:</b><br>
			Text To Replace: <input type=text name="new_text" size=5> | Image URL: <input type=text name="new_url" size=40><br>
			<input type=submit value="Do It!">
			</form>
		<?
}

// Finish messing with the icons
function exec_icons() {
	global $tables, $delete, $replace_text, $url, $new_text, $new_url;
	
	foreach($replace_text as $key => $val) {
		if($delete[$key] == 1) {
			// Delete the icon
			mysql_query("DELETE FROM $tables[icon] WHERE id = $key") or lederror(mysql_error());
		} else {
			// Update
			mysql_query("UPDATE $tables[icon] SET replace_text = '$replace_text[$key]', url = '$url[$key]' WHERE id = $key") or lederror(mysql_error());
		}
	}
	
	// New Icon
	if(!empty($new_text) && !empty($new_url)) {
		mysql_query("INSERT INTO $tables[icon] (replace_text, url) VALUES ('$new_text', '$new_url')") or lederror(mysql_error());
	}
	
	icons();
}

// Menu
function menu() {
	?>
	<center><a href="index.php?a=style">Style Settings</a> | <a href="index.php?a=forums">Work with Forums</a> | <a href="index.php?a=icons">Work with Icons</a></center>
	<?
}

?>