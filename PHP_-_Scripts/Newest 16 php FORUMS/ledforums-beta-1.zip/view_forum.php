<?php
 /*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
$first=time();
 //Require
 require("config.inc.php");
 
 //If there's no ID entered, redirect them to the main listing.
 if(empty($id)){header("Location: index.php\n\n");}
 
 $tbl_data=style_settings();
 
 $result=mysql_query("SELECT * FROM $tables[flist] WHERE id=$id");
 
 $mid = mysql_result($result,0,"moderator_id");
 
 $moderator = get_user_data($mid,"username");
 $moderator_id = get_user_data($mid,"id");
 
 //Load the Top of the Page
   $forum_name=mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$id"),0,"name");
   $top_message="<a href=\"index.php\">$tbl_data[forum_name]</a> | $forum_name";
 load_top();
 
 ?>
 <table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr><td width="50%">
  <font face="<? echo $tbl_data['font'] ?>" size="2">
        <? if(!empty($moderator)){echo "Forum Moderator: <a href=\"profile.php?id=$moderator_id\">$moderator</a>";} ?>
  </td>
  <td width="50%" align="right">
  <font face="<? echo $tbl_data['font'] ?>" size="2">
      <a href="post.php?a=new_post&forum=<? echo $id; ?>">New Topic</a>
  </td></tr>
  
 </font>
 </table>
 
<table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="1" cellpadding="1">
        <tr> 
          <td width="15" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"><font color="#<? echo $tbl_data['table_top_background'] ?>">aa</font></td>
          <td width="35%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Topic</font></td>
          <td width="15%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"> 
            <div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2">Author</font></div>
          </td>
          <td width="15%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"> 
            <div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2">Replies</font></div>
          </td>
          <td width="35%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"> 
            <div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2">Last Post</font></div>
          </td>
        </tr>
 <?php
 
	if(empty($limit)) {
		$limit = 0;
	}
 
 	//List all the topics
    $query="SELECT * FROM $tables[threads] WHERE forum_id=$id ORDER BY update_time DESC LIMIT $limit,30";
    $result=mysql_query($query);
    $number=mysql_numrows($result);
    
    $i=0;
    while($i<$number){
      $start_post=mysql_result($result,$i,"post_id");
      $closed=mysql_result($result,$i,"closed");
      
      //Get that message's id and headline
      $message=mysql_query("SELECT * FROM $tables[posts] WHERE id=$start_post");
        $post_id=mysql_result($message,0,"id");
        $poster_id=mysql_result($message,0,"poster_id");
        $headline=mysql_result($message,0,"headline");
        $unixtime=mysql_result($message,0,"unixtime");
        $icon_id=mysql_result($message,0,"icon_id");
      
      $icon=icon_index($icon_id);
      
      $author=get_user_data($poster_id,"username");
      $authorid=get_user_data($poster_id,"id");
      
      $q=mysql_query("SELECT * FROM $tables[threads] WHERE post_id=$post_id ORDER BY update_time DESC") or lederror(mysql_error());
      $reply_number=mysql_numrows($q);
        if($reply_number==0)
         {
          $last_time=$unixtime;
         } else {
          $last_time=mysql_result($q,0,"update_time");
         }
         
      $n=mysql_numrows(mysql_query("SELECT * FROM $tables[posts] WHERE parent_id=$post_id ORDER BY unixtime"));

    //Page #'s
    $total_posts=mysql_numrows(mysql_query("SELECT * FROM $tables[posts] WHERE parent_id=$post_id"));
    $n_pages=$total_posts/$q_limit;
    $n_pages=ceil($n_pages);
    
    $page_n='';
    if($n_pages>1) {
    $page_n=$page_n."(Page: ";
      for($ci=1;$ci<=$n_pages;$ci++)
       {
         if($ci==1) {
          $page_n=$page_n."<a href=\"view_thread.php?id=$post_id\">$ci</a> ";
         } else {
          $page_n=$page_n."<a href=\"view_thread.php?id=$post_id&qleft=".($q_limit * ($ci-1))."\">$ci</a> ";
         }
       }
     $page_n=$page_n.")";
    }

 ?>
        <tr> 
          <td width="15" bgcolor="#<? echo $tbl_data['first_alt_colum_bg'] ?>"><img src="<? echo $icon ?>"></td>
          <td width="35%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg'] ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><a href="view_thread.php?id=<? echo $post_id ?>"><? echo $headline ?></a><? if($closed==1) {echo " (Closed Thread)";} ?> <? echo $page_n; ?></font></td>
          <td width="15%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg'] ?>" valign="middle"> 
            <div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2"><a href="profile.php?id=<?echo $authorid ?>"><? echo $author ?></a></font></div>
          </td>
          <td width="15%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg'] ?>" valign="middle"> 
            <div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2"><? echo $n ?></font></div>
          </td>
          <td width="35%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg'] ?>" valign="middle">
            <div align="left"><font face="<? echo $tbl_data['font'] ?>" size="1"><? echo date("F j, Y",$last_time); ?>,
              <? echo date("h:i A",$last_time) ?></font></div>

          </td>
        </tr>
 <?php
    $i++;
    }
 ?>
      </table>
    </td>
  </tr>
</table>
               <table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="1" cellpadding="1" align="center">
                 <tr><td width="100%" align="right">
                   <font face="<? echo $tbl_data['font'] ?>" size="2">
                  	<a href="<?=$PHP_SELF?>?id=<?=$id?>&limit=<? echo ($limit + 30); ?>">Next 30 Posts</a>
                  </td></tr>
               </table>
 <?php
 
 load_bottom();

 mysql_close();

?>