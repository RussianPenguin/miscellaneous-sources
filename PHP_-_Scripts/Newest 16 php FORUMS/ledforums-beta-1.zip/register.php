<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
  //Require
  require("config.inc.php");
  
  load_top();
  
  if($QUERY_STRING=='reg'){reg();}else{start();}

function start() {
    $tbl_data=style_settings();
  ?>
  <form action="register.php?reg" method=POST>
<table width="450" border="0" cellspacing="2" cellpadding="0" align="center">
  <tr> 
    <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">User 
      Name *</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <input type="text" name="username" size="30" maxlength="40">
      </font></td>
  </tr>
  <tr> 
    <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Password *</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <input type="password" name="password" size="30" maxlength="40">
      </font></td>
  </tr>
  <tr> 
    <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">E-mail 
      Address *</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <input type="text" name="email" size="30" maxlength="40">
      </font></td>
  </tr>
  <tr> 
    <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Homepage</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <input type="text" name="homepage" size="30" maxlength="40">
      </font></td>
  </tr>
  <tr> 
    <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">ICQ 
      Number</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <input type="text" name="icq" size="30" maxlength="40">
      </font></td>
  </tr>
  <tr> 
    <td width="100%" valign="top" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Signature</font></td>
    <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
      <textarea name="sig" cols="30" rows="5"  wrap="VIRTUAL"></textarea>
      </font></td>
  </tr>
</table>
<center><input type=submit value="Register"></form></center>
    <?php
}

function reg() {
    //Globals
    global $username,$password,$email,$homepage,$icq,$sig,$tables;

    if(empty($username)){lederror("Please Enter a Username");}
    if(empty($password)){lederror("Please Enter a Password");}
    if(empty($email)){lederror("Please Enter an E-mail address");}
    
    $result=mysql_query("SELECT * FROM $tables[user] WHERE username='$username'");
    if(mysql_numrows($result)>0){lederror("Username Taken<br>Please Choose Another");}
    
    $md5pass=md5($password);
    mysql_query("INSERT INTO $tables[user] (username,password,email,homepage,icq,sig,uncrypt_pass) VALUES ('$username','$md5pass','$email','$homepage','$icq','$sig','$password')") or lederror(mysql_error());
    
    $tbl_data=style_settings();
    echo "<font face=\"$tbl_data[font]\" size=\"2\"><center>User Created. <a href=\"log.php\">Login</a></center></font>";

}
  
  load_bottom();
  
  mysql_close();
?>