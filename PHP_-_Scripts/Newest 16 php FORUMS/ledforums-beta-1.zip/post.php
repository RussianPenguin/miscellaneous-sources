<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
  //Require
  require("config.inc.php");
  
  //Check the Action
  if(!empty($a)){$a();}else{header("Location: index.php");}
  
//New Post
function new_post() {
    global $PHP_SELF,$HTTP_COOKIE_VARS,$forum,$tables;
    
    $tbl_data = style_settings();
    
    $forum_name = mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum"),0,"name");
    
    load_top();
      ?>
      <center>
      <form action="<? echo $PHP_SELF ?>?a=post_new&forum=<? echo $forum; ?>" method=POST>
      <table width="90%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Forum</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><? echo $forum_name; ?></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Username</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><? if(empty($HTTP_COOKIE_VARS["username"])){?>Username:<br><input type=text name=username><br>  Password:<br><input type=password name=password> <small><a href="misc.php?a=password">Forget Your Password?</a></small><?}else{echo $HTTP_COOKIE_VARS['username'];} ?></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2">Icon</font></td>
	  <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2">
       <?
    //Icons
    $iq=mysql_query("SELECT * FROM $tables[icon]") or lederror(mysql_error());
    $icount=mysql_numrows($iq);
    
    $ii=0;
    $ci=1;
    while($ii<$icount) {
      if($ii==0){$checked=' checked';}else{$checked='';}
      echo "<input type=radio name=icon value='".mysql_result($iq,$ii,"id")."'$checked><img src='".mysql_result($iq,$ii,"url")."'> | ";
       if($ci>2){
        echo "<br>";
        $ci=0;
       }
      $ci++;
      $ii++;
    }
       ?>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2">Topic</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><input type=text name="topic"></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Message</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><textarea name=message rows=7 cols=40></textarea></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Options</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><input type=checkbox name=sig value=1>Include Signature<br></font></td>
        </tr>
      </table>
      <? if(empty($HTTP_COOKIE_VARS["username"])){ ?><input type=hidden name=login value=1><? } ?> 
      <input type=submit value="Post Thread"><input type=reset value="Clear Fields">
      </from>
      </center>
      <?
    load_bottom();
}

//Add the New Post to the Database
function post_new() {
    global $login,$username,$password,$forum,$user_id,$topic,$message,$sig,$mail,$tables,$icon;
    
    //Check for login
    if($login==1){$user_id=login_user($username,$password);}
    
    //Check Fields
    if(empty($topic)){lederror("Please Enter a Topic $topic");}
    if(empty($message)){lederror("Please Enter a Message");}
    if($sig!=1){$sig=0;}
    if($mail!=1){$mail=0;}
    if(empty($user_id)){lederror("You're not logged in. The cookie may have expired.");}
    
    $unixtime=time();
    
    //Add data to the Posts table
    mysql_query("INSERT INTO $tables[posts] (forum_id,poster_id,headline,body,unixtime,icon_id,sig) VALUES ('$forum','$user_id','$topic','$message','$unixtime','$icon','$sig')") or lederror(mysql_error());
    $post_id=mysql_insert_id();
    
    //Add data to the threads table
    mysql_query("INSERT INTO $tables[threads] (forum_id,post_id,update_time,mail) VALUES ('$forum','$post_id','$unixtime','0')") or lederror(mysql_error());
    
    //Increment the poster's post count
    mysql_query("UPDATE $tables[user] SET status=status+1 WHERE id='$user_id'") or lederror(mysql_error());
    
    //Forward to the new thread just created
    header("Location: view_thread.php?id=$post_id");
}

//Reply to a Post
function reply() {
    global $PHP_SELF,$HTTP_COOKIE_VARS,$tables,$thread,$forum,$post_id;
    
    if(mysql_result(mysql_query("SELECT * FROM $tables[threads] WHERE id=$thread"),0,"closed")==1){lederror("Thread is closed. Nice Try.");}
    
    $tbl_data=style_settings();
    
    $topic=mysql_result(mysql_query("SELECT * FROM $tables[posts] WHERE id=$post_id"),0,"headline");
    
    load_top();
      ?>
      <center>
      <form action="<? echo $PHP_SELF ?>?a=post_reply&thread=<? echo $thread; ?>&post_id=<? echo $post_id; ?>&forum=<? echo $forum; ?>" method=POST>
      <table width="90%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Topic</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><? echo $topic; ?></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Username</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><? if(empty($HTTP_COOKIE_VARS["username"])){?>Username:<br><input type=text name=username><br>  Password:<br><input type=password name=password> <small><a href="misc.php?a=password">Forget Your Password?</a></small><?}else{echo $HTTP_COOKIE_VARS['username'];} ?></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Message</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><textarea name=message rows=7 cols=40></textarea></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Options</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><input type=checkbox name=sig value=1>Include Signature</font></td>
        </tr>
      </table>
      <? if(empty($HTTP_COOKIE_VARS["username"])){ ?><input type=hidden name=login value=1><? } ?> 
      <input type=submit value="Post Reply"><input type=reset value="Clear Fields">
      </from>
      </center>
      <?
    load_bottom();
}

//Add the New Post to the Database
function post_reply() {
    global $PHP_SELF,$login,$username,$password,$thread,$user_id,$message,$sig,$tables,$post_id;

    // Do a rig here
    $PHP_SELF = preg_replace("/post.php$/i", "", $PHP_SELF);
    
    //Check for login
    if($login==1){$user_id=login_user($username,$password);}
    
    //Check Fields
    if(empty($message)){lederror("Please Enter a Message");}
    if($sig==1){$fsig=1;}else{$fsig=0;}
    if(empty($user_id)){lederror("You're not logged in. The cookie may have expired.");}
    
    $unixtime=time();
    
    //Add data to the Posts table
    mysql_query("INSERT INTO $tables[posts] (parent_id,forum_id,poster_id,headline,body,unixtime,icon_id,sig) VALUES ('$post_id','$forum','$user_id','','$message','$unixtime','1','$fsig')") or lederror(mysql_error());
    
    //Update data in the threads table
    mysql_query("UPDATE $tables[threads] SET update_time='$unixtime' WHERE id=$thread") or lederror(mysql_error());
    
    //Increment the poster's post count
    mysql_query("UPDATE $tables[user] SET status=status+1 WHERE id='$user_id'") or lederror(mysql_error());
	
	/*
	// See if we need to send an email
	if(@mysql_result(@mysql_query("SELECT * FROM $tables[threads] WHERE id = $thread"), 0, 'email') == 1) {
		$uid = @mysql_result(@mysql_query("SELECT * FROM $tables[posts] WHERE post_id = (SELECT post_id FROM $tables[threads] WHERE id = $thread)"), 0, 'poster_id');
		
		$query = mysql_query("SELECT * FROM $tables[user] WHERE id = $user_id") or lederror(mysql_error());
		$row = mysql_fetch_object($query);
		
		mail($row->email, "Reply to post", "This is an E-Mail to inform you that someone has replied to your post at http://$HTTP_HOST$PHP_SELF?thread=$thread");
		
		// Update so they don't get more replies
		@mysql_query("UPDATE $tables[threads] SET email = 0 WHERE id = $thread");
	}
	*/
	
    //Forward to the new thread just created
    header("Location: view_thread.php?id=$post_id");
}

//Edit Message Form
function edit() {
    global $id,$tables,$forum,$thread,$HTTP_COOKIE_VARS;
    
    $tbl_data=style_settings();
    
    //Get the Post
    $result=mysql_query("SELECT * FROM $tables[posts] WHERE id=$id");
    
    //Print the Data Into a table
    load_top();
      ?>
      <center>
      <form action="<? echo $PHP_SELF ?>?a=post_edit&thread=<? echo $thread; ?>&id=<? echo $id; ?>&forum=<? echo $forum; ?>" method=POST>
      <table width="90%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Username</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><? if(empty($HTTP_COOKIE_VARS["username"])){?>Username:<br><input type=text name=username><br>  Password:<br><input type=password name=password> <small><a href="misc.php?a=password">Forget Your Password?</a></small><?}else{echo $HTTP_COOKIE_VARS['username'];} ?></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Message</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><textarea name=message rows=7 cols=40><? $body=mysql_result($result,0,"body"); $body=str_replace("</textarea>","</text-area>",$body); echo $body; ?></textarea></font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Options</font></td>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="middle"><font face="<? echo $tbl_data['font'] ?>" size="2"><input type=checkbox name=sig value=1<? if(mysql_result($result,0,"sig")=='1'){echo " checked";} ?>>Include Signature<br><input type=checkbox name=delete value=1>Delete Message</a></font></td>
        </tr>
      </table>
      <? if(empty($HTTP_COOKIE_VARS["username"])){ ?><input type=hidden name=login value=1><? } ?> 
      <input type=submit value="Update Message"><input type=reset value="Clear Fields">
      </from>
      </center>
      <?
    load_bottom();
}

//Put the Data Back into the databsae
function post_edit() {
    global $forum,$id,$thread,$tables,$user_id,$delete,$message,$sig,$username,$login,$password;
    
    //Check for login
    if($login==1){$user_id=login_user($username,$password);}
    
    //Clean it a little
    $message=str_replace("</text-area>","</textarea>",$message);
    
    //Make sure the User had permission to edit this message
    $mod_id=mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum"),0,"moderator_id");
    
    //Check for Administrator or Message Poster
    if(get_user_data($user_id,"auth")==1){$admin_true=1;}
    if($user_id==mysql_result(mysql_query("SELECT * FROM $tables[posts] WHERE id=$id"),0,"poster_id")){$owner_true=1;}
    
    //Do the check
    if($mod_id!=$user_id && $admin_true!=1 && $owner_true!=1){lederror("You're Not Authorized to perform this action.");}
    
    //If no Error, check for delete... otherwise update the data
    if($delete==1)
     {
      if(mysql_result(mysql_query("SELECT * FROM $tables[posts] WHERE id=$id"),0,"parent_id")==0){lederror("You cann't delete the Topic this way");}
      mysql_query("DELETE FROM $tables[posts] WHERE id=$id") or lederror(mysql_error());
     } else {
      if($sig!=1){$sig=0;}
      $message=$message."\n\n[ Edit by $username: ".date("m/d/Y h:i:s A")." ]";
      mysql_query("UPDATE $tables[posts] SET body='$message', sig='$sig' WHERE id=$id") or lederror(mysql_error());
     }
     
    //Redirect
    header("Location: view_thread.php?id=$thread");
     
}

//This function log's in the user from the post page.
function login_user($username,$password) {
    global $tables;
    $password = md5($password);
    
    $result = mysql_query("SELECT * FROM $tables[user] WHERE username='$username' AND password='$password'") or lederror(mysql_error());
    $number = mysql_numrows($result);
    
    if($number!=1){lederror("Bad Username or Password");}
    
    $lifetime = time() + 86400 * 356;
    
    setcookie("username",$username, $lifetime);
    setcookie("user_id",mysql_result($result,0,"id"), $lifetime);
    
    return mysql_result($result,0,"id");
}
?>