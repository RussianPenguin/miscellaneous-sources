<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
  //Require
  require("config.inc.php");
  
  //I probably should add a check to this, but I don't care right now.
  
    //check permissions
    $mod_id=mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum"),0,"moderator_id");
    
    //Check for Administrator
    $admin=get_user_data($user_id,"auth");
    if($admin==1){$admin_true=1;}
    
    //Do the check
    if($mod_id!=$user_id && $admin_true!=1){lederror("You're Not Authorized to perform this action");}
    
    //Delete the Thread
    mysql_query("DELETE FROM $tables[threads] WHERE id = $thread") or lederror(mysql_error());
    mysql_query("DELETE FROM $tables[posts] WHERE id = $post_id") or lederror(mysql_error());
    mysql_query("DELETE FROM $tables[posts] WHERE parent_id = $post_id") or lederror(mysql_error());
    
    header("Location: view_forum.php?id=$forum");
?>