<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
  //Require
  require("config.inc.php");

  if($a){$a();}
  elseif($id){view_profile();}
  else{start();}
  
//Allow User to edit profile
function start() {
   global $username,$user_id,$tables,$PHP_SELF;

   if(empty($username)){lederror("You must be logged in to edit your profile.");}
   
   $result=mysql_query("SELECT * FROM $tables[user] WHERE id=$user_id") or lederror(mysql_error());
   
   $tbl_data=style_settings();
   load_top();
     ?>
     <form action="<? echo $PHP_SELF; ?>?a=update&id=<? echo $user_id ?>" method=POST>
   <table width="450" border="0" cellspacing="2" cellpadding="0" align="center">
     <tr> 
       <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">User 
         Name</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <? echo mysql_result($result,0,"username") ?>
         </font></td>
     </tr>
     <tr> 
       <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">New Password</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <input type="password" name="password" size="30" maxlength="40">
         </font></td>
     </tr>
     <tr> 
       <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">E-mail 
         Address *</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <input type="text" name="email" size="30" maxlength="40" value="<? echo mysql_result($result,0,"email") ?>">
         </font></td>
     </tr>
     <tr> 
       <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Homepage</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <input type="text" name="homepage" size="30" maxlength="40" value="<? echo mysql_result($result,0,"homepage") ?>">
         </font></td>
     </tr>
     <tr> 
       <td width="100%" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">ICQ 
         Number</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <input type="text" name="icq" size="30" maxlength="40" value="<? echo mysql_result($result,0,"icq") ?>">
         </font></td>
     </tr>
     <tr> 
       <td width="100%" valign="top" bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Signature</font></td>
       <td bgcolor="<? echo $tbl_data['first_alt_colum_bg'] ?>"> <font face="<? echo $tbl_data['font'] ?>" size="2"> 
         <textarea name="sig" cols="30" rows="5"  wrap="VIRTUAL"><? echo mysql_result($result,0,"sig") ?></textarea>
         </font></td>
     </tr>
   </table>
   <center><input type=submit value="Update Profile"></form></center>
    <?php
    
    load_bottom();
}

//Update the Profile
function update() {
   global $user_id,$password,$tables,$homepage,$icq,$email,$sig,$HTTP_REFERER;
   
   if(empty($email)){lederror("You must enter an e-mail address.");}
   
   if(!empty($password)){
     $md5pass=md5($password);
     mysql_query("UPDATE $tables[user] SET password='$md5pass',uncrypt_pass='$password',homepage='$homepage',icq='$icq',email='$email',sig='$sig' WHERE id=$user_id") or lederror(mysql_error());
   }else{
     mysql_query("UPDATE $tables[user] SET homepage='$homepage',icq='$icq',email='$email',sig='$sig' WHERE id=$user_id") or lederror(mysql_error());
   }
   
   //Redirect
   header("Location: $HTTP_REFERER");
}

//Show a User's profile
function view_profile() {
    global $tables,$id;
    
    $tbl_data = style_settings();
    
    load_top();
      $result = mysql_query("SELECT * FROM $tables[user] WHERE id=$id") or lederror(mysql_error());
      $number =  mysql_num_rows($result);
    ?>
		<table width="<? echo $tbl_data['table_width']; ?>" border="0" cellspacing="1" cellpadding="0" align="center">
        <tr> 
          <td width="18%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg']; ?>" valign="middle"><font face="<? echo $tbl_data['font']; ?>" size="2">Username</font></td>
          <td width="72%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg']; ?>" valign="middle"> 
            <font face="<? echo $tbl_data['font']; ?>" size="2"><? echo mysql_result($result,0,"username"); ?></font>
          </td>
        </tr>
        <tr> 
          <td width="18%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg']; ?>" valign="middle"><font face="<? echo $tbl_data['font']; ?>" size="2">E-mail</font></td>
          <td width="72%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg']; ?>" valign="middle"> 
            <font face="<? echo $tbl_data['font']; ?>" size="2"><? echo "<a href=\"mailto:".mysql_result($result,0,"email")."\">".mysql_result($result,0,"email")."</a>"; ?></font>
          </td>
        </tr>
        <tr> 
          <td width="18%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg']; ?>" valign="middle"><font face="<? echo $tbl_data['font']; ?>" size="2">ICQ Number</font></td>
          <td width="72%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg']; ?>" valign="middle"> 
            <font face="<? echo $tbl_data['font']; ?>" size="2"><? echo mysql_result($result,0,"icq"); ?></font>
          </td>
        </tr>
        <tr> 
          <td width="18%" bgcolor="#<? echo $tbl_data['second_alt_colum_bg']; ?>" valign="middle"><font face="<? echo $tbl_data['font']; ?>" size="2">Homepage</font></td>
          <td width="72%" bgcolor="#<? echo $tbl_data['first_alt_colum_bg']; ?>" valign="middle"> 
            <font face="<? echo $tbl_data['font']; ?>" size="2"><? echo "<a href=\"".mysql_result($result,0,"homepage")."\">".mysql_result($result,0,"homepage")."</a>"; ?></font>
          </td>
        </tr>
</table>
     <?

    load_bottom();
}
?>