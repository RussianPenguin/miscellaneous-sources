/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/

INSTALL:
	- Open config.inc.php and set the appropriate variables (very easy).
	- Upload all the files to its own directory.
	- Go to http://www.yoursite.com/directory/admin/install.php
	- Enter the username and password of the person that will be the administrator
	  - Notice: you can only have ONE administrator, so I suggest you make this a real user.
	  - You can make this whatever you want, there are no preset. This will register this user too.
	- After everything goes OK (I hope), delete install.php from the /admin/ folder.

* That's It *

UPGRADES:
	None, initial release.
	
SUPPORT:
	Now since this readme is pretty thin, you might want to seek support at
	http://www.ledscripts.com/ledforums/
	
Have fun!