<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
  //Require
  require("config.inc.php");
  
  //Check to see if the user's loged in.
  if($QUERY_STRING=='login'){process();}
    elseif(empty($HTTP_COOKIE_VARS['username'])){login();}
    elseif($QUERY_STRING=='logout'){logout();}
  else{loggedin();}
  
//Login Page
function login() {
  global $PHP_SELF;
  
  $tbl_data = style_settings();
  
  load_top();
  
  ?>
  <center>
  <font face="<? echo $tbl_data['font'] ?>" size="2">
  <form action="<? echo "$PHP_SELF?login"; ?>" method=POST>
  Username:<br><input type=text name=username><br>
  Password:<br><input type=password name=password><br>
  <input type=submit value="Login">
  </form>
  </font>
  </center>
  <?php
  
  load_bottom();
}

//Do the login
function process() {
    global $username,$password,$tables;
    
    $password=md5($password);
    
    $result=mysql_query("SELECT * FROM $tables[user] WHERE username='$username' AND password='$password'");
    $number=mysql_numrows($result);
    
    if($number!=1){log_error("Bad Username or Password");}
    
    $lifetime = time() + 86400 * 356;
    
    setcookie("username",$username, $lifetime);
    setcookie("user_id",mysql_result($result,0,"id"), $lifetime);
    
    header("Location: index.php?top_message=Logged In");
}

//Logout User
function logout() {
    setcookie("username");
    setcookie("user_id");
    
    header("Location: index.php?top_message=Logged Out");
}

//Logged In Function
function loggedin() {
    load_top();
        print_text("You are already logged in.<br><a href=\"log.php?logout\">Click Here to Log Out</a>");
    load_bottom();
}

//Error for Login
function log_error($text) {
    load_top();
      print_text($text);
    load_bottom();
    exit;
}

?>