<?php
 /*
 	LedForums Beta 1
 	By: Jon Coulter (ledjon@ledjon.com)
 	Homepage: http://www.ledscripts.com
 	Working Example: http://www.ledscripts.com/ledforums/
 	
 	About:
 		One day I decided to throw together some forums since it seemed
 		that all the other free php forums on the net where pretty poor.
 			(http://www.phpbb.com seems to be the best I've found)
 		Note, however, that I started these and did most of the coding
 		back in my PHP-newbieist -- so they're rather sloppy and may have
 		several bugs in them. I have a total rewrite planned, but not started
 		yet.
 	
 	Copyright:
 		ALL code in all of these files was written by scratch by me. Since
 		I'm considering this whole thing open source, you can use any of it
 		that you want, but please give credit if you release the script in any
 		way.
 		
 		Exception:
 			You may NOT sell any of the code in these scripts without first
 			getting permission from me. Most people wont try this, but I've got
 			to try :).
*/
 //Require
 require("config.inc.php");

 $tbl_data = style_settings();
 
 $oq_limit=$q_limit;
 
 $result=mysql_query("SELECT * FROM $tables[posts] WHERE id=$id");
 
 $topic = mysql_result($result,0,"headline");
 $body = mysql_result($result,0,"body");
 $time = mysql_result($result,$i,"unixtime");
 $forum_id = mysql_result($result,0,"forum_id");
 $static_forum_id = $forum_id;
 $sig = mysql_result($result,0,"sig");
 
 $thread=mysql_result(mysql_query("SELECT * FROM $tables[threads] WHERE post_id=$id"),0,"id");
 $closed=mysql_result(mysql_query("SELECT * FROM $tables[threads] WHERE post_id=$id"),0,"closed");
 
 $author_id		=mysql_result($result,0,"poster_id");
 $author		=get_user_data($author_id,"username");
 $author_admin	=get_user_data($author_id,"auth");
 $author_posts	=get_user_data($author_id,"status");
 $author_status	=get_user_data($author_id,"status");
 $author_sig	=get_user_data($author_id,"sig");
 
 // Author's Status
 if($author_status > 14) {
 	$author_status=1;
 } else {
 	$author_status=0;
 }
 
 if(mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum_id"),0,"moderator_id") == $author_id) {
 	$author_mod=1;
 } else {
	$author_mod=0;
 }
  
  if($sig==1){$body=$body."\n---------------\n".$author_sig;}
  $body = clean_data($body);
  $body = convert_smiles($body);
  // Clean the body a bit
	
 
 	//Load the Top of the Page
	$forum_name=mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum_id"),0,"name");
	$top_message="<a href=\"index.php\">$tbl_data[forum_name]</a> | <a href=\"view_forum.php?id=$forum_id\">$forum_name</a> | $topic";

    //Page #'s
    $total_posts = mysql_numrows(mysql_query("SELECT * FROM $tables[posts] WHERE parent_id=$id"));
    
    $n_pages = ceil($total_posts / $oq_limit);
    
    if($n_pages>1) {
    $top_message=$top_message." (Page: ";
      for($i=1;$i<=$n_pages;$i++)
       {
         if($i==1) {
          $top_message=$top_message."<a href=\"view_thread.php?id=$id\">$i</a> ";
         } else {
          $top_message=$top_message."<a href=\"view_thread.php?id=$id&qleft=".($oq_limit * ($i-1))."\">$i</a> ";
         }
       }
     $top_message=$top_message.")";
    }

 load_top();
 
 ?>
 <table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr><td width="100%" align="right">
  <font face="<? echo $tbl_data['font'] ?>" size="2">
      <? if($closed!=1){ ?>
      <a href="post.php?a=reply&thread=<? echo $thread ?>&post_id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Reply</a> | <a href="close.php?thread=<? echo $thread ?>&post_id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Close Thread</a> | <a href="delete.php?thread=<? echo $thread ?>&post_id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Delete Thread</a>
      <? } else { ?>
      Thread Closed | <a href="close.php?open=1&thread=<? echo $thread ?>&post_id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Open Thread</a> | <a href="delete.php?thread=<? echo $thread ?>&post_id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Delete Thread</a>
      <? } ?>
      
  </td></tr>
 </table>
<table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="1" cellpadding="1">
        <tr> 
          <td width="18%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Author</font></td>
          <td width="82%" bgcolor="#<? echo $tbl_data['table_top_background'] ?>"><font face="<? echo $tbl_data['font'] ?>" size="2">Topic: <? echo $topic ?></font></td>
        </tr>
        <? if(empty($qleft)) { ?>
        <tr> 
          <td bgcolor="#<? echo $tbl_data['first_alt_colum_bg'] ?>" width="18%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><b><? echo $author ?></b><br>
            <small><? if($author_admin==1){echo "Administrator";} elseif($author_mod==1){echo "Moderator";} elseif($author_status==1){echo "Member";} else {echo "Junior Member";} ?>
            <br>Posts: <? echo $author_posts ?>
            </small></font></td>
          <td bgcolor="#<? echo $tbl_data['first_alt_colum_bg'] ?>" width="82%" valign="top">
               <table width="100%" border="0" cellspacing="1" cellpadding="1">
                 <tr><td width="50%">
                   <font face="<? echo $tbl_data['font'] ?>" size="1"><? echo date("F j, Y, g:i A",$time); ?>
                 </td><td width="50%" align="right">
                   <font face="<? echo $tbl_data['font'] ?>" size="1"><a href="post.php?a=edit&thread=<? echo $id ?>&id=<? echo $id; ?>&forum=<? echo $forum_id; ?>">Edit Message</a> | <a href="profile.php?id=<? echo $author_id ?>" target="_blank">View User's Profile</a>
                 </td></tr>
               </table>
          <hr>
          <font face="<? echo $tbl_data['font'] ?>" size="2">
          <? echo $body ?>
          </font></td>
        </tr>
 <?php
  }
    //Set the Next rotation to the 2nd color
    $color=2;
    
    //Ok, that take care of the 1st post. All the others have to be done differently.
 
 //List all the posts
     $q_limit--;
   if(empty($qleft)){
     $query="SELECT * FROM $tables[posts] WHERE parent_id=$id ORDER BY unixtime ASC LIMIT 0,$q_limit";
   } else {
     $query="SELECT * FROM $tables[posts] WHERE parent_id=$id ORDER BY unixtime ASC LIMIT $qleft,$oq_limit";
   }
   
    $result=mysql_query($query);
    $number=mysql_numrows($result);
    
    $i=0;
    while($i<$number){
     $msg_id=mysql_result($result,$i,"id");
     $topic=mysql_result($result,$i,"headline");
     $body=mysql_result($result,$i,"body");
     $time=mysql_result($result,$i,"unixtime");
     $forum_id=mysql_result($result,$i,"forum_id");
     $sig=mysql_result($result,$i,"sig");
 
     $author_id		=mysql_result($result,$i,"poster_id");
     $author		=get_user_data($author_id,"username");
     $author_admin	=get_user_data($author_id,"auth");
     $author_posts	=get_user_data($author_id,"status");
     $author_status	=get_user_data($author_id,"status");
     $author_sig	=get_user_data($author_id,"sig");
     
     if($author_status>14){$author_status=1;}else{$author_status=0;}
 
     if(@mysql_result(mysql_query("SELECT * FROM $tables[flist] WHERE id=$forum_id"),0,"moderator_id")==$author_id)
      {
       $author_mod=1;
      } else {
       $author_mod=0;
      }

      if($sig==1){$body=$body."\n---------------\n".$author_sig;}
      $body = clean_data($body);
      $body = convert_smiles($body);
 ?>
        <tr> 
          <td bgcolor="#<? if($color==1){echo $tbl_data['first_alt_colum_bg'];}else{echo $tbl_data['second_alt_colum_bg'];} ?>" width="18%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><b><? echo $author ?></b><br>
            <small><? if($author_admin==1){echo "Administrator";} elseif($author_mod==1){echo "Moderator";} elseif($author_status==1){echo "Member";} else {echo "Junior Member";} ?>
            <br>Posts: <? echo $author_posts ?>
            </small></font></td>
          <td bgcolor="#<? if($color==1){echo $tbl_data['first_alt_colum_bg'];}else{echo $tbl_data['second_alt_colum_bg'];} ?>" width="82%" valign="top">
               <table width="100%" border="0" cellspacing="1" cellpadding="1">
                 <tr><td width="50%">
                   <font face="<? echo $tbl_data['font'] ?>" size="1"><? echo date("F j, Y, g:i A",$time); ?>
                 </td><td width="50%" align="right">
                   <font face="<? echo $tbl_data['font'] ?>" size="1"><a href="post.php?a=edit&thread=<? echo $id ?>&id=<? echo $msg_id; ?>&forum=<? echo $static_forum_id; ?>">Edit Message</a> | <a href="profile.php?id=<? echo $author_id ?>" target="_blank">View User's Profile</a>
                 </td></tr>
               </table>      
          <hr>
          <font face="<? echo $tbl_data['font'] ?>" size="2">
          <? echo $body ?>
          </font></td>
        </tr>
 <?php
    $i++;
    if($color==1){$color=2;}else{$color=1;}
    }
 ?>
      </table>
    </td>
  </tr>
</table>
 <?php
 
 //Check for a Next Link
 /*
  if(empty($qleft)) {
   $q_limit = $q_limit++;
   $q_left  = $q_limit;
   $q_limit = $q_limit  + $q_limit;
  } else {
   $q_limit = $qlimit++;
   $q_left  = $qlimit;
   $q_limit = $qlimit + $oq_limit;
  }
   
   if(mysql_numrows(mysql_query("SELECT * FROM $tables[posts] WHERE parent_id=$id LIMIT $q_left,$q_limit"))>0){
   ?>
   <center>
               <table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="1" cellpadding="1">
                 <tr><td width="100%" align="right">
                   <font face="<? echo $tbl_data['font'] ?>" size="1"><a href="view_thread.php?id=<? echo $id; ?>&qleft=<? echo $q_left; ?>&qlimit=<? echo $q_limit; ?>">Next</a>
                 </td></tr>
               </table>
   </center>
   <?
   }
 */

 $total_posts=mysql_numrows(mysql_query("SELECT * FROM $tables[posts] WHERE parent_id=$id"));
 $n_pages=$total_posts/$oq_limit;
 $n_pages=ceil($n_pages);
 
 ?>
   <center>
               <table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="1" cellpadding="1">
                 <tr><td width="100%" align="right">
                   <font face="<? echo $tbl_data['font'] ?>" size="2">
 <?

 if($n_pages>1) {
 echo "Page: ";
   for($i=1;$i<=$n_pages;$i++)
    {
      if($i==1) {
       echo "<a href=\"view_thread.php?id=$id\">$i</a> ";
      } else {
       echo "<a href=\"view_thread.php?id=$id&qleft=".($oq_limit * ($i-1))."\">$i</a> ";
      }
    }
 }
 
 ?>
                 </td></tr>
               </table>
 <?
 
 load_bottom();

 mysql_close();

?>