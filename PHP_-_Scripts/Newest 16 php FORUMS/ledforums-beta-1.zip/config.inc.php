<?php

//Variables
/* This is the hostname of your mysql server. Usually 'localhost' */
$hostname	= 'localhost';

/* This is the Username for mysql */
$sqluser	= 'username';

/* This is the Password for mysql */
$sqlpass	= 'password';

/* This is the database name that will store all the tables */
$dbName		= 'databasename';

$tables = array(
				// Users Table
				user		=> 'ledforums_users',
				
				// Style Table
				style		=> 'ledforums_style_settings',
				
				// Forum List table
				flist		=> 'ledforums_forum_list',
				
				// Posts Table
				posts		=> 'ledforums_posts',
				
				// Icons table
				icon		=> 'ledforums_icons',
				
				// Threads table
				threads		=> 'ledforums_threads'
			   );

// The number of posts to appear per-page when viewing a thread
$q_limit	= 15;

/*==============================================================*/
/*NO NEED TO EDIT BELOW THIS LINE!								*/
/*	BUT YOU CAN IF YOU WANT! :)									*/
/*==============================================================*/

if(is_file('admin/install.php')) {
	lederror('You MUST delete install.php from the /admin/ folder.');
}

// This is the variable for timing. No need to change it
$exec_time = explode(" ", microtime());
$exec_time = $exec_time[0] + $exec_time[1];

//Database Connection 
$lfdb = db_connect();

//Database Connection
function db_connect() {
    global $dbName,$sqluser,$sqlpass,$hostname;
    
    //Made the connection
    $handle = mysql_connect($hostname, $sqluser, $sqlpass) or lederror("Unable to connect to database");
    @mysql_select_db($dbName, $handle) or lederror("Unable to select database");
    
    return $handle;
}
 
//Error
function lederror($text) {
    echo "<center><font face=Arial size=2>$text</a></center>";
    exit;
}

//Page Top
function load_top() {
    global $PHP_SELF,$HTTP_COOKIE_VARS,$top_message;
    
    //Get the style settings
    $tbl_data = style_settings();
    
    ?>
		<html>
		<head>
		<title><? echo $tbl_data['forum_name'] ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		</head>

		<body bgcolor="#<? echo $tbl_data['background'] ?>" text="#<? echo $tbl_data['text_color'] ?>" link="#<? echo $tbl_data['link_color'] ?>" vlink="#<? echo $tbl_data['vlink_color'] ?>" alink="#<? echo $tbl_data['alink_color'] ?>"<? if(!empty($tbl_data[background_image_url])){echo " background=\"$tbl_data[background_image_url]\"";} ?>>
		<?=$tbl_data[header]?>
		<table width="<? echo $tbl_data['table_width'] ?>" border="0" cellspacing="0" cellpadding="0" align="center">
		  <tr>
			<td width="50%"> 
			<? if(!empty($tbl_data[image_url])){echo "<a href=\"index.php\"><img src=\"$tbl_data[image_url]\" border=0></a>";} ?>
			 </td>
			<td width="50%"> 
			  <table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr> 
				  <td>
					<div align="center"><font face="<? echo $tbl_data['font'] ?>" size="3"><? echo $tbl_data['forum_name'] ?></font></div>
				  </td>
				</tr>
				<tr> 
				  <td> 
					<div align="center"><font face="<? echo $tbl_data['font'] ?>" size="2"><a href="register.php">Register</a> | <a href="profile.php">Profile</a><!-- | <a href="search.php">Search</a> --> | <? if(empty($HTTP_COOKIE_VARS['username'])){echo "<a href=\"log.php\">Login</a>";}else{echo "<a href=\"log.php?logout\">Logout</a>";} ?></font></div>
				  </td>
				</tr>
			  </table>
			</td>
		  </tr>
  <?
  if(!empty($top_message)){
  ?>
 	 <tr><td><font face="<? echo $tbl_data['font'] ?>" size="1"><? echo $top_message; ?></font></td></tr>
  <?php
  }
  ?>
		</table>
		<hr width="<? echo $tbl_data['table_width'] ?>" size="1" noshade>
<?php
}

//Page Bottoms
function load_bottom() {
    global $exec_time, $tables;
    
    //Get the style settings
    $tbl_data = style_settings();
    
    $ftime = explode(" ", microtime());
    $ftime = $ftime[0] + $ftime[1];
    
    ?>
		<hr width="<? echo $tbl_data['table_width'] ?>" size="1" noshade>
		<div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
			<?=$tbl_data[copyright_text]?><br>
		  Powered  by <a href="http://www.ledscripts.com">Led-Forums</a> Beta 1<br>
		  Copyright <a href="mailto:ledjon@ledscripts.com">Jon Coulter</a>, 2000<br>
		  Page Generated in <b><? printf( "%1.4f", $ftime - $exec_time ); ?></b> seconds.
		  </font>
		  </div>
			<?=$tbl_data[footer]?>
		</body>
	  </html>
  
    <?php
}

//Get the style settings
function style_settings() {
    global $PHP_SELF,$tables,$dbName;
    static $tbl_data;

	// We're caching the style settings as well
	// No need to requery for everything
    if(empty($tbl_data)) {
		//Very cool way of getting the table's data
		$result = @mysql_query("SELECT * FROM $tables[style]");

		$fields = @mysql_list_fields("$dbName","$tables[style]") or lederror(mysql_error());
		$columns = @mysql_num_fields($fields);

		while ($row = mysql_fetch_array ($result)) {
			for ($i = 0; $i < $columns; $i++) {
				$field_name = mysql_field_name($fields, $i);
				$tbl_data[$field_name] = mysql_result($result,0,$field_name);
			}
		} //End Data Get
    }
    
    return $tbl_data;
}

//Get a user's data
function get_user_data($id,$field){
    global $tables;
    
    $result = @mysql_query("SELECT * FROM $tables[user] WHERE id=$id");
    
    if(@mysql_num_rows($result)>0){
    	$return = @mysql_result($result,0,$field) or mysql_error();
    } else {
    	$return = "No User Data, ID: $id";
    }
    
    return $return;
}

//Change Icon ID's into the image
function icon_index($id) {
    global $tables;
    
	$result = mysql_query("SELECT * FROM $tables[icon] WHERE id=$id") or lederror(mysql_error());    
    
    if(mysql_numrows($result)>0){
    	$return=mysql_result($result,0,"url") or lederror(mysql_error());
    } else { 
    	$return = "No User Data, ID: $id";
    }
    
    return $return;
}

//Clean Data
function clean_data($text) {
    $text = ereg_replace("<","&lt;",$text);
    #$text = nl2br($text);
    $text = str_replace("\n", "<br>", $text);
    $text = str_replace("\r", "", $text);
    $text = ereg_replace("\[code\](<br>)?","<blockquote>Code:<hr><pre><big>",$text);
    $text = ereg_replace("\[\/code\](<br>)?","</big></pre><hr></blockquote>",$text);
    $text = ereg_replace("\[quote\](<br>)?","<blockquote>Quote:<hr><b>",$text);
    $text = ereg_replace("\[\/quote\](<br>)?","</b><hr></blockquote>",$text);
    $text = preg_replace("/\[image\](.*)?\[\/image\]/","<img src=\"\\1\" border=\"0\">",$text);
    $text = preg_replace("/ http:\/\/(.*)? /"," <a href=\"http://\\1\" target=\"_blank\">http://\\1</a> ",$text);
    $text = preg_replace("/\[link\]([^\]]+)\[\/link\]/","<a href=\"\\1\" target=\"_blank\">\\1</a>",$text);	
    $text = preg_replace("/\[email\]([^\[]+)\[\/email\]/","<a href=\"mailto:\\1\">\\1</a>",$text);
    $text = preg_replace("/\[link=([^\]]+)\]([^\]]+)\[\/link\]/i","<a href=\"\\1\" target=\"_blank\">\\2</a>",$text);
	
    return $text;
}

//Convert Smiles
function convert_smiles($text = NULL) {
	global $tables;
	static $icons;

	// We're going to cache the icons in an array
	if(empty($icons)) {
		$query = mysql_query("SELECT * FROM $tables[icon]");
		while($row = mysql_fetch_object($query)) {
			$icons["$row->replace_text"] = "<img src=\"$row->url\">";
		}
	}
	
	foreach($icons as $key => $val) {
		$text = ereg_replace($key, $val, $text);
	}

	return $text;
}

//Print Text
function print_text($text) {
    $tbl_data = style_settings();
    
    echo "<center><font face=\"$tbl_data[font]\" size=2>$text</font></center>";
}

/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
 
?>