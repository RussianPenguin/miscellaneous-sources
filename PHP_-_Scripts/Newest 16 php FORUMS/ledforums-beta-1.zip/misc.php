<?php
/*
	LedForums Beta 1
	By: Jon Coulter (ledjon@ledjon.com)
	Homepage: http://www.ledscripts.com
	Working Example: http://www.ledscripts.com/ledforums/
	
	About:
		One day I decided to throw together some forums since it seemed
		that all the other free php forums on the net where pretty poor.
			(http://www.phpbb.com seems to be the best I've found)
		Note, however, that I started these and did most of the coding
		back in my PHP-newbieist -- so they're rather sloppy and may have
		several bugs in them. I have a total rewrite planned, but not started
		yet.
	
	Copyright:
		ALL code in all of these files was written by scratch by me. Since
		I'm considering this whole thing open source, you can use any of it
		that you want, but please give credit if you release the script in any
		way.
		
		Exception:
			You may NOT sell any of the code in these scripts without first
			getting permission from me. Most people wont try this, but I've got
			to try :).
*/
	//Require
	require("config.inc.php");
	
	//Check the Action
	if(!empty($a) && function_exists($a)) {
		$a();
	} else {
		header("Location: index.php");
	}

// Lost Password
function password() {
	global $PHP_SELF,$HTTP_COOKIE_VARS,$forum,$tables, $uname;
	
	$tbl_data = style_settings();
    
    load_top();
      ?>
      <center>
      <form action="<? echo $PHP_SELF ?>?a=exec_password" method=POST>
      <table width="90%" border="0" cellspacing="2" cellpadding="0">
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" width="20%" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2">Enter Your Username Below</font></td>
        </tr>
        <tr>
          <td bgcolor="#<? echo $tbl_data[first_alt_colum_bg]; ?>" valign="top"><font face="<? echo $tbl_data['font'] ?>" size="2"><input type="text" name="uname" size=35></font></td>
        </tr>
      </table>
      <input type=submit value="Send me my Password!"> <input type=reset value="Clear Field">
      </from>
      </center>
      <?
    load_bottom();
}

function exec_password() {
	global $PHP_SELF,$HTTP_HOST, $HTTP_COOKIE_VARS,$forum,$tables, $uname;
	
	$query = mysql_query("SELECT email, uncrypt_pass FROM $tables[user] WHERE username = '$uname'") or lederror(mysql_error());
	
	load_top();
	
	$tbl_data = style_settings();
	
	print "<font face='$tbl_data[font]' size=2><center>";
	
	if(mysql_num_rows($query) == 0) {
		print "Unable to find that Username!";
	} else {
		$row = mysql_fetch_object($query);
		
		// Fire off a cheap email
		mail($row->email, "Password Request.", "Below is your password for the forums at http://$HTTP_HOST$PHP_SELF\n\nUsername: $uname\nPassword: $row->uncrypt_pass");
		
		print "Password Sent to <b>$row->email</b>!";
	}
	
	load_bottom();
}

?>