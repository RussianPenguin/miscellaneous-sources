<?php

function print_header () {
?>
<html><head>
</head><style> A:link {font-family:arial;font-size:10pt;text-decoration:none;color:#0000ff;}
A:hover {font-family:arial;font-size:10pt;text-decoration:none;color:red;}";
A:visited {font-family:arial;font-size:10pt;text-decoration:underline;color:#0000ff;}
BODY {background-color:#e6e8fa;font-family:arial;font-size:10pt;color:#333300;}
TD {font-family:arial;font-size:10pt;color:#333300;}
</style><body>
<p align=right><font face="Impact" size=7>
<font color="bfbfbf">F</font><font color="aaaaaa">O</font><font color="959595">R</font><font color="7f7f7f">U</font><font color="aaaaaa">M</font>
</font>
<?php
}

function print_header2 () {
?>
<html><head>
<script language="javascript">
<!--
function is_ValidLogin (entry1) {
if (entry1.length==0 || entry1.length < 3) {
alert ('You must enter login name not less than 3 characters!');
document.reg.login.focus ();
} 
}
function is_ValidPass (entry2) {
if (entry2.length==0 || entry2.length < 6) {
alert ('You must enter password not less than 6 characters!');
document.reg.pass.focus ();
}
}
function verPasswd () {
if (document.reg.verpass.value !=document.reg.pass.value || document.reg.verpass.value==0) {
alert ("Error!This field must be the same as password field!");
document.reg.verpass.select ();
document.reg.verpass.focus ();
}
}

function true_Email (mail) {
if (mail.length==0) {
alert ('You must enter the E-mail value !');
document.reg.email.focus ();
} else if (mail.indexOf ('\@',0)==-1) {
alert ("Invalid E-mail address!The char '\@' is missing!");
document.reg.email.select ();
document.reg.email.focus ();
} else {
return true;
} 
}

//-->
</script>
</head><style> A:link {font-family:arial;font-size:10pt;text-decoration:none;color:#000080;}
A:hover {font-family:arial;font-size:10pt;text-decoration:none;color:red;}";
A:visited {font-family:arial;font-size:10pt;text-decoration:none;color:#808080;}
BODY {background-color:#e6e8fa;font-family:arial;font-size:10pt;color:#333300;}
TD {font-family:arial;font-size:10pt;color:#0000ff;}
</style><body>
<p align=right><font face="Impact" size=7>
<font color="bfbfbf">F</font><font color="aaaaaa">O</font><font color="959595">R</font><font color="7f7f7f">U</font><font color="aaaaaa">M</font>
</font>
<?php
}

function connect () {
$hostname="localhost:3306";
$user="root";
$password="xxxxxx";
$db="forum";

mysql_connect ($hostname,$user,$password);
$request=mysql_select_db ($db);
if (!mysql_connect) {
echo "Error: ".mysql_error ();
}
}
//////////////////////////////�����������/////////////////////////////////////////////////
if ($action=="register") { 
connect ();
if ($verify) {

$query="select id from info where name='$login'"; 
$result=mysql_query ($query); 
        
if (mysql_num_rows ($result)) {   
 print_header ();
 echo "<p align=center><b>Error!</b>";
 echo "<p>Name <b>".$login."</b> already exists.Please,go back and choose another name.";
 echo "<p><center><a href='forum.php?action=register'>Go back</a></center>";
} else {

$query="insert into info (name,password,email) values ('$login','$pass','$email')";
$result=mysql_query ($query);

print_header (); 
echo "<h3 align=center>Thank you,<font color='ff0000'>".$login."!</font></h3>";?>
<p>You are successfuly registered and your information added to our database.
<p>Please,remember your information.Only registered users may post messages and replies.
<p><font face='arial' size=2 color='0000ff'>Your login:</font>
<font face='arial' size=2 color='ff0000'><?php echo $login?></font><br>
<font face='arial' size=2 color='0000ff'>Password:</font>
<font face='arial' size=2 color='ff0000'><?php echo $pass?></font><br>
<font face='arial' size=2 color='0000ff'>E-mail:</font>
<font face='arial' size=2 color='ff0000'><?php echo $email?></font>
<p>Good luck!
<center><a href="forum.php">| Go to topics</a> |<a href="forum.php?action=add_new_top"> Post new topic</a> |</center>
<?php 
}
} else {
print_header2 ();
?>
<h2 align=center><font color="ff0000">Registration.</font></h2>
<p><font face="serif" size=2> Please,fill in the form below.
<p>You may use only english chars in your name,and name's length should be not less than 3 and 
not more than 15 characters.
<br>Remember:all form fields are case sensitive.It means the names <font face="arial" size=2
color="0000ff">name</font> and <font face="arial" size=2 color="0000ff">Name</font>
are different.
<p>Password's length should be not less than 6 characters.<br>
Don't forget to enter your e-mail address,you may need it if you'll forget your password.
<p><FORM ACTION="forum.php" METHOD="POST" name="reg">
<p align=right><a href="forum.php3">Home</a>
<center><TABLE BGCOLOR="bfbfbf">
<tr><td colspan=2>&nbsp;</td></tr>
<TR><TD><b>Login:</b><TD><INPUT TYPE="text" NAME="login" SIZE="20" maxlength="15" >&nbsp;&nbsp;
<TR><TD><b>Password:</b><TD><INPUT TYPE="password" NAME="pass" SIZE="20" onFocus="is_ValidLogin (this.form.login.value)";return true>&nbsp;&nbsp;
<TR><TD><b>Verify password:</b><TD><INPUT TYPE="password" NAME="verpass" SIZE="20" onFocus="is_ValidPass (this.form.pass.value)";return true>&nbsp;&nbsp;
<TR><TD><b>E-mail:</b><TD><INPUT TYPE="text" NAME="email" SIZE="20" onFocus="verPasswd ()";return true>&nbsp;&nbsp;
<tr><td colspan=2><input type="hidden" name="action" value="register">
<tr><td colspan=2><input type="hidden" name="verify" value="ok">
<TR><TD colspan=2><p><center><INPUT TYPE="submit" name="submit" VALUE="Submit" onMouseOver="true_Email (this.form.email.value)";return true></center>
<tr><td colspan=2>&nbsp;</table>
</form>
<?php
}        
}

//////////////////////////////////��������� ������////////////////////////////////////////
elseif ($action=="remind_pass") {
if ($email) {
connect ();

$query="select name,password from info where email='$email'"; 
$result=mysql_query ($query);

$row=mysql_fetch_array ($result);
$name=$row["name"];
$password=$row["password"];

if (mysql_num_rows ($result)) {
print_header ();
?>
<h3 align=center>Hello,<?php echo $name ?>!</h3>
<p>You entered valid e-mail address.
<p>Your login name:<font color="0000ff"><?php echo $name ?></font><br> 
Your password:<font color="0000ff"><?php echo $password ?></font>
<p><center>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |</center>
<?php
} else {
print_header ();
?>
<h3 align=center>Sorry!</h3>
<p>This e-mail address hasn't been found in our database.<br>
Please,verify your e-mail address an try again,or go to our registration page and register.
<p><center>| <a href='forum.php?action=remind_pass'>Go back</a> |<a href='forum.php?action=register'> Register</a> |</center>
<?php
}
} else {
print_header ();
?>
<p><h4 align=center>Please,enter your e-mail address,you provided while registered.</h4> 
<p><FORM ACTION="forum.php" METHOD="POST">
<p align=right><a href="forum.php3">Home</a>
<center><TABLE BGCOLOR="bfbfbf">
<tr><td colspan=2>&nbsp;
<TR><td><b>E-mail:</b><TD><INPUT TYPE="text" NAME="email" SIZE="20">&nbsp;&nbsp;
<tr><td colspan=2><input type="hidden" name="action" value="remind_pass">
<TR><TD colspan=3><p><center><INPUT TYPE="submit" VALUE="Submit"></center>
<?php
}
}
///////////////////////////////////������������� ���������///////////////////////////////
elseif ($action=="edit") {
if ($submit) {
connect ();
$date=date ( "Y-m-d H:i:s",mktime ());
$end="<hr>This message was edited by $nick $date.";
$post.=$end;
$posted=nl2br($post);
$posted=str_replace ("'"," ",$posted);

if ($type=="message") {
$query="select id from info where name='$name' and password='$passwd'";
$result=mysql_query ($query);

if (mysql_num_rows ($result) && $name==$nick) {
$query="update topics set message='$posted' where top_name='$top_name'";
$result=mysql_query ($query);
print_header ();
?>
<h3 align=center>Thank you,<font color='ff0000'><?php echo $nick ?></font>!</h3>
<p>Your message was changed.
<p><center>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |</center> 
<?php
} else {
print_header ();
?>
<h3 align=center>Error!</h3>
<p>This message cannot be edited.May be you entered incorrect nick or password,
or you are not an author of this message.
<p>Please,go back and try again.
<p><center>| <a href='javascript:history.back ()'> Go back</a>| <a href='forum.php'>Go to topics</a> |</center> 
<?php
}
} elseif ($type=="reply") { 
$query="select id from info where name='$name' and password='$passwd'";
$result=mysql_query ($query);

if (mysql_num_rows ($result) && $name==$nick) {
$query="update replies set reply='$post' where top_name='$top_name' and name='$nick' and reply_date='$reply_date'";
$result=mysql_query ($query);
print_header ();
?>
<h3 align=center>Thank you,<font color='ff0000'><?php echo $nick ?></font>!</h3>
<p>Your message was changed.
<p><center>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |</center> 
<?php
} else {
print_header ();
?>
<h3 align=center>Error!</h3>
<p>This message cannot be edited.May be you entered incorrect nick or password,
or you are not an author of this message.
<p>Please,go back and try again.
<p><center>| <a href='javascript:history.back ()'> Go back</a>| <a href='forum.php'>Go to topics</a> |</center> 
<?php
}
}
} else {
print_header ();
?>
<h3 align=center><font color="0000ff">Edit message.</font></h3>
<p align=right>| <a href='forum.php'>Go to topics</a> | <a href='forum.php?action=register'> Register</a> |
<p align=right><font color="0000ff">Only registered users may post messages in this forum.</font>

<p><form action="forum.php" name="editmsg" method="GET">
<table width=60% align=center bgcolor="aaaaaa">
<tr><td>&nbsp;
<tr><td><b>Your nick:</b><td><input type="text" name="name" size=20>
<tr><td><b>Your password:</b><td><input type="password" name="passwd" size=20>
<tr><td colspan=2>&nbsp;<b>Message:</b><p>&nbsp;&nbsp;<textarea cols=40 rows=15 WRAP 80="virtual" name="post">
<?php echo $message ?><br></textarea>
<tr><td colspan=2><input type="hidden" name="action" value="edit">
<tr><td colspan=2><input type="hidden" name="submit" value="1">
<tr><td colspan=2><input type="hidden" name="top_name" value="<?php echo $top_name ?>">
<tr><td colspan=2><input type="hidden" name="nick" value="<?php echo $nick ?>">
<tr><td colspan=2><input type="hidden" name="type" value="<?php echo $type ?>">
<tr><td colspan=2><input type="hidden" name="reply_date" value="<?php echo $reply_date ?>">
<tr><td colspan=2 align=center>&nbsp;<br><input type="submit" value="Submit"></table>
<?php
}
}
///////////////////////////////////����� �����//////////////////////////////////////////
elseif ($action=="add_new_top") {
connect ();
if ($test) {

$date=date ( "Y-m-d H:i:s",mktime ());
$topic=nl2br($message);
$topic=str_replace ("'"," ",$topic);
$theme=str_replace ('"'," ",$theme);
connect ();
$query="select id from info where name='$nick' AND password='$passwd'"; 
$result=mysql_query ($query);


if (mysql_num_rows ($result)) {
print_header ();

$query="insert into topics (top_name,name,message,post_date,last_reply) values ('$theme','$nick','$topic','$date','$date')";
$result=mysql_query ($query);

$query="update info set posts=posts+1 where name='$nick'";
$result=mysql_query ($query);

echo "<h3 align=center>Thank you,<font color='ff0000'>".$nick."!</font></h3>";
echo "<p>Your topic has been submitted.";
echo "<p><center>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |</center>";

} else {
print_header ();
?>
 <h2 align=center>Error!</h2>
 <p>You entered incorrect name or password.Please,go back and try again.
 <p><center>| <a href="forum.php?action=add_new_top">Go back</a> |
 <a href="forum.php?action=remind_pass">Forgot password?</a> |</center>
<?php
}
} else {
print_header ();
?>
<h3 align=center><font color="0000ff">New topic</font></h3>
<p align=right>| <a href='forum.php'>Go to topics</a> | <a href='forum.php?action=register'> Register</a> |
<p align=right><font color="0000ff">Only registered users may post messages in this forum.</font>

<p><form action="forum.php" name="newtop" method="POST">
<table width=60% align=center bgcolor="aaaaaa">
<tr><td>&nbsp;
<tr><td><b>Your nick:</b><td><input type="text" name="nick" size=20>
<tr><td><b>Your password:</b><td><input type="password" name="passwd" size=20>
<tr><td><b>Topic name:</b><td><input type="text" name="theme" size=20>
<tr><td colspan=2>&nbsp;<b>Message:</b><p>&nbsp;&nbsp;<textarea cols=40 rows=15 WRAP="VIRTUAL" name="message"></textarea>
<tr><td colspan=2><input type="hidden" name="action" value="add_new_top">
<tr><td colspan=2><input type="hidden" name="test" value="ok">
<tr><td colspan=2 align=center>&nbsp;<br><input type="submit" name="post" value="Submit"></table>
<?php
} 
}
/////////////////////////////�������� �� �����//////////////////////////////////////////

elseif ($action=="post_reply") {
if ($validate) {
connect ();
$date=date ( "Y-m-d H:i:s",mktime ());
$message1=nl2br($message);
$message1=str_replace ("'"," ",$message1);

$query="select id from info where name='$nick' AND password='$passwd'"; 
$result=mysql_query ($query); 

if (mysql_num_rows ($result)) {
print_header ();
$query="insert into replies (name,top_name,reply,reply_date) values ('$nick','$top_name','$message1','$date')";
$result=mysql_query ($query);

$query="update topics set replies=replies+1,last_reply='$date' where top_name='$top_name'";
$result=mysql_query ($query);

$query="update info set posts=posts+1 where name='$nick'";
$result=mysql_query ($query);

echo "<h3 align=center>Thank you,<font color='ff0000'>".$nick."!</font></h3>";
echo "<p>Your reply has been submitted.";
echo "<p><center>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |</center>";
} else {
print_header ();
?>
 <h2 align=center>Error!</h2>
 <p>You entered incorrect name or password.Please,go back and try again.
 <p><center>| <a href="forum.php?action=add_new_top">Go back</a> |
 <a href="forum.php?action=remind_pass">Forgot password?</a> |</center>
<?php
}
} else {
print_header ();
?>
<h3 align=center><font color="0000ff">Post reply.</font></h3>
<p align=right>| <a href='forum.php'>Go to topics</a> | <a href='forum.php?action=register'> Register</a> |
<p align=right><font color="0000ff">Only registered users may post messages in this forum.</font>

<p><form action="forum.php" name="reply" method="POST">
<table width=60% align=center bgcolor="aaaaaa">
<tr><td>&nbsp;
<tr><td><b>Your nick:</b><td><input type="text" name="nick" size=20>
<tr><td><b>Your password:</b><td><input type="password" name="passwd" size=20>
<tr><td colspan=2>&nbsp;<b>Message:</b><p>&nbsp;&nbsp;<textarea cols=40 rows=15 WRAP="VIRTUAL" name="message"></textarea>
<tr><td colspan=2><input type="hidden" name="action" value="post_reply">
<tr><td colspan=2><input type="hidden" name="top_name" value="<?php echo $top_name ?>">
<tr><td colspan=2><input type="hidden" name="validate" value="ok">
<tr><td colspan=2 align=center>&nbsp;<br><input type="submit" value="Submit"></table>
<?php
  }
}

////////////////////////////////������ ������////////////////////////////////////////////

elseif ($action=="read_topic") {
if ($top_name) {
connect ();

$query="select message,post_date,info.posts,info.email from topics,info where topics.name=info.name and topics.top_name='$top_name' and topics.name='$name'";
$result=mysql_query ($query);

$row=mysql_fetch_array ($result);
$message=$row["message"];
$post_date=$row["post_date"];
$posts=$row["posts"];
$email=$row["email"];
$message=str_replace ('"',"'",$message);
mysql_free_result ($result);

print_header (); 
?>
<p align=right>| <a href='forum.php'>Go to topics</a> |<a href='forum.php?action=add_new_top'> Post new topic</a> |
<a href='forum.php?action=post_reply&top_name=<?php echo $top_name ?>'> Post reply</a> |
<p><table cellspacing=0 cellpadding=5 border=1 width=100%> 
<tr><td align=center width=150 bgcolor="D5E6E1"><font face="Arial" size=2 color="808080">Author</font>
<td bgcolor="D5E6E1"><font face="serif" size=2 color="0000ff">Topic:</font><font face="serif" size=2 color="ff0000"><?php echo $top_name ?></font></td></tr>
<tr><td rowspan=2 bgcolor="D5E6E1" align=center><font face="serif" size=3 color="ff0000"><?php echo $name ?></font>
<br><font face="serif" size=2 color="0000ff">Posts:<?php echo $posts ?></font></td>
<td bgcolor="e6e8fa" height=30><font face="serif" size=1 color="000080">Posted:<?php echo $post_date ?></font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo $email ?>"><img src="email.gif" border=0></a>
&nbsp;&nbsp;<font face="serif" size=1 color="000080">E-mail </font><font face="serif" size=1 color="0000ff"><?php echo $name ?></font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forum.php?action=edit&top_name=<?php echo $top_name ?>&message=<?php echo $message ?>&nick=<?php echo $name ?>&type=message">
<img src="edit.gif" border=0></a>&nbsp;&nbsp;<font face="serif" size=1 color="000080">Edit message</font></td></tr>
<tr><td bgcolor="f7f7f7"><font face="serif" size=2 color="000080"><?php echo $message ?></font></td></tr></table>
<?php

$lines=20;
$begin=$page*$lines;
if (empty ($page)) {
$page=0;
}

$query="select replies.name,reply,reply_date,info.posts,info.email from replies,info where replies.name=info.name and replies.top_name='$top_name' order by reply_date limit $begin,$lines"; 
$result=mysql_query ($query);

while ($row=mysql_fetch_array ($result)) {
$nick=$row["name"];
$reply=$row["reply"];
$reply_date=$row["reply_date"];
$posts=$row["posts"];
$mail=$row["email"];
$reply=str_replace ('"',"'",$reply);

if (mysql_num_rows ($result)) {
?>
<table cellspacing=0 cellpadding=5 border=1 width=100%> 
<tr><td rowspan=2 bgcolor="e6e8fa" align=center width=150><font face="serif" size=2 color="0000ff">
<?php echo $nick ?></font><br><font face="serif" size=2 color="333300">Posts:<?php echo $posts ?></font></td>
<td bgcolor="e6e8fa" height=30><font face="serif" size=1 color="000080">Posted:<?php echo $reply_date ?></font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mailto:<?php echo $mail ?>"><img src="email.gif" border=0></a>
&nbsp;&nbsp;</font><font face="serif" size=1 color="000080">E-mail </font><font face="serif" size=1 color="0000ff"><?php echo $nick ?></font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="forum.php?action=edit&top_name=<?php echo $top_name ?>&message=<?php echo $reply ?>&nick=<?php echo $nick ?>&type=reply&reply_date=<?php echo $reply_date ?>">
<img src="edit.gif" border=0></a>&nbsp;&nbsp;<font face="serif" size=1 color="000080">Edit message</font></td></tr>
<tr><td bgcolor="f7f7f7"><font face="serif" size=2><?php echo $reply ?></td></tr></table>
<?php
          }
       }
$query="select COUNT(*) as count from replies where top_name='$top_name'";
$result=mysql_query ($query);
$items=mysql_fetch_array ($result);
$count=$items["count"];
$pages=ceil ($count/$lines);

if ($count>$lines) {
echo "<p align=right>";
for ($i=0;$i<$pages;$i++) {
echo "|<a href='forum.php?action=read_topic&top_name=".$top_name."&name=".$name."&page=".$i."'>".($i+1)."</a>";
           }
        }
     }
  }

//////////////////////////////////�������///////////////////////////////////////////////
else {
print_header (); 
?>
<h2 align=center><font color="0000ff">Webboard.</font></h2>
<p align=right>| <a href="forum.php?action=add_new_top">Post new topic</a> |
<a href="forum.php?action=register">Registration</a> |<a href="forum.php?action=remind_pass"> Forgot password?</a> |
<p><table cellspacing=0 cellpadding=5 border=1>
<tr bgcolor="D5E6E1"><td align=center width=300 height=50><font face="arial" size=2 color="0000ff">Topic name</font></td>
<td align=center width=120 height=50><font face="arial" size=2 color="0000ff">Topic starter</font></td>
<td align=center width=50 height=50><font face="arial" size=2 color="0000ff">Replies</font></td>
<td align=center width=120 height=50><font face="arial" size=2 color="0000ff">Posted</font></td>
<td align=center width=120 height=50><font face="arial" size=2 color="0000ff">Last reply</font></td>

<?php
connect ();
$lines=20;
$begin=$page*$lines;
if (empty ($page)) {
$page=0;
}

$query="select top_name,name,replies,post_date,last_reply from topics order by last_reply desc limit $begin,$lines";
$result=mysql_query ($query);

while ($row=mysql_fetch_array ($result)) {  
$name=$row["name"];
$top_name=$row["top_name"];
$replies=$row["replies"];
$post_date=$row["post_date"];
$last_reply=$row["last_reply"];

echo "<tr bgcolor='e6f8fa'><td><a href='forum.php?action=read_topic&top_name=$top_name&name=$name'>".$top_name."</a>";
echo "</td><td>".$name."</td><td align=center>".$replies."</td><td>".$post_date."</td><td>".$last_reply."</td></tr>";
}
echo "</table>"; 

$query="select COUNT(*) as count from topics";
$result=mysql_query ($query);
$items=mysql_fetch_array ($result);
$count=$items["count"];
$pages=ceil ("$count/$lines");

if ($count>$lines) {
echo "<p align=right>";
for ($i=0;$i<$pages;$i++) {
echo "|<a href='forum.php?page=".$i."'>".($i+1)."</a>";
        }
    } 
 }
?>