
/******************************************************************************\
*       This is a part of the Microsoft Source Code Samples. 
*       Copyright (C) 1993 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
\******************************************************************************/

#define IDM_ABOUT 100
#define IDM_PLATFORM 200
#define IDM_TRANS                       103
#define ID_TRANSLATION_HELP             104
#define ID_HELP_CONTACTTOUS             106
#define IDC_NUMBER                      1001
#define IDC_COUNT                        1002
#define IDC_SYS1                        1004
#define IDC_SYS2                        1005
#define IDC_CLEAR                       1006
#define IDC_ANSWER                      1019
#define IDC_ANSWER1                     1020
#define IDC_STATIC                      -1
#define IDC_COMBO1                      1021
int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
BOOL InitApplication(HANDLE);
BOOL InitInstance(HANDLE, int);
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK About(HWND, UINT, WPARAM, LPARAM);
void Cpt(int,int,int,HWND);
void System(HWND,int,int,int);
BOOL CALLBACK Translator(HWND, UINT, WPARAM, LPARAM);
