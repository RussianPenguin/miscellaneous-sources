//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDI.rc
//
#define IDS_VOIDMENUNAME                1
#define IDM_BOUNCE                      10
#define IDM_HELLO                       11
#define ID_BLACK                        20
#define IDM_BLACK                       20
#define ID_RED                          21
#define IDM_RED                         21
#define ID_GREEN                        22
#define IDM_GREEN                       22
#define ID_BLUE                         23
#define IDM_BLUE                        23
#define ID_WHITE                        24
#define IDM_WHITE                       24
#define ID_CUSTOM                       25
#define IDM_CUSTOM                      25
#define IDM_FAST                        30
#define IDM_SLOW                        31
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_HELLOTYPE                   129
#define IDS_TIMER                       130
#define IDD_DIALOG1                     132
#define IDR_INT_MENU                    133
#define IDD_MENU_SETUP                  160
#define IDC_PAGER_CTRL1                 1000
#define IDC_TAB1                        1001
#define IDC_COMBO                       3234
#define IDR_BOUNCETYPE                  31234
#define IDR_HELLO_TYPE                  31235
#define IDR_MAIN_FRAME                  31236
#define IDR_BOUNCE_TYPE                 31237
#define ID_FILE_NEWHELLO                32771
#define ID_FILE_NEWBOUNCE               32772
#define ID_SPEED_SLOW                   32778
#define ID_SPEED_FAST                   32779
#define IDS_NOHELLOTEMPLATE             32780
#define ID_FAST                         32781
#define IDS_NOBOUNCETEMPLATE            32781
#define IDS_STANDARD                    32782
#define ID_MIX                          32783
#define IDS_UNKCOLOR                    32784
#define ID_SHOWFULL                     32792
#define ID_INTMODE                      32794
#define IDM_MENU                        32845

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32795
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
