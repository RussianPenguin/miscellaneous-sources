// TestMDIView.cpp : implementation of the CTestMDIView class
//

#include "stdafx.h"
#include "TestMDI.h"

#include "TestMDIDoc.h"
#include "TestMDIView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView

IMPLEMENT_DYNCREATE(CTestMDIView, CEditView)

BEGIN_MESSAGE_MAP(CTestMDIView, CEditView)
	//{{AFX_MSG_MAP(CTestMDIView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView construction/destruction

CTestMDIView::CTestMDIView()
{
	// TODO: add construction code here

}

CTestMDIView::~CTestMDIView()
{
}

BOOL CTestMDIView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView drawing

void CTestMDIView::OnDraw(CDC* pDC)
{
	CTestMDIDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView printing

BOOL CTestMDIView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CTestMDIView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CTestMDIView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView diagnostics

#ifdef _DEBUG
void CTestMDIView::AssertValid() const
{
	CEditView::AssertValid();
}

void CTestMDIView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CTestMDIDoc* CTestMDIView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestMDIDoc)));
	return (CTestMDIDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestMDIView message handlers
