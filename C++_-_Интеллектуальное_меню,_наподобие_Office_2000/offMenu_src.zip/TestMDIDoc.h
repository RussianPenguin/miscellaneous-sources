// TestMDIDoc.h : interface of the CTestMDIDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTMDIDOC_H__086933C8_82D0_42A2_9E24_C027BEF40649__INCLUDED_)
#define AFX_TESTMDIDOC_H__086933C8_82D0_42A2_9E24_C027BEF40649__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTestMDIDoc : public CDocument
{
protected: // create from serialization only
	CTestMDIDoc();
	DECLARE_DYNCREATE(CTestMDIDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestMDIDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestMDIDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestMDIDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTMDIDOC_H__086933C8_82D0_42A2_9E24_C027BEF40649__INCLUDED_)
