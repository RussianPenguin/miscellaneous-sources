//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GridCtrlDemo.rc
//
#define IDCANCEL2                       3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GRIDCTRLDEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU                        128
#define IDB_RESIZE                      129
#define IDB_IMAGES                      141
#define IDC_PRINT_BUTTON                1000
#define IDC_ALLOW_SELECTION             1001
#define IDC_FONT_BUTTON                 1002
#define IDC_SCROLLBAR1                  1003
#define IDC_GRID                        1004
#define IDC_EDIT_ROWS                   1005
#define IDC_SPIN_ROW                    1006
#define IDC_EDIT_COLS                   1007
#define IDC_SPIN_COL                    1008
#define IDC_EDIT_FIXROWS                1009
#define IDC_SPIN_FIXROW                 1010
#define IDC_EDIT_FIXCOLS                1011
#define IDC_SPIN_FIXCOL                 1012
#define IDC_VERT_LINES                  1013
#define IDC_HORZ_LINES                  1014
#define IDC_LISTMODE                    1015
#define IDC_EDITABLE                    1016
#define IDC_ROW_RESIZE                  1017
#define IDC_COL_RESIZE                  1018
#define IDC_HEADERSORT                  1019
#define IDC_READ_ONLY                   1020
#define IDC_SIZEBOX                     1021
#define IDC_ITALICS                     1022
#define IDC_TITLETIPS                   1023
#define IDC_INSERT_ROW                  1024
#define IDC_DELETE_ROW                  1025
#define IDC_SINGLESELMODE               1026
#define ID_EDIT_SELECTALL               32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
