// CurPosIndicatorDoc.cpp : implementation of the CCurPosIndicatorDoc class
//

#include "stdafx.h"
#include "CurPosIndicator.h"

#include "CurPosIndicatorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorDoc

IMPLEMENT_DYNCREATE(CCurPosIndicatorDoc, CDocument)

BEGIN_MESSAGE_MAP(CCurPosIndicatorDoc, CDocument)
	//{{AFX_MSG_MAP(CCurPosIndicatorDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorDoc construction/destruction

CCurPosIndicatorDoc::CCurPosIndicatorDoc()
{
	// TODO: add one-time construction code here

}

CCurPosIndicatorDoc::~CCurPosIndicatorDoc()
{
}

BOOL CCurPosIndicatorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorDoc serialization

void CCurPosIndicatorDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorDoc diagnostics

#ifdef _DEBUG
void CCurPosIndicatorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCurPosIndicatorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorDoc commands
