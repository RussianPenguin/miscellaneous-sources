// CurPosIndicator.h : main header file for the CURPOSINDICATOR application
//

#if !defined(AFX_CURPOSINDICATOR_H__DBA2F8A5_E3BA_11D4_85A7_444553540000__INCLUDED_)
#define AFX_CURPOSINDICATOR_H__DBA2F8A5_E3BA_11D4_85A7_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorApp:
// See CurPosIndicator.cpp for the implementation of this class
//

class CCurPosIndicatorApp : public CWinApp
{
public:
	CCurPosIndicatorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCurPosIndicatorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CCurPosIndicatorApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CURPOSINDICATOR_H__DBA2F8A5_E3BA_11D4_85A7_444553540000__INCLUDED_)
