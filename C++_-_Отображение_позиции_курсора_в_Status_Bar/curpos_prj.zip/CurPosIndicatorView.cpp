// CurPosIndicatorView.cpp : implementation of the CCurPosIndicatorView class
//

#include "stdafx.h"
#include "CurPosIndicator.h"
#include "MainFrm.h"
#include "CurPosIndicatorDoc.h"
#include "CurPosIndicatorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorView

IMPLEMENT_DYNCREATE(CCurPosIndicatorView, CEditView)

BEGIN_MESSAGE_MAP(CCurPosIndicatorView, CEditView)
	//{{AFX_MSG_MAP(CCurPosIndicatorView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorView construction/destruction

CCurPosIndicatorView::CCurPosIndicatorView()
{
	// TODO: add construction code here

}

CCurPosIndicatorView::~CCurPosIndicatorView()
{
}

BOOL CCurPosIndicatorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorView drawing

void CCurPosIndicatorView::OnDraw(CDC* pDC)
{
	CCurPosIndicatorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorView diagnostics

#ifdef _DEBUG
void CCurPosIndicatorView::AssertValid() const
{
	CEditView::AssertValid();
}

void CCurPosIndicatorView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CCurPosIndicatorDoc* CCurPosIndicatorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCurPosIndicatorDoc)));
	return (CCurPosIndicatorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCurPosIndicatorView message handlers

void CCurPosIndicatorView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	((CMainFrame*)AfxGetApp()->m_pMainWnd)->SetEdit(&GetEditCtrl());	
}
