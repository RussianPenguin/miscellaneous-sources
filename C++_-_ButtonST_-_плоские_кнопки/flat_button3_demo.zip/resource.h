//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CButtonST_demo.rc
//
#define IDS_TT_BALOON                   1
#define IDD_CBUTTONST_DEMO_DIALOG       102
#define IDD_ABOUTBOX                    103
#define IDR_MAINFRAME                   128
#define IDB_SOFTECHLOGO                 129
#define IDI_ZIP256                      130
#define IDI_CANCEL16                    133
#define IDI_OK16                        134
#define IDI_HAND256                     136
#define IDI_CDGOLD256                   137
#define IDI_OK256                       138
#define IDI_CANCEL256                   139
#define IDI_LAMP256                     140
#define IDI_OKBOR16                     141
#define IDI_CANCELBOR16                 142
#define IDI_EXPLORE16                   143
#define IDI_VIEW16                      144
#define IDI_TEXT16                      145
#define IDI_QUESTION16                  146
#define IDI_LEFT16                      147
#define IDC_HAND                        147
#define IDI_RIGHT16                     148
#define IDI_SCREW16                     149
#define IDI_EXIT16                      150
#define IDI_ABOUT16                     151
#define IDI_LAMP2                       152
#define IDI_OKBOR2                      153
#define IDI_CANCELBOR2                  154
#define IDI_ZIPSMALL256                 155
#define IDI_BALOON256                   157
#define IDC_ZIP256                      1001
#define IDC_CANCEL16                    1002
#define IDC_OK16                        1003
#define IDC_HAND256                     1004
#define IDC_LAMP256                     1005
#define IDC_OK256                       1006
#define IDC_CANCEL256                   1007
#define IDC_CDGOLD256                   1008
#define IDC_OKBOR16                     1009
#define IDC_CANCELBOR16                 1010
#define IDC_EXPLORE16                   1011
#define IDC_VIEW16                      1012
#define IDC_EMAILLINK                   1012
#define IDC_TEXT16                      1013
#define IDC_HOMEPAGELINK                1013
#define IDC_QUESTION16                  1014
#define IDC_LEFT16                      1015
#define IDC_RIGHT16                     1016
#define IDC_SCREW16                     1017
#define IDC_ABOUT16                     1018
#define IDC_VERSION                     1019
#define IDC_BALOON256                   1019
#define IDC_FRIENDS                     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        158
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
