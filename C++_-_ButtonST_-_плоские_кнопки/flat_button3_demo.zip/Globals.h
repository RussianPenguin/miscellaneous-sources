// Globals for CButtonST_demo
#ifndef _GLOBALS_H
#define _GLOBALS_H

#define PROJECT_NAME "CButtonST v2.5"
#define SEMAPHORE_NAME "25CButtonST"

#define IDS_MAILADDR "mailto:davide_calabro@yahoo.com"
#define IDS_HOMEPAGEADDR  "http://members.tripod.com/~SoftechSoftware/index.html" 

#define STSIGN "SoftechSoftware"

#endif
