// DragToolBar.h : header file

/////////////////////////////////////////////////////////////////////////////
// CDragToolBar window

class CDragToolBar : public CToolBar
{
// Construction
public:
	CDragToolBar();

	BOOL m_dragMode;
	CPoint m_point;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDragToolBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDragToolBar();
	// Generated message map functions
protected:
	//{{AFX_MSG(CDragToolBar)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
