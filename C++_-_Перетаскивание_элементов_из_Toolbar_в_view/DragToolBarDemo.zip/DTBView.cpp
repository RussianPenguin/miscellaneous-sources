// DTBView.cpp : implementation of the CDTBView class
//
// Writen by Pham Hong Nguyen
// Home page: http://www.geocities.com/phhnguyen/
//
// Feel free to do anything with this code

#include "stdafx.h"
#include "DTB.h"

#include "DTBDoc.h"
#include "DTBView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDTBView

IMPLEMENT_DYNCREATE(CDTBView, CView)

BEGIN_MESSAGE_MAP(CDTBView, CView)
	//{{AFX_MSG_MAP(CDTBView)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_START_DRAG, OnStartDrag)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND_RANGE(ID_CIRCLE, ID_TRIANGLE, OnDragToolBar)
	ON_UPDATE_COMMAND_UI_RANGE(ID_CIRCLE, ID_TRIANGLE, OnDragToolBarUI)
	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDTBView construction/destruction

CDTBView::CDTBView()
{
	m_dragBtn = -1;
	m_dragdrop = FALSE;
	m_str = _T("Please drag any button on Toolbar above and drop to me!");
}

CDTBView::~CDTBView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CDTBView drawing

void CDTBView::OnDraw(CDC* pDC)
{
	CDTBDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	pDC->TextOut(10,30, m_str);
}

/////////////////////////////////////////////////////////////////////////////
// CDTBView diagnostics

#ifdef _DEBUG
void CDTBView::AssertValid() const
{
	CView::AssertValid();
}

void CDTBView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDTBDoc* CDTBView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDTBDoc)));
	return (CDTBDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDTBView message handlers

void CDTBView::OnDragToolBar(UINT nCmdID)
{
	m_dragBtn = nCmdID;
}

void CDTBView::OnDragToolBarUI(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID==(UINT)m_dragBtn);
}



void CDTBView::BeginDrag()
{
	if (m_dragdrop) return;
	m_dragdrop = TRUE;

	static BOOL first = TRUE;
	if (first) {
		m_ImageList.Create(IDB_BITMAP1, 30, 3, 0);
		first = FALSE;
	}

	// Build drag cursor, then enter drag mode
	CPoint ptAction;
	GetCursorPos(&ptAction);

	IMAGEINFO ImageInfo;
	m_ImageList.GetImageInfo(0, &ImageInfo);
	// The original cursor set in middle of drag item
	int w = (ImageInfo.rcImage.right-ImageInfo.rcImage.left)/2;
	int h = (ImageInfo.rcImage.bottom-ImageInfo.rcImage.top)/2;

	// image number of drag
	int z = m_dragBtn-ID_CIRCLE;

	m_ImageList.DragShowNolock(TRUE);
	m_ImageList.BeginDrag(z, CPoint(w,h));
	m_ImageList.SetDragCursorImage(z, CPoint(0,0));
	m_ImageList.DragMove(ptAction);
	m_ImageList.DragEnter(NULL, ptAction);	// NULL means desktop screen

	SetCapture();
}

void CDTBView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_dragdrop) return;

	ClientToScreen(&point);		// Remember that we should drag over screen
	m_ImageList.DragMove(point);
}

void CDTBView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (!m_dragdrop) return;
	m_dragdrop = FALSE;

	m_ImageList.DragLeave(NULL);
	m_ImageList.EndDrag();
	ReleaseCapture();

	// Inform what we drag
	static CString name[3] = {"cirlce","rectangle","triangle"};
	m_str = "A " + name[m_dragBtn-ID_CIRCLE] + " has been dragged and dropped!";
	Invalidate();
}

void CDTBView::OnStartDrag() 
{
	BeginDrag();
}
