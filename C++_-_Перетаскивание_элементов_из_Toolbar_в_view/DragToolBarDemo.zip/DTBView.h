// DTBView.h : interface of the CDTBView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DTBVIEW_H__645B8330_283E_11D5_BFA4_08009000023D__INCLUDED_)
#define AFX_DTBVIEW_H__645B8330_283E_11D5_BFA4_08009000023D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDTBView : public CView
{
protected: // create from serialization only
	CDTBView();
	DECLARE_DYNCREATE(CDTBView)

// Attributes
public:
	CDTBDoc* GetDocument();

	void OnDragToolBar(UINT nCmdID);
	void OnDragToolBarUI(CCmdUI *pCmdUI);
	void BeginDrag();

	CImageList m_ImageList;
	int m_dragBtn;
	BOOL m_dragdrop;
	CString m_str;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTBView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDTBView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDTBView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnStartDrag();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DTBView.cpp
inline CDTBDoc* CDTBView::GetDocument()
   { return (CDTBDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTBVIEW_H__645B8330_283E_11D5_BFA4_08009000023D__INCLUDED_)
