// DTB.h : main header file for the DTB application
//

#if !defined(AFX_DTB_H__645B8328_283E_11D5_BFA4_08009000023D__INCLUDED_)
#define AFX_DTB_H__645B8328_283E_11D5_BFA4_08009000023D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDTBApp:
// See DTB.cpp for the implementation of this class
//

class CDTBApp : public CWinApp
{
public:
	CDTBApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDTBApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CDTBApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DTB_H__645B8328_283E_11D5_BFA4_08009000023D__INCLUDED_)
