// DragToolBar.cpp : implementation file
//
// Writen by Pham Hong Nguyen
// Home page: http://www.geocities.com/phhnguyen/
//
// Feel free to do anything with this code

#include "stdafx.h"
#include "DragToolBar.h"
#include "resource.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDragToolBar

CDragToolBar::CDragToolBar()
{
	m_dragMode = FALSE;
}

CDragToolBar::~CDragToolBar()
{
}

BEGIN_MESSAGE_MAP(CDragToolBar, CToolBar)
	//{{AFX_MSG_MAP(CDragToolBar)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDragToolBar message handlers

void CDragToolBar::OnLButtonDown(UINT nFlags, CPoint point) 
{
	int nCount = GetToolBarCtrl().GetButtonCount();
	for (int i=0; i<nCount; i++) {
		CRect rect;
		GetItemRect(i, rect);
		if (rect.PtInRect(point)) {
			PostMessage(WM_COMMAND, GetItemID(i));
			m_dragMode = TRUE;
			m_point = point;
			return;
		}
	}
		
	CToolBar::OnLButtonDown(nFlags, point);
}

void CDragToolBar::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_dragMode && abs(m_point.x-point.x)+abs(m_point.y-point.y)>=3) {
		PostMessage(WM_COMMAND, ID_START_DRAG);
		m_dragMode = FALSE;
	}
	CToolBar::OnMouseMove(nFlags, point);
}
