/*prototypes*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd);
BOOL SetMainWnd(HINSTANCE hInstance);
BOOL CreateMainWnd(HINSTANCE hInstance);
LRESULT CALLBACK WindowProc(HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam);
void Mold(HDC bpHDC);
/* globals */
HWND hwMain, hwStatica, hwStaticb;
HBITMAP hwBmp;
HINSTANCE hInst;
int x, y;
HRGN finala;
BOOL work = TRUE;
POINT pta, ptb;