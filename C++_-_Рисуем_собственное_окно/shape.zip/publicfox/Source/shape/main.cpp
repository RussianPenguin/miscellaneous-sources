/******************************************/
/*PROJECT: window shaping example         */
/*AUTHOR: Leviticus (Brad Zasada)         */
/*WEBPAGE: http://www.leviticus-inc.com   */
/*EMAIL: brad@integerx.net                */
/******************************************/
#include <windows.h>
#include "main.h"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	SetMainWnd(hInstance);
	CreateMainWnd(hInstance);
	
	{
			MSG wMsg;

			while (GetMessage(&wMsg,hwMain,0,0) == TRUE)
			{
				TranslateMessage(&wMsg);
				DispatchMessage(&wMsg);
			}
	}
    return 0;
}

BOOL SetMainWnd(HINSTANCE hInstance)
{
	hInst = hInstance;

	WNDCLASSEX wcxMain;
	/*fill wcxMain with appropriate values*/
	ZeroMemory(&wcxMain,sizeof(wcxMain)); /*initialize all members to null*/
	wcxMain.cbSize = sizeof(wcxMain);
	wcxMain.hbrBackground = (HBRUSH) (COLOR_WINDOW); 
	wcxMain.hCursor = LoadCursor(hInstance, IDC_ARROW);
	wcxMain.hInstance = hInstance;
	wcxMain.lpfnWndProc = WindowProc;
	wcxMain.lpszClassName = "Window Shaping";
	wcxMain.style = CS_VREDRAW | CS_HREDRAW;

	if(!RegisterClassEx(&wcxMain))
		return FALSE;
	
	return TRUE;
}

BOOL CreateMainWnd(HINSTANCE hInstance)
{
	HFONT buttonfont;	/*create windows and set fonts*/
	hwMain = CreateWindowEx(0,"Window Shaping","Window Shaping", WS_OVERLAPPED,50,50,450,350,0,0,hInstance,0);
	hwStatica = CreateWindowEx(0,"Button","Site",WS_CHILD | WS_VISIBLE | SS_CENTER, 100,88,50,20,hwMain,0,hInstance,0);
	hwStaticb = CreateWindowEx(0,"Button","Quit",WS_CHILD | WS_VISIBLE | SS_CENTER, 194,88,50,20,hwMain,0,hInstance,0);
	buttonfont = CreateFont(16,0,FW_DONTCARE,FW_DONTCARE,FW_DONTCARE,
		FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FF_DONTCARE,"Arial");
	
	SendMessage(hwStatica,WM_SETFONT,reinterpret_cast<WPARAM>(buttonfont),MAKELPARAM(1, 0));
	SendMessage(hwStaticb,WM_SETFONT,reinterpret_cast<WPARAM>(buttonfont),MAKELPARAM(1, 0));
	
	SetWindowPos(hwMain,HWND_TOPMOST,50,50,450,350, NULL);
	
	ShowWindow(hwMain,1);

	if(!hwMain)
		return FALSE;
	return TRUE;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT wMsg, WPARAM wParam, LPARAM lParam)
{
	switch(wMsg) {
	case WM_DESTROY:
		PostQuitMessage(0);	/*destroy window*/
		return 0;
		break;
	case WM_PAINT:
		HDC hdcTemp, bpHDC;
		PAINTSTRUCT sentinel;
		BITMAP bm;
		bpHDC = BeginPaint(hwMain, &sentinel);
		if(work)	/*if its our first time painting, shape the window*/
		{
			ShowWindow(hwMain,0);	/* window not visible until shaped*/
			Mold(bpHDC);
			ShowWindow(hwMain,1);
		}
		hdcTemp = CreateCompatibleDC(bpHDC);	/*load and bitblt image to our hdc*/
		hwBmp = LoadBitmap(hInst,MAKEINTRESOURCE(104));
		SelectObject(hdcTemp,static_cast<HGDIOBJ>(hwBmp));
		GetObject(static_cast<HGDIOBJ>(hwBmp),sizeof(bm),&bm);
		BitBlt(bpHDC,-3,-22,bm.bmWidth,bm.bmHeight,hdcTemp,0,0,SRCCOPY);
		DeleteDC(bpHDC);	/*delete uneeded objects to free up memory*/
		DeleteDC(hdcTemp);
		EndPaint(hwMain,&sentinel);
		return 0;
		break;
	case WM_COMMAND:
		if(wParam == BN_CLICKED)
		{
			if(reinterpret_cast<HWND>(lParam) == hwStatica)
				ShellExecute(NULL, "open", "http://www.leviticus-inc.com", NULL, NULL, SW_SHOWNORMAL);
			else if(reinterpret_cast<HWND>(lParam) == hwStaticb)
				DestroyWindow(hwMain);
		}
	return 0;
	break;
	case WM_LBUTTONDOWN:
		SendMessage(hwMain,WM_SYSCOMMAND,SC_MOVE,0);	/*tell the window the user wants to move the window*/
	break;
	default:
		return DefWindowProc(hWnd,wMsg,wParam,lParam);
	}
return FALSE;
}

void Mold(HDC bpHDC)
{
		HDC hdcTemp;
		BITMAP bm;
		COLORREF filtercolor;	/*color to filter out*/
		HRGN temp, final;
		int left, startpos, row;
		final = CreateRectRgn(0,0,0,0);	/*final must be initialized before being combined*/
		hdcTemp = CreateCompatibleDC(bpHDC);
		hwBmp = LoadBitmap(hInst,MAKEINTRESOURCE(103));
		SelectObject(hdcTemp,static_cast<HGDIOBJ>(hwBmp));
		GetObject(static_cast<HGDIOBJ>(hwBmp),sizeof(bm),&bm);
		filtercolor = GetPixel(hdcTemp, 0,0);
		row = 0;
		left = 0;
		for(row;row<=bm.bmHeight-1;row++)
		{
			
			while(left<bm.bmWidth-1)
			{
				while((GetPixel(hdcTemp,left,row) == filtercolor) && left<bm.bmWidth)
					left++;
				if(left != bm.bmWidth)
				{	
					startpos = left;
					while((GetPixel(hdcTemp,left,row) != filtercolor) && (left < bm.bmWidth))
						left++;
					temp = CreateRectRgn(startpos, row, left, row+1);
					CombineRgn(final, final, temp, RGN_XOR);
				}
			}
			left = 0;
		}
		DeleteObject(reinterpret_cast<HGDIOBJ>(temp));
		DeleteDC(bpHDC);
		DeleteDC(hdcTemp);
		SetWindowRgn(hwMain,final,TRUE);
		work = FALSE;
		DeleteObject(reinterpret_cast<HGDIOBJ>(final));
}