/********************************************************************************************

	File:			strutil.cpp
	Created On:		07/19/2000
	Created By:		Justin Kirby
	Modified On:	08/20/2000


	Description:
		To provide frequently used code fragments dealing specifically with strings and 
		encapsulate them into functions. possibly move into class eventually?
		

	Functions:
		strcpyalloc(PCHAR *dest, CTPCHAR src);
		strcatalloc(PCHAR *dest, CTPCHAR src)
		stralloc(PCHAR *dest, UNINT sz);
		strcnt(CTPCHAR src, CHAR chr, INT &cnt);
		

	Dependancies
		strutil.h

	Modifications:

	07/31/2000
		added functions:
			strcatalloc()
			stralloc()

	08/20/2000
		added functions
			strcnt()
		cleaned up memory leak in strcatalloc(). the temp storage was not being deleted before return


********************************************************************************************/


#include "strutil.h"
#include <string>

/*
	Verifies:
		src is pointing to something, i.e. its has data
		dest is a pointer to a char* initialized to zero

	Allocates enough memory to copy src to dest.
	Adds one byte for '\0' 

	returns the number of bytes copied to *dest
*/
unsigned int jkl_str::strcpyalloc(char **dest, const char *src)
{
	unsigned int cb=0;

	//the source string MUST contain data.
	if(!src)
	{
		*dest = 0;
		return 0;
	}

	//the destination MUST be initialized to NULL (0)
	if(*dest)
	{
		*dest = 0;
		return 0;
	}

	cb = strlen(src)+1;
	*dest = new char[cb];
	memset((void*)*dest,0,cb);
	strcpy(*dest,src);

	return strlen(*dest);	//returning length of *dest

}

/*
	Reallocates dest and appends contents of src
*/
unsigned int jkl_str::strcatalloc(char **dest, const char *src)
{
	unsigned int cb =0;
	char *tmpstr=0;

	if(!src)
	{
		*dest = 0;
		return 0;
	}

	if(*dest)
	{
		cb = strlen(tmpstr)+1;
		tmpstr = new char[cb];
		memset((void*)tmpstr,0,cb);
		strcpy(tmpstr,*dest);
		delete [] *dest;
	}

	cb += strlen(src)+1;
	*dest = new char[cb];
	memset((void*)*dest,0,cb);
	
	if(tmpstr){
		strcpy(*dest,tmpstr);
		strcat(*dest,src);
		delete [] tmpstr;
	}
	else{
		strcpy(*dest,src);
	}

	return strlen(*dest);
}

//allocates a string of size sz
unsigned int jkl_str::stralloc(char **dest, unsigned int sz)
{
	if(*dest){
		return 0;
	}

	*dest = new char[sz];
	memset((void*)*dest,0,sz);
	return sizeof(*dest);
}

unsigned int jkl_str::strcnt(const char *src, char chr, int &cnt)
{
	unsigned int cb = 0;
	char chsrc=0;
	if(!src){
		cnt = -1;
		return 1;
	}
	
	
	try
	{
		cnt = 0;
		cb = strlen(src)+1;
		for(int i=0; i<cb;i++)	{
			
			chsrc = *(src + i);
			
			if(chsrc == chr){
			
				cnt++;

			}
		}
	}
	catch(...)
	{
		//damn thing
		return 1;
	}
	return 0;

}
