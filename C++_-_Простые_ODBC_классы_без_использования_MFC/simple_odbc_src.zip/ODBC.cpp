/*********************************************************************
	File:			ODBC,cpp
	Created On:		07/17/2000
	Created By:		Justin Kirby
	Modified On:	08/24/2000


	Description:
			To provide a simple encapsulation of the ODBC API with 
		regards to establishing a connection to a data source. As well 
		as maintaining and creating queries.
			Dynamic and fat cursors are pseudo supported with the query 
		class
		
	Classes:
		CODBCCnx
		CODBCQuery
		CODBCFatQuery

	Structs:

	Global Functions:
		SQLSuccess()		

	Dependancies:
		..\Library\includes\ODBC.h
		strutil.h
		stdio.h
		
	Modifications:

	02/18/2000
		Added this comment block

	07/31/2000
		Added dependancy on strutil.h
		Added dependancy on	stdio.h
		Added support for driver connections
			Connect() and CODBCCnx() overridden funtions
		Added enumerated type CNXTYPE

	08/24/2000
		Removed dependancy of redefs.h	//custom redefinition of basic types
		Added status repot functions to CODBCFatQuery
			GetStatus()
			GetCount()

*********************************************************************/


#include "ODBC.h"
#include "strutil.h"
#include "stdio.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
int SQLSuccess(SQLRETURN ret)
{
	if(ret == SQL_SUCCESS || ret == SQL_SUCCESS_WITH_INFO)
		return 1;//returning 1 to make sense, i.e. usually refered to as true
	return 0;
}


using namespace jkl_str;	//the namespace that the strutil funcs are in

CODBCCnx::CODBCCnx()
{
	//setting all dsn info to null;
	m_driver ="DRIVER={%s};SERVER=%s;UID=%s;PWD=%s;";
	m_cnxstr=0;
	m_cnx	=0;
	m_dbms	=0;
	m_dsn	=0;
	m_usr	=0;
	m_pwd	=0;	
	m_szDsn =0;
	m_szUsr =0;
	m_szPwd =0;
	//making sure that the handles are set to null!
	h_env	=NULL;
	h_con	=NULL;
	h_stmt	=NULL;
	//initializing all of the bool values
	m_isEnv =0;
	m_isCon =0;
	SQLRETURN ret;


	ret = SQLAllocHandle(SQL_HANDLE_ENV,SQL_NULL_HANDLE,&h_env);
	if(SQLSuccess(ret))
	{	//now we set the environment attributes, i.e. force to ODBC 3.0
		ret = SQLSetEnvAttr(h_env,SQL_ATTR_ODBC_VERSION,
							(SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);
		if(SQLSuccess(ret))
			m_isEnv = 1;//if set env fails enviro will be considered uninited!!!

		ret = SQLAllocHandle(SQL_HANDLE_DBC,h_env,&h_con);
		if(SQLSuccess(ret))
			m_isCon = 1;

	}
}
//supplying the dsn user and password at construction
CODBCCnx::CODBCCnx(char *dsn, char *usr, char *pwd)

{
	SQLRETURN ret;
	*this = CODBCCnx::CODBCCnx();	//ack, but no better way than this <sigh>
									//suppose I could make a private init func()
	//initializing member chars
	if(dsn && usr)
	{
		m_szDsn = strcpyalloc(&m_dsn,dsn);
		m_szUsr = strcpyalloc(&m_usr,usr);

		if(pwd){//to allow for NULL passwords		
			m_szPwd = strcpyalloc(&m_pwd,pwd);
		}
		else{
			m_szPwd = 0;
			m_pwd =0 ;
		}
		

		if(m_isCon && m_isEnv)//insuring that the env is inited
		{
			ret = SQLConnect(h_con, (SQLCHAR*)m_dsn, m_szDsn,
								(SQLCHAR*)m_usr, m_szUsr,
								(SQLCHAR*)m_pwd, m_szPwd);
			if(SQLSuccess(ret))
			{
				ret = SQLAllocHandle(SQL_HANDLE_STMT, h_con, &h_stmt);
				if(SQLSuccess(ret))
					m_isStmt = 1;
			}
		}
	}
}
CODBCCnx::CODBCCnx(char *dbms, char *cnx, char *usr, char *pwd)
{
	SQLRETURN ret = SQL_ERROR;
	unsigned int cbCnxOut=0;
	unsigned int cbActualCnxOut=0;
	char *szCnxOut=0;
	char *pwdrmv=0;
	//if connecting to dsn, use that constructor instead
	if(!dbms)
	{
		*this = CODBCCnx::CODBCCnx(cnx,usr,pwd);
	}
	else
	{
		*this = CODBCCnx::CODBCCnx();
		//don't do a damn thing unless the env and con handles are alive
		if(m_isCon && m_isEnv)
		{
			strcpyalloc(&m_dbms,dbms);
			m_szDsn = strcpyalloc(&m_cnx,cnx);
			m_szUsr = strcpyalloc(&m_usr,usr);
			m_szPwd = strcpyalloc(&m_pwd,pwd);

			//createing connections string
			stralloc(&szCnxOut,HUGE_STR); //HUGE_STR is 1024, suggested by ODBC docs
			stralloc(&m_cnxstr,MAX_STR);
			sprintf(m_cnxstr,m_driver,m_dbms,m_cnx,m_usr,m_pwd);
			//if there is no password, removing requirement from connection string
			if(!m_pwd){
				pwdrmv = strstr(m_cnxstr,"PWD");
				pwdrmv[0] = '\0';
			}
			cbCnxOut = MAX_STR;
			ret = SQLDriverConnect(h_con,
									NULL,
									(SQLCHAR*)m_cnxstr,
									strlen(m_cnxstr),
									(SQLCHAR*)szCnxOut,
									cbCnxOut,
									(short*)&cbActualCnxOut,
									SQL_DRIVER_NOPROMPT);
			if(SQLSuccess(ret))
			{
				ret = SQLAllocHandle(SQL_HANDLE_STMT,h_con,&h_stmt);
				if(SQLSuccess(ret)){
					m_isStmt=1;
				}
			}
		}
	}

	if(szCnxOut){
		delete [] szCnxOut;	//I saw no point in keeping this data.
	}
}
CODBCCnx::~CODBCCnx()
{
	if(m_dsn){
		delete [] m_dsn;
	}
	if(m_usr){
		delete [] m_usr;
	}
	if(m_pwd){
		delete [] m_pwd;
	}
	if(m_dbms){
		delete [] m_dbms;
	}
	if(m_cnx){
		delete [] m_cnx;
	}
	if(m_driver){
		delete [] m_driver;
	}
	if(m_cnxstr){
		delete [] m_cnxstr;
	}


	if(h_stmt){
		SQLFreeHandle(SQL_HANDLE_STMT, h_stmt);
	}
	if(h_con){
		SQLFreeHandle(SQL_HANDLE_DBC, h_con);
	}
	if(h_env){
		SQLFreeHandle(SQL_HANDLE_ENV, h_env);
	}

}

SQLRETURN CODBCCnx::Connect(char *dsn, char *usr, char *pwd)
{
	if(dsn && usr)
	{
		m_szDsn = strcpyalloc(&m_dsn,dsn);
		m_szUsr = strcpyalloc(&m_usr,usr);

		if(pwd)	{
			m_szPwd = strcpyalloc(&m_pwd,pwd);
		}
		else	{
			m_szPwd = 0;
			m_pwd =0;
		}

		return Connect();
	}
	
	else{
		return SQL_ERROR;
	}	
}

SQLRETURN CODBCCnx::Connect(char *dbms, char *cnx, char *usr, char *pwd)
{
	SQLRETURN ret = SQL_ERROR;
	unsigned int cbCnxOut=0;
	char *szCnxOut=0;
	char *pwdrmv=0;

	if(!dbms)	{
		return Connect(cnx,usr,pwd);
	}
	else
	{
		if(m_isEnv && m_isCon && !m_isStmt)
		{
			strcpyalloc(&m_dbms,dbms);
			m_szDsn = strcpyalloc(&m_cnx,cnx);
			m_szUsr = strcpyalloc(&m_usr,usr);
			m_szPwd = strcpyalloc(&m_pwd,pwd);

			stralloc(&m_cnxstr,MAX_STR);
			stralloc(&szCnxOut,HUGE_STR);	//HUGE_STR is 1024, suggested by ODBC docs

			sprintf(m_cnxstr,m_driver,m_dbms,m_cnx,m_usr,m_pwd);
			//if no pwd remove req
			if(!m_pwd){
				pwdrmv = strstr(m_cnxstr,"PWD");
				pwdrmv[0] = '\0';
			}

			ret = SQLDriverConnect(h_con,
									NULL,
									(SQLCHAR*)m_cnxstr,
									SQL_NTS,
									(SQLCHAR*)szCnxOut,
									HUGE_STR,
									(SHORT*)&cbCnxOut,
									SQL_DRIVER_NOPROMPT);
			if(SQLSuccess(ret))
			{
				ret = SQLAllocHandle(SQL_HANDLE_STMT,h_con,&h_stmt);
				if(SQLSuccess(ret)){
					m_isStmt=1;
				}
			}
		}
	}
	if(szCnxOut){
		delete [] szCnxOut;//again, saw no reason to keep this
	}
	return ret;
}
SQLRETURN CODBCCnx::Connect()
{
	SQLRETURN ret=SQL_ERROR;
	if(m_isCon && m_isEnv && !m_isStmt)//making sure env and con are inited
										//but NOT statement!!!
	{
		ret = SQLConnect(h_con, (SQLCHAR*)m_dsn, m_szDsn,
								(SQLCHAR*)m_usr, m_szUsr,
								(SQLCHAR*)m_pwd, m_szPwd);
		if(!SQLSuccess(ret))
			return ret;

		ret = SQLAllocHandle(SQL_HANDLE_STMT,h_con,&h_stmt);
		if(SQLSuccess(ret))
			m_isStmt = 1;		
	}
	return ret;
}

SQLRETURN CODBCCnx::Connect(SQLHANDLE stmt)
{
	SQLRETURN ret = SQL_ERROR;
	//a check to see if we are already connected
	if(m_isCon && m_isEnv && m_isStmt){
		ret = SQLAllocHandle(SQL_HANDLE_STMT,h_con,&stmt);		
	}
	//if not connected, connect :)
	else if(m_isCon && m_isEnv && !m_isStmt)
	{
		ret = SQLConnect(h_con, (SQLCHAR*)m_dsn, m_szDsn,
								(SQLCHAR*)m_usr, m_szUsr,
								(SQLCHAR*)m_pwd, m_szPwd);
		if(!SQLSuccess(ret)){
			return ret;
		}

		ret = SQLAllocHandle(SQL_HANDLE_STMT,h_con,&stmt);		
	}
	return ret;
}



SQLRETURN CODBCCnx::Disconnect(SQLSMALLINT action)
{
	SQLRETURN ret;
	//making damn sure action is either roll back or commit!
	if(action != SQL_COMMIT){
		action = SQL_ROLLBACK;
	}

	ret = SQLEndTran(SQL_HANDLE_DBC,h_con,action);
	if(SQLSuccess(ret))
	{
		ret = SQLDisconnect(h_con); //this action will invalidate 
									//_ALL_ SQL stmt handles associated with this cnx
		if(SQLSuccess(ret)){
			m_isStmt = 0;
		}
	}
	return ret;
}

int CODBCCnx::IsOk()
{
	if(m_isEnv && m_isCon && m_isStmt)
		return 0;//everything is ok and its ready for use
	else if(!m_isEnv)
		return INIT_ENV;
	else if(!m_isCon)
		return INIT_CON;
	else if(!m_isStmt)
		return INIT_STMT;
	else
		return INIT_UNKNOWN;
}



CODBCQuery::CODBCQuery()
{
	h_qstmt = 0;
	m_isBound = 0;
	m_hasData = 0;
	m_isPrepared = 0;
	m_conIsNew = 0;
	p_con = 0;
}
CODBCQuery::CODBCQuery(CODBCCnx *cnx, bool isnew)
{
	h_qstmt = 0;
	m_isBound = 0;
	m_hasData = 0;
	m_isPrepared = 0;
	p_con=cnx;
	m_conIsNew=isnew;
}
CODBCQuery::CODBCQuery(char *dbms,char *cnx, char *usr, char *pwd)
{
	h_qstmt = 0;
	m_isBound = 0;
	m_hasData = 0;
	m_isPrepared = 0;
	p_con = new CODBCCnx(dbms,cnx,usr,pwd);
	m_conIsNew=1;
}

CODBCQuery::~CODBCQuery()
{
	if(m_conIsNew && p_con){
		delete p_con;
	}
}

SQLRETURN CODBCQuery::Prepare(char *qry)
{
	return SQLPrepare(h_qstmt,(SQLCHAR*)qry,SQL_NTS);
}

bool CODBCQuery::IsBound()
{	return m_isBound;	}

bool CODBCQuery::HasData()
{	return m_hasData;	}

bool CODBCQuery::IsPrepared()
{	return m_isPrepared;}


CODBCFatQuery::CODBCFatQuery(CODBCCnx *cnx, unsigned int sz, bool isnew)
: CODBCQuery(cnx, isnew)
{
	m_rowStatus = 0;
	m_rowFetched = 0;
	m_size = sz;
	FatSize(sz);
}
CODBCFatQuery::~CODBCFatQuery()
{
	if(m_rowStatus){
		delete [] m_rowStatus;
	}
}

SQLRETURN CODBCFatQuery::FatSize(unsigned int sz)
{
	SQLRETURN ret = SQL_ERROR;

	//setting container for status
	m_rowStatus = new SQLUSMALLINT[sz];



	//setting bind type to column
	ret = SQLSetStmtAttr(p_con->h_stmt,
						SQL_ATTR_ROW_BIND_TYPE,
						SQL_BIND_BY_COLUMN,
						0);
	if(!SQLSuccess(ret))
		return ret;

	unsigned long prm = SQL_CURSOR_DYNAMIC;
	//making cursor dynamic in order to support SQLGetData()
	ret = SQLSetStmtAttr(p_con->h_stmt,
						SQL_ATTR_CURSOR_TYPE,
						(void*)&prm,
						0);

	ret = SQLSetStmtAttr(p_con->h_stmt,
						SQL_ATTR_ROW_ARRAY_SIZE,
						(SQLPOINTER)sz,
						SQL_IS_INTEGER);
	if(!SQLSuccess(ret))
		return ret;

	//setting number of rows to return
	ret = SQLSetStmtAttr(p_con->h_stmt,
						SQL_ATTR_ROW_STATUS_PTR,
						m_rowStatus,
						0);
	ret = SQLSetStmtAttr(p_con->h_stmt,
						SQL_ATTR_ROWS_FETCHED_PTR,
						&m_rowFetched,
						0);

	return ret;
}


int CODBCFatQuery::GetStatus(unsigned int num, unsigned long *stat)
{
	if(num >= m_size){
		return 0;
	}
	if(num >= m_rowFetched){
		return 0;
	}
	if(!stat){
		return 0;
	}
	//ok num is within accepted bounds... can safely access array

	*stat = m_rowStatus[num];
	return 1;
}
unsigned long CODBCFatQuery::GetCount()
{	return m_rowFetched;	}
