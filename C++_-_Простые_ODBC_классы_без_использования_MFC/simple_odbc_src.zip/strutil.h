/********************************************************************************************

	File:			strutil.h
	Created On:		07/19/2000
	Created By:		Justin Kirby
	Modified On:	08/20/2000


	Description:
		To provide frequently used code fragments dealing specifically with strings and 
		encapsulate them into functions. possibly move into class eventually?

	Functions:
		strcpyalloc(PCHAR *dest, CTPCHAR src);
		strcatalloc(PCHAR *dest, CTPCHAR src);
		stralloc(PCHAR *dest, UNINT sz);
		strcnt(CTPCHAR src, CHAR chr, INT &cnt);
		

	Dependancies
		..\Library\includes\redefs.h


********************************************************************************************/

#ifndef ZIONLIBRARY_STRUTIL_H
#define ZIONLIBRARY_STRUTIL_H

#define MAX_STR (255)//useful number ;)
#define BIG_STR (512)
#define HUGE_STR (1024)

namespace jkl_str
{
//allocate dest and copy src to dest
//returns number of bytes copied
unsigned int strcpyalloc(char **dest, const char *src);
//reallocates dest and appends contents of src
//returns total size of dest
unsigned int strcatalloc(char **dest, const char *src);
//allocates a string of size sz
unsigned int stralloc(char **dest, unsigned int sz);
//counts number of characters in string
unsigned int strcnt(const char *src, char chr, int &cnt);
};
#endif