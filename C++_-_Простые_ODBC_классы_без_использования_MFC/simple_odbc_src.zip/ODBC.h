// ODBCCnx.h: interface for the CODBCCnx class.
//
//////////////////////////////////////////////////////////////////////

#ifndef QMNGR_DATA_INIT_SZ
#define QMNGR_DATA_INIT_SZ (255)
#endif

#if !defined(AFX_ODBCCNX_H__C02BC524_217B_11D4_8C0E_00A0C913129E__INCLUDED_)
#define AFX_ODBCCNX_H__C02BC524_217B_11D4_8C0E_00A0C913129E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "windows.h"
#include <sql.h>
#include <sqlext.h>

#ifndef MAX_DBSTR
#define MAX_DBSTR (255)
#endif

int SQLSuccess(SQLRETURN ret);
int SQLtoC(SQLSMALLINT *c, SQLSMALLINT sql);




class CODBCCnx  
{
public:
	//enums for various uses ;-)
	enum {INIT_ENV=1,INIT_CON,INIT_STMT,INIT_UNKNOWN};
public:
	enum CNXTYPE{CNX_DRIVER=0,CNX_DSN};
	CODBCCnx();
	CODBCCnx(char *dsn, char *usr, char *pwd);
	CODBCCnx(char *dbms, char *cnx, char *usr, char *pwd);
	virtual ~CODBCCnx();
	virtual SQLRETURN Connect();
	virtual SQLRETURN Connect(SQLHANDLE stmt);
	virtual SQLRETURN Connect(char *dsn, char *usr, char *pwd);
	virtual SQLRETURN Connect(char *dbms, char *cnx, char *usr, char *pwd);

	virtual SQLRETURN Disconnect(SQLSMALLINT action);
	virtual int IsOk();
public:
	
	

	//making this public for query access
	SQLHANDLE h_stmt;	//statement handle

protected:
	SQLHANDLE h_env;	//environment handle
	SQLHANDLE h_con;	//connection handle


	//the following are flags for status of events
	//such as initialization state, etc...
	bool m_isEnv;	//environment handle inited
	bool m_isCon;	//connection handle inited
	bool m_isStmt;	//statement handle inited
	


	//the following are for connecting to the dsn
	char	*m_dsn;		//name of the dsn
	char	*m_usr;		//user name used to connect with
	char	*m_pwd;		//pwd for the user
	int		m_szDsn;	//size of m_dsn
	int		m_szUsr;	//size of m_usr
	int		m_szPwd;	//size of m_pwd
	char	*m_driver;	//format string for connecting to a driver
	char	*m_dbms;	//the driver name to connect to, i.e. DBMS
	char	*m_cnx;		//the name of the server we are connecting to
	char	*m_cnxstr;	//the formated connection string
	

};

/*
	Basic implementation of a query... uses CODBCCnx as connection
*/
class CODBCQuery
{
public:
	CODBCQuery();
	CODBCQuery(CODBCCnx *cnx, bool isnew=false);
	CODBCQuery(char *dbms, char *cnx, char *usr, char *pwd);	
	~CODBCQuery();

	SQLRETURN Prepare(char *qry);

	bool IsBound();
	bool HasData();
	bool IsPrepared();


	SQLHANDLE h_qstmt;
protected:
	CODBCCnx *p_con;//connection
	

	//various flags for status of query object
protected:
	bool m_conIsNew;//whether the CODBCCnx is "shared" or unique
	bool m_isBound;
	bool m_hasData;
	bool m_isPrepared;
};

/*
	Meant to seperate out FAT cursors and regular cursors
*/
class CODBCFatQuery : public CODBCQuery
{
public:
	CODBCFatQuery(CODBCCnx *cnx, unsigned int sz=1, bool isnew=false);
	~CODBCFatQuery();
	int GetStatus(unsigned int num, unsigned long *stat);
	unsigned long GetCount();
protected:	
	virtual SQLRETURN FatSize(unsigned int sz);
public:
protected:
	SQLUSMALLINT *m_rowStatus;
	SQLUINTEGER m_rowFetched;
	unsigned int m_size;
private:
};


#endif // !defined(AFX_ODBCCNX_H__C02BC524_217B_11D4_8C0E_00A0C913129E__INCLUDED_)
