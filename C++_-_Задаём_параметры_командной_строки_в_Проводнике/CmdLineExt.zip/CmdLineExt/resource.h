//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CmdLineExt.rc
//
#define IDS_PROJNAME                    100
#define IDR_CMDLINECONTEXTMENU          101
#define IDS_ABOUTTEXT                   101
#define IDD_CMDLINEPROMPTDLG            102
#define IDI_DOS_PROMPT                  201
#define IDC_COMBO_CMD_LINE              202
#define IDI_DOS_PROMPT_BLINK            202
#define IDC_STATIC_DOS_PROMPT           203

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
