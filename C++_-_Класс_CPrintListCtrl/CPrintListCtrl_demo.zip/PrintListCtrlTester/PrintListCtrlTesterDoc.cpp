// ==========================================================================
// PrintListCtrlTesterDoc.cpp
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

// ==========================================================================
// Les Includes
// ==========================================================================

#include "stdafx.h"
#include "PrintListCtrlTester.h"
#include "PrintListCtrlTesterDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterDoc

IMPLEMENT_DYNCREATE(CPrintListCtrlTesterDoc, CDocument)

BEGIN_MESSAGE_MAP(CPrintListCtrlTesterDoc, CDocument)
	//{{AFX_MSG_MAP(CPrintListCtrlTesterDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterDoc construction/destruction

CPrintListCtrlTesterDoc::CPrintListCtrlTesterDoc()
 {
 }

CPrintListCtrlTesterDoc::~CPrintListCtrlTesterDoc()
 {
 }

BOOL CPrintListCtrlTesterDoc::OnNewDocument()
 {
  if (!CDocument::OnNewDocument()) return FALSE;

  return TRUE;
 }

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterDoc serialization

void CPrintListCtrlTesterDoc::Serialize(CArchive& ar)
 {
 }

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterDoc diagnostics

#ifdef _DEBUG
void CPrintListCtrlTesterDoc::AssertValid() const
 {
  CDocument::AssertValid();
 }

void CPrintListCtrlTesterDoc::Dump(CDumpContext& dc) const
 {
  CDocument::Dump(dc);
 }
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterDoc commands
