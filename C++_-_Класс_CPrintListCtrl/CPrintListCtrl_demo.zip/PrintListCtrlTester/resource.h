//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PrintListCtrlTester.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_PRINTLISTCTRLTESTER_FORM    101
#define IDR_MAINFRAME                   128
#define IDR_PRINTLTYPE                  129
#define IDLC_LISTCTRL                   1000
#define IDPB_PRINT                      1001
#define IDPB_PRINTSETUP                 1002
#define IDCB_PRINTHEAD                  1003
#define IDCB_PRINTCOLUMNSEPARATOR       1004
#define IDCB_PRINTLINESEPARATOR         1005
#define IDCB_RESIZECOLUMNS              1006
#define IDCB_TRUNCATECOLUMN             1007
#define IDED_HEADFONTNAME               1008
#define IDED_HEADFONTHEIGHT             1009
#define IDED_LISTFONTNAME               1010
#define IDED_LISTFONTHEIGHT             1011
#define IDCB_PRINTHEADBKGND             1012
#define IDED_FOOTFONTNAME               1013
#define IDED_FOOTFONTHEIGHT             1014
#define IDCB_PRINTFOOT                  1015
#define IDC_SPIN1                       1016
#define IDC_SPIN2                       1017
#define IDC_SPIN3                       1018
#define IDCB_PRINTFOOTBKGND             1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
