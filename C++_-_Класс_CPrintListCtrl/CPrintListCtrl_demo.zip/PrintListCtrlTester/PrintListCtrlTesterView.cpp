// ==========================================================================
// PrintListCtrlTesterView.cpp
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

// ==========================================================================
// Les Includes
// ==========================================================================

#include "stdafx.h"
#include "PrintListCtrlTester.h"

#include "PrintListCtrlTesterDoc.h"
#include "PrintListCtrlTesterView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// ==========================================================================
// Les Defines
// ==========================================================================

#define MAX_COLUMNS     5
#define MAX_LINES      10

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterView

IMPLEMENT_DYNCREATE(CPrintListCtrlTesterView, CFormView)

BEGIN_MESSAGE_MAP(CPrintListCtrlTesterView, CFormView)
	//{{AFX_MSG_MAP(CPrintListCtrlTesterView)
	ON_BN_CLICKED(IDPB_PRINT, OnPB_Print)
	ON_BN_CLICKED(IDPB_PRINTSETUP, OnPB_PrintSetup)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterView construction/destruction

CPrintListCtrlTesterView::CPrintListCtrlTesterView()
	: CFormView(CPrintListCtrlTesterView::IDD)
 {
	//{{AFX_DATA_INIT(CPrintListCtrlTesterView)
	//}}AFX_DATA_INIT
 }

CPrintListCtrlTesterView::~CPrintListCtrlTesterView()
 {
 }

void CPrintListCtrlTesterView::DoDataExchange(CDataExchange* pDX)
 {
  CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrintListCtrlTesterView)
	DDX_Control(pDX, IDLC_LISTCTRL, m_LC);
	//}}AFX_DATA_MAP
 }

BOOL CPrintListCtrlTesterView::PreCreateWindow(CREATESTRUCT& cs)
 {

  return CFormView::PreCreateWindow(cs);
 }

void CPrintListCtrlTesterView::OnInitialUpdate()
 {
  CFormView::OnInitialUpdate();

  FillListCtrl();

  m_cPrintListCtrl.SetListCtrl(m_LC.GetSafeHwnd());
  
  m_cPrintListCtrl.ResizeColumnsToFitContent(FALSE);

  m_cPrintListCtrl.TruncateColumn(TRUE);

  m_cPrintListCtrl.PrintColumnSeparator(TRUE);

  m_cPrintListCtrl.PrintLineSeparator(FALSE);

  m_cPrintListCtrl.PrintHead(TRUE);

  m_cPrintListCtrl.SetHeadFont("Times New Roman", 12);
  m_cPrintListCtrl.SetFootFont("Times New Roman", 12);

  m_cPrintListCtrl.SetPrinterOrientation(FALSE);

  ((CButton *)GetDlgItem(IDCB_PRINTHEAD           ))->SetCheck(m_cPrintListCtrl.GetPrintHead());
  ((CButton *)GetDlgItem(IDCB_PRINTFOOT           ))->SetCheck(m_cPrintListCtrl.GetPrintFoot());
  ((CButton *)GetDlgItem(IDCB_PRINTCOLUMNSEPARATOR))->SetCheck(m_cPrintListCtrl.GetPrintColumnSeparator());
  ((CButton *)GetDlgItem(IDCB_PRINTLINESEPARATOR  ))->SetCheck(m_cPrintListCtrl.GetPrintLineSeparator());
  ((CButton *)GetDlgItem(IDCB_RESIZECOLUMNS       ))->SetCheck(m_cPrintListCtrl.GetResizeColumnsToFitContent());
  ((CButton *)GetDlgItem(IDCB_TRUNCATECOLUMN      ))->SetCheck(m_cPrintListCtrl.GetTruncateColumn());

  SetDlgItemText(IDED_HEADFONTNAME, m_cPrintListCtrl.GetHeadFontName());
  SetDlgItemText(IDED_FOOTFONTNAME, m_cPrintListCtrl.GetFootFontName());
  SetDlgItemText(IDED_LISTFONTNAME, m_cPrintListCtrl.GetListFontName());
	
  SetDlgItemInt(IDED_HEADFONTHEIGHT, m_cPrintListCtrl.GetHeadFontHeight(), FALSE);
  SetDlgItemInt(IDED_FOOTFONTHEIGHT, m_cPrintListCtrl.GetFootFontHeight(), FALSE);
  SetDlgItemInt(IDED_LISTFONTHEIGHT, m_cPrintListCtrl.GetListFontHeight(), FALSE);

  GetParentFrame()->RecalcLayout();
  ResizeParentToFit();
 }

void CPrintListCtrlTesterView::FillListCtrl()
 {
  CString str;

  for (int C=0; C<MAX_COLUMNS; C++)
   {
    str.Format("Column %02d", C);
    
    if (C == 0) m_LC.InsertColumn(C, str, LVCFMT_LEFT, 80);
    else if (C == 1) m_LC.InsertColumn(C, str, LVCFMT_CENTER, 80);
         else if (C == 2) m_LC.InsertColumn(C, str, LVCFMT_RIGHT, 80);
              else m_LC.InsertColumn(C, str, LVCFMT_LEFT, 80);

//     if (C == 0) m_LC.AddColumn(C, str, LVCFMT_LEFT, 80);
//     else if (C == 1) m_LC.AddColumn(C, str, LVCFMT_CENTER, 80);
//          else if (C == 2) m_LC.AddColumn(C, str, LVCFMT_RIGHT, 80);
//               else m_LC.AddColumn(C, str, LVCFMT_LEFT, 80);
   }

  for (int L=0; L<MAX_LINES; L++)
   for (C=0; C<MAX_COLUMNS; C++)
    {
     str.Format("Item (%02d;%02d)", L, C);

     if (C == 0) m_LC.InsertItem(L, str);
     else m_LC.SetItemText(L, C, str);

//      if (C == 0) m_LC.AddItem(L, C, str);
//      else m_LC.ModifyItem(L, C, str);
    }
 }

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterView printing

BOOL CPrintListCtrlTesterView::OnPreparePrinting(CPrintInfo* pInfo)
 {
  CListCtrl &cList = GetListCtrl();
  HWND       hWnd  = cList.m_hWnd;

  m_cPrintListCtrl.SetListCtrl(hWnd);
  m_cPrintListCtrl.OnPreparePrinting(pInfo, GetDocument()->GetTitle());
   
  // default preparation
  return DoPreparePrinting(pInfo);
 }

void CPrintListCtrlTesterView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
 {
  m_cPrintListCtrl.OnBeginPrinting(pDC, pInfo);
  CFormView::OnBeginPrinting(pDC, pInfo);
 }

void CPrintListCtrlTesterView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
 {
  m_cPrintListCtrl.OnEndPrinting(pDC, pInfo);
  CFormView::OnEndPrinting(pDC, pInfo);
 }

void CPrintListCtrlTesterView::OnPrint(CDC *pDC, CPrintInfo* pInfo)
 {
  m_cPrintListCtrl.OnPrint(pDC, pInfo);
 }

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterView diagnostics

#ifdef _DEBUG
void CPrintListCtrlTesterView::AssertValid() const
 {
  CFormView::AssertValid();
 }

void CPrintListCtrlTesterView::Dump(CDumpContext& dc) const
 {
  CFormView::Dump(dc);
 }

CPrintListCtrlTesterDoc* CPrintListCtrlTesterView::GetDocument() // non-debug version is inline
 {
  ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPrintListCtrlTesterDoc)));
  return (CPrintListCtrlTesterDoc*)m_pDocument;
 }
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterView message handlers

void CPrintListCtrlTesterView::OnPB_Print() 
 {
  CString strHeadFont, strListFont, strFootFont;
  int     iHeadFontHeight, iListFontHeight, iFootFontHeight;
  
  GetDlgItemText(IDED_HEADFONTNAME, strHeadFont);
  GetDlgItemText(IDED_FOOTFONTNAME, strFootFont);
  GetDlgItemText(IDED_LISTFONTNAME, strListFont);

  iHeadFontHeight = (int)GetDlgItemInt(IDED_HEADFONTHEIGHT);
  iFootFontHeight = (int)GetDlgItemInt(IDED_FOOTFONTHEIGHT);
  iListFontHeight = (int)GetDlgItemInt(IDED_LISTFONTHEIGHT);

  m_cPrintListCtrl.PrintColumnSeparator(((CButton *)GetDlgItem(IDCB_PRINTCOLUMNSEPARATOR))->GetCheck());
  m_cPrintListCtrl.PrintHead(((CButton *)GetDlgItem(IDCB_PRINTHEAD))->GetCheck());
  m_cPrintListCtrl.PrintFoot(((CButton *)GetDlgItem(IDCB_PRINTFOOT))->GetCheck());
  m_cPrintListCtrl.PrintLineSeparator(((CButton *)GetDlgItem(IDCB_PRINTLINESEPARATOR))->GetCheck());
  m_cPrintListCtrl.ResizeColumnsToFitContent(((CButton *)GetDlgItem(IDCB_RESIZECOLUMNS))->GetCheck());
  m_cPrintListCtrl.TruncateColumn(((CButton *)GetDlgItem(IDCB_PRINTHEAD))->GetCheck());
  m_cPrintListCtrl.PrintHeadBkgnd(((CButton *)GetDlgItem(IDCB_PRINTHEADBKGND))->GetCheck(), RGB(255,0,0));
  m_cPrintListCtrl.PrintFootBkgnd(((CButton *)GetDlgItem(IDCB_PRINTFOOTBKGND))->GetCheck(), RGB(255,0,0));

  m_cPrintListCtrl.SetHeadFont(strHeadFont, iHeadFontHeight);
  m_cPrintListCtrl.SetFootFont(strFootFont, iFootFontHeight);
  m_cPrintListCtrl.SetListFont(strListFont, iListFontHeight);

  if (!m_cPrintListCtrl.Print(GetSafeHwnd()))
   MessageBox("Failed to print list control contain !");
 }

void CPrintListCtrlTesterView::OnPB_PrintSetup() 
 {
  if (!m_cPrintListCtrl.PrintSetup(GetSafeHwnd()))
   MessageBox("Failed to set printer settings !");
 }
  