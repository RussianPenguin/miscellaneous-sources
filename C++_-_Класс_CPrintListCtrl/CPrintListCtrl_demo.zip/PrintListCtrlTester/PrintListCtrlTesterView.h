// ==========================================================================
// PrintListCtrlTesterView.h
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

#if !defined(AFX_PRINTLISTCTRLTESTERVIEW_H__14C4339D_056A_11D4_A146_004005555C30__INCLUDED_)
#define AFX_PRINTLISTCTRLTESTERVIEW_H__14C4339D_056A_11D4_A146_004005555C30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ==========================================================================
// Les Includes
// ==========================================================================

#include "MMA Libraries Files\PrintListCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// class CPrintListCtrlTesterView

class CPrintListCtrlTesterView : public CFormView
 {
  protected :
              CPrintListCtrl m_cPrintListCtrl;

              CPrintListCtrlTesterView();
              DECLARE_DYNCREATE(CPrintListCtrlTesterView)

              void FillListCtrl();

              // INLINE
              CListCtrl &GetListCtrl() { return m_LC; }

  public :
	//{{AFX_DATA(CPrintListCtrlTesterView)
	enum { IDD = IDD_PRINTLISTCTRLTESTER_FORM };
	CListCtrl	m_LC;
	//}}AFX_DATA

  public :
           CPrintListCtrlTesterDoc *GetDocument();

  public :
	//{{AFX_VIRTUAL(CPrintListCtrlTesterView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

  public :
           virtual ~CPrintListCtrlTesterView();
           #ifdef _DEBUG
           virtual void AssertValid() const;
           virtual void Dump(CDumpContext& dc) const;
           #endif

  protected :

  protected :
	//{{AFX_MSG(CPrintListCtrlTesterView)
	afx_msg void OnPB_Print();
	afx_msg void OnPB_PrintSetup();
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
 };

#ifndef _DEBUG  // debug version in PrintListCtrlTesterView.cpp
inline CPrintListCtrlTesterDoc* CPrintListCtrlTesterView::GetDocument()
   { return (CPrintListCtrlTesterDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRINTLISTCTRLTESTERVIEW_H__14C4339D_056A_11D4_A146_004005555C30__INCLUDED_)
