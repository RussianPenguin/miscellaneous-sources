// SpoofSocket.cpp : implementation file
//
/*
 *
 *
 *  Copyright (c) 2000 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * Contact info:
 * Site: http://www.komodia.com
 * Email: barak@komodia.com
 */

#include "stdafx.h"
#include "Attacker.h"
#include "SpoofSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpoofSocket

CSpoofSocket::CSpoofSocket()
{
	//Invalid the socket
	m_SpoofSocket=INVALID_SOCKET;

	//More invalids
	m_SourceAddress=NULL;

	//Some defaults
	m_TTL=IP_DEF_TTL;
}

CSpoofSocket::~CSpoofSocket()
{
	Close();
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CSpoofSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CSpoofSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CSpoofSocket member functions

BOOL CSpoofSocket::Create(int iProtocol)
{
	//Here we create the raw socket
	m_SpoofSocket=socket(AF_INET,SOCK_RAW,iProtocol);//iProtocol);

	//Check for socket validity
	if (m_SpoofSocket==INVALID_SOCKET)
	{
		//Error
		m_LastError=WSAGetLastError();
		return FALSE;
	}

	//Set that the application will send the IP header
	unsigned int iTrue=1;

	if(setsockopt(m_SpoofSocket,IPPROTO_IP,IP_HDRINCL,(char*)&iTrue,sizeof(iTrue))==SOCKET_ERROR)
	{
		//Check for options error
		m_LastError=WSAGetLastError();
		return FALSE;
	}

	//Now set the send buffer size
	
	m_LastError=0;

	return TRUE;
}

BOOL CSpoofSocket::Send(LPCSTR lpDestinationAddress,char* buf,int bufLength)
{
	//Quit if not ok
	if (!CheckSocketValid())
		return FALSE;

	//First construct the packet
	LPIpHeader lpHead=ConstructIPHeader(m_Protocol,IpFragFlag_DONT_FRAG,m_TTL,GetCurrentProcessId());

	//Set the address
	SetIPHeaderAddress(lpHead,m_SourceAddress,lpDestinationAddress);

	//Now add some more options
	int iTotalLength;
	iTotalLength=IpHeaderLength+bufLength;

	//Set the header
	lpHead->TotalLength=htons(iTotalLength);

	//Need to construct a new packet
	char* newBuf=new char[iTotalLength];
	//Copy two buffers
	memcpy(newBuf,lpHead,IpHeaderLength);

	//Only if not null
	if (buf)
		memcpy(newBuf+IpHeaderLength,buf,bufLength);
	
	//Calculate the checksum
	lpHead->CheckSum=CalculateChecksum((unsigned short*)newBuf,iTotalLength);

	//Recopy the ip
	memcpy(newBuf,lpHead,IpHeaderLength);

	//Send the packet
	int iResult;

	//Define the target address
	sockaddr_in m_TargetAddress;
	memset(&m_TargetAddress,0,sizeof(m_TargetAddress));

	m_TargetAddress.sin_family=AF_INET;
	m_TargetAddress.sin_addr.s_addr=inet_addr(lpDestinationAddress);
	m_TargetAddress.sin_port=0;

	//Send the data
	iResult=sendto(m_SpoofSocket,(const char*)newBuf,iTotalLength,0,(sockaddr*)&m_TargetAddress,sizeof(m_TargetAddress));
	
	if (iResult==SOCKET_ERROR)
		//Set the error
		SetLastError();
	else
		m_LastError=0;

	//Dispose of the buffer
	delete newBuf;

	//Dispose the header
	delete lpHead;

	return iResult!=SOCKET_ERROR;
}

LPIpHeader CSpoofSocket::ConstructIPHeader(unsigned char  ucProtocol,
										   unsigned short usFragmentationFlags,
										   unsigned short usTTL,
										   unsigned short usIdentification)
{
	//Need to construct the IP header
	LPIpHeader lpHead=new _IpHeader;

	//Header length (in 32 bits)
	lpHead->HeaderLength_Version=IpHeaderLength/4 + IpVersion*16;

	//Version of the IP (Some how doesn't receive constant)
	//lpHead->Version=IpVersion;

	//Protocol
	lpHead->Protocol=ucProtocol;

	//Fragmentation flags
	lpHead->FragmentationFlags=htons(usFragmentationFlags);

	//Time to live
	lpHead->TTL=usTTL;

	//Checksum - set to 0
	lpHead->CheckSum=0;

	//Identification
	lpHead->Identification=htons(usIdentification);

	//Precedence
	lpHead->TypeOfService=IpService_ROUTINE;

	//Return IP to user
	return lpHead;
}

void CSpoofSocket::SetIPHeaderAddress(LPIpHeader lpHead, LPCSTR lpSourceAddress, LPCSTR lpDestinationAddress)
{
	//We need to place the header
	
	//If source is NULL then we need to use default source
	if (!lpSourceAddress)
	{
		//We will implement it
	}
	else
		//Use sockets2
		lpHead->sourceIPAddress=inet_addr(lpSourceAddress);

	//Place destination address
	lpHead->destIPAddress=inet_addr(lpDestinationAddress);

	//Done
}

void CSpoofSocket::SetLastError()
{
	m_LastError=WSAGetLastError();
}

int CSpoofSocket::GetLastError()
{
	return m_LastError;
}

BOOL CSpoofSocket::ValidSocket()
{
	return m_SpoofSocket!=INVALID_SOCKET;
}

unsigned short CSpoofSocket::CalculateChecksum(unsigned short *usBuf, int iSize)
{
	unsigned long usChksum=0;

	//Calculate the checksum
	while (iSize>1)
	{
		usChksum+=*usBuf++;
		iSize-=sizeof(unsigned short);
	}

	//If we have one char left
	if (iSize)
		usChksum+=*(unsigned char*)usBuf;

	//Complete the calculations
	usChksum=(usChksum >> 16) + (usChksum & 0xffff);
	usChksum+=(usChksum >> 16);

	//Return the value (inversed)
	return (unsigned short)(~usChksum);
}


BOOL CSpoofSocket::Bind(LPCSTR lpSourceAddress)
{
	//Quit if not ok
	if (!CheckSocketValid())
		return FALSE;

	//Create the local address
	sockaddr_in soSrc;
	//Set to 0
	memset(&soSrc,0,sizeof(soSrc));
	soSrc.sin_family=AF_INET;
	soSrc.sin_addr.s_addr=inet_addr(lpSourceAddress);

	//Now we need to bind it
	if (bind(m_SpoofSocket,(sockaddr*)&soSrc,sizeof(soSrc))==SOCKET_ERROR)
	{
		//Error
		m_LastError=WSAGetLastError();
		return FALSE;
	}

	m_LastError=0;

	//If already has a source address then don't change it
	if (!m_SourceAddress)
		m_SourceAddress=lpSourceAddress;

	return TRUE;
}

SOCKET CSpoofSocket::getHandle()
{
	return m_SpoofSocket;
}

BOOL CSpoofSocket::CheckSocketValid()
{
	//Check if socket is invalid
	if (!ValidSocket())
	{
		m_LastError=WSAESHUTDOWN;
		return FALSE;
	}

	//OK
	return TRUE;
}

BOOL CSpoofSocket::Close()
{
	//Close the socket
	//Quit if not ok
	if (!CheckSocketValid())
		return FALSE;

	//Close it
	if (closesocket(m_SpoofSocket)==SOCKET_ERROR)
	{
		//Error in closing ?
		m_LastError=WSAGetLastError();
		return FALSE;
	}

	//Set the socket to invalid
	m_SpoofSocket=INVALID_SOCKET;

	return TRUE;
}


BOOL CSpoofSocket::InitializeSockets()
{
	//Initialize the sockets
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
 
	wVersionRequested = MAKEWORD( 2, 2 );
 
	err = WSAStartup( wVersionRequested, &wsaData );
	if (err!=0)
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		return FALSE;
 
	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */
 
	if (LOBYTE(wsaData.wVersion)!=2 || HIBYTE(wsaData.wVersion)!=2)
	{
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		WSACleanup();
		return FALSE;
	}

	//OK
	return TRUE;
}
 

void CSpoofSocket::SetProtocol(int iProtocol)
{
	m_Protocol=iProtocol;
}

void CSpoofSocket::SetSourceAddress(LPCSTR lpSourceAddress)
{
	//Set the source address, in case we want to spoof it
	m_SourceAddress=lpSourceAddress;
}

unsigned short CSpoofSocket::CalculatePseudoChecksum(char *buf, int BufLength,LPCSTR lpDestinationAddress,int iPacketLength)
{
	//Calculate the checksum
	LPPseudoHeader lpPseudo;
	lpPseudo=new PseudoHeader;

	lpPseudo->DestinationAddress=inet_addr(lpDestinationAddress);
	lpPseudo->SourceAddress=inet_addr(m_SourceAddress);
	lpPseudo->Zeros=0;
	lpPseudo->PTCL=m_Protocol;
	lpPseudo->Length=htons(iPacketLength);

	//Calculate checksum of all
	int iTotalLength;
	iTotalLength=PseudoHeaderLength+BufLength;

	char* tmpBuf;
	tmpBuf=new char[iTotalLength];

	//Copy pseudo
	memcpy(tmpBuf,lpPseudo,PseudoHeaderLength);

	//Copy header
	memcpy(tmpBuf+PseudoHeaderLength,buf,BufLength);

	//Calculate the checksum
	unsigned short usChecksum;
	usChecksum=CalculateChecksum((unsigned short*)tmpBuf,iTotalLength);

	//Delete all
	delete tmpBuf;
	delete lpPseudo;

	//Return checksum
	return usChecksum;
}

void CSpoofSocket::SetTTL(unsigned char ucTTL)
{
	//Set the ttl
	m_TTL=ucTTL;
}

BOOL CSpoofSocket::Listen(int iBackLog)
{
	int iResult;
	iResult=listen(m_SpoofSocket,iBackLog);

	if (iResult==SOCKET_ERROR)
		SetLastError();

	return iResult!=SOCKET_ERROR;
}

BOOL CSpoofSocket::ShutdownSockets()
{
	if (WSACleanup()==SOCKET_ERROR)
	{
		SetLastError();
		return FALSE;
	}
	else
		return TRUE;
}
