// TCPSocket.cpp: implementation of the CTCPSocket class.
//
//////////////////////////////////////////////////////////////////////
/*
 *
 *
 *  Copyright (c) 2000 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *
 * Contact info:
 * Site: http://www.komodia.com
 * Email: barak@komodia.com
 */

#include "stdafx.h"
#include "Attacker.h"
#include "TCPSocket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTCPSocket::CTCPSocket() : CSpoofSocket()
{

}

CTCPSocket::~CTCPSocket() 
{
	CSpoofSocket::~CSpoofSocket();
}

BOOL CTCPSocket::Create()
{
	SetProtocol(IPPROTO_TCP);
	return CSpoofSocket::Create(IPPROTO_IP);
}

BOOL CTCPSocket::Connect(int iSourcePort, LPCSTR lpDestinationAddress, int iDestinationPort)
{
	//Let's try our first attack
	LPTCPHeader lpHead;

	//Create the header
	lpHead=ConstructTCPHeader(iSourcePort,iDestinationPort);

	//Set the flags
	SetHeaderFlag(lpHead,TCPFlag_ACK);
	
	lpHead->Checksum=CalculatePseudoChecksum((char*)lpHead,TCPHeaderLength,lpDestinationAddress,TCPHeaderLength);
	
	//Send the data
	BOOL bResult;
	bResult=CSpoofSocket::Send(lpDestinationAddress,(char*)lpHead,TCPHeaderLength);

	//Dispose the header
	delete lpHead;

	return bResult;
}

LPTCPHeader CTCPSocket::ConstructTCPHeader(int iSourcePort, int iDestinationPort)
{
	//Construct the header
	LPTCPHeader lpHead=new _TCPHeader;
	
	//Set source and destination port
	lpHead->SourcePort=htons(iSourcePort);
	lpHead->DestinationPort=htons(iDestinationPort);

	//No checksums yet
	lpHead->Checksum=0;

	//Set windows to 3.0k
	lpHead->Windows=htons(512);

	//Set the packet number
	lpHead->AcknowledgeNumber=0;

	//And the sequence
	lpHead->SequenceNumber=htonl(m_Sequence++);

	//Data offset
	lpHead->DataOffset=(TCPHeaderLength/4) << 4;

	//Flags
	lpHead->Flags=0;

	//Urgent pointer
	lpHead->UrgentPointer=0;

	//Return it to the user
	return lpHead;
}

unsigned int CTCPSocket::m_Sequence=(unsigned int)GetCurrentProcessId();

void CTCPSocket::SetHeaderFlag(LPTCPHeader lpHead, int iFlag)
{
	//Logical or
	lpHead->Flags|=iFlag;	
}
