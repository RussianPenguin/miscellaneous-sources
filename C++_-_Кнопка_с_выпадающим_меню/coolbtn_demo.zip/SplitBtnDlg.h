// SplitBtnDlg.h : header file
//

#if !defined(AFX_SPLITBTNDLG_H__3A906816_CE5F_11D3_808C_005004D6CF90__INCLUDED_)
#define AFX_SPLITBTNDLG_H__3A906816_CE5F_11D3_808C_005004D6CF90__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSplitBtnDlg dialog
#include "CoolBtn.h"

class CSplitBtnDlg : public CDialog
{
// Construction
public:
	CSplitBtnDlg(CWnd* pParent = NULL);	// standard constructor
  CCoolBtn  m_btn;

// Dialog Data
	//{{AFX_DATA(CSplitBtnDlg)
	enum { IDD = IDD_SPLITBTN_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitBtnDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSplitBtnDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFileOpen();
	afx_msg void OnFileOpenReadOnly();
	afx_msg void OnEnable();
	afx_msg void OnDisable();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLITBTNDLG_H__3A906816_CE5F_11D3_808C_005004D6CF90__INCLUDED_)
