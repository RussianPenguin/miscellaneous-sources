// SplitBtn.h : main header file for the SPLITBTN application
//

#if !defined(AFX_SPLITBTN_H__3A906814_CE5F_11D3_808C_005004D6CF90__INCLUDED_)
#define AFX_SPLITBTN_H__3A906814_CE5F_11D3_808C_005004D6CF90__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSplitBtnApp:
// See SplitBtn.cpp for the implementation of this class
//

class CSplitBtnApp : public CWinApp
{
public:
	CSplitBtnApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitBtnApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSplitBtnApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLITBTN_H__3A906814_CE5F_11D3_808C_005004D6CF90__INCLUDED_)
