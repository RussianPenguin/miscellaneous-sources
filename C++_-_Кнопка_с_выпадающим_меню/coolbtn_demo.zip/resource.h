//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SplitBtn.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define ID_OPENFILE                     101
#define IDD_SPLITBTN_DIALOG             102
#define ID_OPENFILE_READ                102
#define IDR_MAINFRAME                   128
#define IDC_FILE                        129
#define IDB_BITMAP1                     131
#define IDC_BUTTON2                     1000
#define IDC_ENABLE                      1001
#define IDC_DISABLE                     1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
