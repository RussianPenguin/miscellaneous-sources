#ifndef __printer_h__
#define __printer_h__


#ifdef __printer_implementation__
#undef EXTERN
#define EXTERN
#endif

EXTERN text lst;
#undef EXTERN
#define EXTERN extern

#endif
