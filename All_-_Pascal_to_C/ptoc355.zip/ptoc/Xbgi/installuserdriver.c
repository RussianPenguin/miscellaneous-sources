/*
 * $Id: installuserdriver.c,v 0.1 1993/12/10 00:39:08 king Exp king $
 * Installs a vendor-added device driver to the BGI device driver table.
 *
 * $Log: installuserdriver.c,v $
 * Revision 0.1  1993/12/10  00:39:08  king
 * Initial version.
 *
 */
#include "graphics.h"

int installuserdriver(char *name, int *detect)
{
/*
 * This routine not currently implemented.
 */
    return 0;
}
