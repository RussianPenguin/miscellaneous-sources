// ProgressBarTestDlg.h : header file
//

#if !defined(AFX_PROGRESSBARTESTDLG_H__476B90AA_6932_11D4_B261_00104BB13A66__INCLUDED_)
#define AFX_PROGRESSBARTESTDLG_H__476B90AA_6932_11D4_B261_00104BB13A66__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProgressCtrlX.h"

/////////////////////////////////////////////////////////////////////////////
// CProgressBarTestDlg dialog

class CProgressBarTestDlg : public CDialog
{
// Construction
public:
	CProgressBarTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CProgressBarTestDlg)
	enum { IDD = IDD_PROGRESSBARTEST_DIALOG };
	CButton	m_btnRun;
	CProgressCtrlX	m_progressV;
	CProgressCtrlX	m_progressH;
	BOOL	m_fUseBrush;
	BOOL	m_fRubberBar;
	BOOL	m_fTiedText;
	BOOL	m_fVertText;
	int		m_nBorder;
	int		m_iTextMode;
	int		m_iProgressMode;
	UINT	m_nRange;
	int 	m_nStepSize;
	UINT	m_nTailSize;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgressBarTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CFont m_fontV;
	CFont m_fontH;
	int m_pos;
	BOOL m_inc;
	CBrush m_brBk;
	CBrush m_brBar;

	// Generated message map functions
	//{{AFX_MSG(CProgressBarTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButtonMssetup();
	afx_msg void OnButtonMulticolor();
	afx_msg void OnButtonNsSnake();
	afx_msg void OnCheckBrush();
	afx_msg void OnCheckRubberbar();
	afx_msg void OnCheckTiedtext();
	afx_msg void OnCheckVerttext();
	afx_msg void OnClrBk();
	afx_msg void OnClrEnd();
	afx_msg void OnClrStart();
	afx_msg void OnChangeEditBorder();
	afx_msg void OnRadioTextMode();
	afx_msg void OnRadioProgressMode();
	afx_msg void OnChangeRange();
	afx_msg void OnReset();
	afx_msg void OnReverse();
	afx_msg void OnRun();
	afx_msg void OnStep();
	afx_msg void OnChangeStepsize();
	afx_msg void OnChangeTail();
	afx_msg void OnClrTextBk();
	afx_msg void OnClrTextBar();
	afx_msg void OnButtonMulticolorCentered();
	afx_msg void OnButtonMySnake();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRESSBARTESTDLG_H__476B90AA_6932_11D4_B261_00104BB13A66__INCLUDED_)
