// ProgressBarTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ProgressBarTest.h"
#include "ProgressBarTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BASE 500	// for test 

#define PROGRESS 0
#define SNAKE 1

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgressBarTestDlg dialog

CProgressBarTestDlg::CProgressBarTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgressBarTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProgressBarTestDlg)
	m_fUseBrush = FALSE;
	m_fRubberBar = FALSE;
	m_fTiedText = FALSE;
	m_fVertText = TRUE;
	m_nBorder = 0;
	m_iTextMode = 0;
	m_iProgressMode = 0;
	m_nRange = 100;
	m_nStepSize = 2;
	m_nTailSize = 40;
	//}}AFX_DATA_INIT
	m_pos = 0;
	m_inc = TRUE;

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CProgressBarTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProgressBarTestDlg)
	DDX_Control(pDX, IDC_RUN, m_btnRun);
	DDX_Control(pDX, IDC_PROGRESS_V, m_progressV);
	DDX_Control(pDX, IDC_PROGRESS_H, m_progressH);
	DDX_Check(pDX, IDC_CHECK_BRUSH, m_fUseBrush);
	DDX_Check(pDX, IDC_CHECK_RUBBERBAR, m_fRubberBar);
	DDX_Check(pDX, IDC_CHECK_TIEDTEXT, m_fTiedText);
	DDX_Check(pDX, IDC_CHECK_VERTTEXT, m_fVertText);
	DDX_Text(pDX, IDC_EDIT_BORDER, m_nBorder);
	DDV_MinMaxInt(pDX, m_nBorder, 0, 10);
	DDX_Radio(pDX, IDC_RADIO_NOTEXT, m_iTextMode);
	DDX_Radio(pDX, IDC_RADIO_PROGRESS, m_iProgressMode);
	DDX_Text(pDX, IDC_RANGE, m_nRange);
	DDX_Text(pDX, IDC_STEPSIZE, m_nStepSize);
	DDX_Text(pDX, IDC_TAIL, m_nTailSize);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CProgressBarTestDlg, CDialog)
	//{{AFX_MSG_MAP(CProgressBarTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_MSSETUP, OnButtonMssetup)
	ON_BN_CLICKED(IDC_BUTTON_MULTICOLOR, OnButtonMulticolor)
	ON_BN_CLICKED(IDC_BUTTON_NS_SNAKE, OnButtonNsSnake)
	ON_BN_CLICKED(IDC_CHECK_BRUSH, OnCheckBrush)
	ON_BN_CLICKED(IDC_CHECK_RUBBERBAR, OnCheckRubberbar)
	ON_BN_CLICKED(IDC_CHECK_TIEDTEXT, OnCheckTiedtext)
	ON_BN_CLICKED(IDC_CHECK_VERTTEXT, OnCheckVerttext)
	ON_BN_CLICKED(IDC_CLR_BK, OnClrBk)
	ON_BN_CLICKED(IDC_CLR_END, OnClrEnd)
	ON_BN_CLICKED(IDC_CLR_START, OnClrStart)
	ON_EN_CHANGE(IDC_EDIT_BORDER, OnChangeEditBorder)
	ON_BN_CLICKED(IDC_RADIO_NOTEXT, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_PROGRESS, OnRadioProgressMode)
	ON_EN_CHANGE(IDC_RANGE, OnChangeRange)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_REVERSE, OnReverse)
	ON_BN_CLICKED(IDC_RUN, OnRun)
	ON_BN_CLICKED(IDC_STEP, OnStep)
	ON_EN_CHANGE(IDC_STEPSIZE, OnChangeStepsize)
	ON_EN_CHANGE(IDC_TAIL, OnChangeTail)
	ON_BN_CLICKED(IDC_CLR_TEXT_BK, OnClrTextBk)
	ON_BN_CLICKED(IDC_CLR_TEXT_BAR, OnClrTextBar)
	ON_BN_CLICKED(IDC_BUTTON_MULTICOLOR_CENTERED, OnButtonMulticolorCentered)
	ON_BN_CLICKED(IDC_RADIO_PERCENT, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_PERCENT_F, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_POS, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_POS_F, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_TEXTONLY, OnRadioTextMode)
	ON_BN_CLICKED(IDC_RADIO_SNAKE, OnRadioProgressMode)
	ON_BN_CLICKED(IDC_BUTTON_MY_SNAKE, OnButtonMySnake)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgressBarTestDlg message handlers

BOOL CProgressBarTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
//	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	OnChangeRange(); //init
	OnChangeStepsize(); //init

	LOGFONT lf;
	memset (&lf, 0, sizeof (LOGFONT));
	_tcscpy (lf.lfFaceName, _T("Arial")); // !!!!!!!! Only True-Type Fonts (TTF) can be rotated
	lf.lfWeight = 700;
	m_fontH.CreateFontIndirect(&lf);
	lf.lfOrientation = 900;
	lf.lfEscapement = 900;
	m_fontV.CreateFontIndirect(&lf);
	m_progressV.SetFont(&m_fontV);
	m_progressH.SetFont(&m_fontH);

	m_brBk.CreateHatchBrush(HS_DIAGCROSS, RGB(0,0,255));
	CBitmap bmp;
	bmp.LoadBitmap(IDB_BITMAP1);
	m_brBar.CreatePatternBrush(&bmp);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CProgressBarTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CProgressBarTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CProgressBarTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CProgressBarTestDlg::OnRun() 
{
	// TODO: Add your control notification handler code here
	static BOOL fRun = FALSE;
	if(fRun)
	{
		m_btnRun.SetWindowText("Run");
		KillTimer(1);
	}
	else
	{
		m_btnRun.SetWindowText("Stop");
		SetTimer(1, 55, 0);
	}
	fRun = !fRun;
}

void CProgressBarTestDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_iProgressMode == PROGRESS)
	{
		if((UINT)m_pos > m_nRange)
			m_pos = m_nRange;
		if(m_pos < 0)
			m_pos = 0;
		if((UINT)m_pos == m_nRange)
			m_inc = FALSE;
		if(m_pos == 0)
			m_inc = TRUE;
		m_pos += (m_inc ? m_nStepSize : -m_nStepSize);
		m_progressH.SetPos(BASE+m_pos);
		m_progressV.SetPos(BASE+m_pos);
	}
	else
	{
		m_progressH.StepIt();
		m_progressV.StepIt();
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CProgressBarTestDlg::OnButtonMssetup() 
{
	// TODO: Add your control notification handler code here
	COLORREF white = RGB(255,255,255);
	COLORREF blue = RGB(0,0,127);
	
	m_progressH.SetBkColor(white);
	m_progressV.SetBkColor(white);

	m_progressH.SetGradientColors(blue, blue);
	m_progressV.SetGradientColors(blue, blue);
	
	m_progressH.SetTextColor(white, blue);
	m_progressV.SetTextColor(white, blue);

	m_fUseBrush = FALSE;
	m_fTiedText = FALSE;
	m_nBorder = 0;
	m_iTextMode = 1;
	m_iProgressMode = PROGRESS;

	UpdateData(FALSE);
	OnCheckBrush();
	OnCheckTiedtext();
	OnChangeEditBorder();
	OnRadioTextMode();
	OnRadioProgressMode();
	if(m_progressH.GetStyle()&PBS_REVERSE)
		OnReverse();
}

void CProgressBarTestDlg::OnButtonMulticolor() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrStart, clrEnd;
	m_progressH.GetGradientColors(clrStart, clrEnd);
	if(clrStart == clrEnd)
	{
		clrStart = RGB(255, 0, 0);
		clrEnd = RGB(0,0,127);
	}

	m_progressH.SetGradientColorsX(4, clrStart, clrEnd, clrStart, clrEnd);
	m_progressV.SetGradientColorsX(4, clrStart, clrEnd, clrStart, clrEnd);

	m_fUseBrush = FALSE;
	UpdateData(FALSE);
	OnCheckBrush();
}

void CProgressBarTestDlg::OnButtonMulticolorCentered() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrStart, clrEnd;
	m_progressH.GetGradientColors(clrStart, clrEnd);
	if(clrStart == clrEnd)
	{
		clrStart = RGB(255, 0, 0);
		clrEnd = RGB(0,255,0);
	}

	m_progressH.SetGradientColorsX(3, clrStart, clrEnd, clrStart);
	m_progressV.SetGradientColorsX(3, clrStart, clrEnd, clrStart);

	m_fUseBrush = FALSE;
	UpdateData(FALSE);
	OnCheckBrush();
}

void CProgressBarTestDlg::OnButtonNsSnake() 
{
	// TODO: Add your control notification handler code here
	COLORREF black = RGB(0,0,0);
	COLORREF gray = RGB(192,192,192);
	COLORREF dkgray = RGB(128,128,128);
	
	m_progressH.SetBkColor(gray);
	m_progressV.SetBkColor(gray);

	m_progressH.SetGradientColors(gray, dkgray);
	m_progressV.SetGradientColors(gray, dkgray);
	
	m_progressH.SetTextColor(black, black);
	m_progressV.SetTextColor(black, black);

	m_fUseBrush = FALSE;
	m_nBorder = 0;
	m_iTextMode = 0;
	m_iProgressMode = SNAKE;

	UpdateData(FALSE);
	OnCheckBrush();
	OnChangeEditBorder();
	OnRadioTextMode();
	OnRadioProgressMode();
}

void CProgressBarTestDlg::OnCheckBrush() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	CBrush* pbrBar = NULL, *pbrBk = NULL;
	if(m_fUseBrush)
	{
		pbrBar = &m_brBar;
		pbrBk = &m_brBk;
	}
	
	m_progressH.SetBarBrush(pbrBar);
	m_progressH.SetBkBrush(pbrBk);
	
	m_progressV.SetBarBrush(pbrBar);
	m_progressV.SetBkBrush(pbrBk);
	
	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnCheckRubberbar() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetRubberBar(m_fRubberBar);
	m_progressV.SetRubberBar(m_fRubberBar);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnCheckTiedtext() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetTiedText(m_fTiedText);
	m_progressV.SetTiedText(m_fTiedText);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnCheckVerttext() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressV.SetFont(m_fVertText ? &m_fontV : &m_fontH);
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnClrBk() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrBk = m_progressH.GetBkColor();
	CColorDialog dlg(clrBk, CC_SOLIDCOLOR, this);
	if(dlg.DoModal() != IDOK)
		return;
	
	clrBk = dlg.GetColor();

	m_progressH.SetBkColor(clrBk);
	m_progressV.SetBkColor(clrBk);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnClrEnd() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrStart, clrEnd;
	m_progressH.GetGradientColors(clrStart, clrEnd);
	CColorDialog dlg(clrEnd, CC_ANYCOLOR, this);
	if(dlg.DoModal() != IDOK)
		return;
	
	clrEnd = dlg.GetColor();

	m_progressH.SetGradientColors(clrStart, clrEnd);
	m_progressV.SetGradientColors(clrStart, clrEnd);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnClrStart() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrStart, clrEnd;
	m_progressH.GetGradientColors(clrStart, clrEnd);
	CColorDialog dlg(clrStart, CC_ANYCOLOR, this);
	if(dlg.DoModal() != IDOK)
		return;
	
	clrStart = dlg.GetColor();

	m_progressH.SetGradientColors(clrStart, clrEnd);
	m_progressV.SetGradientColors(clrStart, clrEnd);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
	
}

void CProgressBarTestDlg::OnClrTextBk() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrTextOnBar = m_progressH.GetTextColor();
	COLORREF clrTextOnBk = m_progressH.GetTextColorOnBk();
	CColorDialog dlg(clrTextOnBk, CC_SOLIDCOLOR, this);
	if(dlg.DoModal() != IDOK)
		return;
	
	clrTextOnBk = dlg.GetColor();

	m_progressH.SetTextColor(clrTextOnBar, clrTextOnBk);
	m_progressV.SetTextColor(clrTextOnBar, clrTextOnBk);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnClrTextBar() 
{
	// TODO: Add your control notification handler code here
	COLORREF clrTextOnBar = m_progressH.GetTextColor();
	COLORREF clrTextOnBk = m_progressH.GetTextColorOnBk();
	CColorDialog dlg(clrTextOnBar, CC_SOLIDCOLOR, this);
	if(dlg.DoModal() != IDOK)
		return;
	
	clrTextOnBar = dlg.GetColor();

	m_progressH.SetTextColor(clrTextOnBar, clrTextOnBk);
	m_progressV.SetTextColor(clrTextOnBar, clrTextOnBk);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnChangeEditBorder() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	CRect rcBorders(m_nBorder, m_nBorder, m_nBorder, m_nBorder);
	m_progressH.SetBorders(rcBorders);
	m_progressV.SetBorders(rcBorders);
	
	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnRadioTextMode() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	switch(m_iTextMode)
	{
		case 0:
			m_progressH.HideText();
			m_progressV.HideText();
			break;
		case 1:
			m_progressH.SetTextFormat("%d%%", PBS_SHOW_PERCENT);  // also can use SetShowPercent()
			m_progressV.SetTextFormat("%d%%", PBS_SHOW_PERCENT);
			break;
		case 2:
			m_progressH.SetTextFormat("%d", PBS_SHOW_POSITION);
			m_progressV.SetTextFormat("%d", PBS_SHOW_POSITION);
			break;
		case 3:
			m_progressH.SetTextFormat("Done : %d%%", PBS_SHOW_PERCENT);
			m_progressV.SetTextFormat("Done : %d%%", PBS_SHOW_PERCENT);
			break;
		case 4:
			m_progressH.SetTextFormat("Done : %d", PBS_SHOW_POSITION);
			m_progressV.SetTextFormat("Done : %d", PBS_SHOW_POSITION);
			break;
		case 5:
			m_progressH.SetTextFormat("Text");
			m_progressV.SetTextFormat("Text");
			break;
	}

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnRadioProgressMode() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetSnake(m_iProgressMode == SNAKE);
	m_progressV.SetSnake(m_iProgressMode == SNAKE);
	
	// snake mode includes rubberbur mode
	m_fRubberBar = m_progressH.GetRubberBar()?1:0;
	UpdateData(FALSE);
}

void CProgressBarTestDlg::OnChangeRange() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetRange32(BASE, BASE+m_nRange);
	m_progressV.SetRange32(BASE, BASE+m_nRange);

	m_progressH.SetPos(BASE+m_pos);
	m_progressV.SetPos(BASE+m_pos);

	m_progressH.Invalidate();
	m_progressV.Invalidate();

}

void CProgressBarTestDlg::OnReset() 
{
	// TODO: Add your control notification handler code here
	m_pos = 0;
	m_inc = TRUE;

	m_progressH.SetPos(BASE+m_pos);
	m_progressV.SetPos(BASE+m_pos);
}

void CProgressBarTestDlg::OnReverse() 
{
	// TODO: Add your control notification handler code here
	if(m_progressH.GetStyle()&PBS_REVERSE)
	{
		m_progressH.ModifyStyle(PBS_REVERSE, 0);
		m_progressV.ModifyStyle(PBS_REVERSE, 0);
	}
	else
	{
		m_progressH.ModifyStyle(0, PBS_REVERSE);
		m_progressV.ModifyStyle(0, PBS_REVERSE);
	}
	m_progressH.Invalidate();
	m_progressV.Invalidate();
}

void CProgressBarTestDlg::OnStep() 
{
	// TODO: Add your control notification handler code here
	if(m_iProgressMode == PROGRESS)
	{
		m_pos+=m_nStepSize;
		if((UINT)m_pos > m_nRange)
			m_pos = 0;

		m_progressH.SetPos(BASE+m_pos);
		m_progressV.SetPos(BASE+m_pos);
	}
	else
	{
		m_progressH.StepIt();
		m_progressV.StepIt();
	}
}

void CProgressBarTestDlg::OnChangeStepsize() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetStep(m_nStepSize);
	m_progressV.SetStep(m_nStepSize);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
	
}

void CProgressBarTestDlg::OnChangeTail() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;
	
	m_progressH.SetSnakeTail(m_nTailSize);
	m_progressV.SetSnakeTail(m_nTailSize);

	m_progressH.Invalidate();
	m_progressV.Invalidate();
}


void CProgressBarTestDlg::OnButtonMySnake() 
{
	// TODO: Add your control notification handler code here
	COLORREF black = RGB(0,0,0);
	COLORREF gray = RGB(192,192,192);
	COLORREF dkgray = RGB(128,128,128);
	
	m_progressH.SetBkColor(gray);
	m_progressV.SetBkColor(gray);

	m_progressH.SetGradientColorsX(3, gray, dkgray, gray);
	m_progressV.SetGradientColorsX(3, gray, dkgray, gray);
	
	m_progressH.SetTextColor(black, gray);
	m_progressV.SetTextColor(black, gray);

	m_fUseBrush = FALSE;
	m_nBorder = 0;
	m_iTextMode = 0;
	m_iProgressMode = SNAKE;

	UpdateData(FALSE);
	OnCheckBrush();
	OnChangeEditBorder();
	OnRadioTextMode();
	OnRadioProgressMode();
}
