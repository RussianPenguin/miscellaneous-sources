//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ProgressBarTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PROGRESSBARTEST_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDC_PROGRESS_H                  1000
#define IDC_PROGRESS_V                  1001
#define IDC_STEP                        1002
#define IDC_RUN                         1003
#define IDC_RESET                       1004
#define IDC_RANGE                       1005
#define IDC_RADIO_NOTEXT                1006
#define IDC_RADIO_PERCENT               1007
#define IDC_RADIO_POS                   1008
#define IDC_RADIO_PERCENT_F             1009
#define IDC_RADIO_POS_F                 1010
#define IDC_RADIO_TEXTONLY              1011
#define IDC_CHECK_TIEDTEXT              1012
#define IDC_REVERSE                     1013
#define IDC_RADIO_PROGRESS              1014
#define IDC_STEPSIZE                    1015
#define IDC_TAIL                        1016
#define IDC_RADIO_SNAKE                 1017
#define IDC_CHECK_RUBBERBAR             1018
#define IDC_EDIT_BORDER                 1019
#define IDC_CLR_BK                      1020
#define IDC_CLR_TEXT_BAR                1021
#define IDC_CLR_TEXT_BK                 1022
#define IDC_CLR_START                   1023
#define IDC_CLR_END                     1024
#define IDC_CHECK_BRUSH                 1026
#define IDC_CHECK_VERTTEXT              1027
#define IDC_BUTTON_MULTICOLOR           1028
#define IDC_BUTTON_MSSETUP              1029
#define IDC_BUTTON_NS_SNAKE             1030
#define IDC_BUTTON_MULTICOLOR_CENTERED  1031
#define IDC_BUTTON_MY_SNAKE             1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
