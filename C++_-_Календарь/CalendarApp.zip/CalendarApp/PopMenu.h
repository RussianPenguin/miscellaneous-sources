

#ifndef __POPMENU__
#define __POPMENU__

class CPopMenu : public CMenu
{
public:
	CPopMenu();
	~CPopMenu();
};

#endif // __POPMENU__

