//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by xo.rc
//
#define IDR_MENU                        101
#define IDD_CONDIALOG                   102
#define IDI_IC                          104
#define IDC_CUR                         105
#define IDC_IP                          1002
#define ID_CONNECT_SERVER               40001
#define ID_CONNECT_CLIENT               40002
#define ID_CONNECT_EXIT                 40003
#define ID_GAME_NEW                     40004
#define ID_GAME_EXIT                    40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
