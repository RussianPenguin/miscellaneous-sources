#include<afxwin.h>
#include<afxsock.h>
#include"resource.h"


#define WS_VERSION_REQD	0x0101
#define WM_ASYNC WM_USER+1

WSADATA stWSAData;
SOCKET hSock = INVALID_SOCKET;
SOCKET hSock2 = INVALID_SOCKET;
SOCKADDR_IN myaddr;
WORD WSAEvent;
#define bufsize 2
char buf[bufsize];
int lenaddr,nRet;
enum mode { X , O };

struct Cell
{
	mode	mod;
	bool	active;
	CRect	place;

	Cell()					{active = false;}
	void SetCell(mode m)	{mod = m; active = true;}
};



//Dialog for IP addres inputing
class Dlg : public CDialog
{
public:
	CString addr;
	Dlg(CWnd* p=NULL) 
		: CDialog(IDD_CONDIALOG,p){}
protected:
	virtual void DoDataExchange(CDataExchange* pDX);
};

void Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_IP , addr);
}


class XO : public CFrameWnd
{
public:
	void Send(char buf[bufsize]);
	bool Check(int i1,int i2,int i3);
	bool IsWon();
	void CalcCellRect();
	void DrawFrame(CPaintDC*);
	XO();

private:
	CString sAddr;
	CMenu menu;
	CPen pen;
	Cell cells[9];
	mode cur_mod;
	bool bConnected;
	bool bGame;
	bool bServer;
	bool bClient;
	int	num_cells;
	bool mymove;
	
protected:
	//{{AFX_VIRTUAL(XO)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(XO)
	afx_msg void OnConnectClient();
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnGameNew();
	afx_msg void OnGameExit();
	afx_msg void OnClose();
	afx_msg void OnConnectServer();
	afx_msg void OnUpdateConnectClient(CCmdUI* pCmdUI);
	afx_msg void OnUpdateConnectServer(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGameNew(CCmdUI* pCmdUI);
	afx_msg LRESULT OnAsync(WPARAM wparam, LPARAM lparam);
	//}}AFX_MSG

	//{{AFX_DATA(XO)
	//}}AFX_DATA

	DECLARE_MESSAGE_MAP()
};

BEGIN_MESSAGE_MAP(XO,CFrameWnd)
	//{{AFX_MSG_MAP(XO)
	ON_COMMAND(ID_CONNECT_CLIENT, OnConnectClient)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_GAME_NEW, OnGameNew)
	ON_COMMAND(ID_GAME_EXIT, OnGameExit)
	ON_WM_CLOSE()
	ON_COMMAND(ID_CONNECT_SERVER, OnConnectServer)
	ON_UPDATE_COMMAND_UI(ID_CONNECT_CLIENT, OnUpdateConnectClient)
	ON_UPDATE_COMMAND_UI(ID_CONNECT_SERVER, OnUpdateConnectServer)
	ON_UPDATE_COMMAND_UI(ID_GAME_NEW, OnUpdateGameNew)
	ON_MESSAGE(WM_ASYNC,OnAsync)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


XO::XO()
{
	//{{AFX_DATA_INIT(XO)
	//}}AFX_DATA_INIT

	CString s=AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW ,
		AfxGetApp()->LoadCursor(IDC_CUR),
		(HBRUSH)GetStockObject(WHITE_BRUSH),
		AfxGetApp()->LoadIcon(IDI_IC));
	Create(s,"xo");
	menu.LoadMenu(IDR_MENU);
	SetMenu(&menu);
	pen.CreatePen(PS_SOLID,3,RGB(0,0,0));
	cur_mod = X;
	CalcCellRect();
	bGame=false;
	bConnected=false;
	num_cells=0;
	bServer=bClient=true;
}


/////////////////////////////////////////////////////////////////
class MyApp : public CWinApp
{
public:
	virtual BOOL InitInstance()
	{
		AfxSocketInit();
		m_pMainWnd = new XO;
		m_pMainWnd->ShowWindow(SW_SHOWNORMAL);
		return TRUE;
	}
};
MyApp app;
//////////////////////////////////////////////////////////////////


BOOL XO::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style &= ~WS_MAXIMIZEBOX;
	cs.style &= ~WS_THICKFRAME;
	cs.cx = 200;
	cs.cy = 200;
	return CFrameWnd::PreCreateWindow(cs);
}

LRESULT XO::OnAsync(WPARAM wParam,LPARAM lParam)
{
	WSAEvent = WSAGETSELECTEVENT (lParam);
	switch (WSAEvent)
	{
		case FD_READ:
			if(bServer)
				recv(hSock2, buf, bufsize, 0);
			else recv(hSock, buf, bufsize, 0);
			if(buf[0]==33)
			{
				
				for(int i=0; i<9; i++)
				{
					cells[i].active=false;
				}
				cur_mod=X;
				bGame=true;
				mymove=false;
				num_cells=0;
				Invalidate();
				return 0;
			}
			if(mymove==false)
				mymove=true;
			cells[buf[0]].active=true;
			cells[buf[0]].mod = buf[1]==1 ? X : O;
			cur_mod= cur_mod==X ? O : X;
			num_cells++;
			IsWon();
			Invalidate();
			return 0;
		case FD_ACCEPT:
			lenaddr=sizeof(myaddr);
			hSock2=accept(hSock,(LPSOCKADDR)&myaddr,&lenaddr);
			return 0;
	}
	return 1;
}

void XO::OnConnectClient()
{
	bClient=true;
	WSAStartup(WS_VERSION_REQD, &stWSAData);
    hSock = socket (AF_INET, SOCK_STREAM, 0);

	Dlg dlg;
	dlg.DoModal();
	sAddr = dlg.addr;
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = inet_addr(sAddr);
	myaddr.sin_port = htons (2049);
	connect (hSock, (struct sockaddr *)&myaddr,sizeof(myaddr));
	nRet=WSAAsyncSelect(hSock,m_hWnd,WM_ASYNC,FD_READ);
	bConnected=true;
	bServer=false;
	mymove=true;
	SetWindowText("xo - client");
}

void XO::OnConnectServer()
{
	bServer=true;
	WSAStartup(WS_VERSION_REQD, &stWSAData);
	hSock = socket (AF_INET,SOCK_STREAM,0);

	WSAAsyncSelect(hSock,m_hWnd,WM_ASYNC, FD_ACCEPT | FD_READ);

	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = htonl (INADDR_ANY);
	myaddr.sin_port = htons (2049);
	bind(hSock,(LPSOCKADDR)&myaddr, sizeof(struct sockaddr));
	listen (hSock, 5);
	bConnected=true;
	bClient=false;
	mymove=false;
	SetWindowText("xo - server");
}


void XO::Send(char buf[])
{
	if(bClient)
		send(hSock,buf,bufsize,0);
	else send(hSock2,buf,bufsize,0);
}

void XO::OnUpdateConnectClient(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(bClient);
	pCmdUI->SetCheck(int(bClient&&bConnected));
}

void XO::OnUpdateConnectServer(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(bServer);
	pCmdUI->SetCheck(int(bServer&&bConnected));
}

void XO::OnUpdateGameNew(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(bConnected);
}

void XO::OnPaint()
{
	CPaintDC dc(this);
	dc.SelectObject(&pen);
	DrawFrame(&dc);	
	for(int i=0; i<9; i++)
	{
		if(cells[i].active==true)
		{
			if(cells[i].mod==X)
			{
				dc.MoveTo(cells[i].place.left,cells[i].place.top);
				dc.LineTo(cells[i].place.right,cells[i].place.bottom);
				dc.MoveTo(cells[i].place.left,cells[i].place.bottom);
				dc.LineTo(cells[i].place.right,cells[i].place.top);
			}
			else if(cells[i].mod==O)
			{
				dc.Ellipse(cells[i].place);
			}
		}
	}
}

void XO::DrawFrame(CPaintDC* dc)
{
	CRect r;
	GetClientRect(&r);
	dc->MoveTo(r.left,r.bottom/3);
	dc->LineTo(r.right,r.bottom/3);
	dc->MoveTo(r.left,2*r.bottom/3);
	dc->LineTo(r.right,2*r.bottom/3);
	dc->MoveTo(r.right/3,r.top);
	dc->LineTo(r.right/3,r.bottom);
	dc->MoveTo(2*r.right/3,r.top);
	dc->LineTo(2*r.right/3,r.bottom);
}

void XO::OnLButtonDown(UINT nFlags, CPoint point)
{
	if(bGame==false || mymove==false)
		return;

	for(int i=0; i<9; i++)
	{
		if(cells[i].place.PtInRect(point) && !cells[i].active)
		{
			buf[0]=i;
			cells[i].active=true;
			cells[i].mod=cur_mod;
			mymove=false;
			num_cells++;
			InvalidateRect(cells[i].place);
			cur_mod= cur_mod== X ? O : X;
			buf[0]=i;
			buf[1]= cells[i].mod==X ? 1 : 0;
			Send(buf);
			
			break;
		}
	}
	IsWon();
}

void XO::CalcCellRect()
{	
	CRect r;
	GetClientRect(&r);

	int cx = r.right;
	int cy = r.bottom;

	for(int j=0,t=r.top,b=r.top+cy/3; j<3; j++,t+=cy/3,b+=cy/3)
	{
		for(int i=0,l=r.left,p=r.left+cx/3;
		i<3;  i++,p+=cx/3,l+=cx/3)
		{
			cells[j*3+i].place.left=l+5;
			cells[j*3+i].place.right=p-5;
			cells[j*3+i].place.top=t+5;
			cells[j*3+i].place.bottom=b-5;
		}
	}
}

bool XO::IsWon()
{
	bool won=false;
	won = Check(0,1,2)||Check(3,4,5)
		||Check(6,7,8)||Check(0,3,6)
		||Check(1,4,7)||Check(2,5,8)
		||Check(0,4,8)||Check(2,4,6);
	if(!won && num_cells==9)
	{
		MessageBox("None won ...","");
		won=true;
	}
	if(won) bGame=false;
	return won;
}

void XO::OnGameNew()
{
	if(bGame==true)
		return;

	for(int i=0; i<9; i++)
	{
		cells[i].active=false;
	}
	bGame=true;
	mymove=true;
	num_cells=0;
	cur_mod=X;
	buf[0]=33;
	Send(buf);
	Invalidate();
}

bool XO::Check(int i1,int i2,int i3)
{
	bool won=false;
	mode m;
	if(!(cells[i1].active && cells[i2].active && cells[i3].active))
		return won;
	if((m=cells[i1].mod) == cells[i2].mod
		&& cells[i2].mod == cells[i3].mod)
	{
		won=true;
	}
	if(won==true)
	{
		char who= m==X ? 'X' : 'O';
		CString message="Victory of ";
		message += who;
		MessageBox(message,"Congratulations!");
	}
	return won;
}

void XO::OnGameExit()
{
	OnClose();	
}

void XO::OnClose()
{
	nRet = WSACleanup();
	CFrameWnd::OnClose();
}

