
#ifdef HOOKS_EXPORTS
#define HOOKS_API __declspec(dllexport)
#else
#define HOOKS_API __declspec(dllimport)
#endif


void HOOKS_API SetHooks(HHOOK hk, HHOOK hm, HHOOK hs, HWND wnd );
bool HOOKS_API isExit();
LRESULT HOOKS_API CALLBACK KeyProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT HOOKS_API CALLBACK MouseProc(int nCode, WPARAM wParam, LPARAM lParam);

void AddHist(char *letter, int len);
void CheckTimer();
void CheckTask();