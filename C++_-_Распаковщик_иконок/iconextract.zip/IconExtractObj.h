
// IconExtractObj.h : Declaration of the CIconExtractObj

#ifndef __ICONEXTRACTOBJ_H_
#define __ICONEXTRACTOBJ_H_

#include "resource.h"       // main symbols

#include <shlobj.h>
#include <comdef.h>

/////////////////////////////////////////////////////////////////////////////
// CIconExtractObj
class ATL_NO_VTABLE CIconExtractObj : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIconExtractObj, &CLSID_IconExtractObj>,
	public IDispatchImpl<IIconExtractObj, &IID_IIconExtractObj, &LIBID_ICONEXTRACTLib>,
	public IShellExtInit,
	public IContextMenu
{
public:
	CIconExtractObj()
	{
		m_hExtractBmpL = LoadBitmap(_Module.GetModuleInstance(), MAKEINTRESOURCE(IDB_MNUBMPL));
		m_hExtractBmpS = LoadBitmap(_Module.GetModuleInstance(), MAKEINTRESOURCE(IDB_MNUBMPS));
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ICONEXTRACTOBJ)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIconExtractObj)
	COM_INTERFACE_ENTRY(IIconExtractObj)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IShellExtInit)
	COM_INTERFACE_ENTRY(IContextMenu)
END_COM_MAP()

// IIconExtractObj
public:
	// IShellExtInit
    STDMETHOD(Initialize)(LPCITEMIDLIST, LPDATAOBJECT, HKEY);
	// IContextMenu
	STDMETHOD(GetCommandString)(UINT, UINT, UINT*, LPSTR, UINT);
    STDMETHOD(InvokeCommand)(LPCMINVOKECOMMANDINFO);
    STDMETHOD(QueryContextMenu)(HMENU, UINT, UINT, UINT, UINT);

private:
    TCHAR m_szFile[MAX_PATH];
	HBITMAP m_hExtractBmpL;
	HBITMAP m_hExtractBmpS;
};

#endif //__ICONEXTRACTOBJ_H_

