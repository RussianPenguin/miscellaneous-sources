// MultiSliderDemo.h : main header file for the MULTISLIDERDEMO application
//

#if !defined(AFX_MULTISLIDERDEMO_H__D19F4A55_C829_11D3_B7FA_00C04F0DA600__INCLUDED_)
#define AFX_MULTISLIDERDEMO_H__D19F4A55_C829_11D3_B7FA_00C04F0DA600__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMultiSliderDemoApp:
// See MultiSliderDemo.cpp for the implementation of this class
//

class CMultiSliderDemoApp : public CWinApp
{
public:
	CMultiSliderDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMultiSliderDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMultiSliderDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MULTISLIDERDEMO_H__D19F4A55_C829_11D3_B7FA_00C04F0DA600__INCLUDED_)
