// MultiSliderDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MultiSliderDemo.h"
#include "MultiSliderDemoDlg.h"
#include "multislider.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultiSliderDemoDlg dialog

CMultiSliderDemoDlg::CMultiSliderDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMultiSliderDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMultiSliderDemoDlg)
	m_Integer = FALSE;
	m_Colors = FALSE;
	m_Min = _T("");
	m_Max = _T("");
	m_Value1 = _T("");
	m_Value2 = _T("");
	m_Value3 = _T("");
	m_Value4 = _T("");
	m_Value5 = _T("");
	m_Value6 = _T("");
	m_Value7 = _T("");
	m_NumMarkers = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMultiSliderDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMultiSliderDemoDlg)
	DDX_Control(pDX, IDC_SLIDER1, m_Slider);
	DDX_Check(pDX, IDC_CHECK1, m_Integer);
	DDX_Check(pDX, IDC_CHECK2, m_Colors);
	DDX_Text(pDX, IDC_EDIT1, m_Min);
	DDX_Text(pDX, IDC_EDIT2, m_Max);
	DDX_Text(pDX, IDC_EDIT3, m_Value1);
	DDX_Text(pDX, IDC_EDIT4, m_Value2);
	DDX_Text(pDX, IDC_EDIT5, m_Value3);
	DDX_Text(pDX, IDC_EDIT6, m_Value4);
	DDX_Text(pDX, IDC_EDIT7, m_Value5);
	DDX_Text(pDX, IDC_EDIT8, m_Value6);
	DDX_Text(pDX, IDC_EDIT9, m_Value7);
	DDX_Text(pDX, IDC_EDIT10, m_NumMarkers);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMultiSliderDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CMultiSliderDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMultiSliderDemoDlg message handlers

BOOL CMultiSliderDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//Set as many, as few colors as you need to pass to CMultiSlider
	colors[0] = RGB(255, 0, 0);
	colors[1] = RGB(0, 255, 0);
	colors[2] = RGB(0, 0, 255);
	colors[3] = RGB(255, 100, 0);
	colors[4] = RGB(0, 255, 100);
	colors[5] = RGB(100, 0, 255);
	colors[6] = RGB(255, 255, 0);
	colors[7] = RGB(255, 255, 255);

	int range, interval, i;
	float min, max, temp;

	//Set the maximum number of markers you need
	m_NumMarkers = 3;

	//Set the min/max range for the slider
	min = 0;
	max = 100;
	if(max < min)
	{
		temp = max;
		max = min;
		min = temp;
	}
	m_Min.Format("%.1f",min);
	m_Max.Format("%.1f",max);
	range = (int)(max - min);

	//This finds the increment for the tickmarks, modify as you need for your
	//application
	interval = 1;
	if(range%10 == 0 && range != 10)
		interval = 10;
	else if(range%7 == 0 && range != 7)
		interval = 7;
	else if(range%5 == 0 && range != 5)
		interval = 5;
	else if(range%4 == 0 && range != 4)
		interval = 4;
	else if(range%3 == 0 && range != 3)
		interval = 3;
	else if(range%2 == 0 && range != 2)
		interval = 2;
	m_Slider.SetRanges(min, max);	//Must call these two
	m_Slider.SetTicFreq(interval);	
	
	//Set colors
	for(i=0;i<=m_Slider.m_NumMarkers;i++)
		m_Slider.m_Colors.Add(colors[i]);

	m_Integer = FALSE;	//Display values on slider as floats
	m_Colors = FALSE;	//Not displaying colors
	m_Slider.m_NumMarkers = m_NumMarkers;

	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMultiSliderDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMultiSliderDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMultiSliderDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMultiSliderDemoDlg::OnButton1() //Update Slider
{
	UpdateData(TRUE);

	float min, max, temp;
	int range, interval, i;

	//Set new ranges
	min = (float)atof(m_Min);
	max = (float)atof(m_Max);

	if(max < min)
	{
		temp = max;
		max = min;
		min = temp;
	}

	range = (int)(max - min);
	m_Slider.SetRanges(min, max);

	//Set tickmarks
	interval = 1;
	if(range%10 == 0 && range != 10)
		interval = 10;
	else if(range%7 == 0 && range != 7)
		interval = 7;
	else if(range%5 == 0 && range != 5)
		interval = 5;
	else if(range%4 == 0 && range != 4)
		interval = 4;
	else if(range%3 == 0 && range != 3)
		interval = 3;
	else if(range%2 == 0 && range != 2)
		interval = 2;
	m_Slider.SetTicFreq(interval);	

	m_Slider.fInteger = m_Integer;
	m_Slider.fDisplayColors = m_Colors;
	m_Slider.m_NumMarkers = m_NumMarkers;

	//Free, allocate colors
	m_Slider.m_Colors.RemoveAll();
	for(i=0;i<=m_NumMarkers;i++)
		m_Slider.m_Colors.Add(colors[i]);

	//Force re-initializaton of slider.  This would normally never be needed in a
	//real project since everything would be set in OnInitDialog once

	m_Slider.fInit = false;
	m_Slider.Invalidate();
}

void CMultiSliderDemoDlg::OnButton2() //Update values displayed
{
	float *values;
	int count;
	CString text;

	values = (float*)malloc(sizeof(float) * m_NumMarkers);
	count  = m_Slider.GetMarkers(values);
	if(count > 0)		//Display up to 7 values
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[0]);
		else
			text.Format("%.1f", values[0]);
		SetDlgItemText(IDC_EDIT3, text);
	}
	else
		SetDlgItemText(IDC_EDIT3, "");
	if(count > 1)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[1]);
		else
			text.Format("%.1f", values[1]);
		SetDlgItemText(IDC_EDIT4, text);
	}
	else
		SetDlgItemText(IDC_EDIT4, "");
	if(count > 2)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[2]);
		else
			text.Format("%.1f", values[2]);
		SetDlgItemText(IDC_EDIT5, text);
	}
	else
		SetDlgItemText(IDC_EDIT5, "");
	if(count > 3)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[3]);
		else
			text.Format("%.1f", values[3]);
		SetDlgItemText(IDC_EDIT6, text);
	}
	else
		SetDlgItemText(IDC_EDIT6, "");
	if(count > 4)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[4]);
		else
			text.Format("%.1f", values[4]);
		SetDlgItemText(IDC_EDIT7, text);
	}
	else
		SetDlgItemText(IDC_EDIT7, "");
	if(count > 5)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[5]);
		else
			text.Format("%.1f", values[5]);
		SetDlgItemText(IDC_EDIT8, text);
	}
	else
		SetDlgItemText(IDC_EDIT8, "");
	if(count > 6)
	{
		if(m_Slider.fInteger)
			text.Format("%.0f", values[6]);
		else
			text.Format("%.1f", values[6]);
		SetDlgItemText(IDC_EDIT9, text);
	}
	else
		SetDlgItemText(IDC_EDIT9, "");

	free(values);
}
