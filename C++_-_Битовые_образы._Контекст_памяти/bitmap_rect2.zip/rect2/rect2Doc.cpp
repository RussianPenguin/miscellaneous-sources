// rect2Doc.cpp : implementation of the CRect2Doc class
//

#include "stdafx.h"
#include "rect2.h"

#include "rect2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRect2Doc

IMPLEMENT_DYNCREATE(CRect2Doc, CDocument)

BEGIN_MESSAGE_MAP(CRect2Doc, CDocument)
	//{{AFX_MSG_MAP(CRect2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRect2Doc construction/destruction

CRect2Doc::CRect2Doc()
{
	// TODO: add one-time construction code here

}

CRect2Doc::~CRect2Doc()
{
}

BOOL CRect2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CRect2Doc serialization

void CRect2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CRect2Doc diagnostics

#ifdef _DEBUG
void CRect2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CRect2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRect2Doc commands
