// rect2View.h : interface of the CRect2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECT2VIEW_H__9E5C202C_233A_11D4_BE7F_AFED12768F46__INCLUDED_)
#define AFX_RECT2VIEW_H__9E5C202C_233A_11D4_BE7F_AFED12768F46__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CRect2View : public CScrollView
{
protected: // create from serialization only
	CRect2View();
	DECLARE_DYNCREATE(CRect2View)

// Attributes
public:
	CRect2Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRect2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL bMemDCEnabled;
	CBitmap b;
	CDC memDC;
	virtual ~CRect2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CRect2View)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in rect2View.cpp
inline CRect2Doc* CRect2View::GetDocument()
   { return (CRect2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RECT2VIEW_H__9E5C202C_233A_11D4_BE7F_AFED12768F46__INCLUDED_)
