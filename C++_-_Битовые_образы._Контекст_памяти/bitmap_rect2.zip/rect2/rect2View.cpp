// rect2View.cpp : implementation of the CRect2View class
//

#include "stdafx.h"
#include "rect2.h"

#include "rect2Doc.h"
#include "rect2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int cxMax=1280, cyMax=1024;
const int cxLine=30, cyLine=30;
/////////////////////////////////////////////////////////////////////////////
// CRect2View

IMPLEMENT_DYNCREATE(CRect2View, CScrollView)

BEGIN_MESSAGE_MAP(CRect2View, CScrollView)
	//{{AFX_MSG_MAP(CRect2View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRect2View construction/destruction

CRect2View::CRect2View()
{
	// TODO: add construction code here
	bMemDCEnabled = FALSE;
}

CRect2View::~CRect2View()
{
}

BOOL CRect2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	HBRUSH hbrush = CreateSolidBrush ( NULL_BRUSH ) ;
	cs.lpszClass = AfxRegisterWndClass( 0, 0, hbrush ); 
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CRect2View drawing

void CRect2View::OnDraw(CDC* pDC)
{
	CRect2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	pDC -> BitBlt(0,0, cxMax, cyMax, &memDC, 0, 0, SRCCOPY);

}

void CRect2View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	// TODO: calculate the total size of this view
	CRect rect;
	GetClientRect ( &rect );
	CSize sizeTotal(cxMax, cyMax);
	CSize sizePage( rect.Width(), rect.Height() );
	//CSize sizePage( 640, 480 );
	CSize sizeLine( cxLine, cyLine );
	SetScrollSizes(MM_TEXT, sizeTotal, sizePage, sizeLine);


	CClientDC dc(this);
	
	if ( !bMemDCEnabled )
	{
		b.CreateCompatibleBitmap( &dc, cxMax, cyMax ) ;
		memDC.CreateCompatibleDC( &dc ) ;
		bMemDCEnabled = TRUE;
		
	}
	
	memDC.SelectObject( &b );
	//������� memDC
	rect.SetRect(0, 0, cxMax, cyMax);
	CBrush brush ( RGB(0,0,0) );
	memDC.FillRect( rect, &brush);

	srand( (unsigned)time( NULL ) );
	
	GetClientRect( rect ) ;
	int x = rect.Width();
	int y = rect.Height();
	for (int i=0; i< 1000; i++)
		memDC.Rectangle(rand()*x/RAND_MAX, rand()*y/RAND_MAX,
						rand()*x/RAND_MAX, rand()*y/RAND_MAX);
}

/////////////////////////////////////////////////////////////////////////////
// CRect2View diagnostics

#ifdef _DEBUG
void CRect2View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CRect2View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CRect2Doc* CRect2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRect2Doc)));
	return (CRect2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRect2View message handlers
