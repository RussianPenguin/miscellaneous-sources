// halfView.cpp : implementation of the CHalfView class
//

#include "stdafx.h"
#include "half.h"

#include "halfDoc.h"
#include "halfView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "stdlib.h"
const int cxMem = 1024, cyMem = 768;
/////////////////////////////////////////////////////////////////////////////
// CHalfView

IMPLEMENT_DYNCREATE(CHalfView, CView)

BEGIN_MESSAGE_MAP(CHalfView, CView)
	//{{AFX_MSG_MAP(CHalfView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHalfView construction/destruction

CHalfView::CHalfView()
{
	// TODO: add construction code here
	bMemDCEnabled = FALSE;
}

CHalfView::~CHalfView()
{
}

BOOL CHalfView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHalfView drawing

void CHalfView::OnDraw(CDC* pDC)
{
	CHalfDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	CRect rect;
	GetClientRect( rect ) ;
	pDC -> BitBlt(0,0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);

}

/////////////////////////////////////////////////////////////////////////////
// CHalfView diagnostics

#ifdef _DEBUG
void CHalfView::AssertValid() const
{
	CView::AssertValid();
}

void CHalfView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHalfDoc* CHalfView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHalfDoc)));
	return (CHalfDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHalfView message handlers

void CHalfView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CClientDC dc(this);
	
	if ( !bMemDCEnabled )
	{
		b.CreateCompatibleBitmap( &dc, cxMem, cyMem ) ;
		memDC.CreateCompatibleDC( &dc ) ;
		bMemDCEnabled = TRUE;
		
	}
	
	memDC.SelectObject( &b );
	//������� memDC
	CRect rect(0, 0, cxMem, cyMem);
	CBrush brush ( RGB(0,0,0) );
	memDC.FillRect( rect, &brush);

	srand( (unsigned)time( NULL ) );
	
	GetClientRect( rect ) ;
	int x = rect.Width();
	int y = rect.Height();
	for (int i=0; i< 10000; i++)
		memDC.Rectangle(rand()*x/RAND_MAX, rand()*y/RAND_MAX,
						rand()*x/RAND_MAX, rand()*y/RAND_MAX);
	

}

