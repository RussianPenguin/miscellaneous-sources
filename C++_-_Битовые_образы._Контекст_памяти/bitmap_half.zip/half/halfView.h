// halfView.h : interface of the CHalfView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HALFVIEW_H__42BA96AD_22B0_11D4_86E4_008048B665AB__INCLUDED_)
#define AFX_HALFVIEW_H__42BA96AD_22B0_11D4_86E4_008048B665AB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CHalfView : public CView
{
protected: // create from serialization only
	CHalfView();
	DECLARE_DYNCREATE(CHalfView)

// Attributes
public:
	CHalfDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHalfView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	CDC memDC;
	CBitmap b;
	virtual ~CHalfView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHalfView)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in halfView.cpp
inline CHalfDoc* CHalfView::GetDocument()
   { return (CHalfDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HALFVIEW_H__42BA96AD_22B0_11D4_86E4_008048B665AB__INCLUDED_)
