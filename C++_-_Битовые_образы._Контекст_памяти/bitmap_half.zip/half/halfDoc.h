// halfDoc.h : interface of the CHalfDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HALFDOC_H__42BA96AB_22B0_11D4_86E4_008048B665AB__INCLUDED_)
#define AFX_HALFDOC_H__42BA96AB_22B0_11D4_86E4_008048B665AB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CHalfDoc : public CDocument
{
protected: // create from serialization only
	CHalfDoc();
	DECLARE_DYNCREATE(CHalfDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHalfDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHalfDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHalfDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HALFDOC_H__42BA96AB_22B0_11D4_86E4_008048B665AB__INCLUDED_)
