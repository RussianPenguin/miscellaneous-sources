// halfView.cpp : implementation of the CHalfView class
//

#include "stdafx.h"
#include "half.h"

#include "halfDoc.h"
#include "halfView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHalfView

IMPLEMENT_DYNCREATE(CHalfView, CView)

BEGIN_MESSAGE_MAP(CHalfView, CView)
	//{{AFX_MSG_MAP(CHalfView)
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHalfView construction/destruction

CHalfView::CHalfView()
{
	// TODO: add construction code here

}

CHalfView::~CHalfView()
{
}

BOOL CHalfView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHalfView drawing

void CHalfView::OnDraw(CDC* pDC)
{
	CHalfDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	pDC -> Rectangle(10,10,100,100);
	pDC -> Rectangle(120,20,400,200);
	pDC -> Rectangle(220,220,250,230);
	pDC -> Rectangle(100,100,150,150);
}

/////////////////////////////////////////////////////////////////////////////
// CHalfView diagnostics

#ifdef _DEBUG
void CHalfView::AssertValid() const
{
	CView::AssertValid();
}

void CHalfView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CHalfDoc* CHalfView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHalfDoc)));
	return (CHalfDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHalfView message handlers

void CHalfView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	CClientDC dc(this);
	b.CreateCompatibleBitmap( &dc, 1024, 768 ) ;
	memDC.CreateCompatibleDC( &dc ) ;
	memDC.SelectObject( &b );
}

void CHalfView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CView::OnLButtonUp(nFlags, point);
	CDC* pDC = GetDC();
	CRect rect;
	GetClientRect( rect ) ;
	
	memDC. BitBlt(0, 0, rect.Width()/2, rect.Height(), pDC, 0,0, SRCCOPY);
	pDC -> BitBlt(0,0, rect.Width()/2, rect.Height(), pDC, rect.Width()/2, 0, SRCCOPY);
	pDC -> BitBlt(rect.Width()/2,0, rect.Width()/2, rect.Height(), &memDC, 0, 0, SRCCOPY);
}
