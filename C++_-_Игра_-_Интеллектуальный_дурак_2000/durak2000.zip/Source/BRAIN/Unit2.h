//---------------------------------------------------------------------------

#ifndef Unit2H
#define Unit2H
#include <time.h>
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TNeuralNet : public TThread
{
private:
protected:
        void __fastcall Execute();
        float FindError();
        void Propagate();
        void  CorrectWeights();
        char GetDost(char Num){return(char(((Num-1)%9)+1));}
        char GetMast(char Num){return(char((Num-1)/9));}
        float FormatCardMast(char TCard,char Kozir);
        float FormatCardDost(char TCard);
//        float Sigmoid(float x);
        float dxSigmoid(float y);
        unsigned int LoadFile(int FILE,int START);
        void SaveFile(int FILE,int START);
        bool TestAnswer();
public:
        __fastcall TNeuralNet(bool CreateSuspended);
        void LoadTempWeight();
        void SaveTempWeight();
        void GetEnterNeurons();
        void LoadFromFile();
        void InitWeight();
        float MaxErr;
        bool PBP;
        unsigned int CorrectAnsw;
        unsigned int NumTrains;
        float Sigmoid(float x);
        float NU;
        float Alfa;
        float Learn;
        int DBFile;
        time_t StartTime;
        int Status;
        int CurrentPosition;
        float CurrentError;
        int Train;
        void Test();
        int FileWgt;
        int TempFileWgt;
        bool NeedToLearn();
        float MaximumError;

        float TAlfa;
        float TMomentum;
        float TLearn;
        float TSpeedUpMom;
        float TSpeedDownMom;
        float TMinProiz;
        float TMaxWei;
        float TMinMom;
        float TMaxSum;
        bool Direcrion;
        bool NeedToInit;
        char *Memory;
        bool CrossTest;
};
//---------------------------------------------------------------------------
#endif
