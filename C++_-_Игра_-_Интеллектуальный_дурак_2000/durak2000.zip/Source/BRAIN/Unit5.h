//---------------------------------------------------------------------------

#ifndef Unit5H
#define Unit5H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TAbout : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TBevel *Bevel1;
        TLabel *Label3;
        TLabel *Neurons;
        TLabel *HowToWork;
        TLabel *Experim;
        TLabel *Write;
        TBevel *Bevel2;
        TLabel *Label4;
        TButton *Ok;
        void __fastcall OkClick(TObject *Sender);
        void __fastcall HowToWorkMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall WriteClick(TObject *Sender);
        void __fastcall HowToWorkClick(TObject *Sender);
        void __fastcall NeuronsClick(TObject *Sender);
        void __fastcall ExperimClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TAbout(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAbout *About;
//---------------------------------------------------------------------------
#endif
