//---------------------------------------------------------------------------

#ifndef Unit4H
#define Unit4H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TParametrs : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Alfa;
        TLabel *Momentum;
        TLabel *Learn;
        TUpDown *UpDown1;
        TUpDown *UpDown2;
        TUpDown *UpDown3;
        TGroupBox *GroupBox2;
        TLabel *Label4;
        TLabel *SpeedUpMom;
        TUpDown *UpDown4;
        TLabel *Label5;
        TUpDown *UpDown5;
        TLabel *SpeedDownMom;
        TLabel *Label6;
        TLabel *MinProiz;
        TUpDown *UpDown6;
        TButton *Ok;
        TButton *Cancel;
        TButton *Help;
        TLabel *Label8;
        TUpDown *UpDown8;
        TLabel *MaxSum;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *MaxWei;
        TUpDown *UpDown9;
        void __fastcall OkClick(TObject *Sender);
        void __fastcall CancelClick(TObject *Sender);
        void __fastcall UpDown1Click(TObject *Sender, TUDBtnType Button);
        void __fastcall UpDown1MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall HelpClick(TObject *Sender);
private:	// User declarations
        void ShowKoef();
        void Lets();
public:		// User declarations
        __fastcall TParametrs(TComponent* Owner);
        void SaveOptions();
        float TAlfa;
        float TMomentum;
        float TLearn;
        float TSpeedUpMom;
        float TSpeedDownMom;
        float TMinProiz;
        float TMaxWei;
        float TMinMom;
        int TMaxSum;
        int TPBP;
};
//---------------------------------------------------------------------------
extern PACKAGE TParametrs *Parametrs;
//---------------------------------------------------------------------------
#endif
