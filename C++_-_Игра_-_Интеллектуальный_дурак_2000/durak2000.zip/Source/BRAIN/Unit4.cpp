//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit4.h"
#include <inifiles.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TParametrs *Parametrs;
const int DIV=1000;
TIniFile *MyIniFile;
//---------------------------------------------------------------------------
__fastcall TParametrs::TParametrs(TComponent* Owner)
        : TForm(Owner)
{
AnsiString FName=Application->ExeName;
FName=FName.SubString(1,FName.Length()-3);
MyIniFile=new  TIniFile(FName+"INI");//������� INI-����
TAlfa=MyIniFile->ReadFloat("Base parametrs","Alfa",0.99);
TMomentum=MyIniFile->ReadFloat("Base parametrs","Momentum",0.9);
TLearn=MyIniFile->ReadFloat("Base parametrs","Learn",0.1);

if(!TLearn)TLearn=10e-7;

TSpeedUpMom=MyIniFile->ReadFloat("Additional parametrs","SpeedUpMom",1.2);
TSpeedDownMom=MyIniFile->ReadFloat("Additional parametrs","SpeedDownMom",0.5);
TMinProiz=MyIniFile->ReadFloat("Additional parametrs","MinProiz",0.1);
TMaxWei=MyIniFile->ReadFloat("Additional parametrs","MaxWei",0.25);
TMaxSum=MyIniFile->ReadInteger("Additional parametrs","MaxSum",5);
}
//---------------------------------------------------------------------------
void TParametrs::ShowKoef(){
  Alfa->Caption=float(UpDown1->Position)/DIV;
  Momentum->Caption=float(UpDown2->Position)/DIV;
  Learn->Caption=float(UpDown3->Position)/DIV;

  SpeedUpMom->Caption=float(UpDown4->Position)/DIV;
  SpeedDownMom->Caption=float(UpDown5->Position)/DIV;
  MinProiz->Caption=float(UpDown6->Position)/DIV;
  MaxSum->Caption=UpDown8->Position;
  MaxWei->Caption=float(UpDown9->Position)/DIV;
}
//---------------------------------------------------------------------------
void __fastcall TParametrs::OkClick(TObject *Sender)
{
TAlfa=float(UpDown1->Position)/DIV;
TMomentum=float(UpDown2->Position)/DIV;
TLearn=float(UpDown3->Position)/DIV;

TSpeedUpMom=float(UpDown4->Position)/DIV;
TSpeedDownMom=float(UpDown5->Position)/DIV;
TMinProiz=float(UpDown6->Position)/DIV;
TMaxWei=float(UpDown9->Position)/DIV;
TMaxSum=UpDown8->Position;

ModalResult=mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TParametrs::CancelClick(TObject *Sender)
{
ModalResult=mrCancel;
}
//---------------------------------------------------------------------------
void __fastcall TParametrs::UpDown1Click(TObject *Sender,
      TUDBtnType Button)
{
ShowKoef();
}
//---------------------------------------------------------------------------

void __fastcall TParametrs::UpDown1MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
if(Sender==UpDown1)UpDown1->SetFocus();
else if(Sender==UpDown2)UpDown2->SetFocus();
else if(Sender==UpDown3)UpDown3->SetFocus();
else if(Sender==UpDown4)UpDown4->SetFocus();
else if(Sender==UpDown5)UpDown5->SetFocus();
else if(Sender==UpDown6)UpDown6->SetFocus();
else if(Sender==UpDown8)UpDown8->SetFocus();
else if(Sender==UpDown9)UpDown9->SetFocus();
else if(Sender==Ok)Ok->SetFocus();
else if(Sender==Cancel)Cancel->SetFocus();
else if(Sender==Help)Help->SetFocus();
}
//---------------------------------------------------------------------------

void __fastcall TParametrs::FormShow(TObject *Sender)
{
Left=Application->MainForm->Left+Application->MainForm->ClientWidth/2-ClientWidth/2;
Top=Application->MainForm->Top+Application->MainForm->ClientHeight/2-ClientHeight/2;
}
//---------------------------------------------------------------------------
void TParametrs::SaveOptions(){
MyIniFile->WriteFloat("Base parametrs","Alfa",TAlfa);
MyIniFile->WriteFloat("Base parametrs","Momentum",TMomentum);
MyIniFile->WriteFloat("Base parametrs","Learn",TLearn);

MyIniFile->WriteFloat("Additional parametrs","SpeedUpMom",TSpeedUpMom);
MyIniFile->WriteFloat("Additional parametrs","SpeedDownMom",TSpeedDownMom);
MyIniFile->WriteFloat("Additional parametrs","MinProiz",TMinProiz);
MyIniFile->WriteFloat("Additional parametrs","MaxWei",TMaxWei);
MyIniFile->WriteInteger("Additional parametrs","MaxSum",TMaxSum);

delete MyIniFile;
}
//---------------------------------------------------------------------------
void TParametrs::Lets(){
UpDown1->Position=int(TAlfa*DIV);
UpDown2->Position=int(TMomentum*DIV);
UpDown3->Position=int(TLearn*DIV);
UpDown4->Position=int(TSpeedUpMom*DIV);
UpDown5->Position=int(TSpeedDownMom*DIV);
UpDown6->Position=int(TMinProiz*DIV);
UpDown8->Position=TMaxSum;
UpDown9->Position=int(TMaxWei*DIV);
}
//---------------------------------------------------------------------------
void __fastcall TParametrs::FormActivate(TObject *Sender)
{
Lets();
ShowKoef();
}
//---------------------------------------------------------------------------

void __fastcall TParametrs::HelpClick(TObject *Sender)
{
Application->HelpJump("IDH_AddParam");
}
//---------------------------------------------------------------------------

