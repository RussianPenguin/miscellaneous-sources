//---------------------------------------------------------------------------

#include <vcl.h>
#include "Unit1.h"
#pragma hdrstop
USERES("Brain.res");
USEFORM("Unit1.cpp", Form1);
USEUNIT("Unit2.cpp");
USEUNIT("Unit3.cpp");
USEFORM("Unit4.cpp", Parametrs);
USEFORM("Unit5.cpp", About);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->ShowMainForm=false;
                 Application->HelpFile = "Brain.hlp";
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->CreateForm(__classid(TParametrs), &Parametrs);
                 Application->CreateForm(__classid(TAbout), &About);
                 Form1->Opt();//�����
                 Form1->Init();
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
