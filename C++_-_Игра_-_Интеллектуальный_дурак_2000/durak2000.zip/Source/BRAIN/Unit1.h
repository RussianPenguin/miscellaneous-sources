//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "Trayicon.h"
#include <ImgList.hpp>
#include <ExtCtrls.hpp>
#include <DdeMan.hpp>
#include <ComCtrls.hpp>
#include "CGAUGES.h"
#include <Buttons.hpp>
#include <ToolWin.hpp>
#include "Ggauge.hpp"
const int TagUpdateDataBase=1;
const int TagNeural=2;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TTrayIcon *TrayIcon1;
        TImageList *ImageList1;
        TTimer *Timer1;
        TGroupBox *GroupBox1;
        TGroupBox *GroupBox2;
        TLabel *Label1;
        TLabel *Examples;
        TLabel *Label4;
        TLabel *CurrentError;
        TLabel *Label2;
        TLabel *Status;
        TGroupBox *GroupBox3;
        TLabel *Label3;
        TLabel *LastTime;
        TProgressBar *CurrentProgress;
        TLabel *Label12;
        TLabel *Train;
        TGroupBox *GroupBox4;
        TLabel *Label5;
        TLabel *Error;
        TLabel *Label9;
        TLabel *Alfa;
        TLabel *Label10;
        TLabel *Learn;
        TButton *Ok;
        TButton *Exit;
        TLabel *Label8;
        TLabel *Moch;
        TImageList *ImageList2;
        TLabel *Label6;
        Tgradgauge *ProgressBar1;
        TToolBar *ToolBar1;
        TToolButton *Start;
        TToolButton *Pause;
        TToolButton *BackGround;
        TToolButton *ToolButton1;
        TToolButton *RandomWeight;
        TToolButton *Properties;
        TToolButton *ToolButton2;
        TToolButton *Help;
        void __fastcall TrayIcon1Restore(TObject *Sender);
        void __fastcall OkClick(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall BackGroundClick(TObject *Sender);
        void __fastcall RandomWeightClick(TObject *Sender);
        void __fastcall StartClick(TObject *Sender);
        void __fastcall PauseClick(TObject *Sender);
        void __fastcall BackGroundMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall PropertiesClick(TObject *Sender);
        void __fastcall HelpClick(TObject *Sender);
private:	// User declarations
        void UpdateGameDataBase();
        void FalseLabels();
        void ShowKoef();
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        void Init();
        unsigned int NumTrains;
        void Opt();
        int DBFile;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
