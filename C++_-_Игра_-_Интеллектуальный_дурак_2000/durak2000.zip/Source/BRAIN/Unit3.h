//---------------------------------------------------------------------------
const int WarningError=2;
const int FatalError=1;

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TUpdateDataBase : public TThread
{
private:
        char ControlSum();
        void __fastcall MessageError();
protected:
        void __fastcall Execute();
public:
        __fastcall TUpdateDataBase(bool CreateSuspended);
        __fastcall ~TUpdateDataBase();
        unsigned int NumTrains;
        int DBFile;
        String ErrorString;
        int ErrNo;
        int FileWgt;
        int TempFileWgt;
        bool NeedToInit;
        char *Memory;
        char *MemFile;
};
//---------------------------------------------------------------------------
#endif
