//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit5.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAbout *About;
int NumClicks;
//---------------------------------------------------------------------------
__fastcall TAbout::TAbout(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAbout::OkClick(TObject *Sender)
{
ModalResult=mrOk;        
}
//---------------------------------------------------------------------------
void __fastcall TAbout::HowToWorkMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
HowToWork->Font->Color=clNavy;
Neurons->Font->Color=clNavy;
Experim->Font->Color=clNavy;
Write->Font->Color=clNavy;

if(Sender==HowToWork)HowToWork->Font->Color=clBlue;
else if(Sender==Neurons)Neurons->Font->Color=clBlue;
else if(Sender==Experim)Experim->Font->Color=clBlue;
else if(Sender==Write)Write->Font->Color=clBlue;
else if(Sender==Ok)Ok->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TAbout::FormShow(TObject *Sender)
{
Left=Application->MainForm->Left+Application->MainForm->ClientWidth/2-ClientWidth/2;
Top=Application->MainForm->Top+Application->MainForm->ClientHeight/2-ClientHeight/2;
NumClicks=0;
}
//---------------------------------------------------------------------------
void __fastcall TAbout::WriteClick(TObject *Sender)
{
ShellExecute(NULL, "open", "mailto:belser@chat.ru?Subject=������ �� ������������ ��������� Brain", NULL, NULL,SW_NORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TAbout::HowToWorkClick(TObject *Sender)
{
Application->HelpJump("IDH_HowWork");
}
//---------------------------------------------------------------------------

void __fastcall TAbout::NeuronsClick(TObject *Sender)
{
Application->HelpJump("IDH_NeuralNet");
}
//---------------------------------------------------------------------------

void __fastcall TAbout::ExperimClick(TObject *Sender)
{
Application->HelpJump("IDH_Experiment");
}
//---------------------------------------------------------------------------
