//---------------------------------------------------------------------------
#ifndef Unit6H
#define Unit6H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TAbout : public TForm
{
__published:	// IDE-managed Components
        TLabel *L1;
        TLabel *L2;
        TButton *OK;
        TLabel *L5;
        TLabel *MyLink;
        TTimer *Timer1;
        TLabel *y1;
        TLabel *Label2;
        TBevel *Bevel1;
        TLabel *Label3;
        TLabel *NN;
        void __fastcall MyLinkMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall OKClick(TObject *Sender);
        void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall MyLinkClick(TObject *Sender);
        void __fastcall OKMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TAbout(TComponent* Owner);
        unsigned int TCorrectAnsw;
};
//---------------------------------------------------------------------------
extern PACKAGE TAbout *About;
//---------------------------------------------------------------------------
#endif
