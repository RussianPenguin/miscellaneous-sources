//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit6.h"
#include "Unit1.h"
#include "Version.h"
#include "stdlib.h"
Graphics::TBitmap *TempCard;
int NumOfCard;
int Angel;
int Sp;
int SaveX=0;
bool FaceOrNot;
const divx=CardLength/2;
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TAbout *About;
//---------------------------------------------------------------------------
__fastcall TAbout::TAbout(TComponent* Owner): TForm(Owner)
{
L5->Caption="������ "+DURVERSION+",  Copyright � SeBco soft, 1999-2000.";
SaveX=0;

Word Y,M,d;
DecodeDate(Date(),Y,M,d);
L1->Caption="���������� ����� "+IntToStr(Y)+"!�";
}
//---------------------------------------------------------------------------
void __fastcall TAbout::MyLinkMouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
MyLink->Font->Color=clBlue;
SaveX=0;
}
//---------------------------------------------------------------------------
void __fastcall TAbout::OKClick(TObject *Sender)
{
SaveX=0;
Timer1->Enabled=false;
delete TempCard;
ModalResult=mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TAbout::FormMouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
SaveX=0;
MyLink->Font->Color=clNavy;
}
//---------------------------------------------------------------------------
void __fastcall TAbout::MyLinkClick(TObject *Sender)
{
SaveX=0;
Form1->HomePageClick(NULL);
}
//---------------------------------------------------------------------------
void __fastcall TAbout::OKMouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
MyLink->Font->Color=clNavy;
OK->SetFocus();
SaveX=0;
}
//---------------------------------------------------------------------------
void __fastcall TAbout::Timer1Timer(TObject *Sender)
{
TempCard->Canvas->Rectangle(0,0,CardLength,CardHeight);
if(FaceOrNot)
  StretchBlt(TempCard->Canvas->Handle,divx-Angel,0,Angel*2,CardHeight,Form1->Buffer[NumOfCard]->Canvas->Handle,0,0,CardLength,CardHeight,cmSrcCopy);
else
  StretchBlt(TempCard->Canvas->Handle,divx-Angel,0,Angel*2,CardHeight,Form1->Buffer[0]->Canvas->Handle,0,0,CardLength,CardHeight,cmSrcCopy);

StretchBlt(Canvas->Handle,5,5,CardLength,CardHeight,TempCard->Canvas->Handle,0,0,CardLength,CardHeight,cmSrcCopy);

const SS=3;
Angel+=Sp;
if(Angel<=0){
  Sp=SS;
  Angel=0;
if(FaceOrNot)FaceOrNot=false;else FaceOrNot=true;
}
else
  if(Angel>=divx){
    Sp=-SS;
    Angel=divx;
  }

}
//---------------------------------------------------------------------------
void __fastcall TAbout::FormShow(TObject *Sender)
{
NN->Caption="��������� ���� ������� �� "+IntToStr(TCorrectAnsw)+" ��������";
TempCard=new Graphics::TBitmap;
TempCard->Height=CardHeight;
TempCard->Width=CardLength;
TempCard->Canvas->Pen->Color=About->Color;
TempCard->Canvas->Brush->Color=About->Color;
NumOfCard=random(36)+1;
Angel=CardLength;
SaveX=0;
Sp=-1;
FaceOrNot=true;
Timer1->Enabled=true;
Timer1Timer(NULL);
}
//---------------------------------------------------------------------------
