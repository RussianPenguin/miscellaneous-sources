//---------------------------------------------------------------------------
#ifndef Unit4H
#define Unit4H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "CSPIN.h"
#include <Dialogs.hpp>
#include <ExtDlgs.hpp>
#include "ocontrls.hpp"
#include "OContrls.hpp"
#include "DsCheck.hpp"
#include "DsGroup.hpp"
#include "DsRadio.hpp"
#include "ADVSPIN.HPP"
#include "EZLabel.hpp"
#include <Mask.hpp>
#include "ADVSPIN.HPP"
#include "advspin.hpp"
//---------------------------------------------------------------------------
class TOptions : public TForm
{
__published:	// IDE-managed Components
        TPageControl *Prp;
        TTabSheet *Main;
        TTabSheet *Adv;
        TOpenPictureDialog *FileOpenName;
        TTabSheet *View;
        TTabSheet *Rules;
        TColorDialog *ColorBG;
        TOpenPictureDialog *OpenBgFile;
        TOfficeButton *OK;
        TOfficeButton *Cancel;
        TOfficeButton *Apply;
        TOfficeButton *Help;
        TDsGroup *BG1;
        TDsCheck *CanSort;
        TDsGroup *BG2;
        TDsRadio *ByMast;
        TDsRadio *ByDost;
        TDsCheck *ExeptKozir;
        TDsGroup *BG3;
        TDsRadio *CRight;
        TDsRadio *CLeft;
        TDsCheck *SeveralCards;
        TDsCheck *Animate;
        TDsCheck *MyHint;
        TDsCheck *Statist;
        TDsCheck *QStart;
        TDsCheck *Sound;
        TOfficeButton *ResetResult;
        TDsGroup *Gx1;
        TEZLabel *EZLabel1;
        TEZLabel *EZLabel2;
        TTrackBar *Level;
        TDsCheck *Warning;
        TDsCheck *StatusBar;
        TDsCheck *AutoGame;
        TDsCheck *ShowTop10;
        TDsGroup *GB4;
        TEZLabel *LFrames;
        TEZLabel *EZLabel4;
        TAdvSpinEdit *FramesCount;
        TAdvSpinEdit *AnimateDelay;
        TDsGroup *GB9;
        TDsRadio *UseRect;
        TDsRadio *BlinkCard;
        TDsGroup *GB8;
        TEZLabel *L97;
        TDsCheck *MyCursor;
        TAdvSpinEdit *CursorTime;
        TDsGroup *GrpB1;
        TDsRadio *Flat;
        TDsRadio *Volume;
        TDsGroup *GBox1;
        TDsRadio *Standart;
        TDsRadio *ColorCursor;
        TDsCheck *ToolBar;
        TDsGroup *GpBx1;
        TOfficeButton *AdjustColor;
        TOfficeButton *LoadGB;
        TOfficeButton *StandartBG;
        TDsRadio *ColoredBG;
        TDsRadio *FileBG;
        TDsCheck *AreaAutoSize;
        TDsCheck *RealButton;
        TDsCheck *NewStatistic;
        TDsCheck *Hilighting;
        TDsGroup *Ru;
        TOfficeButton *FileImage;
        TOfficeButton *ResetFaceOff;
        TDsCheck *EnableFirst;
        TDsCheck *OneByOne;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall CanSortClick(TObject *Sender);
        void __fastcall OKClick(TObject *Sender);
        void __fastcall ResetResultClick(TObject *Sender);
        void __fastcall HelpClick(TObject *Sender);
        void __fastcall AnimateClick(TObject *Sender);
        void __fastcall FileImageClick(TObject *Sender);
        void __fastcall ResetFaceOffClick(TObject *Sender);
        void __fastcall AdjustColorClick(TObject *Sender);
        void __fastcall LoadGBClick(TObject *Sender);
        void __fastcall StandartBGClick(TObject *Sender);
        void __fastcall ApplyClick(TObject *Sender);
private:	// User declarations
        void ShowHide();
public:		// User declarations
        bool MyResetResult;
        __fastcall TOptions(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TOptions *Options;
//---------------------------------------------------------------------------
#endif
