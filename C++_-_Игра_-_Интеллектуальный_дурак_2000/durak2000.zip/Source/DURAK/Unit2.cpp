//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
#include "Unit1.h"
#include "version.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TTopNames *TopNames;
int NameSelected=255, LSelected=255;
int NameDown=0;
int LetterHeight=0,LetterWidth=0;
int W1=0,W2=0;
//---------------------------------------------------------------------------
__fastcall TTopNames::TTopNames(TComponent* Owner)
        : TForm(Owner)
{
Canvas->Brush->Style=bsClear;
Canvas->Font=TopNames->Font;
Canvas->Pen->Width=1;
NameDown=255;
LetterHeight=TopNames->Canvas->TextHeight("S")+1;
LetterWidth=TopNames->Canvas->TextWidth("S")+1;
}
//---------------------------------------------------------------------------
void __fastcall TTopNames::OkClick(TObject *Sender)
{
PutName();
ModalResult=mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TTopNames::FormPaint(TObject *Sender)
{
String Temp;
Canvas->Draw(0,0,Form1->MyBackGround);
Canvas->Font->Style=TFontStyles()<<fsBold;

Temp="��� ������";

Canvas->Font->Color=clBlack;
Canvas->TextOutA(7,2,Temp);
Canvas->Font->Color=clWhite;
Canvas->TextOutA(5,0,Temp);

Temp="���������";

Canvas->Font->Color=clBlack;
Canvas->TextOutA(202,2,Temp);
Canvas->Font->Color=clWhite;
Canvas->TextOutA(200,0,Temp);

W1=200+Canvas->TextWidth(Temp)+LetterWidth;
Temp="����������";

Canvas->Font->Color=clBlack;
Canvas->TextOutA(W1+2,2,Temp);
Canvas->Font->Color=clWhite;
Canvas->TextOutA(W1,0,Temp);

W2=W1+Canvas->TextWidth(Temp)+LetterWidth;
Temp="�����";

Canvas->Font->Color=clBlack;
Canvas->TextOutA(W2+2,2,Temp);
Canvas->Font->Color=clWhite;
Canvas->TextOutA(W2,0,Temp);


Temp="����� ������������";

Canvas->Font->Color=clBlack;
Canvas->TextOutA(7,TUserName->Top+7,Temp);
Canvas->Font->Color=clWhite;
Canvas->TextOutA(5,TUserName->Top+5,Temp);

Canvas->Pen->Color=clBlack;//���������� �����
Canvas->MoveTo(3,LetterHeight);
Canvas->LineTo(TopNames->ClientWidth-5,LetterHeight);
Canvas->Pen->Color=clWhite;
Canvas->MoveTo(4,LetterHeight+1);
Canvas->LineTo(TopNames->ClientWidth-4,LetterHeight+1);


Canvas->Pen->Color=clBlack;//���������� �����
Canvas->MoveTo(3,TUserName->Top-11);
Canvas->LineTo(TopNames->ClientWidth-5,TUserName->Top-11);
Canvas->Pen->Color=clWhite;
Canvas->MoveTo(4,TUserName->Top-10);
Canvas->LineTo(TopNames->ClientWidth-4,TUserName->Top-10);

for(int i=0;i<10;i++)
  if(!Form1->TotalNames[i].IsEmpty()){
    Canvas->Font->Color=clBlack;
    Canvas->TextOutA(7,27+i*LetterHeight,Form1->TotalNames[i]);
    Canvas->TextOutA(202,27+i*LetterHeight,Form1->TotalWins[i]);
    Canvas->TextOutA(W1+2,27+i*LetterHeight,Form1->TotalLoses[i]);
    Canvas->TextOutA(W2+2,27+i*LetterHeight,Form1->TotalGames[i]);

    if(i==Index)Canvas->Font->Color=clYellow;
    else if(i==NameSelected)Canvas->Font->Color=clAqua;
         else Canvas->Font->Color=clWhite;

    Canvas->TextOutA(5,25+i*LetterHeight,Form1->TotalNames[i]);
    Canvas->TextOutA(200,25+i*LetterHeight,Form1->TotalWins[i]);
    Canvas->TextOutA(W1,25+i*LetterHeight,Form1->TotalLoses[i]);
    Canvas->TextOutA(W2,25+i*LetterHeight,Form1->TotalGames[i]);
}
}
//---------------------------------------------------------------------------

void __fastcall TTopNames::FormMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
if(Form1->DynamicFocus)
  if(Sender==TUserName)TUserName->SetFocus();
  else Ok->SetFocus();

NameSelected=255;
for(int i=0;i<10;i++)
 if(X>=0&&X<=TopNames->ClientWidth)
   if(Y>=25+i*LetterHeight&&Y<=Canvas->TextHeight(Form1->TotalNames[i])+25+i*LetterHeight)
     if(!Form1->TotalNames[i].IsEmpty())NameSelected=i;

if(NameDown!=255&&NameSelected!=255&&NameDown!=NameSelected){Cursor=crArrow;return;}
if(Index==NameSelected&&Sender!=NULL){Cursor=crArrow;return;}

if(LSelected!=NameSelected){
  if(LSelected!=255){
    Canvas->Font->Color=clBlack;
    Canvas->TextOutA(7,27+LSelected*LetterHeight,Form1->TotalNames[LSelected]);
    Canvas->TextOutA(202,27+LSelected*LetterHeight,Form1->TotalWins[LSelected]);
    Canvas->TextOutA(W1+2,27+LSelected*LetterHeight,Form1->TotalLoses[LSelected]);
    Canvas->TextOutA(W2+2,27+LSelected*LetterHeight,Form1->TotalGames[LSelected]);

    if(Index==LSelected)Canvas->Font->Color=clYellow;
    else Canvas->Font->Color=clWhite;
    Canvas->TextOutA(5,25+LSelected*LetterHeight,Form1->TotalNames[LSelected]);
    Canvas->TextOutA(200,25+LSelected*LetterHeight,Form1->TotalWins[LSelected]);
    Canvas->TextOutA(W1,25+LSelected*LetterHeight,Form1->TotalLoses[LSelected]);
    Canvas->TextOutA(W2,25+LSelected*LetterHeight,Form1->TotalGames[LSelected]);
  }

  if(NameSelected!=255){
    if(NameDown==NameSelected)Canvas->Font->Color=clAqua; else Canvas->Font->Color=clBlack;
    Canvas->TextOutA(7,27+NameSelected*LetterHeight,Form1->TotalNames[NameSelected]);
    Canvas->TextOutA(202,27+NameSelected*LetterHeight,Form1->TotalWins[NameSelected]);
    Canvas->TextOutA(W1+2,27+NameSelected*LetterHeight,Form1->TotalLoses[NameSelected]);
    Canvas->TextOutA(W2+2,27+NameSelected*LetterHeight,Form1->TotalGames[NameSelected]);

    if(NameDown==NameSelected)Canvas->Font->Color=clBlack; else
    Canvas->Font->Color=clAqua;
    Canvas->TextOutA(5,25+NameSelected*LetterHeight,Form1->TotalNames[NameSelected]);
    Canvas->TextOutA(200,25+NameSelected*LetterHeight,Form1->TotalWins[NameSelected]);
    Canvas->TextOutA(W1,25+NameSelected*LetterHeight,Form1->TotalLoses[NameSelected]);
    Canvas->TextOutA(W2,25+NameSelected*LetterHeight,Form1->TotalGames[NameSelected]);
  }
}

if(NameSelected==255)Cursor=crArrow;else Cursor=crHandPoint;
LSelected=NameSelected;
}
//---------------------------------------------------------------------------


void __fastcall TTopNames::FormMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
if(NameSelected!=255&&NameSelected==LSelected&&Index!=NameSelected){
  NameDown=NameSelected;
  LSelected=255;
  FormMouseMove(NULL,Shift,X,Y);
}

}
//---------------------------------------------------------------------------

void __fastcall TTopNames::FormMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
if(NameSelected!=255&&NameSelected==LSelected&&Index!=NameSelected){
  NameDown=255;

  Canvas->Font->Color=clBlack;
  Canvas->TextOutA(7,27+Index*LetterHeight,Form1->TotalNames[Index]);
  Canvas->TextOutA(202,27+Index*LetterHeight,Form1->TotalWins[Index]);
  Canvas->TextOutA(W1+2,27+Index*LetterHeight,Form1->TotalLoses[Index]);
  Canvas->TextOutA(W2+2,27+Index*LetterHeight,Form1->TotalGames[Index]);

  Canvas->Font->Color=clWhite;
  Canvas->TextOutA(5,25+Index*LetterHeight,Form1->TotalNames[Index]);
  Canvas->TextOutA(200,25+Index*LetterHeight,Form1->TotalWins[Index]);
  Canvas->TextOutA(W1,25+Index*LetterHeight,Form1->TotalLoses[Index]);
  Canvas->TextOutA(W2,25+Index*LetterHeight,Form1->TotalGames[Index]);

  Index=NameSelected;
  X=0;
  Y=0;
  FormMouseMove(NULL,Shift,X,Y);
}
NameDown=255;
}
//---------------------------------------------------------------------------

void TTopNames::PutName(){//������ � ������ ������ ������������
if(TUserName->Text==NewPlayer)return;

for(int i=0;i<10;i++)
  if(Form1->TotalNames[i]==TUserName->Text)return;

for(int i=0;i<10;i++)
  if(Form1->TotalNames[i].IsEmpty()){
    Form1->TotalNames[i]=TUserName->Text;
    Form1->TotalWins[i]=0;
    Form1->TotalLoses[i]=0;
    Form1->TotalGames[i]=0;
    Index=i;
    FormPaint(NULL);
    break;
  }

Ok->SetFocus();
}
//---------------------------------------------------------------------------


void __fastcall TTopNames::TUserNameKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
if(Key==13)PutName();
}
//---------------------------------------------------------------------------

void __fastcall TTopNames::FormShow(TObject *Sender){
Left=Application->MainForm->Left+Application->MainForm->ClientWidth/2-ClientWidth/2;
Top=Application->MainForm->Top+Application->MainForm->ClientHeight/2-ClientHeight/2;
}
//---------------------------------------------------------------------------

