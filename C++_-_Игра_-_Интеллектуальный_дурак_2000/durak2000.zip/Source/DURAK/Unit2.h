//---------------------------------------------------------------------------
#ifndef Unit2H
#define Unit2H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TTopNames : public TForm
{
__published:	// IDE-managed Components
        TButton *Ok;
        TEdit *TUserName;
        void __fastcall OkClick(TObject *Sender);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall FormMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall FormMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall TUserNameKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
        void PutName();
public:		// User declarations
        int Index;//������� ������������
        __fastcall TTopNames(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TTopNames *TopNames;
//---------------------------------------------------------------------------
#endif
