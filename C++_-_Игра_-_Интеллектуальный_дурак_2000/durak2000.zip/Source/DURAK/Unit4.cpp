//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit4.h"
#include "Unit1.h"
#include "Version.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma link "OContrls"
#pragma link "OContrls"
#pragma link "DsCheck"
#pragma link "DsGroup"
#pragma link "DsRadio"
#pragma link "advspin"
#pragma link "EZLabel"
#pragma link "advspin"
#pragma link "advspin"
#pragma resource "*.dfm"

TOptions *Options;
//---------------------------------------------------------------------------
__fastcall TOptions::TOptions(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TOptions::FormShow(TObject *Sender)
{
Left=Application->MainForm->Left+Application->MainForm->ClientWidth/2-ClientWidth/2;
Top=Application->MainForm->Top+Application->MainForm->ClientHeight/2-ClientHeight/2;

MyResetResult=false;
Options->ShowHide();
}
//---------------------------------------------------------------------------

void TOptions::ShowHide(){//���������/���������
if(CanSort->Checked){
  ByDost->Enabled=true;
  ByMast->Enabled=true;

  if(ByDost->Checked){
    CRight->Enabled=false;
    CLeft->Enabled=false;
    ExeptKozir->Enabled=true;
  }
  else
  {
    CRight->Enabled=true;
    CLeft->Enabled=true;
    ExeptKozir->Enabled=false;
  }

}
else{
  ByDost->Enabled=false;
  ByMast->Enabled=false;
  CRight->Enabled=false;
  CLeft->Enabled=false;
  ExeptKozir->Enabled=false;
}


if(MyCursor->Checked){
  L97->Enabled=true;
  CursorTime->Enabled=true;
}
else{
  L97->Enabled=false;
  CursorTime->Enabled=false;
}

if(ToolBar->Checked){
  Flat->Enabled=true;
  Volume->Enabled=true;
}
else{
  Flat->Enabled=false;
  Volume->Enabled=false;
}

}
//---------------------------------------------------------------------------

void __fastcall TOptions::CanSortClick(TObject *Sender)
{
Options->ShowHide();
}
//---------------------------------------------------------------------------

void __fastcall TOptions::OKClick(TObject *Sender)
{
if(Sender==OK)ModalResult=mrOk;
else ModalResult=mrCancel;
}
//---------------------------------------------------------------------------

void __fastcall TOptions::ResetResultClick(TObject *Sender)
{
MyResetResult=true;
Form1->Wins=0;
Form1->Loses=0;
Form1->Games=0;
Form1->PutCaption();
}
//---------------------------------------------------------------------------
void __fastcall TOptions::HelpClick(TObject *Sender)
{
if(Prp->ActivePage==Main)Application->HelpJump("IDH_Options1");
else if(Prp->ActivePage==Adv)Application->HelpJump("IDH_Options2");
else if(Prp->ActivePage==View)Application->HelpJump("IDH_View");
else if(Prp->ActivePage==Rules)Application->HelpJump("IDH_Rules");
}
//---------------------------------------------------------------------------

void __fastcall TOptions::AnimateClick(TObject *Sender)
{
bool t=Animate->Checked;

GB4->Enabled=t;
LFrames->Enabled=t;
FramesCount->Enabled=t;
}
//---------------------------------------------------------------------------

void __fastcall TOptions::FileImageClick(TObject *Sender)
{
FileOpenName->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TOptions::ResetFaceOffClick(TObject *Sender)
{
FileOpenName->FileName="";
}
//---------------------------------------------------------------------------
void __fastcall TOptions::AdjustColorClick(TObject *Sender)
{
ColoredBG->Checked=true;
ColorBG->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TOptions::LoadGBClick(TObject *Sender)
{
FileBG->Checked=true;
OpenBgFile->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TOptions::StandartBGClick(TObject *Sender)
{
OpenBgFile->FileName="";
FileBG->Checked=true;
}
//---------------------------------------------------------------------------

void __fastcall TOptions::ApplyClick(TObject *Sender)
{
Form1->ApplyOptions();
}
//---------------------------------------------------------------------------

