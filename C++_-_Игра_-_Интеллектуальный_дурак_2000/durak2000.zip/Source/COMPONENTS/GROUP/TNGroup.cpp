//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TNGroup.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("DsCheck.pas");
USERES("DsCheck.dcr");
USEUNIT("DsGroup.pas");
USERES("DsGroup.dcr");
USEUNIT("DsRadio.pas");
USERES("DsRadio.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
