// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DsCheck.pas' rev: 5.00

#ifndef DsCheckHPP
#define DsCheckHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dscheck
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TAlignment { taLeft, taRight };
#pragma option pop

#pragma option push -b-
enum TCheckStyle { ckRaised, ckFlat };
#pragma option pop

#pragma option push -b-
enum TTextStyle { txNone, txRaised, txLowered };
#pragma option pop

class DELPHICLASS TDsCheck;
class PASCALIMPLEMENTATION TDsCheck : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	TAlignment FAlignment;
	Graphics::TColor FCheckColor;
	TCheckStyle FCheckStyle;
	Graphics::TColor FColor_High;
	Graphics::TColor FColor_Low;
	bool FDown;
	bool FFocused;
	Stdctrls::TCheckBoxState FState;
	TTextStyle FTextStyle;
	HIDESBASE MESSAGE void __fastcall CMEnabledChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMTextChanged(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMDialogChar(Messages::TWMKey &Message);
	HIDESBASE MESSAGE void __fastcall WMSetFocus(Messages::TWMSetFocus &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMKillFocus(Messages::TWMKillFocus &Message);
	
protected:
	DYNAMIC void __fastcall DoEnter(void);
	DYNAMIC void __fastcall DoExit(void);
	bool __fastcall GetChecked(void);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyUp(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	virtual void __fastcall Paint(void);
	void __fastcall SetAlignment(TAlignment Value);
	void __fastcall SetCheckColor(Graphics::TColor Value);
	void __fastcall SetChecked(bool Value);
	void __fastcall SetColor_High(Graphics::TColor Value);
	void __fastcall SetColor_Low(Graphics::TColor Value);
	void __fastcall SetDown(bool Value);
	void __fastcall SetState(Stdctrls::TCheckBoxState Value);
	
public:
	__fastcall virtual TDsCheck(Classes::TComponent* AOwner);
	
__published:
	__property TAlignment Alignment = {read=FAlignment, write=SetAlignment, default=0};
	__property Caption ;
	__property Graphics::TColor CheckColor = {read=FCheckColor, write=SetCheckColor, default=0};
	__property bool Checked = {read=GetChecked, write=SetChecked, default=0};
	__property Color ;
	__property Graphics::TColor Color_High = {read=FColor_High, write=SetColor_High, default=14739688};
		
	__property Graphics::TColor Color_Low = {read=FColor_Low, write=SetColor_Low, default=6852002};
	__property bool Down = {read=FDown, write=SetDown, default=0};
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property ParentColor ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property Stdctrls::TCheckBoxState State = {read=FState, write=SetState, default=0};
	__property TabOrder ;
	__property TabStop ;
	__property Visible ;
	__property OnClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
public:
	#pragma option push -w-inl
	/* TCustomControl.Destroy */ inline __fastcall virtual ~TDsCheck(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TDsCheck(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Dscheck */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dscheck;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DsCheck
