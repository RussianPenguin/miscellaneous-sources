// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DsGroup.pas' rev: 5.00

#ifndef DsGroupHPP
#define DsGroupHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dsgroup
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TCapAlignment { caLeft, caCenter, caRight };
#pragma option pop

#pragma option push -b-
enum TTextStyle { txNone, txLowered, txRaised, txShadowed };
#pragma option pop

class DELPHICLASS TDsGroup;
class PASCALIMPLEMENTATION TDsGroup : public Stdctrls::TCustomGroupBox 
{
	typedef Stdctrls::TCustomGroupBox inherited;
	
private:
	TCapAlignment FCapAlignment;
	Graphics::TColor FColor_High;
	Graphics::TColor FColor_Low;
	int FCornerRadius;
	Graphics::TColor FFaceColor;
	TTextStyle FTextStyle;
	
protected:
	virtual void __fastcall AlignControls(Controls::TControl* AControl, Windows::TRect &Rect);
	virtual void __fastcall Paint(void);
	void __fastcall SetFaceColor(Graphics::TColor Value);
	void __fastcall SetCapAlignment(TCapAlignment Value);
	void __fastcall SetColor_High(Graphics::TColor Value);
	void __fastcall SetColor_Low(Graphics::TColor Value);
	void __fastcall SetCornerRadius(int Value);
	void __fastcall SetTextStyle(TTextStyle Value);
	
public:
	__fastcall virtual TDsGroup(Classes::TComponent* AOwner);
	__fastcall virtual ~TDsGroup(void);
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	
__published:
	__property Align ;
	__property TCapAlignment CapAlignment = {read=FCapAlignment, write=SetCapAlignment, default=0};
	__property Caption ;
	__property Color ;
	__property Graphics::TColor Color_High = {read=FColor_High, write=SetColor_High, default=14739688};
		
	__property Graphics::TColor Color_Low = {read=FColor_Low, write=SetColor_Low, default=6852002};
	__property int CornerRadius = {read=FCornerRadius, write=SetCornerRadius, default=3};
	__property Ctl3D ;
	__property Cursor ;
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Graphics::TColor FaceColor = {read=FFaceColor, write=SetFaceColor, default=536870911};
	__property Font ;
	__property Height ;
	__property HelpContext ;
	__property Hint ;
	__property Left ;
	__property ParentColor ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property TTextStyle TextStyle = {read=FTextStyle, write=SetTextStyle, default=2};
	__property Visible ;
	__property Width ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnKeyDown ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TDsGroup(HWND ParentWindow) : Stdctrls::TCustomGroupBox(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Dsgroup */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Dsgroup;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DsGroup
