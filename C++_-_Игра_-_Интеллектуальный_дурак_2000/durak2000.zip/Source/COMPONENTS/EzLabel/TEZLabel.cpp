//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TEZLabel.res");
USEPACKAGE("vcl50.bpi");
USEFORMNS("EZLabel.pas", Ezlabel, LabelEditorDlg);
USERES("EZLabel.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
