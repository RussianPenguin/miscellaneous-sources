// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'EZLabel.pas' rev: 5.00

#ifndef EZLabelHPP
#define EZLabelHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Menus.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <DsgnIntf.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ezlabel
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum T3DEffect { Normal3d, Resit3d, Raised3d, Shadowed3d };
#pragma option pop

#pragma option push -b-
enum TFitType { NormalFit, BestFitVert, BestFithorz, BestFitBoth };
#pragma option pop

class DELPHICLASS TEZLabel;
class PASCALIMPLEMENTATION TEZLabel : public Stdctrls::TLabel 
{
	typedef Stdctrls::TLabel inherited;
	
private:
	HIDESBASE void __fastcall setTransparent(bool Value);
	void __fastcall setStyleEffect(T3DEffect Value);
	void __fastcall SetShadowColor(Graphics::TColor Value);
	void __fastcall SetWhiteColor(Graphics::TColor Value);
	HIDESBASE void __fastcall DoDrawText(Windows::TRect &Rect, Word Flags);
	void __fastcall SetFhOffSet(int value);
	void __fastcall SetFvOffSet(int value);
	void __fastcall SetShadeLT(bool value);
	void __fastcall SetFitType(TFitType Value);
	HIDESBASE MESSAGE void __fastcall WMMouseMove(Messages::TWMMouse &msg);
	void __fastcall DoMouseOut(const Messages::TWMMouse &msg);
	void __fastcall DoMouseMove(const Messages::TWMMouse &msg);
	void __fastcall DoEdit(void);
	void __fastcall UpdateDesigner(void);
	
protected:
	int FOldWidth;
	int FOldHeight;
	int FOldSize;
	AnsiString FOldCaption;
	Classes::TNotifyEvent MouseOut;
	TFitType FFitType;
	T3DEffect F3DEffect;
	Graphics::TColor FShadowColor;
	Graphics::TColor FWhiteColor;
	Graphics::TColor FLast;
	int FhOffSet;
	int FvOffSet;
	bool FShadeLTSet;
	bool FTransparent;
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TEZLabel(Classes::TComponent* AOwner);
	__fastcall virtual ~TEZLabel(void);
	
__published:
	__property Align ;
	__property Caption ;
	__property TFitType AFitType = {read=FFitType, write=SetFitType, nodefault};
	__property T3DEffect AStyle3D = {read=F3DEffect, write=setStyleEffect, default=0};
	__property Graphics::TColor AShadeRightBottom = {read=FShadowColor, write=SetShadowColor, default=8421504
		};
	__property Graphics::TColor AShadeLeftTop = {read=FWhiteColor, write=SetWhiteColor, default=16777215
		};
	__property int AHShadeOffSet = {read=FhOffSet, write=SetFhOffSet, default=5};
	__property int AVShadeOffSet = {read=FvOffSet, write=SetFvOffSet, default=-5};
	__property bool AShadeLTSet = {read=FShadeLTSet, write=SetShadeLT, default=1};
	__property bool Transparent = {read=FTransparent, write=setTransparent, default=1};
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property ParentColor ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property ShowHint ;
	__property Visible ;
	__property Width ;
	__property Top ;
	__property Left ;
	__property Height ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property Classes::TNotifyEvent OnMouseOut = {read=MouseOut, write=MouseOut};
};


class DELPHICLASS TLabelEditorDlg;
class PASCALIMPLEMENTATION TLabelEditorDlg : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TRadioGroup* E3dStyle;
	Extctrls::TRadioGroup* EFitType;
	Dialogs::TFontDialog* FontD;
	Stdctrls::TButton* btFont;
	Extctrls::TPanel* Panel;
	Stdctrls::TEdit* ECaption;
	Stdctrls::TLabel* Label1;
	Buttons::TBitBtn* BitBtn1;
	Buttons::TBitBtn* BitBtn2;
	Dialogs::TColorDialog* ColorD;
	Stdctrls::TButton* btColor;
	Stdctrls::TButton* Button1;
	Stdctrls::TCheckBox* cTrans;
	void __fastcall OKButtonClick(System::TObject* Sender);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall EFitTypeClick(System::TObject* Sender);
	void __fastcall E3dStyleClick(System::TObject* Sender);
	void __fastcall btFontClick(System::TObject* Sender);
	void __fastcall ECaptionChange(System::TObject* Sender);
	void __fastcall btColorClick(System::TObject* Sender);
	void __fastcall Button1Click(System::TObject* Sender);
	void __fastcall cTransClick(System::TObject* Sender);
	
private:
	TEZLabel* EZLabel;
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TLabelEditorDlg(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TLabelEditorDlg(Classes::TComponent* AOwner, 
		int Dummy) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TLabelEditorDlg(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TLabelEditorDlg(HWND ParentWindow) : Forms::TForm(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TLabelEditor;
class PASCALIMPLEMENTATION TLabelEditor : public Dsgnintf::TDefaultEditor 
{
	typedef Dsgnintf::TDefaultEditor inherited;
	
public:
	virtual void __fastcall Edit(void);
	virtual void __fastcall ExecuteVerb(int Index);
	virtual AnsiString __fastcall GetVerb(int Index);
	virtual int __fastcall GetVerbCount(void);
public:
	#pragma option push -w-inl
	/* TComponentEditor.Create */ inline __fastcall virtual TLabelEditor(Classes::TComponent* AComponent
		, Dsgnintf::_di_IFormDesigner ADesigner) : Dsgnintf::TDefaultEditor(AComponent, ADesigner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TLabelEditor(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Ezlabel */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ezlabel;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// EZLabel
