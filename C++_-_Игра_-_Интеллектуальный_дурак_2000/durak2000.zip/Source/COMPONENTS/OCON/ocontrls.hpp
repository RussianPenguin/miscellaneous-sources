// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'OContrls.pas' rev: 5.00

#ifndef OContrlsHPP
#define OContrlsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Ocontrls
{
//-- type declarations -------------------------------------------------------
typedef Shortint TBorderWidth;

class DELPHICLASS TOfficeButton;
class PASCALIMPLEMENTATION TOfficeButton : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	Graphics::TColor FBorderColor;
	TBorderWidth FBorderWidth;
	Graphics::TColor FButtonColor;
	AnsiString FCaption;
	bool FEnabled;
	Graphics::TFont* FFont;
	Graphics::TBitmap* FGlyph;
	int FRoundSize;
	bool FTransparent;
	Classes::TNotifyEvent FMouseEnter;
	Classes::TNotifyEvent FMouseLeave;
	bool HasMouse;
	bool IsMouseDown;
	Word ExtraSpace;
	void __fastcall SetBorderColor(Graphics::TColor value);
	void __fastcall SetBorderWidth(TBorderWidth value);
	void __fastcall SetButtonColor(Graphics::TColor value);
	void __fastcall SetCaption(AnsiString value);
	HIDESBASE void __fastcall SetEnabled(bool value);
	HIDESBASE void __fastcall SetFont(Graphics::TFont* value);
	void __fastcall SetRoundSize(int value);
	void __fastcall SetTransparent(bool value);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	
protected:
	DYNAMIC void __fastcall Click(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	virtual void __fastcall Paint(void);
	HIDESBASE MESSAGE void __fastcall WMMouseMove(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMLButtonDblClick(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMMButtonDblClick(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMRButtonDblClick(Messages::TWMMouse &Message);
	
public:
	__fastcall virtual TOfficeButton(Classes::TComponent* AOwner);
	__fastcall virtual ~TOfficeButton(void);
	
__published:
	__property Graphics::TColor BorderColor = {read=FBorderColor, write=FBorderColor, default=8421504};
		
	__property TBorderWidth BorderWidth = {read=FBorderWidth, write=SetBorderWidth, default=1};
	__property Graphics::TColor ButtonColor = {read=FButtonColor, write=SetButtonColor, default=12632256
		};
	__property AnsiString Caption = {read=FCaption, write=SetCaption};
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property Graphics::TFont* Font = {read=FFont, write=SetFont};
	__property int RoundSize = {read=FRoundSize, write=SetRoundSize, default=15};
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=1};
	__property ShowHint ;
	__property Visible ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnMouseDown ;
	__property Classes::TNotifyEvent OnMouseEnter = {read=FMouseEnter, write=FMouseEnter};
	__property Classes::TNotifyEvent OnMouseLeave = {read=FMouseLeave, write=FMouseLeave};
	__property OnMouseMove ;
	__property OnMouseUp ;
};


#pragma option push -b-
enum TLEDType { RoundLED, TriLEDDown, TriLEDUp };
#pragma option pop

class DELPHICLASS TOfficeLabel;
class PASCALIMPLEMENTATION TOfficeLabel : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	AnsiString FCaption;
	bool FEnabled;
	Graphics::TFont* FFont;
	Graphics::TBitmap* FGlyph;
	Graphics::TColor FLabelColor;
	TLEDType FLedType;
	bool FTransparent;
	Classes::TNotifyEvent FMouseEnter;
	Classes::TNotifyEvent FMouseLeave;
	bool HasMouse;
	bool IsMouseDown;
	bool IsClicked;
	void __fastcall SetCaption(AnsiString value);
	HIDESBASE void __fastcall SetEnabled(bool value);
	HIDESBASE void __fastcall SetFont(Graphics::TFont* value);
	void __fastcall SetLabelColor(Graphics::TColor value);
	void __fastcall SetLEDType(TLEDType value);
	void __fastcall SetTransparent(bool value);
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	
protected:
	DYNAMIC void __fastcall Click(void);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, 
		int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int 
		Y);
	virtual void __fastcall Paint(void);
	HIDESBASE MESSAGE void __fastcall WMMouseMove(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMLButtonDblClick(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMMButtonDblClick(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMRButtonDblClick(Messages::TWMMouse &Message);
	
public:
	__fastcall virtual TOfficeLabel(Classes::TComponent* AOwner);
	__fastcall virtual ~TOfficeLabel(void);
	
__published:
	__property AnsiString Caption = {read=FCaption, write=SetCaption};
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property Graphics::TFont* Font = {read=FFont, write=SetFont};
	__property Graphics::TColor LabelColor = {read=FLabelColor, write=SetLabelColor, default=12632256};
		
	__property TLEDType LEDType = {read=FLedType, write=SetLEDType, default=0};
	__property bool Transparent = {read=FTransparent, write=SetTransparent, default=1};
	__property OnClick ;
	__property OnDblClick ;
	__property OnMouseDown ;
	__property Classes::TNotifyEvent OnMouseEnter = {read=FMouseEnter, write=FMouseEnter};
	__property Classes::TNotifyEvent OnMouseLeave = {read=FMouseLeave, write=FMouseLeave};
	__property OnMouseMove ;
	__property OnMouseUp ;
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Ocontrls */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Ocontrls;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OContrls
