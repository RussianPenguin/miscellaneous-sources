//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("Tocontrls.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("ocontrls.pas");
USERES("ocontrls.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
