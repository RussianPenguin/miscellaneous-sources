Office 97 Controls version 1.5, copyright � A. Meeder, december 1996 - may 1997

  ** It's freeware, so you don't have to pay me, but I do not guarantee the working of it

  ATTENTION: This component is now available for Delphi 1.x and Delphi 2.x, you can use the
             same source (ocontrls.pas) but you must use the version-specific files for
             ocontrls.res and ocontrls.dcr

  The idea came from the personal assistent of MS Office 97. To use these components:

  Special properties of TOfficeButton:
  * BorderColor, color of the border when the button has the mouse
  * BorderWidth, basic width of the border (1 .. 3)
  * ButtonColor, color of button-face when Transparent is false
  * RoundSize, used to change the corners of the button
  * Transparent, default true, or false

  Special events of TOfficeButton:
  * OnMouseEnter
  * OnMouseLeave

  Sepcial properties of TOfficeLabel:
  * LabelColor, color of label-face when Transparent is false
  * LEDType, (RoundLED, TriLEDUp, TriLEDDown)
  * Transparent, default true, or false

  Special events of TOfficeLabel:
  * OnMouseEnter
  * OnMouseLeave

  If you have suggestions about TOButton or make changes, please mail me: ameeder@dds.nl

  Version:
      1.5: Added two events 'OnMouseEnter/OnMouseLeave' (Delphi 1.0 version available)
      1.4: Added 'Enabled' property, changed *.RES-name, fixed some code...
      1.3: Reduced the flickering when you have several Officelabels, -buttons and move over them
      1.2: Added 'Transparent' property
      1.1: Fixed some bugs
      1.0: First release 
