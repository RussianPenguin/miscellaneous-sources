
 ConquerChat 2.1.1 README
 Copyright (c) 2000 Peter Theill, ConquerWare
 
 -----------------------------------------------------------------------------
 Introduction
 -----------------------------------------------------------------------------

 This archive contains a simple ASP chat. Most other chatrooms works using
 the Session object. This chat doesn't and thus might be used on larger
 range of browsers and -settings.
 
 By using all files in this archive, you are actually able to set up and
 customise your own chatroom on your ASP enabled web site.
 
 In order to make the chat work properly, you will have to add a couple of 
 lines in your [global.asa] file. The lines below are also included in the 
 downloadable package. You should insert them in the top of your file, i.e. 
 not in any of the default defined Sub functions.

 <OBJECT RUNAT=Server
  SCOPE=Application
  ID=conquerChat
  PROGID="Scripting.Dictionary">
 </OBJECT>

 <OBJECT RUNAT=Server
  SCOPE=Application
  ID=conquerChatTime
  PROGID="Scripting.Dictionary">
 </OBJECT>
 
 The lines above makes it possible to store currently logged in chat users
 and their timestamp for last typed line. We check this object every time
 we refresh the chat window page and kick out inactive users.
 
 Please read 'http://www.theill.com/asp.asp' for updated information about 
 ConquerChat.

 --------------------------------------------------------------------------
 Version History
 --------------------------------------------------------------------------
 7/18/2000 - Released 2.1.1
  + updated code with a more safe logout method.
  + help files updated to show smiley states and descriptions.
 
 6/29/2000 - Released 2.1
  + added ability to replace typed smilies with images showing state. This
    feature was implemented thanks to Michael Mackert.


 Best regards,
 Peter Theill - peter@theill.com - http://www.theill.com
 --------------------------------------------------------------------------