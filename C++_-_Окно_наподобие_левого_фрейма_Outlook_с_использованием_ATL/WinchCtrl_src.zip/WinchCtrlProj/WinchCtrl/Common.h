//--------------------------------------------------------------------------
// file: Common.h
// author: Alex Blekhman
// maintainer:
//
// Common constants and macros.
//--------------------------------------------------------------------------

#if !defined(COMMON_H)
#define COMMON_H


////////////////////////////////////////////////////////////////////////////
// GUI dimensions

const int CX_ICON = ::GetSystemMetrics(SM_CXSMICON);
const int CY_ICON = ::GetSystemMetrics(SM_CYSMICON);
const int CY_BARBUTTON_HEIGHT = (int)(CY_ICON * 1.75);
const int CX_3DBORDER = ::GetSystemMetrics(SM_CXBORDER);
const int CY_3DBORDER = ::GetSystemMetrics(SM_CYBORDER);

// acceleration for smooth scroll
#define ACCELERATE(val) int(val * 1.61) // Golden Cut
const DWORD SCROLL_SPEED = 15;


////////////////////////////////////////////////////////////////////////////
// Custom messages

const UINT WM_INVALIDATE = ::RegisterWindowMessage(TEXT("{650490FE-94FC-4bf0-AD2A-703883D22CAC}"));
const UINT WM_REDRAW = ::RegisterWindowMessage(TEXT("{C3760442-A472-4533-8ED2-F665F1EF15CA}"));


////////////////////////////////////////////////////////////////////////////
// Debug helpers

#if defined(_DEBUG)
#   define ATLVERIFY(f)  ATLASSERT(f)
#else   // NDEBUG
#   define ATLVERIFY(f)  ((void)(f))
#endif


#endif // COMMON_H

//------------------------------- end of file ------------------------------
