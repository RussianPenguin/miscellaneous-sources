//--------------------------------------------------------------------------
// file: WinchCtrl.h
// author: Alex Blekhman
// maintainer:
//
// CWinchCtrl class implements functionality of pager common control.
// CWinchCtrl has a member of CWinch type and provides access to its
// methods.
//--------------------------------------------------------------------------

#if !defined(WINCHCTRL_H)
#define WINCHCTRL_H

#include "Winch.h"

class CWinchCtrl;
typedef CWindowImpl< CWinchCtrl, CWindow, CWinTraits<WS_CHILD | WS_VISIBLE/* | WS_CLIPCHILDREN | WS_CLIPSIBLINGS*/ | PGS_VERT> > WINCHCTRLIMPL;

class CWinchCtrl : public WINCHCTRLIMPL
{
public:
    DECLARE_WND_SUPERCLASS(NULL, WC_PAGESCROLLER)

    CWinchCtrl() {}

    bool Create(HWND hWndParent, RECT& rcPos)
    {
        // Initialize the pager control
        INITCOMMONCONTROLSEX ctrlsex;
        ctrlsex.dwSize = sizeof(INITCOMMONCONTROLSEX);
        ctrlsex.dwICC = ICC_PAGESCROLLER_CLASS;
        ::InitCommonControlsEx(&ctrlsex);

        if(NULL == WINCHCTRLIMPL::Create(hWndParent, rcPos)) return false;

        if(!m_Winch.Create(m_hWnd, rcPos)) return false;

        Pager_SetChild(m_hWnd, m_Winch.m_hWnd);
        Pager_SetButtonSize(m_hWnd, ::GetSystemMetrics(SM_CYSMCAPTION));

#if defined(_DEBUG) // for Spy++
        SetWindowText(TEXT("Debug_WinchCtrl(Pager)"));
#endif // _DEBUG

        return true;
    }

    bool AppendBar(HWND hWndUser, HICON hIcon = NULL,
                   LPCTSTR szCaption = NULL, bool bActivate = false)
    { return m_Winch.AppendBar(hWndUser, hIcon, szCaption, bActivate); }

    void RemoveBar(unsigned nPos) { m_Winch.RemoveBar(nPos); }
    void RefreshBars() { m_Winch.RefreshBars(); }

    bool ActivateBar(unsigned nBarIndex)
    { return m_Winch.ActivateBar(nBarIndex); }

    unsigned GetActive() { return m_Winch.GetActiveBar(); }
    unsigned GetCount() { return m_Winch.GetBarsCount(); }

    LPCTSTR GetBarTitle(unsigned nPos)
    { return m_Winch.GetBarTitle(nPos); }

    void SetBarTitle(LPCTSTR szTitle, unsigned nPos)
    { m_Winch.SetBarTitle(szTitle, nPos); }

    HWND GetWinchHwnd() { return m_Winch; }

private:

BEGIN_MSG_MAP(CWinchCtrl)
    MESSAGE_HANDLER(OCM_NOTIFY, OnNotify)
    DEFAULT_REFLECTION_HANDLER()
END_MSG_MAP()    
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
    
    LRESULT OnPagerCalcSize(LPNMPGCALCSIZE lpnmcs, BOOL&)
    {
        switch ( lpnmcs->dwFlag )
        {
        case PGF_CALCWIDTH:
            lpnmcs->iWidth = 0;
            break;
        case PGF_CALCHEIGHT:
            lpnmcs->iHeight = m_Winch.GetBarsCount() *
                CY_BARBUTTON_HEIGHT * 2;
            break;
        }

        return 0;
    }

    LRESULT OnNotify(UINT, WPARAM, LPARAM lParam,
                     BOOL& bHandled)
    {
        switch(((LPNMHDR)lParam)->code)
        {
        case PGN_CALCSIZE:
            return OnPagerCalcSize((LPNMPGCALCSIZE)lParam, bHandled);
        case PGN_SCROLL:
            ((LPNMPGSCROLL)lParam)->iScroll = Pager_GetButtonSize(m_hWnd);
            break;
        default:
            bHandled = FALSE;
        }

        return 0;
    }

    CWinch m_Winch;
};


#endif // WINCHCTRL_H


//------------------------------- end of file ------------------------------
