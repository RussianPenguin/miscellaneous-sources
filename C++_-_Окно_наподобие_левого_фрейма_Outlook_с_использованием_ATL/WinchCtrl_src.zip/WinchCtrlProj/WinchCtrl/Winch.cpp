//--------------------------------------------------------------------------
// file: Winch.cpp
// author: Alex Blekhman
// maintainer:
//
// Implementation of CWinch class.
//--------------------------------------------------------------------------

#include "stdafx.h"
#include "Winch.h"


bool CWinch::Create(HWND hWndParent, RECT& rcPos)
{
    if(NULL == WINCHIMPL::Create(hWndParent, rcPos)) return false;

#if defined(_DEBUG) // for Spy++
    SetWindowText(TEXT("Debug_Winch"));
#endif _DEBUG

    return true;
}


bool CWinch::AppendBar(HWND hWndUser, HICON hIcon, LPCTSTR szCaption,
                       bool bActivate)
{
    ATLASSERT(::IsWindow(hWndUser));

    TITLEBARINFO* pTitleBar = new TITLEBARINFO;
    ATLASSERT(NULL != pTitleBar);
   
    if(bActivate) 
    {
        m_pActiveBar->SetActive(false);
        m_pActiveBar = pTitleBar;
    }

    pTitleBar->SetActive(bActivate);

    pTitleBar->m_hWndUser = hWndUser;
    ::ShowWindow(pTitleBar->m_hWndUser, SW_HIDE);

    pTitleBar->m_hWndParent = m_hWnd;

    RECT rcWinch;
    GetClientRect(&rcWinch);
    RECT rectBar = { 0, 0, rcWinch.right, CY_BARBUTTON_HEIGHT };
    
    // under W2K use OCR_HAND system resource
    HCURSOR hCursor = (HCURSOR)::LoadImage(
        _Module.GetModuleInstance(), MAKEINTRESOURCE(IDC_CURSOR1),
        IMAGE_CURSOR, 0, 0, LR_DEFAULTSIZE | LR_SHARED);
    ATLASSERT(NULL != hCursor);
        
    if(false == pTitleBar->m_btnBar.Create(
                    m_hWnd, rectBar, szCaption,
                    hIcon, hCursor))
    {
        delete pTitleBar;
        return false;
    }

    pTitleBar->m_nPos = m_BarList.size();
    m_BarList.push_back(pTitleBar);

    // make first active in any case
    if(1 == m_BarList.size())
    {
        pTitleBar->SetActive();
        m_pActiveBar = pTitleBar;
    }

    return true;
}


void CWinch::RemoveBar(unsigned nBarIndex)
{
    BARLIST::iterator it = GetBar(nBarIndex);
    TITLEBARINFO* pTitleBar = *it;
    m_BarList.erase(it);

    if(m_pActiveBar == pTitleBar) m_pActiveBar = NULL;
    
    pTitleBar->m_btnBar.DestroyWindow();
    ::DestroyWindow(pTitleBar->m_hWndUser);
    delete pTitleBar;

    // find first not active bar
    if(NULL == m_pActiveBar && !m_BarList.empty())
    {
        it = m_BarList.begin();
        BARLIST::iterator endOfList = m_BarList.end();
        while(((*it)->m_btnBar.m_bIsActive) && (it != endOfList)) it++;    
        ATLASSERT(it != endOfList);
        m_pActiveBar = *it;
        m_pActiveBar->SetActive();
    }

    RefreshBars();
}


bool CWinch::ActivateBar(TITLEBARINFO* pTitleBar)
{
    if(pTitleBar->m_btnBar.m_bIsActive) return false;

    ::PlaySound(MAKEINTRESOURCE(IDR_WAVE1), _Module.GetModuleInstance(),
                SND_ASYNC | SND_RESOURCE);

    bool bScrollUp = m_pActiveBar->m_iY < pTitleBar->m_iY;

    m_pActiveBar->SetActive(false);

        BARLIST::iterator it;
    BARLIST::iterator endOfList = m_BarList.end();
    RECT rcScroll; GetClientRect(&rcScroll);
    RECT rcToShow;
    ::GetWindowRect(m_pActiveBar->m_hWndUser, &rcToShow);
    int nHeightToShow = rcToShow.bottom - rcToShow.top;
    int nWidthToShow = rcToShow.right - rcToShow.left;    
    ScreenToClient(&rcToShow);
    
    int toY, fromY;

    if(bScrollUp)
    {
        rcScroll.top = m_pActiveBar->m_iY + CY_BARBUTTON_HEIGHT;
        rcScroll.bottom = pTitleBar->m_iY + CY_BARBUTTON_HEIGHT;
       
        it = m_BarList.begin();
        toY = 0;
        // advance till active bar
        while(m_pActiveBar != *it++) toY += CY_BARBUTTON_HEIGHT;
        
        toY += CY_BARBUTTON_HEIGHT; // skip active bar, too
        fromY = (*it)->m_iY;

        ::MoveWindow(pTitleBar->m_hWndUser,
            0, pTitleBar->m_iY + CY_BARBUTTON_HEIGHT,
            nWidthToShow, nHeightToShow, FALSE);
    }
    else // scroll down
    {
        rcScroll.top = pTitleBar->m_iY + CY_BARBUTTON_HEIGHT;
        rcScroll.bottom = rcToShow.bottom;

        it = endOfList;

        toY = rcToShow.bottom - CY_BARBUTTON_HEIGHT;
        // advance till active bar
        while(m_pActiveBar != *--it) toY -= CY_BARBUTTON_HEIGHT;
        
        fromY = pTitleBar->m_iY + CY_BARBUTTON_HEIGHT;
        while(pTitleBar != *it--) toY -= CY_BARBUTTON_HEIGHT;

        toY += CY_BARBUTTON_HEIGHT;

        ::MoveWindow(pTitleBar->m_hWndUser,
            0, pTitleBar->m_iY + CY_BARBUTTON_HEIGHT - nHeightToShow,
            nWidthToShow, nHeightToShow, FALSE);
    }
    
    UINT uFlags = SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOREDRAW;
    ::SetWindowPos(pTitleBar->m_hWndUser, NULL, 0, 0, 0, 0,
        uFlags | SWP_SHOWWINDOW);
        
    SmoothScroll(toY - fromY, rcScroll, pTitleBar->m_hWndUser);

    ::SetWindowPos(m_pActiveBar->m_hWndUser, NULL, 0, 0, 0, 0,
        uFlags | SWP_HIDEWINDOW);

    pTitleBar->SetActive();
    m_pActiveBar = pTitleBar;
    RefreshBars();

    return true;
}


void CWinch::SmoothScroll(int nScroll, RECT& rcToScroll, HWND hWndUser)
{
    bool bScrollUp = nScroll < 0;
    int nCurScroll = (bScrollUp ? -2 : 2);
    int nTotalScroll = nCurScroll;
    RECT rcUser, rcUpdate;
    ::GetWindowRect(hWndUser, &rcUser);
    ScreenToClient(&rcUser);
    int nHeightToShow = rcUser.bottom - rcUser.top;
    int nWidthToShow = rcUser.right - rcUser.left;

    while((bScrollUp ? nTotalScroll > nScroll : nTotalScroll < nScroll))
    {
        ScrollWindowEx(0, nCurScroll, &rcToScroll, &rcToScroll,
            NULL, NULL, SW_SCROLLCHILDREN);
        ::OffsetRect(&rcUser, 0, nCurScroll);        
        ::MoveWindow(hWndUser, rcUser.left, rcUser.top,
                     nWidthToShow, nHeightToShow, FALSE);
        ::IntersectRect(&rcUpdate, &rcUser, &rcToScroll);
        ::MapWindowPoints(m_hWnd, hWndUser, (LPPOINT)&rcUpdate, 2);
        ::InvalidateRect(hWndUser, &rcUpdate, TRUE);
        ::UpdateWindow(hWndUser);
        nCurScroll = ACCELERATE(nCurScroll);
        nTotalScroll += nCurScroll;
        
        ::Sleep(SCROLL_SPEED);
    }
}


void CWinch::RefreshBars(SIZE* pSize)
{
    if(m_BarList.empty()) return;

    ::ShowWindow(m_pActiveBar->m_hWndUser, SW_HIDE);

    RECT rcUserWnd;
    if(NULL == pSize)
        GetClientRect(&rcUserWnd);
    else
    {
        rcUserWnd.left = rcUserWnd.top = 0;
        rcUserWnd.right = pSize->cx;
        rcUserWnd.bottom = pSize->cy;
    }

    BARLIST::iterator it = m_BarList.begin();
    int destY = 0;

    while(m_pActiveBar != *it)
    {
        (*it++)->Move(destY, rcUserWnd.right);
        destY += CY_BARBUTTON_HEIGHT;
    }

    m_pActiveBar->Move(destY, rcUserWnd.right);  // bar to activate

    rcUserWnd.top = destY + CY_BARBUTTON_HEIGHT;

    destY = rcUserWnd.bottom - CY_BARBUTTON_HEIGHT;
    it = m_BarList.end();
    while(m_pActiveBar != *--it)
    {
        (*it)->Move(destY, rcUserWnd.right);
        destY -= CY_BARBUTTON_HEIGHT;
    }

    rcUserWnd.bottom = destY + CY_BARBUTTON_HEIGHT;
    ::MoveWindow(m_pActiveBar->m_hWndUser, 0, rcUserWnd.top,
                 rcUserWnd.right, rcUserWnd.bottom - rcUserWnd.top, FALSE);
    ::ShowWindow(m_pActiveBar->m_hWndUser, SW_SHOW);
    ::InvalidateRect(m_pActiveBar->m_hWndUser, NULL, FALSE); 
 
    SendMessageToDescendants(WM_INVALIDATE);
}


CWinch::TITLEBARINFO* CWinch::GetBarHit(HWND hWnd)
{
    BARLIST::iterator it = m_BarList.begin();
    BARLIST::iterator endOfList = m_BarList.end();
    TITLEBARINFO* pTitleBar;

    while(it != endOfList)
    {
        pTitleBar = *it++;
        if(pTitleBar->m_btnBar.m_hWnd == hWnd) return pTitleBar;
    }

    return NULL;
}


////////////////////////////////////////////////////////////////////////////
// Message handlers


LRESULT CWinch::OnBarClicked(WORD, WORD, HWND hWndCtl, BOOL&)
{
    TITLEBARINFO* pTitleBar = GetBarHit(hWndCtl);
    ATLASSERT(NULL != pTitleBar);

    ActivateBar(pTitleBar);

    return 0;
}


LRESULT CWinch::OnSize(UINT, WPARAM wParam, LPARAM lParam, BOOL&)
{
    if(SIZE_MINIMIZED == wParam) return 0;

    SIZE size = { LOWORD(lParam), HIWORD(lParam) };
    
    RefreshBars(&size);

    return 0;
}


LRESULT CWinch::OnNotify(UINT uMsg, WPARAM wParam, LPARAM lParam,
                         BOOL& bHandled)
{
    BARLIST::iterator it = m_BarList.begin();
    BARLIST::iterator endOfList = m_BarList.end();
    HWND hWndChild;

    while(it != endOfList)
    {
        hWndChild = ((LPNMHDR)lParam)->hwndFrom;
        if((*it++)->m_hWndUser == hWndChild)
        {
            ATLASSERT(::IsWindow(hWndChild));
            // reflect the message
            return ::SendMessage(hWndChild, uMsg, wParam, lParam);   
        }
    }

    bHandled = FALSE;

    return 0;
}


LRESULT CWinch::OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
{
    BARLIST::iterator it = m_BarList.begin();
    BARLIST::iterator endOfList = m_BarList.end();
    TITLEBARINFO* pTitleBar;

    while(it != endOfList) 
    {
        pTitleBar = *it++;
        pTitleBar->m_btnBar.DestroyWindow();
        ::DestroyWindow(pTitleBar->m_hWndUser);
        delete pTitleBar;
    }

    m_BarList.clear();

    return 0;
}


//------------------------------- end of file ------------------------------
