//--------------------------------------------------------------------------
// file: ButtonEx.h
// author: Alex Blekhman
// maintainer:
//
//  CButtonEx - class that allows you to create buttons with icon and
// caption. When button is activated, by setting its member m_bIsActive to
// true, it draws caption using bold font. Otherwise, default GUI font
// is used.
//  CButtonEx uses small icons. If you create icon resource with 16x16
// image and 32x32 image which is empty, then use LoadImage functon with
// small icon size (i.e. GetSystemMetrics(SM_C*SMICON)) specified to obtain
// HICON. If you use LoadIcon to get HICON, uncomment USE_IMGLIST macro
// definition in this file. CButtonEx will use image list control to draw
// an icon. This is neseccary because LoadIcon loads by default 32x32 icon.
//--------------------------------------------------------------------------

#if !defined(BUTTONEX_H)
#define BUTTONEX_H

//#define USE_IMGLIST

class CButtonEx;
typedef CWindowImpl< CButtonEx, CWindow, CWinTraits< WS_CHILD | WS_VISIBLE | BS_OWNERDRAW> > BUTTONEXIMPL;

class CButtonEx : public BUTTONEXIMPL
{
public:
    DECLARE_WND_SUPERCLASS(NULL, _T("BUTTON"))

    CButtonEx() :
        m_hFont(NULL),
        m_hFontActive(NULL),
        m_szCaption(NULL),
        m_hCursor(NULL),
        m_bIsActive(false),
#if defined USE_IMGLIST
        m_hImgList(NULL)
#else
        m_hIcon(NULL)
#endif // USE_IMGLIST
    {}

    bool Create(HWND hWndParent, RECT& rcPos, LPCTSTR szCaption = NULL,
                HICON hIcon = NULL, HCURSOR hCursor = NULL)
    {
        ATLASSERT(NULL == m_hWnd); // create only once
        if(NULL == BUTTONEXIMPL::Create(hWndParent, rcPos)) return false;

        if(NULL != szCaption) SetCaption(szCaption);

        m_hFont = (HFONT)::GetStockObject(DEFAULT_GUI_FONT);
        LOGFONT lf;
        ::GetObject((HGDIOBJ)m_hFont, sizeof(LOGFONT), (void*)&lf);
        lf.lfWeight = FW_SEMIBOLD;
        m_hFontActive = ::CreateFontIndirect(&lf);
        if(NULL != hIcon)
        {
#if defined USE_IMGLIST
            ::InitCommonControls();
            m_hImgList = ::ImageList_Create(CX_ICON, CY_ICON,
                                            ILC_COLOR | ILC_MASK , 0, 1);
            ATLASSERT(NULL != m_hImgList);
            ATLVERIFY(-1 != ImageList_AddIcon(m_hImgList, hIcon));
#else
            m_hIcon = hIcon;
#endif // USE_IMGLIST
        }
        m_hCursor = hCursor;

        return true;
    }

    LPCTSTR GetCaption() const { return m_szCaption; }
    void SetCaption(LPCTSTR szCaption)
    {
        delete[] m_szCaption;
        m_szCaption = new TCHAR[(_tcslen(szCaption) + 1) * sizeof(TCHAR)];
        ATLASSERT(NULL != m_szCaption);
        _tcscpy(m_szCaption, szCaption);
        Invalidate(FALSE);
    }

    bool m_bIsActive;

private:

BEGIN_MSG_MAP(CButtonEx)
    // uses message reflection: WM_* comes back as OCM_*
//    MESSAGE_HANDLER(OCM_COMMAND, OnCommand)
    MESSAGE_HANDLER(OCM_DRAWITEM, OnDrawItem)
    MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnLButtonDblClk)
    MESSAGE_HANDLER(WM_SETCURSOR, OnSetCursor)
    MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
    MESSAGE_HANDLER(WM_DESTROY, OnDestroy) // not a reflected message
    MESSAGE_HANDLER(WM_INVALIDATE, OnInvalidate)
    MESSAGE_HANDLER(WM_REDRAW, OnRedraw)
END_MSG_MAP()

    LRESULT OnInvalidate(UINT, WPARAM, LPARAM, BOOL&)
    { return Invalidate(FALSE); }

    LRESULT OnRedraw(UINT, WPARAM, LPARAM, BOOL&)
    { return RedrawWindow(NULL, 0, RDW_INVALIDATE | RDW_UPDATENOW); }

    LRESULT OnEraseBkgnd(UINT, WPARAM, LPARAM, BOOL&)
    { return 0; }

    LRESULT OnSetCursor(UINT, WPARAM, LPARAM lParam, BOOL& bHandled)
    {
        if(NULL == m_hCursor || LOWORD(lParam) != HTCLIENT)
        {
            bHandled = FALSE;
            return 0;
        }

        ::SetCursor(m_hCursor);

        return 0;
    }   

    // ownerdraw button treats double clicks as single click;
    // we need to unambiguously convert the double click into a second
    // single click
    LRESULT OnLButtonDblClk(UINT, WPARAM wParam, LPARAM lParam, BOOL&)
    { return SendMessage(WM_LBUTTONDOWN, wParam, lParam); }

    LRESULT OnDestroy(UINT, WPARAM, LPARAM, BOOL&)
    {
        if(NULL != m_hFontActive) ::DeleteObject(m_hFontActive);
#if defined USE_IMGLIST
        if(NULL != m_hImgList) ::ImageList_Destroy(m_hImgList);
#else
        // will fail if icon is shared
        if(NULL != m_hIcon) ::DestroyIcon(m_hIcon);
#endif // USE_IMGLIST
        // will fail if cursor is shared
        if(NULL != m_hCursor) ::DestroyCursor(m_hCursor);
        delete[] m_szCaption;

        return 0;
    }

//    LRESULT OnCommand( UINT, WPARAM wParam, LPARAM, BOOL& ) {
//        int code = HIWORD( wParam );
//        if( code == BN_CLICKED/* || code == BN_DOUBLECLICKED */){
//            ::MessageBeep(-1);
//        }
//        return 0;
//    }


    LRESULT OnDrawItem(UINT, WPARAM, LPARAM lParam, BOOL&)
    {       
        LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam;
        
        // flicker-free stuff
        HDC hdcMem = ::CreateCompatibleDC(lpdis->hDC);
        HBITMAP hbmMem = ::CreateCompatibleBitmap(lpdis->hDC,
                            lpdis->rcItem.right - lpdis->rcItem.left,
                            lpdis->rcItem.bottom - lpdis->rcItem.top);
        HGDIOBJ hbmOld = ::SelectObject(hdcMem, (HGDIOBJ)hbmMem);

        // if button pushed down then offset
        // icon and text by width of button's border
        int cxPushed = 0;
        int cyPushed = 0;

        // draw button itself
        if(lpdis->itemState & ODS_SELECTED)
        {   // pushed down
            ::DrawFrameControl(hdcMem, &(lpdis->rcItem),
                               DFC_BUTTON, DFCS_BUTTONPUSH | DFCS_PUSHED);

            cxPushed = CX_3DBORDER;
            cyPushed = CY_3DBORDER;
        }
        else  // pushed up
            ::DrawFrameControl(hdcMem, &(lpdis->rcItem),
                               DFC_BUTTON, DFCS_BUTTONPUSH);
            
  
        // draw icon if necessary

        // position it nicely
        int offset = ((lpdis->rcItem.bottom - lpdis->rcItem.top) -
                      CY_ICON) / 2;

#if defined USE_IMGLIST
        if(NULL != m_hImgList)
            ::ImageList_Draw(m_hImgList, 0, hdcMem,
                offset + cxPushed, offset + cyPushed, ILD_NORMAL);
#else
        if(NULL != m_hIcon)
            ::DrawIconEx(hdcMem, offset + cxPushed, offset + cyPushed,
                         m_hIcon, CX_ICON, CY_ICON, 0, NULL, DI_NORMAL);
#endif // USE_IMGLIST

        // text
        if(NULL != m_szCaption)
        {
            RECT rcText = { 
                CX_ICON + offset * 2 + cxPushed,
                lpdis->rcItem.top + offset + cyPushed,
                lpdis->rcItem.right - CX_3DBORDER - 1, // to be sure
                lpdis->rcItem.bottom - CY_3DBORDER - offset
            };
            HGDIOBJ hOldFont = ::SelectObject(hdcMem,
                (m_bIsActive ? m_hFontActive : m_hFont)); 
                        
            // put text after icon
            ::SetBkMode(hdcMem, TRANSPARENT);
            ::DrawText(hdcMem, m_szCaption, -1, &rcText,
                DT_TOP | DT_LEFT | DT_SINGLELINE | DT_WORD_ELLIPSIS);

            // restore
            ::SelectObject(hdcMem, hOldFont);
        }

        // show it
        ::BitBlt(lpdis->hDC,
           lpdis->rcItem.left, lpdis->rcItem.top,
           lpdis->rcItem.right - lpdis->rcItem.left,
           lpdis->rcItem.bottom - lpdis->rcItem.top,
           hdcMem,
           0, 0,
           SRCCOPY);

        // clean up
        ::SelectObject(hdcMem, hbmOld);
        ::DeleteObject((HGDIOBJ)hbmMem);
        ::DeleteDC(hdcMem);

        return 0;
    }

private:
    HFONT m_hFont;
    HFONT m_hFontActive;
#if defined USE_IMGLIST
    HIMAGELIST m_hImgList;
#else
    HICON m_hIcon;
#endif // USE_IMGLIST
    LPTSTR m_szCaption;
    HCURSOR m_hCursor;

}; // CButtonEx


#endif // BUTTONEX_H


//------------------------------- end of file ------------------------------
