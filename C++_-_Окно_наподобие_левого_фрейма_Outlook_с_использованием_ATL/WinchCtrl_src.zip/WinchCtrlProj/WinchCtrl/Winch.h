//--------------------------------------------------------------------------
// file: Winch.h
// author: Alex Blekhman
// maintainer:
//
//  CWinch class allows to you to create window similar to MS Outlook's
// "Outlook Bar". The window contains button bars with custom window
// associated with each bar. When user clicks on bar - it scrolls up or
// down along with associated window. You can add and remove bars. Also,
// you can change bars' captions.
//  CWinch window will send back to custom window all notification messages.
// It allows to custom window (if you use common control as custom window)
// to process its notifications by itself.
//--------------------------------------------------------------------------

#if !defined(WINCH_H)
#define WINCH_H

#include "ButtonEx.h"
#pragma warning(push, 3)
#include <list>
#pragma warning(pop)


class CWinch;
typedef CWindowImpl< CWinch , CWindow, CWinTraits< WS_CHILD | WS_VISIBLE/* | WS_CLIPCHILDREN | WS_CLIPSIBLINGS*/, WS_EX_CLIENTEDGE> > WINCHIMPL;

class CWinch : public WINCHIMPL
{
public:
    CWinch() : m_pActiveBar(NULL) {}

    bool Create(HWND hWndParent, RECT& rcPos);
    bool AppendBar(HWND hWndUser, HICON hIcon = NULL,
                   LPCTSTR szCaption = NULL, bool bActivate = false);
    void RemoveBar(unsigned nBarIndex);
    bool ActivateBar(unsigned nBarIndex)
    { ActivateBar(*GetBar(nBarIndex)); }
    void RefreshBars(SIZE* pSize = NULL);
    unsigned GetBarsCount() const { return m_BarList.size(); }
    unsigned GetActiveBar() const { return m_pActiveBar->m_nPos; }
    LPCTSTR GetBarTitle(unsigned nBarIndex) const
    { return (*GetBar(nBarIndex))->m_btnBar.GetCaption(); }
    
    void SetBarTitle(LPCTSTR szTitle, unsigned nBarIndex)
    { (*GetBar(nBarIndex))->m_btnBar.SetCaption(szTitle); }
    
private:

    typedef struct tagTITLEBARINFO
    {
        CButtonEx m_btnBar;
        HWND m_hWndUser;
        HWND m_hWndParent;
        int m_iY;
        unsigned m_nPos;

        void SetActive(bool bActive = true)
        { m_btnBar.m_bIsActive = bActive; }

        void Move(int destY, int width = 0)
        {
            RECT rect = { 0 };
            if(width > 0) rect.right = width;
            else ::GetClientRect(m_hWndParent, &rect);

            rect.top    = destY;
            rect.bottom = destY + CY_BARBUTTON_HEIGHT;
            
            m_btnBar.MoveWindow(&rect, FALSE);

            m_iY = destY;
        }

    } TITLEBARINFO;

    typedef std::list<TITLEBARINFO*> BARLIST;

BEGIN_MSG_MAP(CWinch)
    COMMAND_CODE_HANDLER(BN_CLICKED, OnBarClicked)
    MESSAGE_HANDLER(WM_SIZE, OnSize)
    MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
    MESSAGE_HANDLER(WM_NOTIFY, OnNotify)
    MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
    REFLECT_NOTIFICATIONS()      // reflect messages back
END_MSG_MAP()    
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

    LRESULT OnBarClicked(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
    LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnEraseBkgnd(UINT, WPARAM, LPARAM, BOOL&) { return 0; }
    LRESULT OnNotify(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
    LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

    TITLEBARINFO* GetBarHit(HWND hWnd);
    bool ActivateBar(TITLEBARINFO* pTitleBar);


    BARLIST::iterator GetBar(unsigned nBarIndex)
    {
        ATLASSERT(m_BarList.size() > nBarIndex);
        BARLIST::iterator it = m_BarList.begin();
        while(nBarIndex--) it++;
        
        return it;
    }

    BARLIST::const_iterator GetBar(unsigned nBarIndex) const
    {
        ATLASSERT(m_BarList.size() > nBarIndex);
        BARLIST::const_iterator it = m_BarList.begin();
        while(nBarIndex--) it++;
        
        return it;
    }

    void SmoothScroll(int nScroll, RECT& rcToScroll, HWND hWndUser);

    TITLEBARINFO* m_pActiveBar;
    BARLIST m_BarList;

}; // CWinch

#endif // WINCH_H


//------------------------------- end of file ------------------------------
