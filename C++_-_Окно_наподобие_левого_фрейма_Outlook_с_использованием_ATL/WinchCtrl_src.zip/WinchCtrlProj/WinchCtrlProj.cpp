// WinchCtrlProj.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "WinchCtrl.h"

CComModule _Module;


class CMyWindow : public CWindowImpl<CMyWindow> {

BEGIN_MSG_MAP( CMyWindow )
//      MESSAGE_HANDLER( WM_PAINT, OnPaint )
    MESSAGE_HANDLER( WM_DESTROY, OnDestroy )
    MESSAGE_HANDLER( WM_CREATE, OnCreate )
    MESSAGE_HANDLER( WM_SIZE, OnSize )
    MESSAGE_HANDLER( WM_ERASEBKGND, OnEraseBkgnd )
    MESSAGE_HANDLER( WM_PARENTNOTIFY, OnParentNotify )
    REFLECT_NOTIFICATIONS()
END_MSG_MAP()

    LRESULT OnEraseBkgnd(UINT, WPARAM, LPARAM, BOOL&)
    { return 0; }

    LRESULT OnParentNotify(UINT, WPARAM wParam, LPARAM, BOOL&)
    { 
        if(WM_RBUTTONDOWN != LOWORD(wParam)) return 0;
        
        unsigned nBarIndex = m_pWinchCtrl->GetCount();
        if(0 != nBarIndex)
        {
            int iRes = MessageBox(
                TEXT("Are you sure you want to remove last bar?"),
                TEXT("Bar removal confirmation"),
                MB_YESNO | MB_ICONWARNING);
            if(IDYES != iRes) return 0;

            m_pWinchCtrl->RemoveBar(nBarIndex - 1);
        }
        
        return 0;
    }

    LRESULT OnCreate( UINT, WPARAM, LPARAM, BOOL& )
    {
        RECT rcPos;
        HINSTANCE hInstance = _Module.GetModuleInstance();

        m_pWinchCtrl = new CWinchCtrl;

        GetClientRect(&rcPos);

        ATLVERIFY(m_pWinchCtrl->Create(m_hWnd, rcPos));
        HICON hWinLogoIcon = (HICON)::LoadImage(NULL,
            MAKEINTRESOURCE(OIC_WINLOGO),
            IMAGE_ICON, CX_ICON, CY_ICON, LR_SHARED);
        ATLASSERT(NULL != hWinLogoIcon);
        HICON hSmileIcon = (HICON)::LoadImage(
                    hInstance,
                    MAKEINTRESOURCE(IDI_ICON1),
                    IMAGE_ICON, CX_ICON, CY_ICON, LR_SHARED);
        ATLASSERT(NULL != hSmileIcon);

        int nBars = 5;
        TCHAR szTitle[] = TEXT("Bar");
        
        while(nBars--)
        {
            HICON hBarIcon;
            LPTSTR szBarTitle;
            HWND hWndUser;

            hWndUser = ::CreateWindow(
                    TEXT("STATIC"), TEXT("User window"),
                    WS_CHILD | SS_CENTER,
                    0, 0, 0, 0,
                    m_pWinchCtrl->GetWinchHwnd(), NULL,
                    hInstance, NULL);
            ATLASSERT(NULL != hWndUser);

            szBarTitle = szTitle;

            if(nBars % 2) hBarIcon = hSmileIcon;
            else hBarIcon = hWinLogoIcon;
            

            if(0 == nBars) hBarIcon = NULL;
            if(3 == nBars) szBarTitle = NULL;
            if(2 == nBars) hBarIcon = NULL, szBarTitle = NULL;

            m_pWinchCtrl->AppendBar(hWndUser, hBarIcon, szBarTitle);
        }

        m_pWinchCtrl->RefreshBars();
        
        return 0;
    }
    
    LRESULT OnSize( UINT, WPARAM, LPARAM, BOOL& )
    {
        RECT rect;
        GetClientRect(&rect);
        m_pWinchCtrl->MoveWindow(&rect);

        return 0;
    }
    

    LRESULT OnDestroy( UINT, WPARAM, LPARAM, BOOL& )
    {
        m_pWinchCtrl->DestroyWindow();
        delete m_pWinchCtrl;
        PostQuitMessage( 0 );
        return 0;
    }


    CWinchCtrl* m_pWinchCtrl;
};

int APIENTRY _tWinMain( HINSTANCE hInstance, HINSTANCE, LPSTR, int )
{
   _Module.Init( NULL, hInstance );

   CMyWindow wnd;
   wnd.Create(NULL, CWindow::rcDefault, TEXT("Hello"),
      WS_OVERLAPPEDWINDOW|WS_VISIBLE );

   MSG msg;
   while( GetMessage( &msg, NULL, 0, 0 ) ){
      TranslateMessage( &msg );
      DispatchMessage( &msg );
   }

   _Module.Term();
   return msg.wParam;
}


//------------------------------- end of file ------------------------------
