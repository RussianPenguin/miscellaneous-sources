//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestApp.rc
//
#define IDD_TESTAPP_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_TESTMENU                    130
#define IDB_VERTBMP                     131
#define IDB_ITEMUNCHECKED               135
#define IDB_ITEMCHECKED                 136
#define IDC_POPUPMENU                   1000
#define IDC_SHOW4ALL                    1002
#define IDC_WIDTH                       1003
#define IDC_STRETCH                     1004
#define IDC_SHOWBMP                     1005
#define IDC_PATTERN                     1006
#define IDC_SHOWSLIDER                  1007
#define ID_NORMAL                       32771
#define ID_SUB2_SUB1_NORMAL             32773
#define ID_SUB2_SUB2_NORMAL             32774
#define ID_CHECKEDGRAYED                32775
#define ID_SUB3_SUB1_NORMAL             32776
#define ID_INACTIVE                     32777
#define ID_CHECKED                      32778
#define ID_SUB3_SUB3_NORMAL             32783
#define ID_SUB3_SUB2_NORMAL             32788
#define ID_SUB2_SUB3_INACTIVE           32789
#define ID_SUB1_CHECKED                 32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
