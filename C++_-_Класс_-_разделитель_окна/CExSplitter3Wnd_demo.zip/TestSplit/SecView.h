#if !defined(AFX_SECVIEW_H__006815AA_CD76_44E4_A56D_A34EFA12F0F5__INCLUDED_)
#define AFX_SECVIEW_H__006815AA_CD76_44E4_A56D_A34EFA12F0F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SecView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSecView view

class CSecView : public CView
{
protected:
	CSecView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSecView)


// Attributes
public:
	

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSecView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSecView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CSecView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECVIEW_H__006815AA_CD76_44E4_A56D_A34EFA12F0F5__INCLUDED_)
