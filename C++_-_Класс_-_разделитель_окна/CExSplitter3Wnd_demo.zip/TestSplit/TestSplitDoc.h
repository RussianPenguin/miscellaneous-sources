// TestSplitDoc.h : interface of the CTestSplitDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTSPLITDOC_H__3186BABD_68FB_4C66_AC07_3957833C9828__INCLUDED_)
#define AFX_TESTSPLITDOC_H__3186BABD_68FB_4C66_AC07_3957833C9828__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CTestSplitDoc : public CDocument
{
protected: // create from serialization only
	CTestSplitDoc();
	DECLARE_DYNCREATE(CTestSplitDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestSplitDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTestSplitDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestSplitDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTSPLITDOC_H__3186BABD_68FB_4C66_AC07_3957833C9828__INCLUDED_)
