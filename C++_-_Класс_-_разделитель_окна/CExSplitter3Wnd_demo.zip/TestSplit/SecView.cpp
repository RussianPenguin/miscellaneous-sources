// SecView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSplit.h"
#include "SecView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSecView

IMPLEMENT_DYNCREATE(CSecView, CView)

CSecView::CSecView()
{
}

CSecView::~CSecView()
{
}


BEGIN_MESSAGE_MAP(CSecView, CView)
	//{{AFX_MSG_MAP(CSecView)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSecView drawing

void CSecView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	pDC->TextOut(0,0,"Second Window");


}

/////////////////////////////////////////////////////////////////////////////
// CSecView diagnostics

#ifdef _DEBUG
void CSecView::AssertValid() const
{
	CView::AssertValid();
}

void CSecView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSecView message handlers

void CSecView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	
}


