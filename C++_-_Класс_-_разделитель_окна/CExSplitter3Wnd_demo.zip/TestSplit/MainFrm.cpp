// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "TestSplit.h"

#include "MainFrm.h"

#include "SecView.h"
#include "ThirdView.h"
#include "TestSplitView.h"
#include "TestSplitDoc.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_EDIT_CALC, OnEditCalc)
	ON_COMMAND(ID_EDIT_SET, OnEditSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
	
//	delete m_pTopWndSplitter  ;

}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	CSplitterWnd m_SecSplitter;
	int nCurrDim,nMinDim;
 	BOOL bRtn;

	m_pTopWndSplitter  = new CExSplitter3Wnd;
	m_pTopWndSplitter->SetStyle(WS_CHILD | WS_VISIBLE | WS_BORDER);
	m_pTopWndSplitter->SetFirstViewSize(CSize(200,100));
	m_pTopWndSplitter->SetSecondViewSize(CSize(200,100));
	m_pTopWndSplitter->SetThirdViewSize(CSize(100,100));
	m_pTopWndSplitter->SetPattern(this,PATTERN_4,RUNTIME_CLASS(CTestSplitView),RUNTIME_CLASS(CSecView),RUNTIME_CLASS(CThirdView),pContext);
	
	return TRUE;
	//return CFrameWnd::OnCreateClient(lpcs, pContext);
}


//fooling around with dimension
void CMainFrame::OnEditCalc() 
{
	// TODO: Add your command handler code here
	int nCurrDim,nMinDim;
//	m_pWndSplitter->GetColumnInfo(0,nCurrDim,nMinDim);
	m_pTopWndSplitter->GetFirsWndDim(&nCurrDim,&nMinDim );
	m_pTopWndSplitter->GetSecWndDim(&nCurrDim,&nMinDim );
	m_pTopWndSplitter->GetThirdWndDim(&nCurrDim,&nMinDim );
}

void CMainFrame::OnEditSet() 
{
	// TODO: Add your command handler code here
	m_pTopWndSplitter->SetColumnInfo(0,400,100);
	m_pTopWndSplitter->RecalcLayout();
}

