// ThirdView.cpp : implementation file
//

#include "stdafx.h"
#include "TestSplit.h"
#include "ThirdView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThirdView

IMPLEMENT_DYNCREATE(CThirdView, CView)

CThirdView::CThirdView()
{
}

CThirdView::~CThirdView()
{
}


BEGIN_MESSAGE_MAP(CThirdView, CView)
	//{{AFX_MSG_MAP(CThirdView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThirdView drawing

void CThirdView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	pDC->TextOut(0,0,"Third Window");
}

/////////////////////////////////////////////////////////////////////////////
// CThirdView diagnostics

#ifdef _DEBUG
void CThirdView::AssertValid() const
{
	CView::AssertValid();
}

void CThirdView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CThirdView message handlers
