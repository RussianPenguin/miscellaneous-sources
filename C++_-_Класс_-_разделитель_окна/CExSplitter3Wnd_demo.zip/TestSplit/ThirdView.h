#if !defined(AFX_THIRDVIEW_H__66AE3C3C_601E_48F8_92EB_6E1B19CCE38D__INCLUDED_)
#define AFX_THIRDVIEW_H__66AE3C3C_601E_48F8_92EB_6E1B19CCE38D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThirdView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CThirdView view

class CThirdView : public CView
{
protected:
	CThirdView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CThirdView)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThirdView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CThirdView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CThirdView)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THIRDVIEW_H__66AE3C3C_601E_48F8_92EB_6E1B19CCE38D__INCLUDED_)
