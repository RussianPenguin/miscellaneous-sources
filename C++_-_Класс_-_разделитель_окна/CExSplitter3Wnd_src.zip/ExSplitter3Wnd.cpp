// ExSplitter3Wnd.cpp: implementation of the CExSplitter3Wnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestSplit.h"
#include "ExSplitter3Wnd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExSplitter3Wnd::CExSplitter3Wnd()

{
	CSplitterWnd::CSplitterWnd();
	m_FirstViewSize = CSize(0,0);
	m_SecViewSize =  CSize(0,0);
	m_ThirdViewSize=  CSize(0,0);
}

CExSplitter3Wnd::~CExSplitter3Wnd()
{
	
	CSplitterWnd::~CSplitterWnd();
	if (m_pwndSplitter!=NULL)
		delete m_pwndSplitter;

}

void CExSplitter3Wnd ::SetPattern(CWnd* pParent,SPLIT_PATTERN SplitPattern,CRuntimeClass* pFirstView,CRuntimeClass* pSecView,CRuntimeClass* pThirdView,CCreateContext* pContext)
{
  	m_pFirstView = pFirstView;
	m_pSecView = pSecView;
	m_pThirdView = pThirdView;
	m_pContext = pContext;
	m_SplitPattern = SplitPattern ;

	switch (m_SplitPattern)
	{
	case PATTERN_1:
		SetPattern1(pParent);
		break;
	case PATTERN_2:
		SetPattern2(pParent);
		break;
	case PATTERN_3:
		SetPattern3(pParent);
		break;
	case PATTERN_4:
		SetPattern4(pParent);
		break;
	case PATTERN_5:
		SetPattern5(pParent);
		break;
	case PATTERN_6:
		SetPattern6(pParent);
		break;



	}
}	

void CExSplitter3Wnd ::SetPattern1(CWnd* pParent)
{
	
	CreateStatic(pParent,1,2); 
	CreateView(0,0,m_pFirstView, m_FirstViewSize,m_pContext);			
	
	m_pwndSplitter = new CSplitterWnd;

	VERIFY(m_pwndSplitter->CreateStatic(this, 2, 1,m_dwStyle,  // style, WS_BORDER is needed
		this->IdFromRowCol(0, 1))); // For portrait


	VERIFY(m_pwndSplitter->CreateView(0,0,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(m_pwndSplitter->CreateView(1,0,m_pThirdView ,m_ThirdViewSize,m_pContext));



	

}
void CExSplitter3Wnd ::SetPattern2(CWnd* pParent)
{
	
	CreateStatic(pParent,1,2); 
	
	m_pwndSplitter = new CSplitterWnd;
	m_pwndSplitter->CreateStatic(this, 2, 1,m_dwStyle,  // style, WS_BORDER is needed
		this->IdFromRowCol(0,0)); // For portrait
	
	VERIFY(CreateView(0,1,m_pFirstView, m_ThirdViewSize,m_pContext));			

	VERIFY(m_pwndSplitter->CreateView(0,0,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(m_pwndSplitter->CreateView(1,0,m_pThirdView ,m_ThirdViewSize,m_pContext));

	SetColumnInfo(0,m_SecViewSize.cx,10);
	RecalcLayout();

	
	
	
	


}
void CExSplitter3Wnd ::SetPattern3(CWnd* pParent)
{
	
	CreateStatic(pParent,2,1); 
	
	m_pwndSplitter = new CSplitterWnd;
	VERIFY(m_pwndSplitter->CreateStatic(this, 1, 2,m_dwStyle,  // style, WS_BORDER is needed
		this->IdFromRowCol(1,0))); // For portrait
	

	VERIFY(CreateView(0,0,m_pFirstView, m_FirstViewSize,m_pContext));			

	VERIFY(m_pwndSplitter->CreateView(0,0,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(m_pwndSplitter->CreateView(0,1,m_pThirdView ,m_ThirdViewSize,m_pContext));

	
	
	


}

void CExSplitter3Wnd ::SetPattern4(CWnd* pParent)
{
	
	CreateStatic(pParent,2,1); 
	
	m_pwndSplitter = new CSplitterWnd;
	m_pwndSplitter->CreateStatic(this, 1, 2,m_dwStyle,  // style, WS_BORDER is needed
	 	this->IdFromRowCol(0,0)); // For portrait


	VERIFY(CreateView(1,0,m_pFirstView, m_FirstViewSize,m_pContext));			

	VERIFY(m_pwndSplitter->CreateView(0,0,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(m_pwndSplitter->CreateView(0,1,m_pThirdView ,m_ThirdViewSize,m_pContext));

	SetRowInfo(0,m_SecViewSize.cy,10);
	RecalcLayout();



	
	
	


}

void CExSplitter3Wnd ::SetPattern5(CWnd* pParent)
{
	CreateStatic(pParent,3,1,m_dwStyle);
	VERIFY(CreateView(0,0,m_pFirstView, m_FirstViewSize,m_pContext));			

	VERIFY(CreateView(1,0,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(CreateView(2,0,m_pThirdView ,m_ThirdViewSize,m_pContext));


	
}

void CExSplitter3Wnd ::SetPattern6(CWnd* pParent)
{
	CreateStatic(pParent,1,3,m_dwStyle);
	VERIFY(CreateView(0,0,m_pFirstView, m_FirstViewSize,m_pContext));			

	VERIFY(CreateView(0,1,m_pSecView,m_SecViewSize,m_pContext));
	
	VERIFY(CreateView(0,2,m_pThirdView ,m_ThirdViewSize,m_pContext));

}



void CExSplitter3Wnd::GetFirsWndDim(int* nCurrDim,int* nMinDim)
{
	int nRow = GetRowCount();
	int nCol = GetColumnCount();
	switch (m_SplitPattern)
	{
	case (PATTERN_1):
		GetColumnInfo(0,*nCurrDim,*nMinDim);
		break;
	
	case PATTERN_2:
		GetColumnInfo(1,*nCurrDim,*nMinDim);
		break;
	case (PATTERN_3):
		GetRowInfo(0,*nCurrDim,*nMinDim);
		break;
		
	case PATTERN_4:
		GetRowInfo(1,*nCurrDim,*nMinDim);
		break;
	case PATTERN_5:
		GetRowInfo(0,*nCurrDim,*nMinDim);
		break;
	case PATTERN_6:
		GetColumnInfo(0,*nCurrDim,*nMinDim);
		break;


	}
	
}


void CExSplitter3Wnd::GetSecWndDim(int* nCurrDim,int* nMinDim)
{
	VERIFY(m_pwndSplitter !=NULL ) ;
	switch (m_SplitPattern)
	{
	case (PATTERN_1):
		m_pwndSplitter->GetRowInfo(0,*nCurrDim,*nMinDim);
		break;
	
	case PATTERN_2:
		m_pwndSplitter->GetRowInfo(0,*nCurrDim,*nMinDim);
		break;
	case (PATTERN_3):
		m_pwndSplitter->GetColumnInfo(0,*nCurrDim,*nMinDim);
		break;
		
	case PATTERN_4:
		m_pwndSplitter->GetColumnInfo(0,*nCurrDim,*nMinDim);
		break;
	case PATTERN_5:
		GetRowInfo(1,*nCurrDim,*nMinDim);
		break;
	case PATTERN_6:
		GetColumnInfo(1,*nCurrDim,*nMinDim);
		break;


	}
	
}

void CExSplitter3Wnd::GetThirdWndDim(int* nCurrDim,int* nMinDim)
{
	VERIFY(m_pwndSplitter !=NULL ) ;
	switch (m_SplitPattern)
	{
	case (PATTERN_1):
		m_pwndSplitter->GetRowInfo(1,*nCurrDim,*nMinDim);
		break;
	
	case PATTERN_2:
		m_pwndSplitter->GetRowInfo(1,*nCurrDim,*nMinDim);
		break;
	case (PATTERN_3):
		m_pwndSplitter->GetColumnInfo(1,*nCurrDim,*nMinDim);
		break;
		
	case PATTERN_4:
		m_pwndSplitter->GetColumnInfo(1,*nCurrDim,*nMinDim);
		break;
	case PATTERN_5:
		GetRowInfo(2,*nCurrDim,*nMinDim);
		break;
	case PATTERN_6:
		GetColumnInfo(2,*nCurrDim,*nMinDim);
		break;


	}
	
}


