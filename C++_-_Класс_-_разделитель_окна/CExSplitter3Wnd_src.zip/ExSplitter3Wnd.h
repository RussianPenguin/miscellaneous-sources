// ExSplitter3Wnd.h: interface for the CExSplitter3Wnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EXSPLITTER3WND_H__1D7C0013_4AE0_48B3_9688_D660B00D6CB9__INCLUDED_)
#define AFX_EXSPLITTER3WND_H__1D7C0013_4AE0_48B3_9688_D660B00D6CB9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


typedef enum 
{
	PATTERN_1 ,
	PATTERN_2 ,
	PATTERN_3 ,
	PATTERN_4 ,
	PATTERN_5 ,
	PATTERN_6 ,

}SPLIT_PATTERN;


////pattern properties///////////////
/*
PATTERN_1			PATTERN_2
***************	    ****************
first	* sec *		*sec    *first *
		*******		*********      *
		*third*		*third  *	   *
***************		****************

PATTERN_3			PATTERN_4
***************		****************
   first	  *		*sec    * third*
***************		****************
sec   * third *		*     first	   *
***************		****************

PATTERN_5			PATTERN 6
***************     **************** 
   first	  *		first*sec*third*
***************		*    *   *     * 
   second     *		*	 *	 *	   *
***************		*	 *	 *	   *
   third	  *		*	 *	 *	   *
***************		****************
*/
class CExSplitter3Wnd : public CSplitterWnd  
{
public:
	CExSplitter3Wnd();
	virtual ~CExSplitter3Wnd();
	void SetStyle(DWORD dwStyle) {m_dwStyle = dwStyle ; }
	void SetPattern(CWnd* pParent,SPLIT_PATTERN SplitPattern,CRuntimeClass* pFirstView,CRuntimeClass* pSecView,CRuntimeClass* pThirdView,CCreateContext* pContext);
	void SetFirstViewSize(CSize FirstViewSize)   {m_FirstViewSize = FirstViewSize  ;}
	void SetSecondViewSize(CSize SecondViewSize) {m_SecViewSize = SecondViewSize ;}
	void SetThirdViewSize(CSize ThirdViewSize)   {m_ThirdViewSize = ThirdViewSize  ;}
	
	void GetFirsWndDim(int* nCurrDim,int* nMinDim);
	void GetSecWndDim(int* nCurrDim,int* nMinDim);
	void GetThirdWndDim(int* nCurrDim,int* nMinDim);
	
	CSplitterWnd* GetSeconderySplitter() {return m_pwndSplitter;}



protected:
	CSize m_FirstViewSize;
	CSize m_SecViewSize;
	CSize m_ThirdViewSize;
	CRuntimeClass* m_pFirstView;
	CRuntimeClass* m_pSecView;
	CRuntimeClass* m_pThirdView;
	CCreateContext* m_pContext;
	DWORD m_dwStyle;
	SPLIT_PATTERN m_SplitPattern;
	void SetPattern1(CWnd* pParent);
	void SetPattern2(CWnd* pParent);
	void SetPattern3(CWnd* pParent);
	void SetPattern4(CWnd* pParent);
	void SetPattern5(CWnd* pParent);
	void SetPattern6(CWnd* pParent);
	CSplitterWnd*  m_pwndSplitter ;



};
#endif // !defined(AFX_EXSPLITTER3WND_H__1D7C0013_4AE0_48B3_9688_D660B00D6CB9__INCLUDED_)
