// TestView.cpp : implementation of the CTestView class
//

#include "stdafx.h"
#include "Test.h"

#include "TestDoc.h"
#include "TestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestView

IMPLEMENT_DYNCREATE(CTestView, CView)

BEGIN_MESSAGE_MAP(CTestView, CView)
	//{{AFX_MSG_MAP(CTestView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_MESSAGE(ID_PROPERTY_CHANGED, OnPropertyChanged)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestView construction/destruction
CTestView::CTestView()
{

}

CTestView::~CTestView()
{
	delete m_pPropertyListCtrl;
	delete m_pListBoxFont;
	delete m_pPropertyFont;
}

BOOL CTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestView drawing

void CTestView::OnDraw(CDC* pDC)
{
	CTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTestView diagnostics

#ifdef _DEBUG
void CTestView::AssertValid() const
{
	CView::AssertValid();
}

void CTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestDoc* CTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestDoc)));
	return (CTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestView message handlers
void CTestView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	///////////////////////////////////////
	// Create the list box font
	m_pListBoxFont = new CFont();
	m_pListBoxFont->CreateFont( 14, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_TT_PRECIS, 
							 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS,
							 "arial");	
	
	///////////////////////////////////////
	// Create a Property Font
	m_pPropertyFont = new CFont();
	m_pPropertyFont->CreateFont( 16, 0, 0, 0, FW_NORMAL, 0, 0, 0, ANSI_CHARSET, OUT_TT_PRECIS, 
							 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, VARIABLE_PITCH | FF_SWISS, "system");	
	
	///////////////////////////////////////
	// Create the Control
	m_pPropertyListCtrl = new CPropertyListCtrl();
	m_pPropertyListCtrl->Create(WS_CHILD|WS_BORDER|WS_VISIBLE|LBS_NOTIFY|WS_VSCROLL|WS_HSCROLL|LBS_HASSTRINGS|LBS_OWNERDRAWFIXED, CRect(200,100,550,300), this, ID_PROPERTYLIST);
	
	///////////////////////////////////////
	// Set some attributes (Completly Optional)
	m_pPropertyListCtrl->SetFont(m_pListBoxFont);
	m_pPropertyListCtrl->SetBkColor(RGB(214,227,239));
	m_pPropertyListCtrl->SetTextColor(RGB(74,109,132));
	m_pPropertyListCtrl->SetTextHighlightColor(RGB(80,80,80));
	m_pPropertyListCtrl->SetHighlightColor(RGB(246,246,220));
	m_pPropertyListCtrl->SetPropertyBkColor(RGB(255,255,255));
	m_pPropertyListCtrl->SetPropertyTextColor(RGB(0,0,192));
	m_pPropertyListCtrl->SetBoldSelection(TRUE);
	m_pPropertyListCtrl->SetLineStyle(RGB(74,109,132), PS_SOLID);

	///////////////////////////////////////
	// Add the Properties
	m_pPropertyListCtrl->AddString("Static Text", ID_PROPERTY_STATIC, "C:\\Windows", 0, DT_RIGHT);
	m_pPropertyListCtrl->AddString("Text Property", ID_PROPERTY_TEXT, "This is some text", 0, DT_RIGHT);
	m_pPropertyListCtrl->AddString("Toggle Property", ID_PROPERTY_BOOL, "True!False", 0, DT_RIGHT);
	m_pPropertyListCtrl->AddString("Color Property", RGB(57,109,165), DT_RIGHT);
	m_pPropertyListCtrl->AddString("Font Property", m_pPropertyFont, DT_RIGHT);
	m_pPropertyListCtrl->AddString("File Property", ID_PROPERTY_PATH, "D:\\Code\\C++\\32bit\\Programs\\Blackjack\\Images\\Dealer.bmp!Bitmap Files (*.BMP)|*.bmp|All Files (*.*)|*.*|", 0, DT_RIGHT);
	m_pPropertyListCtrl->AddString("Combobox Property", ID_PROPERTY_COMBO_LIST, "Porsche!BMW!Mercedes!Lotus!Ford!Chevy!Kia!Dodge!Nissan!Toyota", 2, DT_RIGHT, TRUE, TRUE);

	///////////////////////////////////////
	// Get the Properties
	// Text and Path
	CString csText;
	m_pPropertyListCtrl->GetProperty(0, &csText);	

	// Toggle
	bool bValue;
	m_pPropertyListCtrl->GetProperty(1, &bValue);
	
	// Color
	COLORREF crColor;
	m_pPropertyListCtrl->GetProperty(2, &crColor);

	// Font
	LOGFONT lf;
	m_pPropertyListCtrl->GetProperty(3, &lf);

	// Combo Box
	CStringArray Items;
	m_pPropertyListCtrl->GetProperty(5, &Items);

	// Combo Box (get selected item index and text)
	int nSelectedItem;
	m_pPropertyListCtrl->GetProperty(5, &nSelectedItem, &csText);

}

LONG CTestView::OnPropertyChanged(UINT wItemChanged, LONG lPropertyType)
{
	AfxMessageBox("Property Changed");

	return 1;
}
