

// Property Type
#define ID_PROPERTY_TEXT		1
#define ID_PROPERTY_BOOL		2
#define ID_PROPERTY_COLOR		3
#define ID_PROPERTY_FONT		4
#define ID_PROPERTY_PATH		5
#define ID_PROPERTY_STATIC		6
#define ID_PROPERTY_COMBO_BTN	7
#define ID_PROPERTY_COMBO_LIST	8

// Message ID to parent
#define ID_PROPERTY_CHANGED		11111

/////////////////////////////////////////////////////////////////////////////
// CSortStringArray CStringArray
class CSortStringArray : public CStringArray  
{
public:
	void	Sort();
	int		FindString(CString csText);
private: 
	BOOL CompareAndSwap( int pos );

};

// Holds an item
typedef struct PropertyItem_t
{
	int					nType;
	int					nWidth;
	int					nAlignment;
	int					nPropertySelected;
	BOOL				bComboEditable;
	BOOL				bComboSorted;
	LOGFONT				LogFont;
	CBrush*				pBrush;
	CSortStringArray	csProperties;

} PROPERTYITEM;

/////////////////////////////////////////////////////////////////////////////
// CComboButton window
class CComboButton : public CButton
{
	void DrawTriangle(CDC* pDC, CRect Rect);

// Construction
public:
	BOOL	Create( CRect Rect, CWnd* pParent, UINT uID);
	CComboButton();

// Attributes
public:
	CPen*		m_pBkPen;
	CPen*		m_pGrayPen;
	CBrush*		m_pBkBrush;  
	CBrush*		m_pBlackBrush;

// Operations
public:

	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct );
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComboButton)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CComboButton();

	// Generated message map functions
protected:
	//{{AFX_MSG(CComboButton)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CPropertyListCtrl window
class CPropertyListCtrl : public CListBox
{
	int				m_nWidestItem;
	BOOL			m_bDeleteFont;
	BOOL			m_bBoldSelection;
	BOOL			m_bChanged;
	CPen*			m_pBorderPen;
	CRect			m_CurRect;
	CFont*			m_pTextFont;
	CFont*			m_pSelectedFont;
	CFont*			m_pCurFont;
	CString			m_csText;
	CBrush*			m_pCurBrush;
	CBrush*			m_pBkBrush;
	CBrush*			m_pBkHighlightBrush;
	CBrush*			m_pBkPropertyBrush;
	CButton*		m_pFontButton;
	CButton*		m_pPathButton;
	CComboButton*	m_pComboButton;
	CListBox*		m_pListBox;

	COLORREF		m_crBorderColor;
	COLORREF		m_crBkColor;
	COLORREF		m_crTextColor;
	COLORREF		m_crTextHighlightColor;
	COLORREF		m_crHighlightColor;
	COLORREF		m_crPropertyBkColor;
	COLORREF		m_crPropertyTextColor;

	// Controls
	CEdit*			m_pEditWnd;

	// The item list
	CPtrList		m_Items;
	PROPERTYITEM*	m_pCurItem;
	PROPERTYITEM*	m_pCurDrawItem;

// Construction
public:
	CPropertyListCtrl();

// Attributes
private:
	// Helper Functions
	void	DrawItem(CDC* pDC, CRect ItemRect, BOOL bSelected);
	void	DrawPropertyText(CDC* pDC, CRect ItemRect);
	void	CreateControl(int nType);
	BOOL	SetProperty(PROPERTYITEM* pPropertyItem, int nType, CString csData);
	void	ParseProperties(PROPERTYITEM* pPropertyItem, CString csData);
	void	HideControls();

// Operations
public:
	// GUI Functions
	void			SetFont(CFont* pFont);
	void			SetBkColor(COLORREF crColor);
	void			SetPropertyBkColor(COLORREF crColor);
	void			SetHighlightColor(COLORREF crColor);
	void			SetLineStyle(COLORREF crColor, int nStyle = PS_SOLID);
	inline	void	SetBoldSelection(BOOL bBoldSelection)			{ m_bBoldSelection = bBoldSelection; };
	inline	void	SetTextColor(COLORREF crColor)					{ m_crTextColor = crColor; };
	inline	void	SetTextHighlightColor(COLORREF crColor)			{ m_crTextHighlightColor = crColor; };
	inline	void	SetPropertyTextColor(COLORREF crColor)			{ m_crPropertyTextColor = crColor; };

	// Add the data
	BOOL	AddString(CString csText);
	BOOL	AddString(CString csText, int nType, CString csData, int nPropertySelected = 0, int nAlignment = DT_LEFT, BOOL bComboEditable = FALSE, BOOL bComboSorted = FALSE);
	BOOL	AddString(CString csText, COLORREF crColor, int nAlignment = DT_LEFT);
	BOOL	AddString(CString csText, CFont* pFont, int nAlignment = DT_LEFT);
	
	// Get the Data
	bool	GetProperty(int nItem, CString* pText);	
	bool	GetProperty(int nItem, bool* bValue);	
	bool	GetProperty(int nItem, COLORREF* crColor);	
	bool	GetProperty(int nItem, LOGFONT* LogFont);	
	bool	GetProperty(int nItem, CStringArray* pArray, int* SelectedItem = NULL);	
	bool	GetProperty(int nItem, int* SelectedItem, CString* csText = NULL);	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPropertyListCtrl)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPropertyListCtrl();
	void	Reset();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPropertyListCtrl)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void OnSelchange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnDblclk();
	afx_msg void OnEditLostFocus();
	afx_msg void OnEditChange();
	afx_msg void OnFontPropertyClick();
	afx_msg void OnPathPropertyClick();
	afx_msg void OnComboBoxClick();
	afx_msg void OnSelChange();
	afx_msg void OnListboxLostFocus();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};
