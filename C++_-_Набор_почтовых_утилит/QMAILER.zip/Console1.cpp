//  Email sender. (Console)
//
//  Send e-mail from command line
//  Support attach 
//
//  Author: Shilonosov Alex.  2000 year.
//
//  VisualC++6.0 (no pack, no MFC)


#include "winsock.h"
#include <stdio.h>

int s,x;
char b64b_table[]=
"A78BCDabcdeEFGwxyHIopYZfghijkPQXlmnqJKLMNOrsz01234RStuvTUVW569+/ \0";
char base64table[]=
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/ \0";
union _B64
{
   struct
     {
     unsigned int a4:6;
     unsigned int a3:6;
     unsigned int a2:6;
     unsigned int a1:6;
     } a;
   unsigned char b[3];
   unsigned long num;
} b64;

FILE *f_out;
//#define exit_0 (exit_code=0; goto exit;)

bool is_error(char* text)
{
        return  ( !strncmp("220",text,3) ||
                      !strncmp("250",text,3) ||
                          !strncmp("354",text,3) ||
                          !strncmp("221",text,3) );

}

//******************************************************************
// send data to SMTP 
//
//******************************************************************
int send_to(char* chr )
{
    if ( send(s,chr,strlen(chr),0)==SOCKET_ERROR )
                {
                 printf("error send: %d\n",WSAGetLastError());
                 return 0;
                }

        // fwrite(chr,strlen(chr),1,f_out);

  return 1;
}

//******************************************************************
// Recieve Responce from SMTP and examine it for error 
// true - no error (error mean that operation failed)
//******************************************************************
bool reciv_and_noerr(char* chr )
{
  //  return true;
        int len;

         if ( (len=(recv(s,(char*)chr,490,0)))==SOCKET_ERROR )
                 { printf("error recv %d \n",WSAGetLastError()); return false;}
         *(chr+len-1)=0;
         printf(chr);
         printf("\n");

         return is_error((char*)chr);

}

//******************************************************************
// Defence function :)
// decode my %mailer% tag 
//   Thi is defence from boys who like to change resources in exe's files
// 
// You may remove this function without any loss of functionality
//******************************************************************
char* de_b64b(char *str)
{
     int num,n=1,a=0,b=0;
        char ch;
        char *s2=str;

        while ( *(str+b) )
        {
                ch=*(str+b++);
                if (ch=='\r' || ch=='\n') continue;
                num=0;
                for (a=strlen(b64b_table); a>0; a--)
                {
                        if (b64b_table[a]==ch)  { num=a; break; }
                }
                switch (n)
                {
                case 1: b64.a.a1=num; break;
                case 2: b64.a.a2=num; break;
                case 3: b64.a.a3=num; break;
                case 4: b64.a.a4=num; break;
                };
                n++;
                if (n>=5 )
                {
                        n=1;
                        *(s2)=b64.b[2];
                        *(s2+1)=b64.b[1];
                        *(s2+2)=b64.b[0];
                        s2+=3;
                }
        }

        *s2=0;
    n=3;
        __int16 sum64=0,sm2=0;
        while ( *(str+n++) ) sum64+=(unsigned int)*(str+n)-30;
        memmove(&sm2,str,2);
        if ( sum64!=sm2) { _asm
        {
                mov eax,23;
                push eax;
                push eax;
                push eax;
        } delete &str;
         return (char*)1313 ;}
        //SetDlgItemText(IDC_STATIC3,"ok");

        return str+2;

}

// cl tiny.cpp /MD /Og /Os /link /ALIGN:0x10 /merge:.rdata=.data

//*********************************************************************
//*********************************************************************
int main(int argc, char* argv[])
{
        if (argc < 6)
        {

                //cout <<  de_b64b("6yOooYHycaumiZ4Kkn7nQI7oiaKzjvV2kv9vEJC1c8ANkvmOja91jTG2yaumiZ31kMpO") << endl ;
                //cout <<  "QMAIL.EXE [@I.P]smtpServer from to [-]\"subject\" [@filename]\"message\" [attach]" << endl ;
                printf("\n============================================================\n");
                printf(de_b64b("fyuooYHycaumiZ4Kkn7nQI7oiaKzjvV2kv9vEJC1c8ANkvmOja91jTG2PJ70gZKzEMduc8U1yaumiZ31jZyO")) ;
                printf("\nsee: www.shilonosov.f2s.com, www.shilonosov.da.ru");
                printf("\nQMAIL.EXE [@I.P]smtpServer from to [-]\"subject\" [@filename]\"message\" [attach]");
                printf("\noptions :\n");
                printf(" [@I.P]      = I.P. instead name of SMTP server \n");
                printf(" [-]         = no subject, file must contain \"Subject:*<enter><enter>\")\n");
                printf(" [@filename] = file with full path to send as message (text!)\n");
                printf(" [attach]    = files to atach (base64)\n");
                printf(" programm output:  answers of SMTP server\n (errorlevel=1 if succes)\n" );
                printf(" examples:\n");
                printf("qmail.exe smtp.mail.com from@mail.com to@mail.com \"Hello\" \"message!\" attach.rar\n");
                printf("qmail.exe @138.9.0.1 from@mail.com to@mail.com - @mess.txt attch1.rar attch2.exe\n");
                printf("============================================================");

                return 0;
        }

        WSADATA rec;
        struct sockaddr_in con;
        PHOSTENT pHost;
        char* text= new char[1500];
                bool is_attach = argc > 6;
                // command line have more than 6 argument == attach names


        char error[255];
        int err=0;
        int exit_code = 1;


//Open Sokets
        int wVer = MAKEWORD(1, 1);
        if ( WSAStartup(wVer,&rec) )
        {
        printf("error WSAstarup \n");
        return 0;
        }
        
         if ((s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == INVALID_SOCKET) // open socket
    { printf("Socket Error:     %d \n",WSAGetLastError()); goto exit_0;}
//resolve
         if ( *(argv[1])=='@' ) con.sin_addr.s_addr=inet_addr(argv[1]+1); // IP instead name
         else
         {
                 printf("Look up for SMTP....\n");                // make IP from name
                 if ( !(pHost=gethostbyname(argv[1])) )
                 { printf("Cant find (error %d)\n",WSAGetLastError());
                                 goto exit_0;
                                 }
                 //
                 PCHAR p;
                 memmove(&p,*pHost->h_addr_list,sizeof(PCHAR));
                 memmove(&con.sin_addr.s_addr,&p,sizeof(PCHAR));
         }
         printf((char*)inet_ntoa(con.sin_addr));
         printf("\n");

        con.sin_family=AF_INET;
        con.sin_port=htons(25);
//conect
        if ( connect(s,(struct sockaddr*)&con,sizeof(con))==INVALID_SOCKET )
        { printf("error connect %d\n",WSAGetLastError());  goto exit_0; }
        printf("Connected...\n");


        int len;
        if ( !reciv_and_noerr(text) ) goto exit_0; // recieve < 220... SMTP .... > from SMTP

// Talk to SMTP server begin....
// Talk - because every command need responce <ok>
         strcpy(text,"helo friend\xD\xA\x0");   // Say  "250 Hello" to SMTP
         if ( !send_to( text) ) goto exit_0;

         if ( !reciv_and_noerr(text) ) goto exit_0;  // recieve  "Hello" from SMTP 

         strcpy(text,"MAIL FROM:<");   
         strcat(text,argv[2]);
         strcat(text,">\xD\xA\x0");
         if ( !send_to( text) ) goto exit_0;        // send "From"
         if ( !reciv_and_noerr(text) ) goto exit_0;   // recieve "250 syntax correct..."


         strcpy(text,"RCPT TO:<");
         strcat(text,argv[3]);
         strcat(text,">\xD\xA\x0");
         if ( !send_to( text) ) goto exit_0;        // send "To"
         if ( !reciv_and_noerr(text) ) goto exit_0; // recieve "250 verifyed ..."

         strcpy(text,"DATA\xD\xA\x0");
         if ( !send_to( text) ) goto exit_0;        // Ask to send DATA (mess body,attaches)
         if ( !reciv_and_noerr(text) ) goto exit_0; // Answer <354  Enter message, ending with "."> from SMTP
         //SendData

// DATA transmition begin....
// no responce need (reciv_and_noerr no need) just send data

// at the begining we send tags "X-Mailer" ,...
// also you may send other RFC tags 

         strcpy(text,de_b64b("ZlugEpumiZ4KkqNlppumiZ4Kkn7nQI7oiaKzjvV2kv9vEJC1c8mqeoc3FBAlebGNiZ42jL9SjThAjZDOj8VRPIJ="));
         // if you delete de_b64b function you uncomment following 
         //strcpy(text,"X-Mailer:mailer by your_name. (c)2000");
         strcat(text,"\xD\xA\x0");
         if ( !send_to( text) ) goto exit_0;    // send  <X-Mailer:> tag

         strcpy(text,"To: ");                // send  <To:> tag
         strcat(text,argv[3]);
         strcat(text,"\xD\xA\x0");
         if ( !send_to( text) ) goto exit_0;

         if (*(argv[4])!='-' )  // no Subj
         {
                 strcpy(text,"Subject: ");
                 strcat(text,argv[4]);
                 strcat(text,"\xD\xA\x0");
                 //strcat(text,"\xD\xA\xD\xA\x0");
                 if ( !send_to( text) ) goto exit_0; // send  <Subject:> tag
         }

            // if attaches pointed in command line, prepare header
            // i.e. we should separate message into - text and atach1, atach2
         if ( is_attach )
                 {
                         
                        // This is not absolutely correct 
                        // I just examine how does it write in big email client              
                         send_to("Content-Type: multipart/mixed; boundary=\"----------Qmailer\"") ;
                         send_to("\n\n\0");
                         send_to("------------Qmailer"); send_to("\n\x0");           
                         send_to("Content-Type: text/plain;\n\n");
                 }
                 else
                         send_to("\n\0");


         if (*(argv[5])!='@')
         {
                 if ( !send_to( argv[5]) ) goto exit_0;  // send Message
         }
         else
         {                                     // or read message from file
                 FILE *f;                       //  and send it as message
                 if ((f = fopen(argv[5]+1, "r")) == NULL)
                 { printf("error opening file\n"); goto exit_0; };
                 while ( !feof(f) )
                 {
                         *text=0;
                         fgets(text,1000,f);
                         if ( (strstr(text,".\n") ) ) strcat(text," ");
                         if ( !send_to(text) ) goto exit_0;
                 }
         }


           // send attaches
         for (x=7; x<=argc; ++x)
         {
                 send_to("\n\x0");
                 send_to("\n\x0");
                 send_to("------------Qmailer"); send_to("\n\x0");
                 send_to("Content-Type: application/octet-stream; name=\"\x0");
                 send_to(argv[x-1]);
                 send_to("\"\n\x0");
                 send_to("Content-Transfer-Encoding: base64 \x0"); send_to("\n\x0");
                 send_to("Content-Disposition: attachment; filename=\"\x0");
                 send_to(argv[x-1]);
                 send_to("\"\n\x0");
                 send_to("\n\x0");

                 //fstream finp(argv[x-1], ios::binary|ios::in);
                 FILE* f2;
                 if ( (f2=fopen(argv[x-1],"rb"))==NULL ) { goto exit_0; }

                 //if (finp==NULL)
                 // { cout << "error open file " << endl; return 0; }
                 int  num=2,str=1;
                 char s[4+5];
                 char ch;

                 while ( true )
                 {
                         ch=fgetc(f2);
                         if ( !feof(f2) )*(b64.b+num)=ch;
                         if ( num==0 || feof(f2) )
                         {
                                 s[0]=base64table[b64.a.a1];
                                 s[1]=base64table[b64.a.a2];
                                 s[2]=base64table[b64.a.a3];
                                 s[3]=base64table[b64.a.a4];
                                 if (num==2)     { break;  }
                                 if (num==1)     { s[2]='='; s[3]='='; }
                                 if (num==0 && feof(f2) )   { s[3]='='; }

                                 s[4]=0;
                                 send_to(s);

                                 if (++str>=20 ) { send_to("\n\x0"); str=1; }
                                 num=3;
                                 memset(b64.b,0,3 );
                                 if ( feof(f2) ) { break;  }
                         }
                         num--;
                 }
                 fclose(f2);
                 send_to("\n------------Qmailer");
         }

         if ( argc>6 ) send_to("--");
         strcpy(text,"\xD\xA.\xD\xA\x0");     
         if ( !send_to( text) ) goto exit_0;         // send " <CR>.<CR>" - end of data block
         if ( !reciv_and_noerr(text) ) goto exit_0;   // get Answer - OK

         strcpy(text,"quit\xD\xA");
         if ( !send_to( text) ) goto exit_0;          // Say <BY-BY> to SMTP
         if ( !reciv_and_noerr(text) ) goto exit_0;    // ANSWER - <OK> 


exit:
         delete text;
        closesocket(s);
        WSACleanup();
        return 1;
        Sleep(1000);
exit_0:
        delete text;
        closesocket(s);
        WSACleanup();
        Sleep(1000);
        return 0;

}


