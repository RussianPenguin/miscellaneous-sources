#ifndef DLLVERSION_H_INCLUDED
#define DLLVERSION_H_INCLUDED

BOOL GetModuleVersion( LPTSTR lpszModulePath, CString& lpszFileVersion );

#endif