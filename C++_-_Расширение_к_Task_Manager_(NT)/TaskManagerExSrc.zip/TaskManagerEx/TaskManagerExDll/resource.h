//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TaskManagerExDll.rc
//
#define IDD_SYSTEMINFODLG               101
#define IDR_SYSTEMINFODLG               102
#define IDD_EXTENSION_ABOUT             105
#define IDI_MAINICON                    106
#define IDD_FINDUSEDDLG                 106
#define IDR_PROCESSES                   107
#define IDR_FINDUSEDDLG                 108
#define IDI_DEFAULTPROCESS              111
#define IDI_SERVICEPROCESS              112
#define IDC_SYSTEMINFO                  1000
#define IDC_FINDUSED                    1002
#define ID_EXTENSION_REFRESH            40001
#define ID_MODULES_UNLOAD               40007
#define ID_HANDLES_RELEASE              40009
#define ID_THREADS_KILL                 40010
#define ID_WINDOWS_ACTIVATE             40011
#define ID_WINDOWS_CLOSE                40012
#define ID_HANDLES_RELEASEALLINSTANCES  40014
#define ID_HANDLES_EVENT_SET            40015
#define ID_HANDLES_EVENT_RESET          40016
#define ID_HANDLES_EVENT_PULSE          40019
#define ID_HANDLES_MUTANT_RELEASE       40020
#define ID_BUTTON40027                  40027
#define ID_BUTTON40028                  40028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40030
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
