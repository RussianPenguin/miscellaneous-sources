// Demonstrates Fonts and Color changing for an Edit Control without MFC

// By Max Raskin, 08 October 2000


#include "stdafx.h"
#include "resource.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];								// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];								// The title bar text

// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void SetEditFont(HWND hwndEdit, LPCSTR lpFontName, int FontSize, DWORD dwCharSet, BOOL bBold, BOOL bItalic, BOOL bUnderLine, BOOL bStrikeOut);

HWND hEdit; // Handle for the Edit Control

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_COLOREDIT, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_COLOREDIT);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_COLOREDIT);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex.lpszMenuName	= (LPCSTR)IDC_COLOREDIT;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
   
   // Create the edit control:
   hEdit = CreateWindowEx(WS_EX_LEFT + WS_EX_LTRREADING + WS_EX_RIGHTSCROLLBAR + WS_EX_CLIENTEDGE,
	   "Edit", "Select Fonts From The Fonts Menu", ES_MULTILINE + WS_VISIBLE + WS_CHILDWINDOW + WS_VSCROLL + WS_HSCROLL, 
	   0, 0, 0, 0, hWnd, 0, hInstance, 0); 

   SetFocus(hEdit);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				case IDM_FONT_1:
					// To Times New Roman Font
					SetEditFont(hEdit, "Times New Roman", 0, ANSI_CHARSET, FALSE, FALSE, FALSE, FALSE);
					SetFocus(hEdit);
					break;
				case IDM_FONT_2:
					// To Terminal Font
					SetEditFont(hEdit, "Terminal", 0, OEM_CHARSET, FALSE, FALSE, FALSE, FALSE);
					SetFocus(hEdit);
					break;
				case IDM_FONT_3:
					// To Arial Bold Font
					SetEditFont(hEdit, "Arial", 0, ANSI_CHARSET, TRUE, FALSE, FALSE, FALSE);
					SetFocus(hEdit);
					break;
				case IDM_FONT_4:
					// To System Bold Italic Font
					SetEditFont(hEdit, "System", 0, OEM_CHARSET, TRUE, TRUE, FALSE, FALSE);
					SetFocus(hEdit);
					break;
				case IDM_FONT_5:
					// To Symbol Strike Out Font
					SetEditFont(hEdit, "Symbol", 0, OEM_CHARSET, FALSE, FALSE, FALSE, TRUE);
					SetFocus(hEdit);
					break;
				case IDM_FONT_6:
					// To MS SANS SERIF Under Line Out Font
					SetEditFont(hEdit, "Ms Sans Serif", 0, OEM_CHARSET, FALSE, FALSE, TRUE, FALSE);
					SetFocus(hEdit);
					break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_SIZE:
			// Simply sizes the edit control to the size of the parent window
			MoveWindow(hEdit, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
			return 0;
		case WM_CTLCOLOREDIT:
			HBRUSH hBrush; // Handle to background brush
			// NOTE: WM_CTLCOLOREDIT sent to the parent window
			// of the Edit Control(s) if they are not ReadOnly (EM_READONLY style)
			// if its read only the WM_CTLCOLORSTATIC is sent.

			// Create the background brush (black)
			// Note - if you modify this, and want same color
			// for the background
			// you also need  to change
			// SetBkColor RGB values to same values
			// as CreateSolid brush, if they aren't the same
			// it creates a nice effect - where there is text
			// its background will be coloured the the specified
			// color in SetBkColor RGB values
			hBrush = CreateSolidBrush(RGB(0, 0, 0));
			SetBkColor((HDC)wParam, RGB(0, 0, 0));
			// Set text color (white)
            SetTextColor((HDC)wParam, RGB(255, 255, 255));
			return (DWORD)hBrush; // The brush must be returned or other wise no changes will be made
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}

// A simple function, sets a specified font to an edit control
void SetEditFont(HWND hwndEdit, LPCSTR lpFontName, int FontSize, DWORD dwCharSet, BOOL bBold, BOOL bItalic, BOOL bUnderLine, BOOL bStrikeOut)
{
   HFONT hFont;
   DWORD Bold = 200;
   if (bBold == TRUE) { Bold = FW_BOLD; }
   hFont = CreateFont(FontSize, 0, 0, 0, Bold, bItalic, bUnderLine, bStrikeOut, 
	   dwCharSet, 0, 0, PROOF_QUALITY, 0, lpFontName);
   SendMessage(hwndEdit, WM_SETFONT, (WPARAM)hFont, TRUE);
   //DeleteObject(hFont);
}
