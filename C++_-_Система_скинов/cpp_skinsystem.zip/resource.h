//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MPEGPlayer.rc
//
#define BUTTON_PLAY                     1
#define BUTTON_EJECT                    2
#define BUTTON_STOP                     3
#define BUTTON_NEXT                     4
#define BUTTON_PREV                     5
#define BUTTON_PAUSE                    6
#define BUTTON_EXIT                     7
#define BUTTON_MINIMIZE                 8
#define BUTTON_PLAYLIST                 9
#define TEXT_SONG                       10
#define TEXT_LEN                        11
#define TEXT_POS                        12
#define TEXT_HINT                       13
#define TRACKBAR_VOLUME                 14
#define TRACKBAR_POS                    15
#define BUTTON_NEXTTRACK                16
#define BUTTON_PREVTRACK                17
#define IDD_MPEGPLAYER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDR_MAINMENU                    129
#define ID_LOADSKIN                     32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
