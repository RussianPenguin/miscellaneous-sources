// TestTabCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "MutliRowTab.h"
#include "TestTabCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define ID_TAB 100
/////////////////////////////////////////////////////////////////////////////
// CTestTabCtrl

CTestTabCtrl::CTestTabCtrl()
{
      m_nNoOfTabs = 0;
	  m_pParentTabCtrl = NULL;
}

CTestTabCtrl::~CTestTabCtrl()
{
    Tab_Info* pInfo = NULL;
    CTestTabCtrl* pChldCtrl = NULL;
    POSITION pos = m_ChildList.GetHeadPosition();
    while(pos)
    {
        Tab_Info* pInfo = (Tab_Info* )m_ChildList.GetNext(pos);
        if(pInfo->m_bIsTab)
        {

            pChldCtrl = (CTestTabCtrl* )pInfo->lpWnd;
			pChldCtrl->SetParentTabCtrl(NULL);
            delete pChldCtrl;
        }
        delete pInfo;
    }
    m_ChildList.RemoveAll();
}


BEGIN_MESSAGE_MAP(CTestTabCtrl, CTabCtrl)
        //{{AFX_MSG_MAP(CTestTabCtrl)
        ON_NOTIFY_REFLECT(TCN_SELCHANGING, OnSelchanging)
        ON_NOTIFY_REFLECT(TCN_SELCHANGE, OnSelchange)
        ON_WM_SIZE()
        //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestTabCtrl message handlers
BOOL CTestTabCtrl::HideCurSel()
{/* Hides the currently selected tab. This function will be recursively called */
/* For each Tab control shown													*/
	int nSel = GetCurSel();
    if(nSel < 0) return FALSE;
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    if(pInfo->m_bIsTab)
    {
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
	     pCtrl->Hide();
    }
    else
    {
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
        pWnd->ShowWindow(SW_HIDE);
    }
	return TRUE;


}
BOOL CTestTabCtrl::Reset()
{
/*
	This function sets the selection to first tab.
	Again this function is called for each tab control	
*/
	if(GetNoOfTabs() == 0) return TRUE;
	SetCurSel(0);
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(0,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    if(pInfo->m_bIsTab)
    {
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
        pCtrl->Reset();
    }
    else
    {
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
        pWnd->ShowWindow(SW_SHOW);
    }
	return TRUE;	

}

void CTestTabCtrl::OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult)
{
        // TODO: Add your control notification handler code here
    *pResult = 0;
	HideCurSel();
}
BOOL CTestTabCtrl::RemoveSelf()
{/* Clears itself from memory and informs the parent about its removal */
	if(m_pParentTabCtrl)
	{//just inform the parent.
		return m_pParentTabCtrl->RemoveTabCtrl(this);
	}
	return FALSE;
}
void CTestTabCtrl::Hide()
{//Get the cur selection. If it is wnd  then call Windows Hide else call Hide.

    int nSel = GetCurSel();
    if(nSel < 0) return;
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    if(pInfo->m_bIsTab)
    {/* This tab is another tab control. Don't call ShowWindow() to Hide */
	/* Since Hide() not only hides the tab control but also window in it */
	/* Call Hide for Tab control */
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
        pCtrl->Hide();
    }
    else
    {//This tab is window. Hide it
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
        pWnd->ShowWindow(SW_HIDE);
    }
    //Hide itself first.
    ShowWindow(SW_HIDE);

}

Tab_Info* CTestTabCtrl::GetTabInfo(int nIndex)
{
    ASSERT(nIndex < m_nNoOfTabs);
    TC_ITEM TabCtrlItem;
    TabCtrlItem.mask     = TCIF_PARAM;
    TabCtrlItem.lParam   = NULL;
    GetItem(nIndex,&TabCtrlItem);
    Tab_Info* pInfo = (Tab_Info* )TabCtrlItem.lParam;
    return pInfo;
}
CString CTestTabCtrl::GetTabText(int nTabNo)
{
    ASSERT(nTabNo < m_nNoOfTabs);
    char cTabText[256];
    TC_ITEM TabCtrlItem;
    TabCtrlItem.mask                 = TCIF_TEXT;
    TabCtrlItem.pszText              = cTabText;
    TabCtrlItem.cchTextMax   = 256;
    GetItem(nTabNo,&TabCtrlItem);
    CString str = cTabText;
    return str;
}
int CTestTabCtrl::GetTabIndex(Tab_Info* pTab)
{
	Tab_Info* pInfo = NULL;
	/* Matches the supplied Tab_Info* with its data */
	/* Don't compare the pointer value              */
	for(int n = 0; n < m_nNoOfTabs ;n++)
	{
		pInfo = GetTabInfo( n);
		if((pTab->m_bIsTab == pInfo->m_bIsTab) && (pTab->lpWnd == pInfo->lpWnd))
		{
			return n;
		}
	}
	return -1;
}
BOOL CTestTabCtrl::RemoveTabCtrl(CTestTabCtrl* pTabCtrl)
{//First find out the index where this tab is residing.
//Removes the tab with Tab control in it.
	Tab_Info* pInfo = NULL;
	int nIndex      = -1;
	for(int n = 0; n < m_nNoOfTabs ;n++)
	{
		pInfo = GetTabInfo( n);
		if(pInfo->m_bIsTab && (CTestTabCtrl* )pInfo->lpWnd == pTabCtrl)
		{
			return RemoveTab(n);
		
		}
	}
	return FALSE;
}
BOOL CTestTabCtrl::RemoveTab(int nIndex)
{
	/* Removes the Tab by its position */
    ASSERT(nIndex < m_nNoOfTabs);
	if(nIndex >  m_nNoOfTabs ) return FALSE;
    Tab_Info* pInfo = GetTabInfo(nIndex);
	ASSERT(pInfo);
    if(pInfo)
    {
        POSITION pos = m_ChildList.Find(pInfo);
        ASSERT(pos);
        m_ChildList.RemoveAt(pos);
        CTestTabCtrl* pChldCtrl = NULL;
        if(pInfo->m_bIsTab)
        {
            pChldCtrl = (CTestTabCtrl* )pInfo->lpWnd;
			/* Before deleting Hide it. So that  */
			/* If this tab is selected then the windows will get hidden. */
			pChldCtrl->Hide();
            delete pChldCtrl;
        }
		else
		{
			CWnd* pWnd = (CWnd* )pInfo->lpWnd;
			pWnd->ShowWindow(SW_HIDE);
		}
        delete pInfo;

    }

    VERIFY(DeleteItem(nIndex));
    m_nNoOfTabs--;
    SetCurSel(0);
	return TRUE;
}
//Returns the currently active view.
CFormView* CTestTabCtrl::GetCurActiveView()
{
/* Returns the currently shown view .  
If you don't have a view as a tab. You need to modify this function
to return CWnd* 	
*/
	CFormView* pView = NULL;;
	int nCurSel = GetCurSel();
	if(nCurSel < 0) return NULL;
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nCurSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    CRect rect;
    if(pInfo->m_bIsTab)
    {
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
        pView = pCtrl->GetCurActiveView();
    }
    else
    {
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
        ASSERT(pWnd->IsKindOf(RUNTIME_CLASS(CFormView)));
		pView      = (CFormView* )pWnd;
    }
	return pView;
}

int  CTestTabCtrl::InsertNewTab(int nTabNo,CString strTabText)
{
	/*
		Inserts a new Tab by position. Remember You need to set either a tab control
		or a window to this index later.
	*/
    ASSERT(nTabNo <= m_nNoOfTabs);
    TC_ITEM TabCtrlItem;
    TabCtrlItem.mask     = TCIF_TEXT|TCIF_PARAM;
    TabCtrlItem.pszText  = strTabText.GetBuffer(strTabText.GetLength()+1);
    TabCtrlItem.lParam   = NULL;
    int nIndex =  InsertItem(nTabNo,&TabCtrlItem);
    ASSERT(nIndex == nTabNo);
	if(nIndex != nTabNo) return -1;
    m_nNoOfTabs++;
    return nIndex;

}
int  CTestTabCtrl::AddNewTab(CString strTabText)
{
	/*
	Adds a Tab at the end.
	*/
    TC_ITEM TabCtrlItem;
    TabCtrlItem.mask     = TCIF_TEXT|TCIF_PARAM;
    TabCtrlItem.pszText  = strTabText.GetBuffer(strTabText.GetLength()+1);
    TabCtrlItem.lParam   = NULL;
    int nIndex =  InsertItem(m_nNoOfTabs,&TabCtrlItem);
    ASSERT(nIndex == m_nNoOfTabs);
   	if(nIndex != m_nNoOfTabs) return -1;
	m_nNoOfTabs++;
    return nIndex;
}
BOOL CTestTabCtrl:: InsertChildTabCtrl(int nTabNo,CTestTabCtrl*& pRet)
{
	/*
	Sets Tab Control to a tab.
	*/
    TC_ITEM TabCtrlItem;
    ASSERT(nTabNo < m_nNoOfTabs);
    Tab_Info* pInfo  = NULL;
	try
	{
		pRet             = new CTestTabCtrl();
		pInfo			 = new Tab_Info(TRUE,(LPARAM)pRet);
    }
	catch(CMemoryException* pMem)
	{/* This is not good */
		if(pRet) delete pRet;
		pMem->ReportError();
		return FALSE;
	}
	CRect rect(10,10,300,300);
    if(!pRet->Create(TCS_MULTILINE|WS_CHILD,rect,this,ID_TAB + nTabNo))
	{
		ASSERT(0);
		delete pRet;
		delete pInfo;
		return FALSE;
	}
    TabCtrlItem.mask     = TCIF_PARAM;
    TabCtrlItem.lParam   = (LPARAM)pInfo;
    SetItem(nTabNo,&TabCtrlItem);
    m_ChildList.AddTail(pInfo);
	pRet->SetParentTabCtrl(this);
    return TRUE;
}
BOOL CTestTabCtrl::InsertWindow(int nTabNo, CWnd* pWnd)
{
	/*
	Sets a Window as a tab.
	*/
    TC_ITEM TabCtrlItem;
    ASSERT(nTabNo < m_nNoOfTabs);
    TabCtrlItem.mask     = TCIF_PARAM;
    Tab_Info* pInfo          = new Tab_Info(FALSE,(LPARAM)pWnd);
    TabCtrlItem.lParam   = (LPARAM)pInfo;
    SetItem(nTabNo,&TabCtrlItem);
    m_ChildList.AddTail(pInfo);
    return TRUE;
}
BOOL CTestTabCtrl:: AddChildTabCtrl(CTestTabCtrl*& pRet)
{
	/*
	Sets a Tab control to the last tab.
	*/
    TC_ITEM TabCtrlItem;
    ASSERT(m_nNoOfTabs);
	Tab_Info* pInfo  = NULL;
	try
	{
		pRet   = new CTestTabCtrl();
		pInfo  = new Tab_Info(TRUE,(LPARAM)pRet);
    }
	catch(CMemoryException* pMem)
	{/* This is not good */
		if(pRet) delete pRet;
		pMem->ReportError();
		return FALSE;
	}
	CRect rect(10,10,300,300);
    if(!pRet->Create(TCS_MULTILINE|WS_CHILD,rect,this,ID_TAB + m_nNoOfTabs))
	{
		ASSERT(0);
		delete pRet;
		delete pInfo;
		return FALSE;

	}
 	TabCtrlItem.mask     = TCIF_PARAM;
    TabCtrlItem.lParam   = (LPARAM)pInfo;
    if(!SetItem(m_nNoOfTabs-1,&TabCtrlItem))
	{
		ASSERT(0);
		delete pRet;
		delete pInfo;
		return FALSE;
	}
    m_ChildList.AddTail(pInfo);
	pRet->SetParentTabCtrl(this);
    return TRUE;
}
BOOL CTestTabCtrl::AddWindow(CWnd* pWnd)
{
	/*
	Sets window to the last tab.
	*/
    ASSERT(m_nNoOfTabs);
    TC_ITEM TabCtrlItem;
    TabCtrlItem.mask     = TCIF_PARAM;
	Tab_Info* pInfo      = NULL;
	try
	{
		pInfo          = new Tab_Info(FALSE,(LPARAM)pWnd);
    }
	catch(CMemoryException* pMem)
	{/* This is not good */
		pMem->ReportError();
		return FALSE;
	}
	TabCtrlItem.lParam   = (LPARAM)pInfo;
    if(!SetItem(m_nNoOfTabs-1,&TabCtrlItem))
	{
		delete pInfo;
		return FALSE;
	}
    m_ChildList.AddTail(pInfo);
    return TRUE;
}

void CTestTabCtrl::GetDisplayRect(CRect* pRect)
{
	/*
	Gets the display rect. This is clientrect minus its Tab height.
	*/
    GetClientRect(pRect);
    AdjustRect(FALSE,pRect);


}
void CTestTabCtrl::GetWndDisplayRect(CWnd* pWnd,CRect* pRect)
{
	/*
		Since window will be child of TabbedView. We need to
		convert the display rect to client coordinates of window's parent.
	*/

    GetDisplayRect(pRect);
    CWnd* pParentWnd = pWnd->GetParent();
    ClientToScreen(pRect);
    pParentWnd->ScreenToClient(pRect);
}

void CTestTabCtrl::Show()
{
/*
This is recursive function to show the current selection.
*/
    int nSel = GetCurSel();
    if(nSel < 0) return;
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    CRect rect;
    if(pInfo->m_bIsTab)
    {
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
        pCtrl->Show();
    }
    else
    {
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
		GetWndDisplayRect(pWnd,&rect);
        pWnd->MoveWindow(&rect);
        pWnd->ShowWindow(SW_SHOW);
    }
    ShowWindow(SW_SHOW);
}

void CTestTabCtrl::OnSelchange(NMHDR* pNMHDR, LRESULT* pResult)
{
        // TODO: Add your control notification handler code here
/*
Selection changed. Show the current selection.
*/
    *pResult = 0;
    int nSel = GetCurSel();
    if(nSel < 0) return;
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    CRect rect;
    if(pInfo->m_bIsTab)
    {
        CTestTabCtrl* pCtrl = (CTestTabCtrl* )pInfo->lpWnd;
        GetDisplayRect(&rect);
        pCtrl->MoveWindow(&rect);
        pCtrl->Show();
    }
    else
    {
        CWnd* pWnd = (CWnd*)pInfo->lpWnd;
        GetWndDisplayRect(pWnd,&rect);
        pWnd->MoveWindow(&rect);
        pWnd->ShowWindow(SW_SHOW);
    }

}
void CTestTabCtrl::SetToNewSize(int nNewWidth,int nNewHeight)
{/* Set to new size. */
    CRect rect(0,0,nNewWidth,nNewHeight);
	CRect curRect;
	GetClientRect(&curRect);
	if(rect != curRect)
	{
		MoveWindow(&rect);
	}
	else
	{
		int nSel = GetCurSel();
		if(nSel < 0) return;
		AdjustRect(FALSE,&rect);
		TC_ITEM itmInfo;
		itmInfo.mask       = TCIF_PARAM;
		Tab_Info* pInfo    = NULL;
		GetItem(nSel,&itmInfo);
		pInfo = (Tab_Info* )itmInfo.lParam;
		CWnd* pWnd = (CWnd*)pInfo->lpWnd;
		// TODO: Add your message handler code here
		if(pInfo->m_bIsTab)
		{
			pWnd->MoveWindow(&rect);
		}
		else
		{
			GetWndDisplayRect(pWnd,&rect);
			pWnd->MoveWindow(&rect);
			pWnd->ShowWindow(SW_SHOW);
		}
	}
}
void CTestTabCtrl::OnSize(UINT nType, int cx, int cy)
{
    CTabCtrl::OnSize(nType, cx, cy);
    int nSel = GetCurSel();
    if(nSel < 0) return;
    CRect rect(0,0,cx,cy);
    AdjustRect(FALSE,&rect);
    TC_ITEM itmInfo;
    itmInfo.mask       = TCIF_PARAM;
    Tab_Info* pInfo    = NULL;
    GetItem(nSel,&itmInfo);
    pInfo = (Tab_Info* )itmInfo.lParam;
    CWnd* pWnd = (CWnd*)pInfo->lpWnd;
    // TODO: Add your message handler code here
    if(pInfo->m_bIsTab)
    {
		pWnd->MoveWindow(&rect);
    }
    else
    {
		GetWndDisplayRect(pWnd,&rect);
		pWnd->MoveWindow(&rect);
		pWnd->ShowWindow(SW_SHOW);
	}

}