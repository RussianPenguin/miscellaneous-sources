// TabView.cpp : implementation file
//

#include "stdafx.h"
#include "MutliRowTab.h"
#include "TabView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
// CTabView1

IMPLEMENT_DYNCREATE(CTabView1, CFormView)

CTabView1::CTabView1()
	: CFormView(CTabView1::IDD)
{
	//{{AFX_DATA_INIT(CTabView1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CTabView1::~CTabView1()
{
}

void CTabView1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabView1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabView1, CFormView)
	//{{AFX_MSG_MAP(CTabView1)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabView1 diagnostics

#ifdef _DEBUG
void CTabView1::AssertValid() const
{
	CFormView::AssertValid();
}

void CTabView1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabView1 message handlers

/////////////////////////////////////////////////////////////////////////////
// CTabView2

IMPLEMENT_DYNCREATE(CTabView2, CFormView)

CTabView2::CTabView2()
	: CFormView(CTabView2::IDD)
{
	//{{AFX_DATA_INIT(CTabView2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CTabView2::~CTabView2()
{
}

void CTabView2::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabView2)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabView2, CFormView)
	//{{AFX_MSG_MAP(CTabView2)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabView2 diagnostics

#ifdef _DEBUG
void CTabView2::AssertValid() const
{
	CFormView::AssertValid();
}

void CTabView2::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabView2 message handlers
/////////////////////////////////////////////////////////////////////////////
// CTabView1

IMPLEMENT_DYNCREATE(CTabView3, CFormView)

CTabView3::CTabView3()
	: CFormView(CTabView3::IDD)
{
	//{{AFX_DATA_INIT(CTabView3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CTabView3::~CTabView3()
{
}

void CTabView3::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabView3)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabView3, CFormView)
	//{{AFX_MSG_MAP(CTabView3)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabView1 diagnostics

#ifdef _DEBUG
void CTabView3::AssertValid() const
{
	CFormView::AssertValid();
}

void CTabView3::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabView3 message handlers
