// TabView1.cpp : implementation file
//

#include "stdafx.h"
#include "MutliRowTab.h"
#include "TabView1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabView1

IMPLEMENT_DYNCREATE(CTabView1, CFormView)

CTabView1::CTabView1()
	: CFormView(CTabView1::IDD)
{
	//{{AFX_DATA_INIT(CTabView1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CTabView1::~CTabView1()
{
}

void CTabView1::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTabView1)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTabView1, CFormView)
	//{{AFX_MSG_MAP(CTabView1)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabView1 diagnostics

#ifdef _DEBUG
void CTabView1::AssertValid() const
{
	CFormView::AssertValid();
}

void CTabView1::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTabView1 message handlers
