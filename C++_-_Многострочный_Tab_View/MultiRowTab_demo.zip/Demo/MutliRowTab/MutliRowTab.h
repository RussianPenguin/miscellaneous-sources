// MutliRowTab.h : main header file for the MUTLIROWTAB application
//

#if !defined(AFX_MUTLIROWTAB_H__B3DC3827_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
#define AFX_MUTLIROWTAB_H__B3DC3827_531A_11D3_BDAA_00805FE7C208__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabApp:
// See MutliRowTab.cpp for the implementation of this class
//

class CMutliRowTabApp : public CWinApp
{
public:
	CMutliRowTabApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMutliRowTabApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMutliRowTabApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MUTLIROWTAB_H__B3DC3827_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
