// MutliRowTabDoc.h : interface of the CMutliRowTabDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MUTLIROWTABDOC_H__B3DC382D_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
#define AFX_MUTLIROWTABDOC_H__B3DC382D_531A_11D3_BDAA_00805FE7C208__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMutliRowTabDoc : public CDocument
{
protected: // create from serialization only
	CMutliRowTabDoc();
	DECLARE_DYNCREATE(CMutliRowTabDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMutliRowTabDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMutliRowTabDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMutliRowTabDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MUTLIROWTABDOC_H__B3DC382D_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
