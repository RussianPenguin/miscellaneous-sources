// MutliRowTabDoc.cpp : implementation of the CMutliRowTabDoc class
//

#include "stdafx.h"
#include "MutliRowTab.h"

#include "MutliRowTabDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabDoc

IMPLEMENT_DYNCREATE(CMutliRowTabDoc, CDocument)

BEGIN_MESSAGE_MAP(CMutliRowTabDoc, CDocument)
	//{{AFX_MSG_MAP(CMutliRowTabDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabDoc construction/destruction

CMutliRowTabDoc::CMutliRowTabDoc()
{
	// TODO: add one-time construction code here

}

CMutliRowTabDoc::~CMutliRowTabDoc()
{
}

BOOL CMutliRowTabDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabDoc serialization

void CMutliRowTabDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabDoc diagnostics

#ifdef _DEBUG
void CMutliRowTabDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMutliRowTabDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabDoc commands
