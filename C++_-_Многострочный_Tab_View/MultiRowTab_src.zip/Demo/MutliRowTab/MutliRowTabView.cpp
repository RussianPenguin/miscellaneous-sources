// MutliRowTabView.cpp : implementation of the CMutliRowTabView class
//

#include "stdafx.h"
#include "testtabctrl.h"
#include "MutliRowTabView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define ID_TAB  1000
#define ID_PARAM_TAB 999
#define ID_FORM1 1001

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView

IMPLEMENT_DYNCREATE(CMutliRowTabView, CView)

BEGIN_MESSAGE_MAP(CMutliRowTabView, CView)
	//{{AFX_MSG_MAP(CMutliRowTabView)
	ON_WM_CREATE()
    ON_WM_SIZE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView construction/destruction

CMutliRowTabView::CMutliRowTabView()
{
	// TODO: add construction code here
	m_nNoOfWindows = 0;
}

CMutliRowTabView::~CMutliRowTabView()
{
}

BOOL CMutliRowTabView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView drawing

void CMutliRowTabView::OnDraw(CDC* pDC)
{
	CMutliRowTabDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView printing

BOOL CMutliRowTabView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMutliRowTabView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMutliRowTabView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView diagnostics

#ifdef _DEBUG
void CMutliRowTabView::AssertValid() const
{
	CView::AssertValid();
}

void CMutliRowTabView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMutliRowTabDoc* CMutliRowTabView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMutliRowTabDoc)));
	return (CMutliRowTabDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMutliRowTabView message handlers


CWnd* CMutliRowTabView::CreateTabWindow(CRuntimeClass* pWndClass)
{
	CRect rect;
    GetClientRect(&rect);
    BOOL bRet = FALSE;
    CWnd* pWnd    = NULL;
	pWnd          = (CWnd* )(pWndClass->CreateObject());
	ASSERT(pWnd);
	if(!pWnd)       return FALSE;
	ASSERT_KINDOF(CWnd, pWnd);
	ASSERT(pWnd->m_hWnd == NULL);       // not yet created
	bRet          = pWnd->Create(NULL, NULL, WS_CHILD, rect,this, m_nNoOfWindows+ID_FORM1, NULL);//don't show
	if(!bRet)
	{
		throw "Could not Create Tabbed Dialog";
	}
	m_nNoOfWindows++;
	return pWnd;
}
CTestTabCtrl* CMutliRowTabView::InsertTabControl(CTestTabCtrl* pTabParent,Tab_Info* pInsertAfter,CString  strTitle)	
{
	int nIndex = 0;//Default the first tab.
	CTestTabCtrl* pChildTab = NULL;
	if(!pTabParent)
	{//Insert it in the root.
		pTabParent = &m_TabCtrl;
	}
	if(pInsertAfter == TAB_LAST)
	{
		nIndex = pTabParent->GetNoOfTabs();
	}
	else if(pInsertAfter == TAB_FIRST)
	{
		nIndex = 0;
	}
	else
	{//Find the tab index.
		int nIndex = pTabParent->GetTabIndex(pInsertAfter);
		if(nIndex == -1) return NULL;//Failed to locate the tab control.
		nIndex++;
	}
	//now construct the tab control.
	if(pTabParent->InsertNewTab(nIndex,strTitle) != nIndex)
	{
		return NULL;
	}
	if(!pTabParent->InsertChildTabCtrl(nIndex,pChildTab))
	{
		return NULL;
	}
	return pChildTab;

}
BOOL CMutliRowTabView::InsertWindow(CTestTabCtrl* pTabParent,Tab_Info* pInsertAfter,CString  strTitle,CWnd* pWnd)
{
	int nIndex = 0;//Default the first tab.
	if(!pTabParent)
	{//Insert it in the root.
		pTabParent = &m_TabCtrl;
	}
	if(pInsertAfter == TAB_LAST)
	{
		nIndex = pTabParent->GetNoOfTabs();
	}
	else if(pInsertAfter == TAB_FIRST)
	{
		nIndex = 0;
	}
	else
	{//Find the tab index.
		nIndex = pTabParent->GetTabIndex(pInsertAfter);
		if(nIndex == -1) return FALSE;//Failed to locate the tab control.
		nIndex++;
	}
	//now construct the tab control.
	if(pTabParent->InsertNewTab(nIndex,strTitle) != nIndex)
	{
		return FALSE;
	}
	if(!pTabParent->InsertWindow(nIndex,pWnd))
	{
		return FALSE;
	}
	return TRUE;
}
BOOL CMutliRowTabView::RemoveTabControl(CTestTabCtrl* pTabControl)
{
	return pTabControl->RemoveSelf();//It knows the parent.
}
BOOL CMutliRowTabView::RemoveWindow(CTestTabCtrl* pTabParent,CWnd* pWnd,BOOL bDestroy)
{
	if(!pTabParent)
	{//Insert it in the root.
		pTabParent = &m_TabCtrl;
	}
	int nTabIndex = 0;
	Tab_Info Info(FALSE,(LPARAM)pWnd);
	if((nTabIndex = pTabParent->GetTabIndex(&Info)) == -1)
	{
		return FALSE;
	}
	return pTabParent->RemoveTab(nTabIndex);

}
	
int CMutliRowTabView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CView::OnCreate(lpCreateStruct) == -1)
            return -1;
    CRect rect(10,10,300,300);
    m_TabCtrl.Create(TCS_MULTILINE|WS_CHILD|WS_VISIBLE,rect,this,ID_TAB);
    return 0;
}

void CMutliRowTabView::OnInitialUpdate()
{
    CView::OnInitialUpdate();

    // TODO: Add your specialized code here and/or call the base class
	/*
	Add the views to tab control.
	*/

    CRect rect;
    GetClientRect(&rect);
#if 0
	//Add your own code here.
	CWnd* pWnd1 = CreateTabWindow(RUNTIME_CLASS(CTabView1));
	CWnd* pWnd2 = CreateTabWindow(RUNTIME_CLASS(CTabView2));
	CWnd* pWnd3 = CreateTabWindow(RUNTIME_CLASS(CTabView3));
	
	/* Insert a tab with window */
	InsertWindow(NULL,TAB_LAST,/* Position*/"Tab1"/* Title*/,pWnd1);
	/* Insert a tab with a tab control */
	CTestTabCtrl* pRow1 = InsertTabControl(NULL,TAB_LAST,"Row");
	/* Insert a tab in new Tab control and set it to window  */
	InsertWindow(pRow1,TAB_LAST,/* Position*/"Tab2"/* Title*/,pWnd2);

	CTestTabCtrl* pRow2 = InsertTabControl(pRow1,TAB_LAST," Another Row");

	InsertWindow(pRow2,TAB_LAST,/* Position*/"Tab3"/* Title*/,pWnd3);
#endif
	m_TabCtrl.HideCurSel();
	m_TabCtrl.Reset();
	m_TabCtrl.Show();
	m_TabCtrl.SetToNewSize(rect.Width(),rect.Height());


}

void CMutliRowTabView::OnSize(UINT nType, int cx, int cy)
{
    CView::OnSize(nType, cx, cy);
    // TODO: Add your message handler code here
    RECT rect;
    GetClientRect(&rect);
    m_TabCtrl.MoveWindow(&rect);
}
