// MutliRowTabView.h : interface of the CMutliRowTabView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MUTLIROWTABVIEW_H__B3DC382F_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
#define AFX_MUTLIROWTABVIEW_H__B3DC382F_531A_11D3_BDAA_00805FE7C208__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define TAB_FIRST               ((Tab_Info* )0xFFFF0001)
#define TAB_LAST                ((Tab_Info* )0xFFFF0002)
class CTestTabCtrl;
class CMutliRowTabView : public CView
{
protected: // create from serialization only
	CMutliRowTabView();
	DECLARE_DYNCREATE(CMutliRowTabView)
	int m_nNoOfWindows;

// Attributes
public:
	CMutliRowTabDoc* GetDocument();
    CTestTabCtrl m_TabCtrl;//Main tab ctrl.
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMutliRowTabView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL
	CWnd* CreateTabWindow(CRuntimeClass* pWndClass);
	CTestTabCtrl* InsertTabControl(CTestTabCtrl* pTabParent,Tab_Info* pInsertAfter,CString  strTitle);	
	BOOL InsertWindow(CTestTabCtrl* pTabParent,Tab_Info* pInsertAfter,CString  strTitle,CWnd* pWnd);
	BOOL RemoveTabControl(CTestTabCtrl* pTabControl);
	BOOL RemoveWindow(CTestTabCtrl* pTabParent,CWnd* pWnd,BOOL bDestroy = FALSE);
// Implementation
public:
	virtual ~CMutliRowTabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMutliRowTabView)
       afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
        afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MutliRowTabView.cpp
inline CMutliRowTabDoc* CMutliRowTabView::GetDocument()
   { return (CMutliRowTabDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MUTLIROWTABVIEW_H__B3DC382F_531A_11D3_BDAA_00805FE7C208__INCLUDED_)
