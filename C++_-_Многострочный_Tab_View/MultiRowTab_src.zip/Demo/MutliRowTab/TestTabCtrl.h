#if !defined(AFX_TESTTABCTRL_H__9B377623_0258_11D3_9231_00805F41ED3F__INCLUDED_)
#define AFX_TESTTABCTRL_H__9B377623_0258_11D3_9231_00805F41ED3F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TestTabCtrl.h : header file
//
struct Tab_Info
{
    BOOL m_bIsTab;
    LPARAM lpWnd;//Either CWnd* or CTabCtrl*
    Tab_Info(BOOL bIsTab,LPARAM pWnd):m_bIsTab(bIsTab),lpWnd(pWnd){}
};
/////////////////////////////////////////////////////////////////////////////
// CTestTabCtrl window

class CTestTabCtrl : public CTabCtrl
{
// Construction
    int m_nNoOfTabs;
    CPtrList m_ChildList;
	CTestTabCtrl* m_pParentTabCtrl;
public:
        CTestTabCtrl();

// Attributes
public:

// Operations
public:
    void Hide();
    void Show();
    void GetDisplayRect(CRect* pRect);
    void GetWndDisplayRect(CWnd* pWnd,CRect* pRect);
    int AddNewTab(CString strTabText);
    int  InsertNewTab(int nTabNo,CString strTabText);
    BOOL  InsertChildTabCtrl(int nTabNo,CTestTabCtrl*& pRet);
    BOOL InsertWindow(int nTabNo, CWnd* pWnd);
    BOOL  AddChildTabCtrl(CTestTabCtrl*& pRet);
    BOOL AddWindow( CWnd* pWnd);
    BOOL RemoveTab(int nIndex);
    int GetNoOfTabs(){return m_nNoOfTabs;}
    Tab_Info* GetTabInfo(int nIndex);
	int GetTabIndex(Tab_Info* pTab);
    CString GetTabText(int nTabNo);
	void SetParentTabCtrl(CTestTabCtrl*  pParentTab){m_pParentTabCtrl = pParentTab;}
	CTestTabCtrl* GetParentTabCtrl( ){return m_pParentTabCtrl;}
	BOOL RemoveTabCtrl(CTestTabCtrl* pTabCtrl);
	CFormView* GetCurActiveView();
	BOOL HideCurSel();
	BOOL RemoveSelf();
	BOOL Reset();
	void SetToNewSize(int nNewWidth,int nNewHeight);
// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CTestTabCtrl)
    //}}AFX_VIRTUAL

// Implementation
public:
    virtual ~CTestTabCtrl();

    // Generated message map functions
protected:
    //{{AFX_MSG(CTestTabCtrl)
    afx_msg void OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnSize(UINT nType, int cx, int cy);
    //}}AFX_MSG

    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTTABCTRL_H__9B377623_0258_11D3_9231_00805F41ED3F__INCLUDED_)