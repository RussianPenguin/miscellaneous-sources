//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DemoUIDevStudio.rc
//
#define IDD_ABOUTBOX                    100
#define IDB_IL_FILE                     108
#define IDB_IL_RSRC                     110
#define IDR_MAINFRAME                   128
#define IDR_DEMOUITYPE                  129
#define IDB_IL_TAB                      130
#define IDB_IL_CLASS                    131
#define IDR_BUILDBAR                    140
#define IDB_BITMAP1                     142
#define IDC_TXT_EMAIL                   1000
#define IDC_TXT_URL                     1001
#define IDC_TXT_VERSION                 1003
#define IDC_FLATTABCTRL                 1004
#define IDC_SHEET1                      1005
#define IDC_SHEET2                      1006
#define IDC_SHEET3                      1007
#define IDC_SHEET4                      1008
#define IDC_SHEET5                      1009
#define IDC_SHEET6                      1010
#define IDC_RADIO1                      1012
#define ID_VIEW_BUILDBAR                0x4269
#define ID_VIEW_WORKSPACEBAR            0x426A
#define ID_VIEW_OUTPUTBAR               0x426B
#define IDC_TIPOFTHEDAY                 32771
#define ID_UNDO                         32772
#define ID_REDO                         32773
#define ID_SAVE_ALL                     32774
#define ID_WORKSPACE                    32775
#define ID_OUTPUT                       32776
#define ID_WINDOW_LIST                  32777
#define ID_FIND_IN_FILES                32778
#define ID_FIND                         32779
#define ID_ACTIVE_PROJECT               32781
#define ID_ACTIVE_CONFIG                32782
#define ID_COMPILE                      32783
#define ID_BUILD                        32784
#define ID_STOP_BUILD                   32785
#define ID_EXECUTE_PROG                 32786
#define ID_GO                           32787
#define ID_INSERT_BREAK                 32788
#define ID_SEARCH                       32789

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        143
#define _APS_NEXT_COMMAND_VALUE         32790
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
