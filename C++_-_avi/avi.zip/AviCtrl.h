#if !defined(AFX_AVICTRL_H__C683C021_847C_11D2_A6CD_000001273812__INCLUDED_)
#define AFX_AVICTRL_H__C683C021_847C_11D2_A6CD_000001273812__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AviCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAviCtrl window

class CAviCtrl : public CWnd
{
// Construction
public:
	CAviCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAviCtrl)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetSize();
	CRect m_rcStandart;
	BOOL fMovieOpen;
	void HideAVI();
	BOOL m_bMaximesed;
	BOOL Create(DWORD dwStyle,CWnd* pParentWnd,BOOL bSatusBar );
	BOOL SetFileName(LPCTSTR lpFName);
	virtual ~CAviCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAviCtrl)
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AVICTRL_H__C683C021_847C_11D2_A6CD_000001273812__INCLUDED_)
