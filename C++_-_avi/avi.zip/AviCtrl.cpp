// AviCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "Html.h"
#include "AviCtrl.h"
#include <windowsx.h>
#include <mmsystem.h>
#include <direct.h>
#include <digitalv.h>
#include <vfw.h>

#ifdef _DEBUG
//# #define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAviCtrl

CAviCtrl::CAviCtrl()
{
m_bMaximesed = FALSE;
fMovieOpen = FALSE;
m_rcStandart.SetRect(0,0,100,100);
}

CAviCtrl::~CAviCtrl()
{
		DestroyWindow();
}


BEGIN_MESSAGE_MAP(CAviCtrl, CWnd)
	//{{AFX_MSG_MAP(CAviCtrl)
	ON_WM_DESTROY()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CAviCtrl message handlers


BOOL CAviCtrl::Create(DWORD dwStyle,CWnd* pParentWnd,BOOL bSatusBar ) 
{
	// TODO: Add your specialized code here and/or call the base class
	m_bMaximesed = FALSE;
	fMovieOpen = FALSE;
	HWND hwndMovie = MCIWndCreate(pParentWnd->m_hWnd, AfxGetApp()->m_hInstance, dwStyle|WS_BORDER |WS_THICKFRAME | MCIWNDF_NOOPEN |
                                MCIWNDF_NOERRORDLG | MCIWNDF_NOTIFYSIZE, NULL);
	if ( hwndMovie )
	{
		Attach( hwndMovie );
		return TRUE;
	}
	return FALSE;
}


BOOL CAviCtrl::SetFileName(LPCTSTR lpFName)
{
	if (MCIWndOpen(m_hWnd, lpFName, 0) == 0)
	{
          /* we opened the file o.k., now set up to */
          /* play it.                                */
		GetWindowRect( &m_rcStandart );
		SetSize();
		ShowWindow( SW_SHOW);
		MCIWndPlay( m_hWnd );
		fMovieOpen = TRUE;
  } else 
	{
          /* generic error for open */
    MessageBox( "Unable to open Movie", lpFName,
			MB_ICONEXCLAMATION|MB_OK);
    fMovieOpen = FALSE;
  }
return fMovieOpen;
}

BOOL CAviCtrl::DestroyWindow() 
{
	HWND hwndMovie = Detach();
	if ( hwndMovie )
		{
		MCIWndClose(hwndMovie);  // close an open movie
		MCIWndDestroy(hwndMovie);    // now destroy the MCIWnd window
		fMovieOpen = FALSE;
		}
	return TRUE;
}

void CAviCtrl::HideAVI()
{
	MCIWndClose( m_hWnd );         // close the movie
    ShowWindow( SW_HIDE); //hide the window
	fMovieOpen = FALSE;
}

void CAviCtrl::OnDestroy() 
{
	DestroyWindow();
	//CWnd::OnDestroy();
}

void CAviCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	SetSize();
	m_bMaximesed  = !m_bMaximesed;
	CWnd::OnLButtonDblClk(nFlags, point);
}


void CAviCtrl::SetSize()
{
		if ( m_hWnd )
		{
			CRect rcI;
			GetParent()->GetClientRect( &rcI );
			int x=0,y=0,cx,cy;
			if (  !m_bMaximesed )
			{
				x = (rcI.Width() - m_rcStandart.Width())/2;
				y = (rcI.Height() - m_rcStandart.Height())/2;
				cx = m_rcStandart.Width();
				cy = m_rcStandart.Height();
			}
			else
			{
				cx = rcI.Width();
				cy = rcI.Height();
			}
			MoveWindow(x,y,cx,cy);
		}
}
