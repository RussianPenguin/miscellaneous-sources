#ifndef __DOTLINEDRAW_H__
#define __DOTLINEDRAW_H__

void DotLineDraw(HDC hdc,int x1,int y1,int x2,int y2,int width,
							int space1,COLORREF color1,int space2,COLORREF color2,
							BOOL OptimizeSpedForOddDots=FALSE);

#endif //!__DOTLINEDRAW_H__
