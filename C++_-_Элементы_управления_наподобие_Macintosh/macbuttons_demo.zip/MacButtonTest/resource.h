//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MacButtonTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MACBUTTONTEST_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_RADIO5                      1004
#define IDC_CHECK1                      1024
#define IDC_CHECK2                      1025
#define IDC_CHECK3                      1026
#define IDC_CHECK4                      1027
#define IDC_CHECK5                      1028
#define IDC_BUTTON1                     1048
#define IDC_BUTTON2                     1049
#define IDC_BUTTON3                     1050
#define IDC_BUTTON4                     1051
#define IDC_BUTTON5                     1052
#define IDC_BUTTON6                     1053
#define IDC_RADIO_ICON                  1061
#define IDC_RADIO_BITMAP                1062
#define IDC_RADIO_TEXT                  1063
#define IDC_RADIO_CHECK                 1064
#define IDC_RADIO_CROSS                 1065
#define IDC_RADIO_TRISTATE              1066
#define IDC_RADIO_RAISED                1067
#define IDC_RADIO_SUNKEN                1068
#define IDC_STATIC_IMAGEEFFECT          1069
#define IDC_RADIO_NONE                  1070
#define IDC_CHECK_ENABLE                1071
#define IDC_BUTTON_MORERADIO            1081
#define IDC_BUTTON_MORECHECKBOX         1082
#define IDC_BUTTON_MOREBUTTON           1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1085
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
