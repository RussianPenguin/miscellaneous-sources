﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("CodeBlock Demo - Author Edition")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Liam Dawson")> 
<Assembly: AssemblyProduct("CodeBlock Demo - Author Edition")> 
<Assembly: AssemblyCopyright("Copyright © Liam Dawson, 2009, under a CPOL licence.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("f50b7f02-7df7-4d3b-b68b-7f7d8f3964b8")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
