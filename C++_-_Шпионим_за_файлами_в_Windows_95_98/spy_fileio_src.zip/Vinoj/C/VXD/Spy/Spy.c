#define WANTVXDWRAPS

#include <basedef.h>
#include <vmm.h>
#include <debug.h>
#include <vxdwraps.h>
#include <vwin32.h>
#include <winerror.h>
#include <ifs.h>
#include <ifsmgr.h>
#include <string.h>

#define SPY_VERSION 0x400

#define SPY_V86_FUNCTION1 1
#define SPY_V86_FUNCTION2 2
#define SPY_PM_FUNCTION1  1
#define SPY_PM_FUNCTION2  2

typedef DIOCPARAMETERS *LPDIOC;

#pragma VxD_LOCKED_CODE_SEG
#pragma VxD_LOCKED_DATA_SEG


DWORD _stdcall SPY_W32_DeviceIOControl(DWORD, DWORD, DWORD, LPDIOC);
DWORD _stdcall SPY_CleanUp(void);
DWORD _stdcall VxDProc(DWORD, DWORD, LPDIOC);
DWORD _stdcall VxDProc1(DWORD, DWORD, LPDIOC);
DWORD _stdcall VxDProc2(DWORD, DWORD, LPDIOC);
int     _cdecl OurFileHook(pIFSFunc pfn, int nFunction, int nDrive, int nResources, int Cp, pioreq pir);
int FormNetPath(char *FileNm, pioreq pir);
ppIFSFileHookFunc ppPrevHook;
char AlreadyInside=0, Init=0, FileFail=0;
DWORD pHandle, bRead;

extern DWORD Sprintf1(char *, char *, char *, char *);

/****************************************************************************
                  SPY_W32_DeviceIOControl
****************************************************************************/
DWORD _stdcall SPY_W32_DeviceIOControl(DWORD  dwService,
                                        DWORD  dwDDB,
                                        DWORD  hDevice,
                                        LPDIOC lpDIOCParms)
{
    DWORD dwRetVal = 0;
    // DIOC_OPEN is sent when VxD is loaded w/ CreateFile 
    //  (this happens just after SYS_DYNAMIC_INIT)
    if ( dwService == DIOC_OPEN )
    {
        Out_Debug_String("SPY: WIN32 DEVIOCTL supported here!\n\r");
        // Must return 0 to tell WIN32 that this VxD supports DEVIOCTL
        dwRetVal = 0;
    }
    // DIOC_CLOSEHANDLE is sent when VxD is unloaded w/ CloseHandle
    //  (this happens just before SYS_DYNAMIC_EXIT)
    else if ( dwService == DIOC_CLOSEHANDLE )
    {
        // Dispatch to cleanup proc
        Out_Debug_String("SPY: Closing!\n\r");
        dwRetVal = SPY_CleanUp();
    }
    else if(dwService==1)
    {
        // CALL requested service
        dwRetVal = VxDProc(dwDDB, hDevice, lpDIOCParms);
        return(dwRetVal);
    }
    else if(dwService==2){
        VxDProc1(dwDDB, hDevice, lpDIOCParms);
        return(NO_ERROR);
    }
    else if(dwService==3){
        VxDProc2(dwDDB, hDevice, lpDIOCParms);
    }
    return(dwRetVal);
}

DWORD _stdcall VxDProc(DWORD dwDDB, DWORD hDevice, LPDIOC lpDIOCParms)
{
    PDWORD pdw;

   pdw = (PDWORD)lpDIOCParms->lpvOutBuffer;
    ppPrevHook=IFSMgr_InstallFileSystemApiHook(OurFileHook);
    return(NO_ERROR);
}

DWORD _stdcall VxDProc2(DWORD dwDDB, DWORD hDevice, LPDIOC lpDIOCParms)
{
    PDWORD pdw;
    char FileNm[]="c:\\FileCall.Spy";
    char buff[50];
    int pAction=0x12;          //Replace/Open
    pdw = (PDWORD)lpDIOCParms->lpvOutBuffer;
    Init=1;
    if(R0_OpenCreateFile(R0_OPENCREATFILE, 0x2, 0, pAction, R0_NO_CACHE, FileNm, &pHandle, &pAction)!=0)
        FileFail=1;
    else{
        Init=FileFail=0;
    }
    return(FileFail);
}

DWORD _stdcall VxDProc1(DWORD dwDDB, DWORD hDevice, LPDIOC lpDIOCParms)
{
    PDWORD pdw;

    pdw = (PDWORD)lpDIOCParms->lpvOutBuffer;
    pdw[0]=IFSMgr_RemoveFileSystemApiHook(OurFileHook);
    R0_CloseFile(pHandle);
    return(NO_ERROR);
}
#pragma VxD_LOCKED_CODE_SEG
int     _cdecl OurFileHook(pIFSFunc pfn, int nFunction, int nDrive, int nResources, int Cp, pioreq pir)
{
        int iRet;
        unsigned long fHan;
        char buff[50];
        DWORD pAction;
        char FileNm[400];
        char TmpStr[400], TmpStr2[50];
        DWORD iLen;
        char TmpStr1[10], TmpStr4[50];
        char *TmpStr5;
        char *TmpStr3;

        iRet=0;
        switch(nFunction)
        {
        case IFSFN_OPEN:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                if((nDrive & 0xFF) != 0xFF){
                        FileNm[0]= nDrive + '@';
                        FileNm[1]=':';
                        iLen=2;
                        iLen+=UniToBCSPath(&FileNm[2], pir->ir_ppath->pp_elements, MAX_PATH, BCS_OEM);
                }
                else{
                        iLen=FormNetPath(FileNm, pir);
                }
                if(iLen>=0){
                        FileNm[iLen]=0;
                        iLen++;
                }
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                TmpStr5= (iRet!=0) ? "Fail":"Success";
                if((pir->ir_flags & ACCESS_MODE_MASK) == ACCESS_READONLY)
                        Sprintf1(TmpStr, "Open for Read %s, Handle %X, ", FileNm, pir->ir_fh);
                else if((pir->ir_flags & ACCESS_MODE_MASK) == ACCESS_WRITEONLY)
                        Sprintf1(TmpStr, "Open for Write %s, Handle %X, ", FileNm, pir->ir_fh);
                else if((pir->ir_flags & ACCESS_MODE_MASK) == ACCESS_READWRITE)
                        Sprintf1(TmpStr, "Open for Read/Write %s, Handle %X, ", FileNm, pir->ir_fh);
                else if((pir->ir_flags & ACCESS_MODE_MASK) == ACCESS_EXECUTE)
                        Sprintf1(TmpStr, "Open for Execute %s, Handle %X, ", FileNm, pir->ir_fh);

                if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_COMPATIBILITY)
                        Sprintf1(TmpStr4, "Share Compatibility %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_DENYREADWRITE)
                        Sprintf1(TmpStr4, "Share Deny Read/Write %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_DENYWRITE)
                        Sprintf1(TmpStr4, "Share Deny Write %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_DENYREAD)
                        Sprintf1(TmpStr4, "Share Deny Read %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_DENYREAD)
                        Sprintf1(TmpStr4, "Share Deny Read %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_DENYNONE)
                        Sprintf1(TmpStr4, "Share Deny None %X, Options %X, ", pir->ir_flags, pir->ir_options);
                else if((pir->ir_flags & SHARE_MODE_MASK) == SHARE_FCB)
                        Sprintf1(TmpStr4, "Share FCB %X, Options %X, ", pir->ir_flags, pir->ir_options);

                strcat(TmpStr, TmpStr4);
                Sprintf1(TmpStr2, "Flags %X, %s\n", pir->ir_flags, TmpStr5);
                strcat(TmpStr, TmpStr2);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_CLOSE:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                
                Sprintf1(TmpStr, "Close Handle %X, %s\n", pir->ir_fh, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_FINDOPEN:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                if((nDrive & 0xFF) != 0xFF){
                        FileNm[0]= nDrive + '@';
                        FileNm[1]=':';
                        iLen=2;
                        iLen+=UniToBCSPath(&FileNm[2], pir->ir_ppath->pp_elements, MAX_PATH, BCS_OEM);
                }
                else{
                        iLen=FormNetPath(FileNm, pir);
                }
                if(iLen>=0){
                        FileNm[iLen]=0;
                        iLen++;
                }
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                TmpStr5 = (iRet!=0) ? "Fail\r\n":"Success\r\n";
                
                Sprintf1(TmpStr, "Find Open %s, Handle %X, ", FileNm, pir->ir_fh);
                strcat(TmpStr, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_FINDNEXT:
                if(AlreadyInside==1 || Init==1)
                        break;
                AlreadyInside=1;
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                Sprintf1(TmpStr, "Find Next Handle %X, %s\n", pir->ir_fh, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_FINDCLOSE:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                
                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                Sprintf1(TmpStr, "Find Close Handle %X, %s\n", pir->ir_fh, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_RENAME:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                if((nDrive & 0xFF) != 0xFF){
                        FileNm[0]= nDrive + '@';
                        FileNm[1]=':';
                        iLen=2;
                        iLen+=UniToBCSPath(&FileNm[2], pir->ir_ppath->pp_elements, MAX_PATH, BCS_OEM);
                }
                else{
                        iLen=FormNetPath(FileNm, pir);
                }
                if(iLen>=0){
                        FileNm[iLen]=0;
                        iLen++;
                }
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);

                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                Sprintf1(TmpStr, "Rename %s, %s\n", FileNm, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_DELETE:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                if((nDrive & 0xFF) != 0xFF){
                        FileNm[0]= nDrive + '@';
                        FileNm[1]=':';
                        iLen=2;
                        iLen+=UniToBCSPath(&FileNm[2], pir->ir_ppath->pp_elements, MAX_PATH, BCS_OEM);
                }
                else{
                        iLen=FormNetPath(FileNm, pir);
                }
                if(iLen>=0){
                        FileNm[iLen]=0;
                        iLen++;
                }
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                
                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                Sprintf1(TmpStr, "Delete %s, %s\n", FileNm, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_DIR:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                if((nDrive & 0xFF) != 0xFF){
                        FileNm[0]= nDrive + '@';
                        FileNm[1]=':';
                        iLen=2;
                        iLen+=UniToBCSPath(&FileNm[2], pir->ir_ppath->pp_elements, MAX_PATH, BCS_OEM);
                }
                else{
                        iLen=FormNetPath(FileNm, pir);
                }
                if(iLen>=0){
                        FileNm[iLen]=0;
                        iLen++;
                }
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                
                TmpStr5 = (iRet!=0) ? "Fail":"Success";
                Sprintf1(TmpStr, "Directory manipulation %s, %s\n", FileNm, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_READ:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                Sprintf1(TmpStr, "Read Handle %X, Position 0x%X, ", pir->ir_fh, pir->ir_pos);
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                
                TmpStr5 = (iRet!=0) ? "Fail\r\n":"Success\r\n";
                Sprintf1(TmpStr2, "Bytes %lu, Address %X, ", pir->ir_length, pir->ir_data); 
                strcat(TmpStr, TmpStr2);
                strcat(TmpStr, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;
        case IFSFN_WRITE:
                if(AlreadyInside==1 || Init==1)
                        break;
                 AlreadyInside=1;
                Sprintf1(TmpStr, "Write Handle %X, Position 0x%X, ", pir->ir_fh, pir->ir_pos);
                iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
                
                TmpStr5 = (iRet!=0) ? "Fail\r\n":"Success\r\n";
                Sprintf1(TmpStr2, "Bytes %lu, Address %X, ", pir->ir_length, pir->ir_data); 
                strcat(TmpStr, TmpStr2);
                strcat(TmpStr, TmpStr5);
                R0_GetFileSize(pHandle, &bRead);
                R0_WriteFile(R0_WRITEFILE, pHandle, strlen(TmpStr), bRead, TmpStr, &bRead);
                AlreadyInside=0;
                return iRet;

        }
        iRet=(*(*ppPrevHook))(pfn, nFunction, nDrive, nResources, Cp, pir);
        return iRet;
}

int FormNetPath(char *FileNm, pioreq pir)
{
 	int		iSizeOfUniPath, iLengthOfPath ;
	char	*UniPath ;
	
	UniPath = (char *)pir->ir_aux3.aux_ptr ;
	_asm
	{
		mov		ebx,	UniPath ;
		xor		ecx,	ecx
	L_MoreInUNI_1:
		cmp		word ptr [ebx],0
		je		L_FoundInUNI_1
		add		ebx,	2
		inc		ecx
		jmp		L_MoreInUNI_1
	L_FoundInUNI_1:
		shl		ecx,	1
		mov		iSizeOfUniPath,ecx	
	}
	iLengthOfPath = UniToBCS(FileNm, pir->ir_aux3.aux_ptr, iSizeOfUniPath,
			MAX_PATH, BCS_OEM ) ;
	
	return iLengthOfPath ;       
}

DWORD _stdcall SPY_Dynamic_Exit(void)
{
    Out_Debug_String("SPY: Dynamic Exit\n\r");

    return(VXD_SUCCESS);
}

DWORD _stdcall SPY_CleanUp(void)
{
    Out_Debug_String("SPY: Cleaning Up\n\r");
    return(VXD_SUCCESS);
}
#pragma VxD_ICODE_SEG
#pragma VxD_IDATA_SEG

DWORD _stdcall SPY_Dynamic_Init(void)
{
    Out_Debug_String("SPY: Dynamic Init\n\r");

    return(VXD_SUCCESS);
}

