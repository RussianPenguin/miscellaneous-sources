Solar light&material example
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is a spinning textured spheres (planets!) OpenGL example with constant frame-rate. Written in Delphi.
You can change the light and material parameters and see results in realtime.
Click&Drag to rotate scene.

ArrowSoft (c)2000 24may

http://arrowsoft.ifrance.com
http://members.xoom.com/arrowsite