//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OleTapi.rc
//
#define IDS_TAPI                        1
#define IDB_TAPI                        1
#define IDS_TAPI_PPG                    2
#define IDS_TAPI_PPG_CAPTION            200
#define IDD_PROPPAGE_TAPI               200
#define IDS_INIFILECORRUPT              201
#define IDS_NODRIVER                    202
#define IDS_REINIT                      203
#define IDI_ICON                        203
#define IDS_NOMULTIPLEINSTANCE          204
#define IDB_PHONE                       204
#define IDS_NOMEM                       205
#define IDS_OPERATIONFAILED             206
#define IDS_RESOURCEUNAVAIL             207
#define IDS_UNHANDLEDERROR              208
#define IDS_DEVICETAPINOTFOUND          209
#define IDS_ERRALLOCATED                210
#define IDS_LINENOVOICE                 211
#define IDS_NOMAKECALL                  212
#define IDS_ERRLINEQUERY                213
#define IDS_LINEUNABLE                  214
#define IDS_TAPIINITIALIZE              215
#define IDS_OK                          216
#define IDS_ERRLINECLOSE                217
#define IDS_OKLINECLOSE                 218
#define IDS_ERRLINESHUTDOWN             219
#define IDS_TAPISHUTDOWN                220
#define IDS_CONNECTCLOSING              221
#define IDS_CONNECTCLOSED               222
#define IDS_ERRLINEDEALLOC              223
#define IDS_ERRLINEREPLY                224
#define IDS_OKLINEREPLY                 225
#define IDS_UNKNOWIDDEVICE              226
#define IDS_DIALTONE                    227
#define IDS_DIALING                     228
#define IDS_PROCEEDING                  229
#define IDS_RINGBACK                    230
#define IDS_LINEBUSY                    231
#define IDS_LINEIDLE                    232
#define IDS_LINECONNECTED               233
#define IDS_TAPINOINIT                  234
#define IDS_NOCONNECT                   235
#define IDS_ERROUTDEVICE                236
#define IDS_DISCONNECTNORMAL            237
#define IDS_DISCONNECTUNKNOWN           238
#define IDS_DISCONNECTREJECT            239
#define IDS_DISCONNECTPICKUP            240
#define IDS_DISCONNECTFORWARDED         241
#define IDS_DISCONNECTBUSY              242
#define IDS_DISCONNECTNOANSWER          243
#define IDS_DISCONNECTBADADDRESS        244
#define IDS_DISCONNECTUNREACHABLE       245
#define IDS_DISCONNECTCONGESTION        246
#define IDS_DISCONNECTINCOMPATIBLE      247
#define IDS_DISCONNECTUNAVAIL           248
#define IDS_DISCONNECTNODIALTONE        249
#define IDS_DISCONNECTBADREASON         250
#define IDS_NODOCUMENTLINECALL          251
#define IDS_TIMEOUT                     252
#define IDS_TAPIERRINIT                 253
#define IDS_ERROUTWAVE                  254

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
