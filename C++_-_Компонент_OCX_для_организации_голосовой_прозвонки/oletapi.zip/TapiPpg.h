#if !defined(AFX_TAPIPPG_H__5B40BA79_CC47_11D4_8A39_0050DACF7F4C__INCLUDED_)
#define AFX_TAPIPPG_H__5B40BA79_CC47_11D4_8A39_0050DACF7F4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// TapiPpg.h : Declaration of the CTapiPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CTapiPropPage : See TapiPpg.cpp.cpp for implementation.

class CTapiPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CTapiPropPage)
	DECLARE_OLECREATE_EX(CTapiPropPage)

//// Constructor
public:
	CTapiPropPage();

// Dialog Data
	//{{AFX_DATA(CTapiPropPage)
	enum { IDD = IDD_PROPPAGE_TAPI };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CTapiPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TAPIPPG_H__5B40BA79_CC47_11D4_8A39_0050DACF7F4C__INCLUDED)
