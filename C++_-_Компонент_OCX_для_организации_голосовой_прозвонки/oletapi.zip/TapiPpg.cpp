// TapiPpg.cpp : Implementation of the CTapiPropPage property page class.

#include "stdafx.h"
#include "OleTapi.h"
//#include "TapiPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CTapiPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CTapiPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CTapiPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CTapiPropPage, "OLETAPI.TapiPropPage.1",
	0x5b40ba6b, 0xcc47, 0x11d4, 0x8a, 0x39, 0, 0x50, 0xda, 0xcf, 0x7f, 0x4c)


/////////////////////////////////////////////////////////////////////////////
// CTapiPropPage::CTapiPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CTapiPropPage

BOOL CTapiPropPage::CTapiPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_TAPI_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CTapiPropPage::CTapiPropPage - Constructor

CTapiPropPage::CTapiPropPage() :
	COlePropertyPage(IDD, IDS_TAPI_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CTapiPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT

	SetHelpInfo(_T("Names to appear in the control"), _T("OLETAPI.HLP"), 0);
}


/////////////////////////////////////////////////////////////////////////////
// CTapiPropPage::DoDataExchange - Moves data between page and properties

void CTapiPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CTapiPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CTapiPropPage message handlers
