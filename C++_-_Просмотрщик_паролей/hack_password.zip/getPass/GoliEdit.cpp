// GoliEdit.cpp : implementation file
//

#include "stdafx.h"
#include "getPass.h"
#include "GoliEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// GoliEdit

GoliEdit::GoliEdit()
{
}

GoliEdit::~GoliEdit()
{
}


void GoliEdit::GotYou() 
{
	// this Procedure will be called when the  the user try's to set the password character
	AfxMessageBox("i will not  reveal the password");
}



BEGIN_MESSAGE_MAP(GoliEdit, CEdit)
	//{{AFX_MSG_MAP(GoliEdit)
	ON_MESSAGE( EM_SETPASSWORDCHAR  , GotYou )
	// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GoliEdit message handlers
