//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CaptionButton Test.rc
//
#define IDC_MYICON                      2
#define IDD_CAPTIONBUTTONTEST_DIALOG    102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_CAPTIONBUTTONTEST           107
#define IDI_SMALL                       108
#define IDC_CAPTIONBUTTONTEST           109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP_AM                   129
#define IDB_BITMAP2                     130
#define IDB_SELECTION                   131
#define IDB_BITMAP3                     132
#define IDB_BITMAP4                     133
#define IDB_BITMAP5                     134
#define IDB_BITMAP6                     135
#define IDB_MOUSEOVER                   136
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
