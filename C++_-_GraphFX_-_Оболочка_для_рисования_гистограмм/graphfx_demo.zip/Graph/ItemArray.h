// ItemArray.h: interface for the CItemArray class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITEMARRAY_H__32C31329_2720_44E2_925E_5ECAAF45E2C9__INCLUDED_)
#define AFX_ITEMARRAY_H__32C31329_2720_44E2_925E_5ECAAF45E2C9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Item.h"
#include <afxtempl.h>

class CItemArray  : public CArray<CItem*, CItem*>
{
public:
	CItemArray();
	virtual ~CItemArray();
	CItem*	HitTest(CPoint point);
	void	AddItem(CItem* pItem);
	void	Draw(CDC* pDC);


};

#endif // !defined(AFX_ITEMARRAY_H__32C31329_2720_44E2_925E_5ECAAF45E2C9__INCLUDED_)
