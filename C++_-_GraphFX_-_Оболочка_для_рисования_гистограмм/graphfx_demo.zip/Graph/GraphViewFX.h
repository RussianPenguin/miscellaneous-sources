////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// Developed by Norm Almond
//
// The software is free to use anywhere...
//
// Please see www.codeproject.com for updates...
//

// GraphViewFX.h : interface of the CGraphViewFX class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GraphViewFX_H__55091326_C58D_11D2_8C5D_00600877E420__INCLUDED_)
#define AFX_GraphViewFX_H__55091326_C58D_11D2_8C5D_00600877E420__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ItemArray.h"
#include "Screen.h"

// Constant for drawing positions
const int BarSize = 22;		// Bar Size (Thickness)
const int LeftMargin = 118;		// Margin
const int TopLine = 40;
const int GraphWidth = 80;
const int RightMargin = 20;


class CGraphViewFX : public CView , public CScreen
{
protected: // create from serialization only
	CGraphViewFX();
	DECLARE_DYNCREATE(CGraphViewFX)

public:
	//{{AFX_DATA(CGraphViewFX)
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

	CItemArray*		GetList();
	CItemArray		m_ItemList;
protected:	
	
	CFont			m_fontSmall;
	CFont			m_font;
	CFont			m_fontSelect;
public:
	
	CFont*			GetSmallFont() { return &m_fontSmall; }
	CFont*			GetBoldFont() { return &m_fontSelect; }
	CFont*			GetFont() { return &m_font; }

	void SetSelected(CItem* pItem) { m_pSelectedItem = pItem; }
	void SetScrollPos(int nPos);

	int GetScrollPos();
	UINT GetItemsPerPage();

protected:
	CToolTipCtrl		m_ToolTip;
	CItem*				m_pItem;
	CItem*				m_pSelectedItem;	
	CScrollBar			m_wndScrollBar;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGraphViewFX)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnDraw(CDC* pDC);
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGraphViewFX();
protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGraphViewFX)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	BOOL OnToolTipNeedText(UINT id, NMHDR * pNMHDR, LRESULT * pResult);
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GraphViewFX_H__55091326_C58D_11D2_8C5D_00600877E420__INCLUDED_)
