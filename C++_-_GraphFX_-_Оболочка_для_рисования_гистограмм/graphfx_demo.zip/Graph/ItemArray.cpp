// ItemArray.cpp: implementation of the CItemArray class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Graph.h"
#include "ItemArray.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CItemArray::CItemArray()
{

}

CItemArray::~CItemArray()
{
	for (int nPos = 0;nPos < GetSize(); nPos++)
	{
		CItem* pItem = GetAt(nPos);

		ASSERT(pItem);
		delete pItem;
	}
}


CItem* CItemArray::HitTest(CPoint point)
{
	CItem* pItem;	
	
	for (int nPos = 0;nPos < GetSize(); nPos++)
	{
		pItem = GetAt(nPos);
		
		ASSERT(pItem);

		if (pItem->GetBoundingRect().PtInRect(point))
			return pItem;
	}

	return NULL;
}

void CItemArray::AddItem(CItem* pItem)
{
	int nCnt = GetSize();

	Add(pItem);
	pItem->SetOrdinal(nCnt);
}

void CItemArray::Draw(CDC* pDC)
{

	CItem* pItem;
	int nSize = GetSize();
	for (int nPos = 0;nPos < nSize;nPos++)
	{
		pItem = GetAt(nPos);
		
		ASSERT(pItem);

		pItem->Draw(pDC);
	}
}



