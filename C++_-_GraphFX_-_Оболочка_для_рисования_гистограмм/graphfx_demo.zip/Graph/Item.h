// Item.h: interface for the CItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITEM_H__CF77B5F8_1BDD_4F49_AC3C_E24E25726B21__INCLUDED_)
#define AFX_ITEM_H__CF77B5F8_1BDD_4F49_AC3C_E24E25726B21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define MAX_POINTS	500

class CGraphViewFX;


class CItem  
{
public:
	CItem();
	CItem(CWnd* pWnd);
	virtual ~CItem();

	virtual	void Select();
	virtual	void Unselect();
	virtual	CString	GetTipText();
	virtual	CRect GetBoundingRect();
	virtual	void Invalidate();
	virtual	BOOL GetLogicalPos();
	void SetOrdinal(int nPos);
	virtual	void Draw(CDC* pDC);
	virtual	void DrawBar(CDC* pDC);
	virtual	void DrawGraph(CDC* pDC);
	virtual	UINT GetPercentage();
	virtual	void SetPercentage(UINT nPercentage);
	virtual void SetItemText(const CString& strItem);

protected:
	bool	m_bSelect;
	CRect	m_rcBounds;
	CRect	m_rcBar;
	CRect	m_rcGraph;
	CRect	m_rcText;
	int		m_nOrdinal;
	UINT	m_nPercentage;
	UINT	m_nHiWaterMark;

	int	m_lStats[MAX_POINTS];

	
	CString	m_strName;

	CGraphViewFX*		m_pWnd;

};

#endif // !defined(AFX_ITEM_H__CF77B5F8_1BDD_4F49_AC3C_E24E25726B21__INCLUDED_)
