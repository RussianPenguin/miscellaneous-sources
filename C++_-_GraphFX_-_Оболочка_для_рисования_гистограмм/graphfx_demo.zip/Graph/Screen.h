#ifndef	__Screen_h__
#define	__Screen_h__

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// Developed by Norm Almond
//
// The software is free to use anywhere...
//
// Please see www.codeproject.com for updates...
//

#include "Item.h"

class CItemList;

// Wrapper for the Screen
class CScreen
{
public:
	CScreen();
	
	~CScreen();
	virtual void Draw(CRect rc, CDC* pDC, CItemArray* pItemArray, int nItemsPerPage);
	virtual void LoadColors();

protected:
	void DrawBackground(CRect& rc, int nItemsPerPage);
	COLORREF			m_crTextColor;
	COLORREF			m_crBkColor;
	COLORREF			m_crGridColor;

	CDC					m_dcBack;
	BOOL				m_bGrid;
	CSize				m_szView;
	CBitmap				m_bmBack;
};

#endif