////////////////////////////////////////////////////////////////////////////////
// Developed by Norm Almond
//
// The software is free to use anywhere...
//
// Please see www.codeproject.com for updates...
//
////////////////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "GraphViewFX.h"
#include "Screen.h"


////////////////////////////////////////////////////////////////////////////////
//
// Function:	CScreen::CScreen
//
// Description:	Default contructor
//
////////////////////////////////////////////////////////////////////////////////

CScreen::CScreen()
{
	m_dcBack.CreateCompatibleDC(NULL);

	m_szView = CSize(0,0);
	m_bGrid = TRUE;

	LoadColors();
}

void CScreen::LoadColors()
{
	m_crTextColor = RGB(255,255,255);
	m_crGridColor = RGB(128,128,128);
	m_crBkColor =   RGB(0,0,0);
}


CScreen::~CScreen()
{
}

void CScreen::Draw(CRect rc, CDC* pDC, CItemArray* pItemArray, int nItemsPerPage)
{
	// Fix up the Memory DC
	
	if (rc.Width() != m_szView.cx || rc.Height() != m_szView.cy)
	{
		m_szView.cx = rc.Width();
		m_szView.cy = rc.Height();
		m_bmBack.DeleteObject();

		m_bmBack.CreateCompatibleBitmap(pDC,m_szView.cx,m_szView.cy);
		m_dcBack.SelectObject(&m_bmBack);		
	}
	
	// Draw Background
	DrawBackground(rc, nItemsPerPage);

	// Draw Items...
	pItemArray->Draw(&m_dcBack);

	// Draw back buffer into current DC
	pDC->BitBlt(0,0,rc.Width(),rc.Height(),&m_dcBack,0,0,SRCCOPY);
}


void CScreen::DrawBackground(CRect& rc, int nItemsPerPage)
{
	
	CBrush bkColor(m_crBkColor);

	m_dcBack.FillRect(CRect(0,0,m_szView.cx,m_szView.cy),&bkColor);

	CRect textRect;

	CFont* pFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	CFont* pOldFont = m_dcBack.SelectObject(pFont);

	m_dcBack.SetTextColor( RGB (255,255,255) );
	m_dcBack.SetBkMode(TRANSPARENT);	

	if (m_bGrid)
	{
		CRect rcGrid(rc);
		rcGrid.left += LeftMargin;
		rcGrid.right -= RightMargin;
		
		int nRightMarg = rcGrid.right;
		
		rcGrid.right -= GraphWidth;


		m_dcBack.SetTextColor(m_crGridColor);
		CPen pen(PS_SOLID,1,m_crGridColor);

		CPen* pOldPen = m_dcBack.SelectObject(&pen);
		
		UINT nStep = 0;

		int nX = 0;
		
		CString strNum;

		int nY = (nItemsPerPage * BarSize) + TopLine;

		// Draw Vertical Lines
		for (int i=0; i < 21;i++)
		{
			double dInc = (double) (rcGrid.Width() * nStep) / 100.0;
			
			nX = (int)((double)(LeftMargin- 2) + dInc);
			m_dcBack.MoveTo(nX,TopLine);
			m_dcBack.LineTo(nX,nY);

			if (!(i % 2))
			{
				strNum.Format(_T("%d%%"),i*5);
				
				CRect dr((int)((double)LeftMargin+dInc),TopLine-20,(int)((double) LeftMargin+dInc),TopLine);

				dr.InflateRect(12,0);

				m_dcBack.DrawText(strNum,dr,DT_SINGLELINE|DT_VCENTER|DT_CENTER);
			}

			nStep += 5;
		}

		 
		m_dcBack.MoveTo(nRightMarg,TopLine);
		m_dcBack.LineTo(nRightMarg,nY);

		// Horizontal Lines
		for (int r=0; r < nItemsPerPage+1;r++)
		{
			int nY = TopLine + (((r+1) * BarSize) - BarSize);
			m_dcBack.MoveTo(LeftMargin-2,nY);
			m_dcBack.LineTo(nRightMarg,nY);
		}

		CFont nfont,bfont;
		LOGFONT lf;
		::GetObject((HFONT)GetStockObject(DEFAULT_GUI_FONT),sizeof(lf),&lf);

		lf.lfHeight = -12;
		nfont.CreateFontIndirect(&lf);

		lf.lfWeight = FW_BOLD;
		bfont.CreateFontIndirect(&lf);

		m_dcBack.SelectObject(pOldPen);

	}	
	m_dcBack.SelectObject(pOldFont);
}

