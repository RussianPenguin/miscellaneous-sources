// FileWatch.h: interface for the CFileWatch class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEWATCH_H__104CC652_50A5_4354_8415_920044C93FD7__INCLUDED_)
#define AFX_FILEWATCH_H__104CC652_50A5_4354_8415_920044C93FD7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct FILEWATCHITEM {
	CString		sFileName;
	__int64		ftLastWriteTime;
	HWND		hWnd;
	CDocument	*pDocument;
	DWORD		dwData;
	bool		bIsFolder;
};

class CFileWatch
{
public:
	static void Start();
	static void Stop();
	static UINT Watch(LPVOID lpParam);

	static DWORD AddFileFolder(LPCTSTR lpszFileName, HWND hWnd, CDocument* pDocument, DWORD dwData);
	static void ResetDate(DWORD dwHandle);
	static void RemoveHandle(DWORD dwHandle);

protected:
	static CMap<DWORD,DWORD&,FILEWATCHITEM,FILEWATCHITEM&>	m_FileMap;
	static CList<CString,CString&>							m_FolderList;
	static CList<HANDLE,HANDLE&>							m_NotifyList;
	static CEvent	m_ClassEvent;
	static DWORD	m_dwNextHandle;
	static bool		m_bWatchClosed;
	static bool		m_bStopWatch;
};

#endif // !defined(AFX_FILEWATCH_H__104CC652_50A5_4354_8415_920044C93FD7__INCLUDED_)
