// TestThreadDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestThread.h"
#include "TestThreadDlg.h"
#include "LoopClass.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TIMER_STOP_DELAY	1
#define TIMER_START_DELAY	2

UINT stopTimer = 0;
UINT startTimer = 0;

UINT WorkerThread(LPVOID pParam);

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestThreadDlg dialog

CTestThreadDlg::CTestThreadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestThreadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestThreadDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestThreadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestThreadDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestThreadDlg, CDialog)
	//{{AFX_MSG_MAP(CTestThreadDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_STOP, OnBtnStop)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestThreadDlg message handlers

BOOL CTestThreadDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	EnableStopButton(false);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestThreadDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestThreadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestThreadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestThreadDlg::OnBtnStart() 
{
	// Starting the first loop by declaring a variable of the
	// class CLoopClass, passing a pointer to the dialog to
	// the classes constructor...This loop will lock up the
	// dialog until it finishes

	DisplayMessage("Starting Loop directly from Class (Loop1 via OnBtnStart)");
	CLoopClass lpcls((CTestThreadDlg*)this);
	lpcls.Loop(10, 100, 100);

	// Here is where we start the new worker thread
	// this is passed using the void pointer pParam
	// from here on the new thread will do the work
	// and the dialog will be free to move about.

	CWinThread* pWThread = AfxBeginThread(WorkerThread, this);
	
}

/*
	The global thread controller function.
	To begin the new worker thread, use

	CWinThread* pWkrThread = AfxBeginThread(WorkerThread, this);
	see the OnBtnStart() function above

*/
UINT WorkerThread(LPVOID pParam)
{
	// Cast void pointer pParam to a CTestThreadDlg pointer passed
	// by the calling function

	CTestThreadDlg* pDlg = (CTestThreadDlg*)pParam;

	pDlg->DisplayMessage("Entering Worker Loop (Loop2)");
	// Enter the first loop of the worker thread
	for(int x = 0; x < 11; x++)
	{
		long cntr1 = 0;
		CString num1;
		num1.Format("%d", x);
		pDlg->SetDlgItemText(IDC_TXT1, num1);
		while(cntr1 < 100)
		{
			long cntr2 = 0;
			CString num2;
			num2.Format("%d", cntr1);
			pDlg->SetDlgItemText(IDC_TXT2, num2);
			while(cntr2 < 100)
			{
				CString num3;
				num3.Format("%d", cntr2);
				pDlg->SetDlgItemText(IDC_TXT3, num3);
				cntr2++;
			}
			cntr1++;
		}
	}
	pDlg->DisplayMessage("Entering Loop Class from Worker Thread (Loop3)");
	// Declare a variable of the CLoopClass class and call
	// the function loop...the second loop of the worker thread

	CLoopClass lpcls(pDlg);
	lpcls.Loop(12, 150, 200);
	// This is just here because I wanted to play with a timer
	// This timer waits 4 seconds then enables the Stop button
	stopTimer = pDlg->SetTimer(TIMER_STOP_DELAY, 4000, 0);


	return 0;
}

void CTestThreadDlg::OnBtnStop() 
{
	EnableStopButton(false);
	SetLabelsToZero();
}

void CTestThreadDlg::OnTimer(UINT nIDEvent) 
{
	
	if(nIDEvent == TIMER_STOP_DELAY)
	{
		KillTimer(stopTimer);
		EnableStopButton();
	}

	CDialog::OnTimer(nIDEvent);
}

void CTestThreadDlg::EnableStopButton(bool enbl /* = true */)
{
	CButton* pBtn = (CButton*)GetDlgItem(IDC_BTN_STOP);
	pBtn->EnableWindow(enbl);

}


void CTestThreadDlg::SetLabelsToZero()
{
	SetDlgItemText(IDC_TXT1, "0");
	SetDlgItemText(IDC_TXT2, "0");
	SetDlgItemText(IDC_TXT3, "0");
	SetDlgItemText(IDC_MESSG, "");

}

CDialog* CTestThreadDlg::GetDlgPointer()
{
	return (CTestThreadDlg*)this;
}

void CTestThreadDlg::DisplayMessage(LPCTSTR mesg)
{
	SetDlgItemText(IDC_MESSG, mesg);
}

