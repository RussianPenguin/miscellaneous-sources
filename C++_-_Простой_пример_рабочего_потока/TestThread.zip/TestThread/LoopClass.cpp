// LoopClass.cpp: implementation of the CLoopClass class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestThread.h"
#include "TestThreadDlg.h"
#include "LoopClass.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLoopClass::CLoopClass()
{

}

CLoopClass::CLoopClass(CDialog* pDlg)
{
	m_pDlg = pDlg;
}

CLoopClass::~CLoopClass()
{

}

void CLoopClass::Loop(long lp1, long lp2, long lp3)
{
	for(int x = 0; x < lp1; x++)
	{
		long cntr1 = 0;
		CString num1;
		num1.Format("%d", x);
		m_pDlg->SetDlgItemText(IDC_TXT1, num1);
		while(cntr1 < lp2)
		{
			long cntr2 = 0;
			CString num2;
			num2.Format("%d", cntr1);
			m_pDlg->SetDlgItemText(IDC_TXT2, num2);
			while(cntr2 < lp3)
			{
				CString num3;
				num3.Format("%d", cntr2);
				m_pDlg->SetDlgItemText(IDC_TXT3, num3);
				cntr2++;
			}
			cntr1++;
		}
	}
}
