// LoopClass.h: interface for the CLoopClass class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOOPCLASS_H__772B4B84_4031_11D5_B7B6_00606708AEF5__INCLUDED_)
#define AFX_LOOPCLASS_H__772B4B84_4031_11D5_B7B6_00606708AEF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLoopClass  
{
public:
	CDialog* m_pDlg;
	void Loop(long lp1, long lp2, long lp3);
	CLoopClass();
	CLoopClass(CDialog* pDlg);
	virtual ~CLoopClass();

};

#endif // !defined(AFX_LOOPCLASS_H__772B4B84_4031_11D5_B7B6_00606708AEF5__INCLUDED_)
