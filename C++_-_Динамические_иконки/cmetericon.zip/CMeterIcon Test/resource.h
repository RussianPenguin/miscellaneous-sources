//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MeterIcon.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG_MAIN                 101
#define IDI_ICON_FRAME32                102
#define IDI_ICON_FRAME                  102
#define IDC_STATIC_32                   1000
#define IDC_BUTTON_REDRAW               1002
#define IDC_EDIT_SPACING                1003
#define IDC_EDIT_VAL1                   1004
#define IDC_EDIT_VAL2                   1005
#define IDC_EDIT_VAL3                   1006
#define IDC_EDIT_MAXVAL                 1009
#define IDC_BUTTON_ANIMATE              1010
#define IDC_EDIT_ABOUT                  1011
#define IDC_STATIC_16                   1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
