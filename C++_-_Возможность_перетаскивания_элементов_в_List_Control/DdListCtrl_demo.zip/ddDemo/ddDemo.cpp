// ddDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ddDemo.h"
#include "ddDemoDlg.h"
#include "SelectInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDdDemoApp

BEGIN_MESSAGE_MAP(CDdDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CDdDemoApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDdDemoApp construction

CDdDemoApp::CDdDemoApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDdDemoApp object

CDdDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDdDemoApp initialization

BOOL CDdDemoApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	//-------------------------
	// Initialize OLE libraries
	//-------------------------
	if (!AfxOleInit())
		return FALSE;

	CSelectInfo selectInfo;
	selectInfo.m_asNames.SetAtGrow(0, "AAAAAAAAAAA");
	selectInfo.m_asNames.SetAtGrow(1, "BBBBBBBBBBB");
	selectInfo.m_asNames.SetAtGrow(2, "CCCCCCCCCCC");
	selectInfo.m_asNames.SetAtGrow(3, "DDDDDDDDDDD");
	selectInfo.m_asNames.SetAtGrow(4, "EEEEEEEEEEE");
	selectInfo.m_asNames.SetAtGrow(5, "FFFFFFFFFFF");
	selectInfo.m_asNames.SetAtGrow(6, "GGGGGGGGGGG");
	selectInfo.m_asNames.SetAtGrow(7, "HHHHHHHHHHH");
	selectInfo.m_asNames.SetAtGrow(8, "IIIIIIIIIII");
	selectInfo.m_asNames.SetAtGrow(9, "JJJJJJJJJJJ");
	selectInfo.m_asNames.SetAtGrow(10, "KKKKKKKKKKK");
	selectInfo.m_asNames.SetAtGrow(11, "LLLLLLLLLLL");
	selectInfo.m_asNames.SetAtGrow(12, "MMMMMMMMMMM");
	selectInfo.m_asNames.SetAtGrow(13, "NNNNNNNNNNN");
	selectInfo.m_asNames.SetAtGrow(14, "OOOOOOOOOOO");
	CDdDemoDlg dlg(&selectInfo);
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
