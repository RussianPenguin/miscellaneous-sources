// ddDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ddDemo.h"
#include "DDListCtrl.h"
#include "ddDemoDlg.h"
#include "SelectInfo.h"
#include "ListSelectData.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDdDemoDlg dialog

CDdDemoDlg::CDdDemoDlg(CSelectInfo *pSelectInfo, CWnd* pParent /*=NULL*/)
	: CDialog(CDdDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDdDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	ASSERT_POINTER(pSelectInfo, CSelectInfo);
    m_pSelectInfo     = pSelectInfo; 

	m_pData     = new CListSelectData(&m_pSelectInfo->m_asNames);



    
	//{{AFX_DATA_INIT(CPivotTableDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDdDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDdDemoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDdDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CDdDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDdDemoDlg message handlers

BOOL CDdDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	

	//----------------------------
	// Subclass the list controls
	//----------------------------
	m_listVars.SubclassDlgItem(IDC_LIST_VAR, this);
	m_listRows.SubclassDlgItem(IDC_LIST_ROWS, this);
	m_listCols.SubclassDlgItem(IDC_LIST_COLS, this);
	m_listData.SubclassDlgItem(IDC_LIST_DATA, this);
	m_listPages.SubclassDlgItem(IDC_LIST_PAGES, this);

    //----------------------------------------------------------
	// Create one column for the "List of var" List view control
	//----------------------------------------------------------
	CString s(TCHAR('M'),29);
	int len = m_listVars.GetStringWidth(s)+15;
	LV_COLUMN lvC;
	lvC.mask = LVCF_FMT | LVCF_WIDTH;
	lvC.fmt  = LVCFMT_LEFT;  // Left-align column
	lvC.cx   = len;          // Width of column in pixels
	if (m_listVars.InsertColumn(0,&lvC) == -1)
		return FALSE;
	m_listVars.DeleteAllItems();

	m_listVars.SetLocalDD(FALSE);   // Disable local Drag&Drop
	m_listVars.SetScrolling(FALSE); // and auto scrolling


	// Create a column for the row variables list view control. 
    if (m_listRows.InsertColumn(0,&lvC) == -1)
		return FALSE;
	m_listRows.DeleteAllItems();

	// Create a column for the column variables list view control. 
    if (m_listCols.InsertColumn(0,&lvC) == -1)
		return FALSE;
	m_listCols.DeleteAllItems();

	// Create a column for the data variables list view control.
    if (m_listData.InsertColumn(0,&lvC) == -1)
		return FALSE;
	m_listData.DeleteAllItems();

	// Create a column for the page variables view control.
    if (m_listPages.InsertColumn(0,&lvC) == -1)
		return FALSE;
	m_listPages.DeleteAllItems();

	//------------------------------------------
	// Set the content of the list view controls
	//------------------------------------------
	CWordArray aVars;
	int size = m_pSelectInfo->m_asNames.GetSize();
	aVars.SetSize(size);
	// Initially the list of available variables contains all variables
	for (int i=0; i<size; i++)
		aVars[i] = i;
   
	// Fill the list of variables
	m_pData->FillListCtrl(m_listVars, aVars);
	m_pData->FillListCtrl(m_listRows, m_pSelectInfo->m_aRowsVar); 
	m_pData->FillListCtrl(m_listCols, m_pSelectInfo->m_aColsVar);  
	m_pData->FillListCtrl(m_listData, m_pSelectInfo->m_aDataVar); 
	m_pData->FillListCtrl(m_listPages, m_pSelectInfo->m_aPagesVar); 


	// Initialize the list controls for Drag&Drop
	m_listVars.Initialize();
	m_listRows.Initialize();
	m_listCols.Initialize();
	m_listData.Initialize();
	m_listPages.Initialize();

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDdDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDdDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDdDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


BOOL CDdDemoDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	delete m_pData;
	
	return CDialog::DestroyWindow();
}
