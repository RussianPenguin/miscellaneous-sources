//////////////////////////////////////////////////////////////////////
// SelectInfo.cpp: implementation of the CSelectInfo class.
//                 A dummy class for demo  


#include "stdafx.h"
#include "ddDemo.h"
#include "SelectInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSelectInfo::CSelectInfo()
{

}

CSelectInfo::~CSelectInfo()
{

}
