// ddDemoDlg.h : header file
//

#if !defined(AFX_DDDEMODLG_H__F68B2E1C_A10D_11D4_8C0D_0050043EB83D__INCLUDED_)
#define AFX_DDDEMODLG_H__F68B2E1C_A10D_11D4_8C0D_0050043EB83D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDdDemoDlg dialog

#include "DDListCtrl.h"

class CSelectInfo;
class CListSelectData;

class CDdDemoDlg : public CDialog
{
// Construction
public:
	CDdDemoDlg(CSelectInfo *pSelectInfo, CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDdDemoDlg)
	enum { IDD = IDD_DDDEMO_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDdDemoDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

	CListSelectData* m_pData;
	CSelectInfo* m_pSelectInfo;     

	CDDListCtrl m_listVars;

	CDDListCtrl m_listRows;
	CDDListCtrl m_listCols;
	CDDListCtrl m_listData;
	CDDListCtrl m_listPages;

protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDdDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DDDEMODLG_H__F68B2E1C_A10D_11D4_8C0D_0050043EB83D__INCLUDED_)
