//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CxSkinButtonDemo.rc
//
#define IDD_CXSKINBUTTONDEMO_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDB_B3NORM                      130
#define IDB_B3OVER                      131
#define IDI_ICON1                       132
#define IDB_B1DOWN                      147
#define IDB_B1GRAY                      148
#define IDB_B1MASK                      149
#define IDB_B1NORM                      150
#define IDB_B2NORM                      151
#define IDB_B2MASK                      152
#define IDB_B2DOWN                      153
#define IDB_B1OVER                      154
#define IDB_RGRAY                       158
#define IDB_ROVER                       159
#define IDB_RNORM                       160
#define IDB_LMASK                       161
#define IDB_LOVER                       162
#define IDB_RDOWN                       163
#define IDB_RMASK                       164
#define IDB_LGRAY                       165
#define IDB_LNORM                       166
#define IDB_LDOWN                       167
#define IDB_B2DOWN1                     168
#define IDC_STX1                        1000
#define IDC_BUTTON1                     1001
#define IDC_NORMAL_BUTTON               1001
#define IDC_BUTTON4                     1006
#define IDC_BUTTON6                     1007
#define IDC_BUTTON7                     1008
#define IDC_BUTTON5                     1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
