//---------------------------------------------------------------------------
#include <vcl.h>

#pragma hdrstop

#include "Timer.h"
#include <penwin.h>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "Placemnt"
#pragma resource "*.dfm"
TTimerForm *TimerForm;
//---------------------------------------------------------------------------
__fastcall TTimerForm::TTimerForm(TComponent* Owner)
        : TForm(Owner)
{
 Wheel=0;
 WheelTimes=1;
 TimerTL->Enabled = false;
 EncodeTime(0,0,1,0);
 DatePicker->Date = Now();
 TimePickerRT->Time = Now()+EncodeTime(1,0,0,0);
 SpeedButtonRTClick(SpeedButtonRC);
 MinTime = EncodeTime(0,0,TimerTL->Interval/1000,0);
 NowTimer->Enabled = true;
 CurrTimeLabel->Caption = FormatDateTime("hh:nn:ss", Now());
 CheckBoxOldAppClick(CheckBoxOldApp);
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::SpeedButtonRTClick(TObject *Sender)
{
 bool a=false;
 if (((TSpeedButton *)Sender)->Name == "SpeedButtonRT")
   a=!a;
 GroupBoxRT->Enabled = a;
 DatePicker->Enabled = a;
 TimePickerRT->Enabled = a;
 Label1->Enabled = a;
 Label2->Enabled = a;
 GroupBoxRC->Enabled = !a;
 TimePickerRC->Enabled = !a;
 Label3->Enabled = !a;
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::ButtonCancelClick(TObject *Sender)
{
 if (!ButtonStart->Enabled)
   Caption = "Timer canceled.";
 else
   Caption = "OFF Timer";
 TimerTL->Enabled = false;
 NowTimer->Enabled = true;
 ButtonStart->Enabled = true;
 TLText->Font->Color = clWindowText;
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::ButtonStartClick(TObject *Sender)
{
 TimerTL->Enabled =false;
 if (SpeedButtonRC->Down)
  {
   TimePickerRC->Date = TDateTime(1);
   TimeLeft = TimePickerRC->Time - TDateTime(1) + MinTime;
  }
 if (SpeedButtonRT->Down)
  {
   TimePickerRT->Date = Now();
   if (DatePicker->Checked)
     TimePickerRT->Date = DatePicker->Date;
   TimeLeft = TimePickerRT->Time - Now() + MinTime;
  }
 if (TimeLeft<=MinTime)
  {
   MessageBeep(0xFFFFFFFF);
   return;
  }
 Caption = "Timer Started ..."; 
 ButtonStart->Enabled = false;
 ButtonCancel->Enabled = true;
 TLText->Font->Color = clBlue;
 TimerTLTimer(TimerTL);
 TimerTL->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::TimerTLTimer(TObject *Sender)
{
 NowTimer->Enabled = false;
 CurrTimeLabel->Caption = FormatDateTime("hh:nn:ss", Now());

 TimeLeft = TimeLeft - MinTime;
 DaysLeft = int(TimeLeft);

 if (DaysLeft>0)
   TLText->Caption = IntToStr(DaysLeft)+" days,  " + TimeToStr(TimeLeft);
 else
   TLText->Caption = TimeToStr(TimeLeft);

 if (TimeLeft <= MinTime)
  {
   TLText->Font->Color = clRed;
   TimerTL->Enabled = false;
   ButtonCancel->Enabled = false;
   ButtonStart->Enabled = true;
   Caption = RadioGroupAction->Items->Strings[RadioGroupAction->ItemIndex];

   if ((CheckBoxOldApp->Checked)&&(AppEdit->Text != ""))
     CloseOldApps(AppEdit->Text);

   if (RadioGroupAction->ItemIndex==0)
     ExitWindowsEx(EWX_SHUTDOWN, 0);
   if (RadioGroupAction->ItemIndex==1)
     ExitWindowsEx(EWX_REBOOT, 0);
   if (RadioGroupAction->ItemIndex==2)
     ExitWindowsEx(EWX_LOGOFF, 0);
  }
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::CloseOldApps(AnsiString AppName_)
{
 if ((CheckBoxOldApp->Checked)&&(AppEdit->Text != ""))
  {
   HWND hWnd=FindWindowByTitle(AppEdit->Text);
   if (hWnd)
    {
     GroupBoxTL->Caption = "Window Finded";
     ShowWindow(hWnd,SW_SHOWNORMAL);
     SetForegroundWindow(hWnd);
     //��������� �������
     SHORT k=VK_ESCAPE;
     //VkKeyScan(Key); //������� �� ������� � VirtualKeyCode
     keybd_event(k, MapVirtualKey(k, 0), 0, 0);
    }
   else
     GroupBoxTL->Caption = "No Window Finded";
  }
}
//---------------------------------------------------------------------------
HWND __fastcall TTimerForm::FindWindowByTitle(AnsiString strWindowTitle)
{
  HWND handleWnd;
  char szWinTitle[200];

  handleWnd = GetTopWindow(0);
  while (handleWnd != 0)
   {
    if (GetWindowText(handleWnd, szWinTitle, sizeof(szWinTitle)) != 0)
      if (AnsiPos(strWindowTitle.LowerCase(), String(szWinTitle).LowerCase()) >0)
        return handleWnd;
    handleWnd = GetNextWindow(handleWnd, GW_HWNDNEXT);
   }
 return NULL;
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::TimePickerRTChange(TObject *Sender)
{
 if (((TDateTimePicker *)Sender)->Time < Now())
   ((TDateTimePicker *)Sender)->Time = Now();
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::DatePickerChange(TObject *Sender)
{
 if (((TDateTimePicker *)Sender)->Date < Now())
  {
   ((TDateTimePicker *)Sender)->Date = Now();
   MessageBeep(0xFFFFFFFF);
  }
 TimePickerRT->Date = DatePicker->Date;
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::FormMouseWheel(TObject *Sender,
      TShiftState Shift, int WheelDelta, TPoint &MousePos, bool &Handled)
{
 if (WheelTimes>=3)
  {
   TPoint MP  = ScreenToClient(MousePos);
     Delta = EncodeTime(0,0,1,0);
   if (Shift.Contains(ssMiddle))
     Delta = EncodeTime(0,0,10,0);
   if (Shift.Contains(ssAlt))
     Delta = EncodeTime(0,1,0,0);
   if (Shift.Contains(ssCtrl))
     Delta = EncodeTime(1,0,0,0);

   CorrectDTP(MP, WheelDelta, TimePickerRC, Delta, GroupBoxRC);
   CorrectDTP(MP, WheelDelta, TimePickerRT, Delta, GroupBoxRT);
   Delta = 1;
   CorrectDTP(MP, WheelDelta, DatePicker, Delta, GroupBoxRT);
   WheelTimes=1;
  }
 WheelTimes++;
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::CorrectDTP(TPoint MP, int WheelDelta, TDateTimePicker *DTP, TDateTime Delta, TGroupBox *GB)
{
 if ((MP.x>=DTP->Left+GB->Left)&&
     (MP.x<=DTP->Left+DTP->Width+GB->Left)&&
     (MP.y>=DTP->Top+GB->Top)&&
     (MP.y<=DTP->Top+DTP->Height+GB->Top))
  {
   if ((DTP->Tag==1)&&(DTP->Checked))
    {
     if (WheelDelta<0)
       DTP->Date = DTP->Date + Delta;
     else
       DTP->Date = DTP->Date - Delta;
     DTP->OnChange(DTP);
    }
   else
    {
     if (WheelDelta<0)
       DTP->Time = DTP->Time + Delta;
     else
       DTP->Time = DTP->Time - Delta;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::SpeedButton1Click(TObject *Sender)
{
 TimePickerRC->Time = EncodeTime(0,0,0,0);
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::SpeedButton2Click(TObject *Sender)
{
 DatePicker->Date = Now();
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::SpeedButton3Click(TObject *Sender)
{
 TimePickerRT->Time = Now();
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::SpeedButton4MouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
 SpeedButton4->Caption = "Written By CyberCat";
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::FormMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
 SpeedButton4->Caption = "";
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::ButtonCloseClick(TObject *Sender)
{
 Close();
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::SpeedButton4Click(TObject *Sender)
{
 AnsiString str = "Written By CyberCat  [30.10.2000]\n\n";
 str = str + "Note:  use mouse wheel for changing time and date\n";
 str = str + "       Wheel:\t\t seconds or days\n";
 str = str + "       Wheel+WheelPress:\t decimal seconds\n";
 str = str + "       Wheel+Alt:\t\t minutes \n";
 str = str + "       Wheel+Shift/Ctrl:\t hours";
 str = str + "\n\n   FREEWARE";
 MessageDlg(str, mtInformation, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::NowTimerTimer(TObject *Sender)
{
 if (!TimerTL->Enabled)
   CurrTimeLabel->Caption = FormatDateTime("hh:nn:ss", Now());
}
//---------------------------------------------------------------------------

void __fastcall TTimerForm::FormResize(TObject *Sender)
{
 GroupBoxTL->Width          = ClientWidth - GroupBoxTL->Left;
 GroupBoxCurrTime->Width    = ClientWidth - GroupBoxCurrTime->Left;

 ClientHeight = GroupBoxCurrTime->Top + GroupBoxCurrTime->Height;
}
//---------------------------------------------------------------------------
void __fastcall TTimerForm::CheckBoxOldAppClick(TObject *Sender)
{
 AppEdit->Enabled = CheckBoxOldApp->Checked;
}
//---------------------------------------------------------------------------



