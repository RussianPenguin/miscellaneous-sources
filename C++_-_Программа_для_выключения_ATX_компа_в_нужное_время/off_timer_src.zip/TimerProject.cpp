//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("TimerProject.res");
USEFORM("Timer.cpp", TimerForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->Title = "OFF Timer";
                 Application->CreateForm(__classid(TTimerForm), &TimerForm);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
