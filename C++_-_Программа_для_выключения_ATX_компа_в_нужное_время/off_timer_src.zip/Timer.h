//---------------------------------------------------------------------------
#ifndef TimerH
#define TimerH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include "Placemnt.hpp"
//---------------------------------------------------------------------------
class TTimerForm : public TForm
{
__published:	// IDE-managed Components
        TSpeedButton *SpeedButtonRT;
        TSpeedButton *SpeedButtonRC;
        TGroupBox *GroupBoxRT;
        TGroupBox *GroupBoxRC;
        TButton *ButtonStart;
        TButton *ButtonCancel;
        TRadioGroup *RadioGroupAction;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TDateTimePicker *DatePicker;
        TDateTimePicker *TimePickerRT;
        TDateTimePicker *TimePickerRC;
        TTimer *TimerTL;
        TGroupBox *GroupBoxTL;
        TSpeedButton *SpeedButton1;
        TSpeedButton *SpeedButton2;
        TSpeedButton *SpeedButton3;
        TSpeedButton *SpeedButton4;
        TButton *ButtonClose;
        TLabel *TLText;
        TGroupBox *GroupBoxCurrTime;
        TLabel *CurrTimeLabel;
        TTimer *NowTimer;
        TCheckBox *CheckBoxOldApp;
        TEdit *AppEdit;
        TFormStorage *FormStorage1;
        void __fastcall SpeedButtonRTClick(TObject *Sender);
        void __fastcall ButtonCancelClick(TObject *Sender);
        void __fastcall ButtonStartClick(TObject *Sender);
        void __fastcall TimerTLTimer(TObject *Sender);
        void __fastcall TimePickerRTChange(TObject *Sender);
        void __fastcall DatePickerChange(TObject *Sender);
        void __fastcall FormMouseWheel(TObject *Sender, TShiftState Shift,
          int WheelDelta, TPoint &MousePos, bool &Handled);
        void __fastcall SpeedButton1Click(TObject *Sender);
        void __fastcall SpeedButton2Click(TObject *Sender);
        void __fastcall SpeedButton3Click(TObject *Sender);
        void __fastcall SpeedButton4MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall ButtonCloseClick(TObject *Sender);
        void __fastcall SpeedButton4Click(TObject *Sender);
        void __fastcall NowTimerTimer(TObject *Sender);
        void __fastcall FormResize(TObject *Sender);
        void __fastcall CheckBoxOldAppClick(TObject *Sender);
private:	// User declarations
        void __fastcall TTimerForm::CorrectDTP(TPoint MP, int WheelDelta, TDateTimePicker *DTP, TDateTime Delta, TGroupBox *GB);
        TDateTime       TimeLeft;
        TDateTime       MinTime;
        int             DaysLeft;
        int             Wheel;
        int             WheelTimes;
        TDateTime       Delta;

public:		// User declarations
        __fastcall TTimerForm(TComponent* Owner);
   void __fastcall TTimerForm::CloseOldApps(AnsiString AppName);
   HWND __fastcall TTimerForm::FindWindowByTitle(AnsiString strWindowTitle);
};
//---------------------------------------------------------------------------
extern PACKAGE TTimerForm *TimerForm;
//---------------------------------------------------------------------------
#endif
